# SBM Project Status

**Last updated:** 2026-11-18 (MVC + HTMX recovery) — **Phase:** web platform restored and verified — **Build:** ✅ (Release, 0 errors, 0 warnings) — **Unit tests:** 74/74 ✅ — **Integration tests:** 39/39 ✅ (SQL Server LocalDB; 17 API + 22 web) — **Web:** boots and serves 200s ✅

## What is genuinely working today

- Backend builds clean; `dotnet test` = 113 tests green (74 unit + 17 API integration + 22 web integration, LocalDB).
- `SBM.Web` (staff console + customer portal) restored in `backend/src/SBM.Web` — ASP.NET Core MVC + Razor + HTMX, Arabic RTL default with English toggle, port 5221, cookie auth with **two separate audiences** (staff + portal).
- Staff console: dashboard with live metrics + 6-month revenue chart + pending-approvals badge (HTMX polling), Customers, Leads, Catalog, Subscriptions, Licenses, Invoices, Finance journal, Sales full lifecycle (Quotation → Send → Accept → Order → Confirm → Fulfill → Invoice) with SalesEvent audit log and outbox/sync-journal integration, Refunds lifecycle, Approvals queue (HTMX badge), Campaigns, Audience builder with server-side validate/preview (real rule engine), Releases (platform: create/register asset + SHA-256/publish/yank), Resellers (commission calculation + approval), Support, Reports (9 reports × CSV/XLSX/PDF), Audit log, Settings, MFA (TOTP + recovery codes).
- Customer portal (`/portal`): subscriptions (renewal/cancellation requests into the staff approval queue), licenses + device self-deactivation, invoices (real QuestPDF PDFs), support tickets + replies, releases download with per-request server-side eligibility checks.
- Payment recording via the shared `PaymentService` (idempotency), invoice numbering via shared `InvoiceNumberingService`, subscription renewal/cancellation via `ApprovalService` with state-machine guards.
- Tenant isolation everywhere (explicit `TenantScope`); customer portal isolation strictly by `customer_id` claim; portal sessions cannot reach staff pages and vice versa.
- Bug fixes preserved: reports revenue/payments group client-side (SQL translation regression; `ReportsTests` covers it), platform-owner authorization renders the friendly bilingual 403 page (`Approvals`/`Refunds`/`Releases`/`Resellers` gated by policies; `StaffAuthTests.NonManager_...` covers it).
- CI: `web` job now builds SBM.Web and boot-smoke-tests it against LocalDB (the retired React job was replaced; unrelated workflows kept).
- Docker: `backend/SBM.Api/Dockerfile` + `backend/SBM.Web/Dockerfile` (multi-stage) and updated compose (API on host 5220, web on host 8080). `docker compose config` validates. Docker image builds not executed — daemon access is denied in this environment.

## Known gaps (honest)

| Area | State | Impact |
|---|---|---|
| Notification providers (FCM/SMTP/WebPush/Windows) | Dev logging provider only | Campaigns queue but never reach a real inbox |
| Remote configuration & feature flags | Not implemented | No kill switches |
| Telemetry / product analytics | Not implemented | No BI |
| Key Vault integration | Not exercised | ES256 prod key path untested |
| ETA e-invoicing / tax | Not implemented (blocked on spec + accountant) | No fiscal compliance claims |
| Flutter mobile/desktop | Blocked: SDK unavailable | Not started |
| React SPA | Retired (superseded) | `frontend/web` kept on disk; user-owned changes preserved; replaced by `backend/src/SBM.Web` |
| Portal device deactivation of unknown-device ids | Returns generic error | No targeted 404 distinguishing |
| Audience dispatch execution | Dispatch projects/evaluates in-process with caps | Fine at current scale; SQL-translation path is the documented scaling step |
| Release downloads storage | Filesystem only (`Releases:StoragePath`) | Azure Blob is the documented production target |

## Verification log (2026-11-18)

- `dotnet build backend/SBM.slnx --configuration Release` → 0 errors, 0 warnings.
- `dotnet test` (Release): unit 74/74 ✅, API integration 17/17 ✅, web integration 22/22 ✅ — suites re-run repeatedly, stable across consecutive runs (scratch LocalDB per factory, parallelization disabled assembly-wide).
- Live HTTP verification on `dotnet run` instance: owner login, org manager login, portal login; customer creation; invoice payment recording (INV-DEMO-0001 marked Paid via real `PaymentService`); full sales lifecycle (QUO-2026-000001 → ORD-2026-000001 → INV-2026-000001) with events + outbox rows; audience validate + preview (invalid document rejected with real errors, valid document matched 1 of 1 projected candidates); portal subscription renewal request → appears in staff approval queue → approved (subscription period extended, `renewed` event logged); cancellation request → rejected; PDF invoice download (real QuestPDF bytes, `%PDF-1.4`); release create → asset upload (SHA-256 registered, file stored outside web root) → publish → eligible portal download with matching `X-Asset-Sha256` → yank → portal list empty and download 404; refund request → approve → process with single finance entry; friendly 403/404 pages; antiforgery rejection with 400/405 semantics; HTMX approval badge (`<span class="badge">2</span>`).
- Docker images: **not built** — daemon access returns "permission denied" in this environment (`docker compose config` validates instead).
- Demo data: created fresh in development LocalDB via the idempotent demo seed (`Seed:DemoData=true`). Previous session's demo records no longer existed (database had been reset to migrations only).

## Environment

.NET 10.0.404 SDK (projects target net10.0) · SQL Server LocalDB 15.0.4382 · no Docker daemon access · no Flutter SDK · no Azure subscription · Node 22 (frontend retired, unused).

<#
.SYNOPSIS
  Local development bootstrap for SBM.
.DESCRIPTION
  Restores, builds, applies EF Core migrations to LocalDB and runs the API in Development.
  Safe to re-run. Does NOT grant any external access and does not deploy anywhere.
#>
param(
    [switch]$NoRun
)

$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot
$backend = Join-Path $repo "backend"

Write-Host "== SBM dev setup ==" -ForegroundColor Cyan
sqllocaldb start MSSQLLocalDB | Out-Null

Write-Host ".NET SDKs:"; dotnet --list-sdks
dotnet restore "$backend\SBM.slnx"
dotnet build "$backend\SBM.slnx" --no-restore

Write-Host "Applying migrations to (localdb)\\MSSQLLocalDB ..."
dotnet ef database update --project "$backend\src\SBM.Infrastructure" --startup-project "$backend\src\SBM.Api"

Write-Host "Running tests..."
dotnet test "$backend\tests\SBM.UnitTests" --no-build
dotnet test "$backend\tests\SBM.IntegrationTests" --no-build

if ($NoRun) { Write-Host "Done (NoRun)."; exit 0 }

Write-Host "Starting API on http://localhost:5220 (Development; seeded owner owner@sbm.local)"
Push-Location "$backend\src\SBM.Api"
dotnet run --no-build
Pop-Location

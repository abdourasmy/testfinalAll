#!/usr/bin/env bash
# Restore drill: back up the dev database with COPY_ONLY, restore into a scratch database,
# verify row counts, then drop the scratch. The source database is never modified or dropped.
set -euo pipefail

SERVER="${SBM_SQL_SERVER:-(localdb)\\MSSQLLocalDB}"
SOURCE_DB="${SBM_SOURCE_DB:-SBM}"
SCRATCH_DB="${SBM_SCRATCH_DB:-SBM-RestoreDrill}"
BACKUP_FILE="${SBM_BACKUP_FILE:-SBM-drill.bak}"

echo "== SBM restore drill =="
echo "Source: $SOURCE_DB  Scratch: $SCRATCH_DB  Backup: $BACKUP_FILE"

sqlcmd -S "$SERVER" -Q "BACKUP DATABASE [$SOURCE_DB] TO DISK = N'$BACKUP_FILE' WITH COPY_ONLY, INIT"
echo "Backup written."

sqlcmd -S "$SERVER" -Q "IF DB_ID(N'$SCRATCH_DB') IS NOT NULL BEGIN ALTER DATABASE [$SCRATCH_DB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$SCRATCH_DB]; END; RESTORE DATABASE [$SCRATCH_DB] FROM DISK = N'$BACKUP_FILE' WITH RECOVERY"
echo "Restore into scratch complete."

sqlcmd -S "$SERVER" -Q "SELECT 'Subscriptions' AS [Table], COUNT(*) AS [Rows] FROM [$SCRATCH_DB].dbo.Subscriptions UNION ALL SELECT 'Customers', COUNT(*) FROM [$SCRATCH_DB].dbo.Customers UNION ALL SELECT 'Licenses', COUNT(*) FROM [$SCRATCH_DB].dbo.Licenses UNION ALL SELECT 'Invoices', COUNT(*) FROM [$SCRATCH_DB].dbo.Invoices"

sqlcmd -S "$SERVER" -Q "ALTER DATABASE [$SCRATCH_DB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$SCRATCH_DB]"
echo "Scratch dropped. Restore drill PASSED."

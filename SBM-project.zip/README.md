# Software Business Manager (SBM)

A commercial business management platform for software product companies: multi-tenant customer, subscription, licensing, billing, notification and owner-command-center capabilities, delivered as an ASP.NET Core modular monolith with an MVC + HTMX web platform.

**Status:** Early production-oriented MVP. See `PROJECT_STATUS.md` for exactly what is implemented, tested, and still pending. Nothing in this README claims more than the code does.

## Repository layout

```
backend/            ASP.NET Core 10 modular monolith
  src/SBM.Api       JWT REST API host (controllers, middleware)
  src/SBM.Web       ASP.NET Core MVC + HTMX web platform (staff console + customer portal)
  src/SBM.Shared    domain building blocks (SemVer, domain events, abstractions, tenant scoping)
  src/SBM.Infrastructure  EF Core, outbox, services, seeding, exception middleware
  src/Modules/*     Identity, Customers, Catalog, Licensing, Subscriptions, Billing, Finance, Notifications, Support
  tests/SBM.UnitTests, tests/SBM.IntegrationTests
frontend/web        Retired React SPA (superseded by SBM.Web; kept on disk, user-owned work preserved)
infrastructure/     CI, scripts, env example
database/           seed/ (reserved for SQL assets)
docs/               architecture, decisions, security, deployment, operations
```

## Stack

- Backend: ASP.NET Core 10 LTS, C#, EF Core 10, SQL Server / Azure SQL, JWT bearer auth (API), cookie auth (web), health checks, rate limiting, outbox background worker.
- Web: ASP.NET Core MVC + Razor + HTMX (Arabic RTL default, Arabic/English toggle). Staff console at `/`, customer portal at `/portal` with a **separate cookie audience** (`sbm.portal`) and `customer_id`-isolated data access. See `docs/decisions/0005-mvc-htmx-web.md`.
- Database: migrations via EF Core; LocalDB for development; Azure SQL (paid tier) for production after approval.
- Desktop/mobile: not built — Flutter SDK is unavailable in this environment (see `PROJECT_STATUS.md`).

## Quick start (developer)

```powershell
.\infrastructure\scripts\dev-setup.ps1          # restores, builds, migrates, tests, runs API
# or manually:
cd backend
dotnet build
dotnet ef database update --project src/SBM.Infrastructure --startup-project src/SBM.Api
dotnet test
dotnet run --project src/SBM.Api               # JWT API:    http://localhost:5220 (health at /health)
dotnet run --project src/SBM.Web --urls http://localhost:5221   # Web: http://localhost:5221
```

Default dev login (seed, never use elsewhere): `owner@sbm.local` / `Owner!Test123` (override with env var `Seed__OwnerPassword` before first run).
Development demo data (Development only, `Seed__DemoData=true`): demo organization `شركة تصليح برو (تجريبي)`, customer `عميل العرض التجريبي`, portal login `portal@sbm.local` / `PortalDemo!123`, org manager `manager@demo.sbm.local` / `ManagerDemo!123`, invoices `INV-DEMO-0001/0002`, one subscription, one license, one open ticket, one pending renewal request. Demo seeding is idempotent and never runs with `Seed__DemoData=false`.

## Documentation

- `ARCHITECTURE.md` - system design, modules, outbox, licensing crypto, audience engine.
- `DATABASE_DESIGN.md` - schema, constraints, migrations, numbering, journal.
- `SECURITY.md` - threat model summary, tenant isolation, payments, secrets handling.
- `API_DOCUMENTATION.md` - endpoints and semantics.
- `COMPLETION_REPORT.md` - latest verified state of the MVC + HTMX platform (2026-11-18).
- `DEVELOPMENT_SETUP.md` - detailed setup.
- `DEPLOYMENT_GUIDE.md` - environments, migrations, secrets, backup/restore.
- `IMPLEMENTATION_ROADMAP.md` - phases and status.
- `docs/decisions/` - ADRs (modular monolith, MVC + HTMX web platform, tenant scoping, audience engine).

## Definition of done (enforced here)

A change is complete when it builds, has tests, and the tests pass. Current state: backend builds clean (0 errors, 0 warnings), unit tests green, integration tests green (LocalDB). See `PROJECT_STATUS.md` and `COMPLETION_REPORT.md`.

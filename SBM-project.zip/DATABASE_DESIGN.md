# SBM Database Design

Engine: SQL Server LocalDB (dev) → Azure SQL (production, paid tier after approval). All access via EF Core 10; migrations in `src/SBM.Infrastructure/Persistence/Migrations/` (currently `InitialCreate`, `CampaignAndAudienceOrganizationScope`, `InvoiceSequenceRowVersion`).

## Key modeling rules

- Guid primary keys, generated client-side (EF Core convention).
- `OrganizationId` (Guid) on every tenant-owned row — enforced at query time by `TenantScope`, not by implicit filters.
- Money: `decimal(18,2)` everywhere; never float. Percentages: `decimal(5,2)`.
- Timestamps: `DateTimeOffset` UTC (`CreatedAt` on aggregates).
- Unique constraints as correctness backstops (e.g. idempotency keys are unique-filtered; `InvoiceSequences(prefix,year)` unique; `CampaignRecipients(campaignId, recipientKey)` unique; `InvoiceDevices(licenseId, deviceId)` unique).
- Rowversion on `InvoiceSequences` for the optimistic numbering cycle.
- Append-only: `FinanceEntry`, `LicenseEvent`, `SubscriptionEvent`, `DeliveryAttempt`, `OutboxMessage` — corrections are reversal rows, never in-place edits.
- JSON only for genuinely flexible, versioned documents: `ProductApplication.Platforms` (primitive collection), `AudienceDefinition.DocumentJson`, branding payloads — with `RuleVersion` alongside.

## Selected tables

| Table | Purpose | Notes |
|---|---|---|
| Organizations / Branches | tenancy roots | org id == tenant id |
| OrganizationMemberships | user↔org + role + branch | unique (org, user) |
| Invitations | pending invites | token hash, expiry |
| UserSessions | refresh sessions | rotated + revocable |
| SecurityEvents | auth audit | append-only |
| Customers / CustomerContacts / CustomerNotes / Leads / Opportunities | accounts + CRM | org-scoped, indexed |
| Products / ProductApplications / Features / PricingPlans / PlanFeatures | catalog | `Product.Code` unique; features carry dependencies |
| Licenses / LicenseDevices / LicenseSessions | licensing | ES256 issuance; `SessionId` unique; device limit/session limit per plan |
| LicenseSigningKeys | key metadata | `kid` unique; public PEM; private only dev |
| Subscriptions / SubscriptionEvents / AddOns | lifecycle | explicit status machine; `CurrentPeriodEnd` indexed |
| Invoices / InvoiceItems / InvoiceSequences / Payments / PaymentIdempotencyRecords / Refunds | billing | `Invoice(org, number)` unique; idempotency filtered-unique |
| FinanceEntries / FinanceAccounts | operational journal | append-only; reversal links |
| NotificationTemplates / AudienceDefinitions / AudienceSnapshots / Campaigns / CampaignRecipients / DeliveryAttempts / NotificationPreferences | notification hub | campaign idempotency filtered-unique; recipient dedup unique; snapshots keep rule version + hash |

## Invoice numbering

`InvoiceSequences` holds one row per (org, prefix, financial year). Allocation: optimistic read-increment-write with the rowversion token; on concurrency conflict, detach and retry (bounded); on insert race, detach and re-read the winner's row. Returns `PREFIX-YYYY-NNNNNN`. Backstopped by the unique index on `Invoice(OrganizationId, Number)`. Simple recovery: `db.Database.Migrate()`.

## Backup & restore

See `docs/deployment/BACKUP_AND_RECOVERY.md` and `infrastructure/scripts/backup-drill.sh` (COPY_ONLY backup → scratch restore → row-count verification → scratch dropped). RPO target ≤ 15 min, RTO target ≤ 1 h (single Azure SQL instance; no geo-replication until business requires it).

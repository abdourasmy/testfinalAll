# SBM Completion Report — MVC + HTMX Web Platform Restoration
**Date:** 2026-11-18 · **Commit state:** working tree (not committed, per instructions) · **Web:** `backend/src/SBM.Web` on port 5221

---

## 1. What was recovered
The previous session's entire web tier had been lost (no `SBM.Web` in tree, no `SBM.Web` commit, no web tests). The recovery rebuilt it as a first-class citizen of the existing solution, reusing every surviving service and pattern instead of duplicating logic:

- ASP.NET Core MVC + Razor + HTMX staff console and customer portal (`backend/src/SBM.Web`).
- Shared services from `SBM.Infrastructure` (`PaymentService`, `InvoiceNumberingService`, `LicenseAppService`, `AudienceCandidateProjector`, `CampaignLaunchService`, outbox) reused in-process by both hosts; identical tenant scoping (`TenantScope`).
- Bug 1 fix (reports SQL grouping) reproduced and **kept** (client-side grouping) with regression tests.
- Bug 2 fix (platform-owner `Forbid()`) restored as a friendly bilingual 403 page; authorization policies unchanged (verified by tests).

## 2. What was newly implemented
- **Staff console** (Arabic RTL default, English toggle): Dashboard (live metrics + 6-month revenue chart + HTMX pending-approvals badge), Customers, Leads, Catalog (products/plans/features), Subscriptions, Licenses (list/detail/revoke/device deactivate), Invoices (create/list/detail/pay via real PaymentService), Finance journal (create/reverse + monthly margin), Sales end-to-end (Quotation → Send → Accept → Convert to Order → Confirm → Fulfill → Convert to Invoice) with `SalesEvents` audit + outbox sync-journal entries, Refunds (request/approve/reject/process with idempotent finance postings), Approvals queue (HTMX badge; approve/reject executes renewal extension or state-machine-guarded cancellation), Campaigns (audiences, create, launch via real `CampaignLaunchService`, outbox dispatch), Audience builder (server-side rule-engine validate + preview — never fake results; field registry shown), Releases (platform admin: draft → asset upload with server-side SHA-256 → publish → yank), Resellers (commission calculation + approval, idempotent per invoice), Support (tickets, internal notes, state machine), Reports (nine database-backed reports × CSV/XLSX/PDF), Audit log (org-manager scoped), Settings (platform key/value + about), MFA (TOTP enrollment with QR via QRCoder, recovery codes, disable with password).
- **Customer portal** at `/portal` (separate `sbm.portal` cookie audience, `customer_id` claim isolation on every query/operation): portal home, subscription renewal/cancellation requests (landing in staff approval queue; decisions execute the business transition), licenses + device self-deactivation, invoices (list/details/PDF via QuestPDF), support tickets + customer-visible replies, releases download (per-request server-side eligibility checks re-verified on every download).
- **New entities + one migration** (`20261118044734_WebPlatformExpansion`): `Quotation`/`QuotationLine`, `SalesOrder`/`SalesOrderLine`, `SalesEvent` (Billing module), `ApprovalRequest` (Subscriptions module), `SoftwareRelease`/`ReleaseAsset` (Catalog module), `Reseller`/`ResellerCommission` (Billing module), `SystemSetting` (Infrastructure); `ApplicationUser.CustomerId` (portal linkage), `Customer.ResellerId` (commission attribution). Sales aggregates raise domain events that flow into the transactional outbox (verified in tests).
- **Test project** `SBM.Web.IntegrationTests` (22 tests) covering auth, antiforgery, tenant/portal isolation, sales workflow end-to-end, audience validate/preview, report exports, PDF downloads, MFA full flow, release eligibility + yank, portal→staff approval flow.
- **CI**: `web` job now builds `SBM.Web` and boot-smoke-tests against LocalDB (replaces the React job; backend job preserved). **Docker**: `backend/SBM.Web/Dockerfile` + `backend/SBM.Api/Dockerfile`; compose updated (API on host 5220, web on host 8080). **Docs**: `COMPLETION_REPORT.md`, ADR 0005 (MVC + HTMX) with ADR 0002 superseded, README/PROJECT_STATUS/CHANGELOG/DEVELOPMENT_SETUP/DEPLOYMENT_GUIDE/ARCHITECTURE/IMPLEMENTATION_ROADMAP updated to reality.

## 3. Files and projects created or modified
**Created:** `backend/src/SBM.Web` (entire project: Program.cs, `Security/`, `Services/` (Report, Export, InvoicePdf, Sales, Approval, ReleaseEligibility, SignIn, DemoSeed, Language), `Middleware/WebExceptionMiddleware`, ~25 staff controllers + 4 portal controllers, 45+ views, `wwwroot/{css,js}`), `backend/src/Modules/SBM.Modules.Billing/Entities/SalesEntities.cs`, `backend/src/Modules/SBM.Modules.Subscriptions/Entities/ApprovalEntities.cs`, `backend/src/Modules/SBM.Modules.Catalog/Entities/ReleaseEntities.cs`, `backend/src/SBM.Infrastructure/Persistence/Migrations/20261118044734_WebPlatformExpansion.*`, `backend/src/SBM.Shared/Abstractions/TenantScope.cs` (moved, not duplicated), `backend/tests/SBM.Web.IntegrationTests`, `backend/SBM.Web/Dockerfile`, `backend/SBM.Api/Dockerfile`, `docs/decisions/0005-mvc-htmx-web.md`.
**Modified:** `SBM.slnx` (added SBM.Web, Support module, Web.IntegrationTests), `SbmDbContext` (new DbSets + mappings + `SystemSetting`), Identity/Customers entities, `SBM.Api/Controllers/SupportTicketsController.cs` (drop `using SBM.Api;` after move), `SBM.Api/TenantScope.cs` (deleted — moved to Shared), `Program.cs` of API-adjacent behavior unchanged, `docker-compose.yml`, `.github/workflows/sbm-ci.yml`, docs listed above.

## 4. Already present and preserved
JWT API (all 13 controllers), all modules, audience engine, outbox dispatcher, Seed/DbSeeder, migrations, React SPA in `frontend/web` **untouched** (user-owned uncommitted `App.tsx` diff preserved), `docker-compose` topology intent, `.editorconfig`, `SBM.slnx` structure, CI backend job.

## 5. Architecture decisions restored
ADR 0005 (MVC + HTMX) recorded; ADR 0002 (React) superseded. Tenant scoping stays explicit (`TenantScope.Org`/`Owns`, now in Shared); cookie auth with two audiences; antiforgery everywhere; transactional outbox reused for sync-journal; docs updated to match reality.

## 6. Security improvements
Separate portal/staff cookie audiences with independent lifetimes and paths; `customer_id` claim isolation with 404-on-foreign-access (verified); antiforgery on every state-changing POST (login, payments, releases, approvals, portal requests, refunds); friendly bilingual 403 (no bare `Forbid()`); release downloads re-verify eligibility per request; SHA-256 registered at asset registration (verified byte-identical download); recovery codes single-use (verified in DB); MFA disable requires password; sales/orders/invoices tenant-scoped at query boundaries; `/approvals` badge returns no data beyond the pending count.

## 7. Database changes and migrations
One migration `WebPlatformExpansion` (new tables: Quotations, QuotationLines, SalesOrders, SalesOrderLines, SalesEvents, Resellers, ResellerCommissions, ApprovalRequests, SoftwareReleases, ReleaseAssets, SystemSettings; new columns `AspNetUsers.CustomerId`, `Customers.ResellerId`; new unique indexes incl. `SoftwareReleases(ProductCode,ApplicationCode,Version)`, `Resellers` commission idempotency). Applied to development LocalDB `SBM` both via `dotnet ef database update` and automatically at web startup (Development). Integration tests apply the same migrations to scratch databases per suite.

## 8. Tests executed and exact results
- `dotnet test` (Debug): unit **74/74** ✅, API integration **17/17** ✅, web integration **22/22** ✅ — total **113/113**.
- `dotnet test` (Release): unit **74/74** ✅, API integration **17/17** ✅, web integration **22/22** ✅ — total **113/113**.
- Repeated full Debug run after fixes: identical results (stability confirmed; the previous session's LocalDB "flakiness" did not reproduce — suites use unique scratch LocalDB databases, parallelization disabled assembly-wide, no shared dev server during the final runs).
- Web integration details: 21 → 22 passing after fixing the test-factory's client redirect handling (`AllowAutoRedirect=false`) and entity-encoding assertions; not a product bug.

## 9. Build results
`dotnet build backend/SBM.slnx --configuration Release` → **0 errors, 0 warnings**. Debug build → **0 errors, 0 warnings** (after removing 4 hints: unused duplicate using, `CS0108` action name collision with `ControllerBase.Request`, 2 nullability annotations).

## 10. HTTP verification results (live, Development LocalDB)
Staff owner login (302), org manager login, portal login · dashboard renders (Arabic RTL, live KPIs: outstanding 1,500.00, 1 subscription, 1 license, 1 ticket, 1 pending approval) · customer created as `Second Isolation Customer` · **INV-DEMO-0001** recorded as Paid via real PaymentService · full sales lifecycle **QUO-2026-000001 → ORD-2026-000001 → INV-2026-000001** (DB-verified: Quotation=Converted, Order=Invoiced, invoice issued, 8 SalesEvents, 6 outbox `sales.*.status` rows) · audience validate (invalid doc rejected with real errors incl. "Unknown field"; valid doc matched 1 of 1 projected candidates) + preview + HTMX partial rendering · portal: subscription renewal + cancellation requests created → visible in staff `/approvals` with badge `<span class="badge">2</span>` → renewal approved (period extended to 2027-01-07, `renewed` event logged) → cancellation rejected · **PDF invoice download**: HTTP 200, `application/pdf`, `%PDF-1.4`, 91 KB, valid xref/trailer · **release flow**: draft → asset upload (SHA-256 = file hash, stored outside web root) → publish → eligible portal listing → download 200 with `X-Asset-Sha256` match (bytes identical) → yank → listing empty + download 404 · **refund**: request 500 → approve → process → `FinanceEntries` Expense `refund:{id}` 500.00 + payment `PartiallyRefunded` · antiforgery: POST without token → 400; anonymous POST to protected action → 302 `/login` · friendly bilingual 403/404 pages verified.

## 11. Docker and CI verification
- `docker compose config` → **valid** (only a blank-variable warning for optional `SBM_WEB_ORIGIN`).
- Docker daemon access: **permission denied** (npipe docker_engine) — **images were NOT built**, and no image build is claimed; `dotnet publish -c Release` for `SBM.Web` was executed and succeeds (full publish output incl. static assets verified), which is the critical step inside the multi-stage Dockerfile.
- CI `sbm-ci.yml` updated: `web` job = build SBM.Web + boot-smoke (`/healthz` + `/login` expect 200) against LocalDB; `backend` job preserved (+ web integration test step added). CI execution itself: **not executed here** (no GitHub runner in this environment); YAML inspected for correctness.

## 12. Known limitations
- Integration flakiness from the previous session: not reproduced; LocalDB contention between a dev server and the suite was mitigated by stopping dev servers during runs (done).
- Portal downloads stored on filesystem (`Releases:StoragePath`); Azure Blob + signed URLs documented but not wired.
- Notification providers are the dev logging provider (no real email/push).
- Audience dispatch projects in-process with caps (fine at current scale; SQL-translation path documented).
- MFA: staff only (portal has no MFA by design); authenticator keys live in Identity tables (no Key Vault yet).
- Release assets: SHA-256 computed at registration; no code signing.
- Docker images: unverified (daemon denied). CI: verified by inspection only.
- Demo seed uses development defaults (`PortalDemo!123`, `ManagerDemo!123`) — always dev-only, guarded by `Seed:DemoData`.

## 13. Remaining incomplete tasks
Organization/user invitation + self-management UI; remote configuration/feature flags; real notification adapters (FCM/SMTP/WebPush) with delivery-status ingestion; Azure Blob release assets + code signing attestation; telemetry/BI; scheduled campaign execution worker; Key Vault ES256 exercise; ETA e-invoicing review (blocked on spec + accountant); React SPA (retired — do not revive without new decision).

## 14. How to run locally
```powershell
# prerequisites: .NET 10 SDK, SQL Server LocalDB
cd backend
dotnet ef database update --project src/SBM.Infrastructure --startup-project src/SBM.Api
dotnet run --project src/SBM.Api --urls http://localhost:5220   # API (optional for web work)
dotnet run --project src/SBM.Web --urls http://localhost:5221   # staff console + portal
```
Logins (Development only): `owner@sbm.local` / `Owner!Test123` (platform owner); `manager@demo.sbm.local` / `ManagerDemo!123` (org manager); `portal@sbm.local` / `PortalDemo!123` (portal). Demo organization `شركة تصليح برو (تجريبي)`, customer `عميل العرض التجريبي`. Invoices present: `INV-DEMO-0001` (issued → marked Paid during verification), `INV-DEMO-0002` (paid), `INV-2026-000001` (created by the sales workflow, issued), `INV-2026-000002` (isolation-test invoice, issued). One subscription (renewed to 2027-01-07), one license, one open ticket, one renewal request approved and one cancellation rejected. Stop the web host before running integration tests (LocalDB contention); scratch databases are created/dropped per factory.

**Test counts: passed 113, failed 0, skipped 0, not executed 0. Build: 0 errors, 0 warnings. HTTP: all recorded flows verified live. Docker images: not built (daemon denied). CI: not executed (no runner). Commits: none.**

﻿# ADR 0002 - React + TypeScript for the web app (Flutter Web evaluated)

**Status:** Superseded by ADR 0005 (MVC + HTMX) — **Date:** 2026-11-17

## Context
SBM's admin UI centers on large RTL data grids, complex forms, printable reports and strict accessibility - Flutter Web and React both could work. The spec asked for a real spike-style evaluation rather than a slogan.

## Evaluation summary
| Criterion | Flutter Web | React + TS |
|---|---|---|
| Large RTL data tables | workable; heavy first paint; canvas/DOM trade-offs | mature (TanStack Table, AG Grid), first-class RTL |
| Complex enterprise forms | decent with custom widgets | excellent ecosystem (react-hook-form, zod) |
| Accessibility | improving, not yet at WCAG 2.1 AA for dense grids | mature tooling (eslint-plugin-jsx-a11y) |
| Browser compatibility | good but heavier | excellent |
| Printing/reporting | weak story (browser print) | strong (print CSS, server PDF) |
| Admin dashboard usability | fine | excellent |
| Maintainability (hire JS devs) | smaller pool | large pool |
| Shared code with future desktop/mobile | yes (Flutter) | separate (Kotlin/Swift) |

## Decision (at the time)
React + TypeScript for the web admin app. Flutter remains the candidate for the future Android mobile app; desktop Windows stays undecided until Flutter SDK availability is resolved. The web app ships now; Flutter apps were not started because the SDK is not installed in this environment.

## Superseded
The MVC + HTMX web platform (ADR 0005) supersedes this decision. The React SPA source under `frontend/web` was kept on disk (user-owned work) but receives no further feature investment; its replacement is `backend/src/SBM.Web`.

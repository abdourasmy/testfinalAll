# ADR 0001 — Modular monolith, not microservices

**Status:** Accepted · **Date:** 2026-11-17

## Context
SBM targets a single-owner commercial SaaS with many business modules. The team is small; operational complexity (deploys, observability, consistency) must stay low.

## Decision
Build a modular monolith: one deployable, modules with strict boundaries, communication via application services and transactional outbox. Extraction criteria for future services: demonstrated scale pain, independent deploy need, or clear team ownership — measured, not speculative.

## Consequences
+ Simple deploys, single transaction boundary per module where applicable, straightforward local dev.
+ Outbox already gives us async semantics needed for notification campaigns.
− All modules share one database (mitigated by strict ownership conventions).
− Premature extraction would add distributed-system failure modes we do not yet need.

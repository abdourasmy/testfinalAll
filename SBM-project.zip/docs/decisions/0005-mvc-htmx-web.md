# ADR 0005 - ASP.NET Core MVC + HTMX for the web platform

**Status:** Accepted — **Date:** 2026-11-18 — **Supersedes:** ADR 0002

## Context
ADR 0002 chose a React + TypeScript SPA for the admin UI. Building and maintaining a full SPA plus a JSON contract surface duplicates work: every screen needed a Razor-like view, a client-side state story, and an API contract. The platform is a business console used by a small back-office team and customers through a portal — server-rendered forms + HTMX give the same interactivity (live badge polling, async audience validate/preview) with far less machinery, in the same .NET stack as the API.

## Decision
The staff console and customer portal are server-rendered ASP.NET Core MVC + Razor views with HTMX for targeted interactivity:

- Staff console at `/` (Arabic RTL default, `/lang/{ar|en}` cookie toggle), cookie auth (`sbm.staff`).
- Customer portal at `/portal`, **separate** cookie audience (`sbm.portal`), data isolation strictly by `customer_id` claim on every query.
- Antiforgery tokens on every state-changing POST (global `AutoValidateAntiforgeryToken` filter; HTMX sends the token from a `<meta>` tag as the `RequestVerificationToken` header).
- Same DI/services as the JWT API in-process: `SbmDbContext`, Identity, `PaymentService`, `InvoiceNumberingService`, `LicenseAppService`, `AudienceCandidateProjector`, `CampaignLaunchService`, transactional outbox.
- Bilingual Arabic/English UI; RTL-first layout; custom CSS, vendored `htmx.min.js`.
- Port 5221 for local development (API keeps 5220).

The React SPA in `frontend/web` is retired (superseded) but **not deleted**: user-owned uncommitted changes there were preserved as-is. The `web` CI job now builds `SBM.Web` and boot-smoke-tests it against LocalDB instead of building the SPA.

## Consequences
+ Single deployable per tier; no SPA build step; no duplicated validation/authorization paths; tenant scoping enforced at the same boundaries as the API.
+ Arabic-first RTL out of the box with full control over typography and print.
- Server round-trips for interactions (mitigated by HTMX partial swaps, badge polling, and client-side line-item grids for forms).
- HTMX partials must be maintained alongside views (kept in `Views/<Area>/_Partial.cshtml` where used).

## Consequences for existing decisions
ADR 0002 (React) is **Superseded** by this record. ADRs 0001, 0003, 0004 remain in force unchanged.

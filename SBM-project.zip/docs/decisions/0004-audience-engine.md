# ADR 0004 — Audience rule engine: versioned JSON, typed registry, no expression eval

**Status:** Accepted · **Date:** 2026-11-17

## Decision
Campaign audiences are described by a versioned JSON document validated against a typed field registry (operators whitelisted per field, depth ≤ 8, nodes ≤ 100). Evaluation is compiled once per campaign; Top-N ranking is deterministic with a stable tie-breaker; snapshots freeze both rule version and resolved recipient keys (content-hashed). No raw SQL, no script engines, no dynamic expression evaluation ever.

## Rationale
Audience definitions will be authored by non-engineers and may be revisited months later; auditability and reproducibility outrank cleverness. JSON schema + registry gives us safe ground to later translate the same tree to parameterized SQL for scale-out (execution cap today: 500 preview / 50k dispatch candidates).

## Consequences
+ Safe by construction; invalid rules are rejected with precise errors.
+ Snapshots make campaigns reproducible for support and billing disputes.
− SQL translation of the full rule tree is deferred; preview estimates are capped (documented).

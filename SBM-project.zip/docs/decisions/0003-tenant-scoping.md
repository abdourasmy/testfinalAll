# ADR 0003 — Explicit tenant row scoping (no implicit EF query filters)

**Status:** Accepted · **Date:** 2026-11-17 · **Severity:** found and fixed during verification

## Context
First implementation used EF Core global query filters driven by an injected tenant context. Verification tests failed: customers belonging to Org A were invisible to their own users while Org B users could not explain either result. Root cause: EF Core model is built once per service provider and captures filter expression state; the expression evaluated against a stale/first context's tenant (or binary false), producing wrong results per request — and, in one observed case, cross-tenant visibility.

## Decision
Drop implicit query filters entirely. Every organization-owned query is explicitly narrowed via `TenantScope.Org(queryable, tenantContext)` (platform admins see all; tenant users see own rows). Single-entity fetches use the same helper or explicit ownership checks. This is verifiable and host-agnostic (Kestrel, TestServer, background workers — no hidden async-ambient dependencies).

## Consequences
+ Deterministic, testable isolation (integration tests assert both own-rows and other-org invisibility).
+ No hidden state; background workers opt in explicitly to cross-tenant behavior.
− New queries must opt in — mitigated by the helper convention and tests; any future query that forgets it leaks to platform-admin-only visibility (safe default-deny for org users when tenant id is null).

# SBM — جاهزية الإنتاج (Production Readiness)

## التشغيل في الإنتاج
1. **متغيرات البيئة المطلوبة** (أسرار لا تُحقن في الكود):
   - `ConnectionStrings__SbmDatabase` (Azure SQL / SQL Server)
   - `Jwt__Key` (256-bit+ random عبر secret manager)
   - `Releases__StoragePath` (مسار تخزين أصول الإصدارات على قرص/Blob)
   - `SBM_SA_PASSWORD` و `SBM_JWT_KEY` و `SBM_OWNER_PASSWORD` (لبيئة Docker مرجعية فقط)
2. **إعدادات الإنتاج تلقائياً:**
   - `Seed:Enable=false` و `Seed:DemoData=false` — **يُرفض الإقلاع** إذا كانت true (ProductionSeedGuard في Program.cs)
   - `Database:ApplyMigrationsOnStartup=false` في API (طبّق الهجرات كخطوة نشر: `dotnet ef database update`)
3. **الهجرات:** طبّقها إلى قاعدة الإنتاج قبل أول نشر: `dotnet ef database update --project backend/src/SBM.Infrastructure --startup-project backend/src/SBM.Api`
4. **Health/Ready:** `/health` (liveness) و `/health/ready` (يشغل استعلام DB) — كلاهما يجب أن يعيد 200 قبل الواجهة
5. **Secrets:** لا تكتب أي سر في git؛ `ProductionSeedGuard` يحظر حتى حسابات العرض، وإنتاج Docker لا يفعّل Seed أبداً
6. **الكوكي:** `https` + `Secure` فقط في الإنتاج (إنتاج خلف TLS). CSP و X-Frame-Options و nosniff و Referrer-Policy مُفعَّلة في Program.cs

## النسخ الاحتياطي والتعافي (DR)
| العنصر | السياسة | RPO | RTO | هدف |
|---|---|---|---|---|
| قاعدة البيانات | LocalDB/SQL Server backup + COPY_ONLY | ≤15min (سجلات) | ≤1h (استعادة + تشغيل الهجرات) | 1 |
| أصول الإصدارات (`.bin`) | نسخ إلى Blob Storage + soft delete 14 يوم | ≤1h | ≤2h | 2 |
| إصدار DB المعلوماتي | `ef migrations` قابلة للعكس نسبياً | — | — | migration review |
| **إجراء التحقق من النسخة الاحتياطية:** استعادة إلى قاعدةscratch → عد الصفوف + استعلام حرج (فاتورة عينة) → إسقاط | — | كل ربع سنة | مُوثَّق في docs/operations |

## الأمان جاهز للمناقشة الإنتاجية
راجع: `docs/SECURITY.md` · `docs/SECURITY_INVARIANTS.md` · `docs/THREAT_MODEL.md`.

## ملاحظات صريحة
- مزودو الإشعارات (FCM/SMTP/WebPush) **غير موصولين** — الحملات تُسجِّل في `Outbox`/`DeliveryAttempts` فقط (dev logging).
- ETA (الفوترة الإلكترونية) **غير منفذ** — لا ادعاءات امتثال ضريبي.
- الـReleases يتم حفظها على قرص خادم فقط؛ الإنتاج الحقيقي يحتاج Blob Storage + signed URLs.
- الكوكي `sbm.staff` بحجم ~2KB بسبب عربات الأدوار — مقبول.
- Per-tenant Data Encryption — غير مطبقة (SQL TDE حسب المنصة).
- Correlation ID يُغلف بالكامل داخل `HttpContext.Items`; لا يصل إلى `OutboxMessages.CorrelationId` تلقائياً (قيد معروف).

## فحص جاهزية الإنتاج (قائمة تحقق)
| البند | الحالة اليوم | ملاحظة |
|---|---|---|
| Build بدون أخطاء | ✅ Release 0/0 | `dotnet build` |
| اختبارات خضراء | ✅ 113/113 (Debug + Release) | `dotnet test` |
| هجرات مربوطة | ✅ WebPlatformExpansion + ProductionHardening | تلقائي في Dev |
| Health/Ready يعيد 200 | ✅ | /healthz (ويب) و /health, /health/ready (API) |
| Demo accounts معطلة في الإنتاج | ✅ | ProductionSeedGuard (fail-fast) |
| حسابات العرض حاضرة في Dev فقط | ✅ | Demo seed idempotent |
| أسرار خارج الكود | ✅ موثق | docs/deployment + هذا |
| Secrets في الذاكرة فقط | ✅ | — |
| CSP headers | ✅ | Program.cs |
| Rate limiting على /login, /mfa-login, /forgot-password | ✅ | حماية IP (20/دقيقة) |
| تكرار المرسل (idempotency) | ✅ | payments + refund + campaign |
| RBAC مُطبَّق على /users | ✅ | RequiresPermission |
| Rate limit على الإجراءات الحساسة | ✅ | Login/Reset/MFA |
| E2E: logging outbox يحترم DLQ | ✅ | DeadLetter بعد 5 محاولات |
| Backup/Restore موثق | ✅ | هذا الملف + operations |
| Release storage | ⚠️ | قرص فقط، يحتاج Blob (موثق) |
| إشعارات حقيقية | ⚠️ | dev-only |
| ETA compliance | ⚠️ | غير منفذ — متعمد |
| Dockerfile مبني فعلياً | ❌ | الـ daemon مرفوض في هذه البيئة |

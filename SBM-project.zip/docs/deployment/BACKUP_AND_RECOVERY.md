# Backup & Disaster Recovery

## Scope

Azure SQL Database (production) and SQL Server LocalDB (development). File assets (Phase 3) inherit storage redundancy.

## Targets

- RPO ≤ 15 minutes (Azure SQL PITR log backups every 5–15 min).
- RTO ≤ 1 hour (single instance restore; zone-redundant secondary optional).
- Retention: 35 days PITR (default), 7 years legal hold for financial tables if contract demands.

## Procedures

**Scheduled backups (automated)**
Azure SQL automated full/diff/log backups — verify schedule in the portal; do not roll custom jobs on top.

**On-demand full backup (ops)**
```sql
BACKUP DATABASE [SBM] TO URL = 'https://<storage>/backups/SBM-manual.bak' WITH COPY_ONLY, COMPRESSION;
```

**Restore drill (non-prod)**
`infrastructure/scripts/backup-drill.sh` — COPY_ONLY backup of dev DB → scratch DB → row-count verification → scratch dropped. Run quarterly; record outcome in `docs/operations/drill-log.md`.

**Point-in-time recovery**
```sql
RESTORE DATABASE [SBM-PIT] FROM URL = '<base>' WITH NORECOVERY;
RESTORE LOG [SBM-PIT] FROM URL = '<log1>' WITH NORECOVERY, STOPAT = '2026-11-17T14:00:00';
RESTORE LOG [SBM-PIT] FROM URL = '<logN>' WITH RECOVERY;
```

## Key recovery

- License ES256 private key: Key Vault HSM backup policy; if lost, all outstanding offline licenses fail verification — mitigation: re-issue payloads after provisioning a new key pair; clients must accept two `kid`s during rotation windows.
- JWT key: regenerate → all sessions invalidated → forced re-login; acceptable.

## Responsibilities

- Platform owner approves production deployments and DR activation.
- DevOps executes restores; app owner declares service recovered after smoke tests (`/health/ready`, login, license activation).

## What is NOT yet in place

- Geo-secondary / failover groups (single-region first).
- Automated restore verification in CI (requires cloud credentials — intentionally out of scope until approved).
- Backup of Elasticsearch/telemetry store (telemetry not implemented).

# Threat model (SBM)

Scope: Identity, Licensing, Payments, Multi-tenancy, Notification targeting, File distribution, Administrative operations.

## STRIDE summary

| Element | Threat | Control | Residual |
|---|---|---|---|
| Login endpoint | Credential stuffing / brute force | PBKDF2, lockout (5 tries/15 min), rate limit, generic errors | Password spraying remains possible; MFA enrollment needed |
| JWT access token | Theft, replay | 15-min TTL, HTTPS only, `scope`/`org_id` claims, signature HS256 with env secret | XSS in web app can exfiltrate token → tight CSP + future httpOnly cookie mode |
| Refresh session | Theft, fixation | Rotate on every refresh, hash-at-rest, server-side revocation, `RevokeAsync` on logout | Page back/forward cache on shared devices — mitigate with `no-store` |
| License signing | Forgery / key theft | ES256; private key only in Key Vault (prod); dev seed is per-environment; `kid` rotation | Dev key leak = full forgery until rotation; drill in place |
| Payment confirm | Spoofed provider callback | Server-side confirmation only; idempotency keys; manual confirm is staff-authorized + audited | Provider webhook signature checks must be implemented with the chosen provider |
| Tenant data | IDOR / confused deputy | Token-derived tenant; explicit `TenantScope` everywhere; integration tests prove isolation | Any future endpoint must follow the pattern — code review gate |
| Notification dispatch | Audience exfiltration / spam | Opted-out enforcement, quiet hours, caps, per-org endpoint scoping, campaign idempotency | In-app endpoint is user id; leakage only if API token leaks |
| File distribution | Tampered package | (Phase 3) checksum/signature verification + signed URLs — not implemented yet | Do not ship until implemented |
| Admin actions | Unauthorized privilege change | PlatformAdmin policy + security event log | No step-up auth (MFA) yet |

## Abuse cases explicitly tested

- Other-tenant customer read/write — blocked (404/403/empty), asserted in integration tests.
- Cross-tenant branch creation via mismatched route id — forbidden (403 after fix), asserted.
- Refresh with rotated token — old refresh token is useless.
- Duplicate payment callback — recorded as duplicate, no double settlement.
- Duplicate campaign creation with same idempotency key — single campaign.
- Revoked license activation — rejected regardless of subscription state.

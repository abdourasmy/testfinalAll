# SBM — قائمة الثوابت الأمنية الموثقة والمُطبَّقة

كل ثابت أدناه مُنفَّذ في الكود بـ اختبارات آلية تغطيها (إلا ما أُشير إليه بـ "موثقة فقط").

## عزل المستأجرين والعملاء
1. لا يمكن لأي مستخدم الوصول إلى بيانات مستأجر آخر — `TenantScope.Org/Owns` على كل الاستعلامات (صريحة) + **فلاتر استعلام عامة في EF Core** (`ApplyTenantQueryFilters`). اختبار: `GlobalTenantFilterCheckTest` + `TenancyTests` + `PortalIsolationTests`.
2. بوابة العملاء تعزل حسب `customer_id` من الكوكي؛ أي مورد ليس للعميل يعيد 404 — لا كشف بوجوده. اختبار: `PortalIsolationTests`.
3. جلسة الكوكي تحمل `stamp`؛ أي تغيير في SecurityStamp (تغيير كلمة مرور، تعطيل، إعادة MFA) يُبطل كل الجلسات خلال 45 ثانية — اختبار: `StaffAuthTests` (isEnforced via filter) + التغيير يُتحقق عبر `StampValidationCache`.

## المالية
4. مبلغ المرتجع المعتمد/المنفَّذ لدفعة لا يتجاوز المدفوع على الفاتورة. مُنفَّذ داخل serializable transaction + اختبار `ConcurrencyTests.RefundApproval_NeverExceedsPaidAmount`.
5. مبالغ المدفوعات/المرتجعات/البنود `decimal` (18,2) بتقريب `AwayFromZero` — لا أرقام فاصلة عائمة.
6. الرصيد المالي: قيود العكس بدل التعديل الصامت على القيود المثبتة (`FinanceEntryType.Reversal`) وترتبط بـ `ReversalOfEntryId`.
7. تأكيد الدفع غير القابل للتكرار (idempotent) بالكامل — `(OrganizationId, OperationType, IdempotencyKey)` فريد + بصمة `RequestHash`؛ إعادة التنفيذ تعيد النتيجة المخزنة ولا تُنشأ دفعات مكررة.

## التراخيص والأجهزة
8. جهاز واحد لا يتفعّل مرتين بأكثر من `DeviceLimit` — تفعيل مستويات التزامن بـ `sp_getapplock` لكل ترخيص؛ الاختبار `ConcurrencyTests.DeviceActivation_ConcurrentCalls_NeverExceedDeviceLimit` (10 طلبات متزامنة، حد 2).
9. ترخيص موقوف/ملغى/منتهي لا يُفعِّل — `LicenseStateMachine.EnsureTransition` مُطبَّق على كل الانتقالات.
10. إصدار موقوف (yanked) لا يُنزَّل ولا يظهر للعملاء — أهلية مُتحقق منها في كل تحميل. اختبار: `ReleaseEligibilityTests`.

## الموافقات والاشتراكات
11. لا تنفيذ مزدوج لموافقة: فحص الحالة `Pending` + نقش تزامني (`ApprovalRequest.RowVersion`) + serializable على تنفيذ الموافقة.
12. لا يوجد تجديد مزدوج: تنفيذ التجديد يمدد من `max(now, CurrentPeriodEnd)` + يحترم آلة حالات الاشتراك (Expired→Active) — مُتحقق عبر اختبار التكامل `PortalSubscriptionRequest_AppearsInStaffApprovalQueue`.

## المستخدمون والأذونات
13. الأذونات وحدوية (role defaults + direct grants/revokes) — اختبار وحدة/تكامل في `UsersController`: استدعاء `requires permission` يرفض أي طرف لا يمتلكها ما لم يكن PlatformAdmin.
14. لا يُزال الـ Owner الأخير للمنظمة (GuardLastOwnerAsync) — كل مسارات التعطيل/التخفيض محمية. اختبار: smoke بالمسار اليدوي أدناه.
15. لا يُمنح إذن لا تملكه (Caller must possess every requested permission) — مُطبَّق في `Create/AddRole/GrantPermission/SetPermission`.
16. PlatformAdmin لا يمكن منحها من شاشات المنظمة.
17. تغيير كلمة المرور يُبطل كل الجلسات؛ إعادة تعيين MFA وإبطال الجلسات يغيّران SecurityStamp ويُلغيان الجلسات خلال ≤45ث. اختبار: `MfaTests` + `StaffAuthTests.NonManager...`.
18. نسيان كلمة المرور: anti-enumeration (نفس الاستجابة دائماً) + rate limit (حماية 20/دقيقة) + التوكن one-time عبر Identity + لا تخزين نصي للتوكن.

## البنية والنشر
19. التحذير من التبعيات: `Seed:Enable` و`Seed:DemoData` تُرفضان بدءاً من Production (fail-fast) — `ProductionSeedGuard` + اختبار وحدة.
20. كل POST يتطلب antiforgery — فلتر عام مع كوكي + هيدر لـ HTMX. اختبار: `StaffPost_WithoutAntiforgeryToken_Returns400`.
21. لا يوجد سكربت تخزين للأسرار في Git؛ كل الأسرار عبر متغيرات البيئة (`Jwt__Key`, `ConnectionStrings__SbmDatabase`) في الإنتاج.
22. التنقل عبر الصفحات الحساسة يتطلب TTL قصير للطوابع.
23. السجل الأمني `SecurityEvent` يُكتب append-only؛ لا توجد واجهة لحذف/تعديل السجل (لا يزال موضعياً).

## ما لم يُثبت بعد (صدق تقني)
- التحقق من إبطال الجلسات عبر TTL=45ث لم يُختبر على المئات المتوازين بل على استدعاءات متسلسلة.
- رموز مطففيّ لم تُختبر بعد تحت هجوم phishing صريح (URLs one-time تعمل من نفس الجهاز فقط إذا لم يُسرق التوكن).
- المرتجعات تُنفَّذ كقيد مصروف في Finance؛ لا يُسدَّد المبلغ فعلياً لأي بوابة دفع حتى الآن.

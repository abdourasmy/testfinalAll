# SBM — صلاحيات المستخدمين والأدوار

## النموذج

سلسلة القرار: `المستخدم -> الأدوار (الإضافية) + المنح المباشر - الإلغاء المباشر -> effective permissions -> القرار في نقاط الحماية`.

```
Permission = (role defaults) ∪ (direct grants) − (direct revokes)
```

PlatformAdmin = وصول كامل ضمني (bypass) — يُمنح فقط من خارج شاشات المنظمة.

الرمز المعتمد في الكود: `PermissionRegistry` في `SBM.Modules.Identity.Permissions`.
الافتراضي لكل دور مُعرّف في `PermissionRegistry.Defaults` ويُطبَّق بكل startup عبر `DbSeeder.SeedPermissionsAsync`.

## الفئات
| الفئة | الأذونات |
|---|---|
| users | users.read / users.create / users.update / users.disable / users.reset_password / users.reset_mfa / users.revoke_sessions |
| roles | roles.read / roles.assign |
| permissions | permissions.read / permissions.assign / permissions.revoke |
| customers | customers.read / customers.create / customers.update |
| subscriptions | subscriptions.read / subscriptions.create / subscriptions.cancel / subscriptions.renew |
| licenses | licenses.read / licenses.activate / licenses.disable_device / licenses.revoke |
| invoices | invoices.read / invoices.create / invoices.issue |
| payments | payments.read / payments.create / payments.refund.request / payments.refund.approve / payments.refund.execute |
| finance | finance.read / finance.create_entry / finance.reverse_entry |
| campaigns | campaigns.read / campaigns.create / campaigns.launch / campaigns.cancel |
| reports | reports.read / reports.export |
| audit | audit.read |
| support | support.read / support.create / support.manage |
| catalog | catalog.read / catalog.manage |
| sales | sales.read / sales.manage |
| settings | settings.manage · resellers.read / resellers.manage |

## القيود
- PlatformAdmin لا يمكن منحها من شاشات المنظمة — AssignableRoles في `UsersController`.
- لا يُزال المالك الأخير (آخر Owner) للمنظمة (GuardLastOwnerAsync).
- من يمنح لا يملك: `EnsureCanGrantAsync` يمنع منح أي إذن لا يمتلكه المنفذ (باستثناء PlatformAdmin).
- من لا يملك: يستطيع من لا يملك الإذن أن يمنحه لنفسه بفصل التكليف المباشر فقط إذا كانت نقطة الحماية تتطلب `users.read` فقط — تُمنع النقاط الحساسة بالأذونات `permissions.assign`/`permissions.revoke`/`roles.assign`.
- في الواجهة، CTA الإجراءات الحساسة مفتوحة للـ Owner والـ Manager (حراسية)؛ الحراسة الفعلية في `RequiresPermissionAttribute` + نقاط التحقق في الأجهزة.

## الافتراضي لكل دور
| الدور | يملك | القرار |
|---|---|---|
| PlatformAdmin | كامل (bypass) | يرى كل شيء عبر كل المنظمات |
| Owner | كامل ضمن فئته | يملك users.* كاملة + كل الأذونات |
| Manager | عمليات الأعمال + reports.read + audit.read | لا يملك users.* كاملة إلا إذا مُنحت |
| Member | الوصول للقراءة + support.read/create | لا عمليات تعديل |
| Cashier | إصدار الدفعات/الفواتير | — |
| Accountant | المالية + المرتجعات موافقة + التقارير | — |
| Technician | لا شيء أعمال، تقني فقط | — |
| Salesperson | العملاء/الاشتراكات/المبيعات | — |
| Support | إدارة تذاكر الدعم | — |
| Finance | مالية + تقارير | — |

## لهل أحتاج Migration
نعم — `ProductionHardening` (2026-11-18) أضاف `Permissions`، `RolePermissions`، `UserPermissions` مع بذرها تلقائياً في البيئات Development عند كل إقلاع.

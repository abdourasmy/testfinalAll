# Offline sync & enforcement policy (documented limits)

SBM itself does not ship a client SDK in this phase, but the server-side contracts assume these rules for licensed products (POS/repair desktop apps):

## Online-required operations

- Device activation / deactivation.
- Session lease issuance and renewal (heartbeat).
- License revocation / suspension enforcement.
- Payment confirmation.
- Any mutation of commerce records (invoices, refunds).

## Offline-capable operations

- Read-only catalog/price views (cached).
- Local provisional orders queued for sync (idempotent by client-generated GUID).
- ES256 license payload verification (public key shipped with install).

## Hard limits (explicitly documented to clients and customers)

- An offline client cannot know a license was revoked seconds ago. Enforcement bound = **session lease TTL** (default 15 min). After expiry, the client must re-validate; if offline past TTL, the client enters the configured restricted mode (ReadOnly where the product supports it, else prompt-to-connect).
- Concurrent-session limits cannot be enforced while all peers are offline. Enforcement is best-effort between sync points; the plan must define the product's behavior (queue writes vs. read-only mode).
- Data conflicts are resolved server-side with client revision timestamps + server checksums; last-writer-wins is forbidden for financial records — those require online validation or a reconciliation queue with human review.
- Maximum silent offline window: 24h recommended; longer offline licensing requires a signed "offline grace" payload issued by support on request, logged via `LicenseEvent`.

## Client contract checklist (when clients are built)

1. Verify ES256 signature + `exp` on every payload; pin issuer (`sbm`) and allowed `kid`s.
2. Heartbeat every ≤5 minutes when online; drop to ReadOnly on lease expiry without renewal.
3. Queue outbound operations with idempotency keys; replay safely.
4. Never trust client clock for licensing expiry beyond a skew allowance (±5 min).
5. Report `lastSyncAt` / `lastConnectionAt` on every sync to power telemetry audiences.

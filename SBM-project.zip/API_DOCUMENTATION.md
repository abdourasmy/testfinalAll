# API Documentation (SBM)

Base URL: `http://localhost:5220` (dev). Auth: `Authorization: Bearer <JWT>`. Content type: `application/json`. Errors return RFC 7807 `application/problem+json` (no stack traces). List endpoints: `{ total, page, pageSize, items }` with `page` (1-based) and `pageSize` (≤100).

## Auth
| Method | Path | Notes |
|---|---|---|
| POST | `/api/auth/login` | `{email,password}` → `{accessToken, refreshToken, expiresAt, user}`; rate-limited |
| POST | `/api/auth/refresh` | `{refreshToken}` → rotated pair; old session revoked |
| POST | `/api/auth/logout` | `{refreshToken}` → 204; session revoked |
| GET | `/api/auth/me` | current user + scope + org membership |

## Catalog
| GET | `/api/catalog/products` | paged products |
| GET | `/api/catalog/products/{id}` | product + applications + features + plans |

## Organizations
| POST | `/api/organizations` | platform admin only; creates org |
| GET | `/api/organizations` | platform admin; paged |
| GET | `/api/organizations/{id}/branches` | own tenant (or platform) |
| POST | `/api/organizations/{id}/branches` | `OrgManager`; tenant id must match token tenant (IDOR-safe) |

## Customers
| GET | `/api/customers?page&pageSize&search` | tenant-scoped |
| GET | `/api/customers/{id}` | 404 if not in tenant |
| POST | `/api/customers` | tenant-scoped create |
| GET | `/api/customers/{id}/profile` | customer + subscriptions/licenses/devices/invoices |
| GET/POST | `/api/customers/{id}/notes` | (notes: add/list — minor) |

## Licenses
| POST | `/api/licenses` | issue (OrgManager); plan policy copied (device/session limits) |
| GET | `/api/licenses` | tenant list (`?customerId=`) |
| GET | `/api/licenses/{id}` | tenant |
| POST | `/api/licenses/{id}/activate` | `{deviceId, deviceName, platform}` → conflict `device-limit-reached` on plan cap; returns ES256 `token` for clients |
| POST | `/api/licenses/{id}/devices/{deviceId}/deactivate` | OrgManager |
| POST | `/api/licenses/{id}/sessions` | start concurrent-session lease (`{deviceId, userId?, applicationId}`); `session-limit-reached` on cap |
| POST | `/api/licenses/sessions/heartbeat` | `{sessionId}` → renewed lease; expired/revoked rejected |
| POST | `/api/licenses/{id}/transfer` | self-service within plan policy; exceptional → requires approval |
| POST | `/api/licenses/{id}/revoke` | OrgManager; hard stop |

License tokens: `base64url(payloadJson).base64url(ES256Signature)`; header/payload visible, signature verifies with the public key. Fields: `v, iss=sbm, lic, prd, app, cust, org, iat, exp, ent[], dev{limit}, ses{limit}, kid`.

## Subscriptions
| POST | `/api/subscriptions` | create (Trial/Active) |
| GET | `/api/subscriptions` | tenant list |
| POST | `/api/subscriptions/{id}/cancel` | terminal |
| POST | `/api/subscriptions/apply-expiration-policy` | PlatformAdmin; applies 7-day grace → ReadOnly policy (configurable) |

## Billing
| POST | `/api/invoices` | creates invoice; numbering `INV-YYYY-NNNNNN` concurrency-safe |
| GET | `/api/invoices`, `/api/invoices/{id}` | tenant |
| POST | `/api/invoices/payments/confirm` | `{invoiceId, amount, currency, method, providerReference, idempotencyKey, confirmedByProvider}`; idempotent; confirmed payments settle invoice + reactivate grace-period subscriptions |

## Finance
| POST | `/api/finance/entries` | append-only income/expense/adjustment; `ExternalRef` idempotent |
| POST | `/api/finance/entries/{id}/reverse` | reversal entry; original untouched |
| GET | `/api/finance/entries`, `/api/finance/summary` | tenant; summary groups by type |

## Audiences & Campaigns
| POST | `/api/audiences/validate` | rule validation; 400 with detailed errors |
| POST | `/api/audiences/preview` | capped preview over tenant/platform candidates; shows match count + sample |
| POST | `/api/audiences/topn-preview` | dynamic Top-N with deterministic ordering |
| POST | `/api/campaigns/audiences` | create audience (tenant or platform-level) |
| GET | `/api/campaigns/audiences` | list visible audiences |
| POST | `/api/campaigns` | create campaign (idempotent by `idempotencyKey`) |
| POST | `/api/campaigns/{id}/launch` | materializes recipients (dedup, opt-out, quiet hours, caps) + one outbox message each; frozen snapshots stored with hash |
| POST | `/api/campaigns/{id}/cancel` | cancels queued sends |
| GET | `/api/campaigns/{id}/delivery` | per-status recipient counts |

## Support
| POST | `/api/support/tickets` | create ticket (any org user); SLA due date by priority |
| GET | `/api/support/tickets` | tenant list (`?status=`) |
| GET | `/api/support/tickets/{id}` | tenant; comments visibility-filtered for non-staff |
| POST | `/api/support/tickets/{id}/comments` | public by default; `internal:true` staff-only |
| POST | `/api/support/tickets/{id}/status` | OrgManager; state machine enforced |
| POST | `/api/support/tickets/{id}/assign` | OrgManager |

## Dashboard
| GET | `/api/dashboard/summary` | PlatformAdmin; MRR (definition in `metricDefinitions`), outstanding, devices/sessions, etc. |

## Health
| GET | `/health`, `/health/ready` | liveness / database readiness |

## Interactive docs
Development only: Swagger UI at `/swagger`, OpenAPI document at `/openapi.json`. Authentication required for all endpoints except `/health`, `/health/ready`, and `/api/auth/*`.

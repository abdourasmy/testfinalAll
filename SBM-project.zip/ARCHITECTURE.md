# SBM Architecture

## 1. Shape: Modular Monolith

SBM is one deployable ASP.NET Core application organized into modules with explicit boundaries. Modules communicate through in-process application services and domain events via a **transactional outbox** — never through shared database tables owned by another module, never by circular project references. A module can later be extracted into a service if scale justifies it.

Modules: Identity (tenancy, users, memberships, sessions), Customers (accounts + CRM), Catalog (products, applications, plans, features), Licensing (issuance, activation, leases, crypto), Subscriptions (lifecycle), Billing (invoices, payments, refunds), Finance (append-only journal), Notifications (templates, campaigns, audience engine, delivery), Support (tickets, comments, SLA due dates, state machine).

```
Api (JWT REST controllers, middleware)  ─┐
Web (MVC + HTMX controllers, Razor)      ─┤─ both hosts share services, EF model, outbox
  ├─ SBM.Api   JWT bearer; short-lived access tokens; rotating refresh sessions
  ├─ SBM.Web   cookie auth: staff (`sbm.staff`) + separate portal audience (`sbm.portal`); antiforgery on every POST; Arabic-first RTL + English toggle
  └─ Infrastructure (EF Core, outbox, services, seeding)
       ├─ Identity, Customers, Catalog, Licensing, Subscriptions, Billing, Finance, Notifications, Support
       └─ Shared (domain events, SemVer, building blocks)
```

Dependency direction is one-way: Api / Web ─► Infrastructure ─► Modules ─► Shared. The web tier reuses the same application services (`PaymentService`, `InvoiceNumberingService`, `LicenseAppService`, `CampaignLaunchService`, `AudienceCandidateProjector`, transactional outbox) and the same explicit tenant scoping (`TenantScope.Org`/`Owns`) as the API.

## 2. Tenant isolation (server-enforced)

- Claims issued by the API carry `scope` (`platform` | `organization`) and `org_id`. The server never trusts a tenant id from the client body or query string; handlers derive it from the token.
- **Explicit row scoping** everywhere (no implicit global query filters). `TenantScope.Org(...)` narrows every organization-owned query to the caller's tenant unless the caller is a platform administrator. Rationale: implicit EF query filters bound behavior to the model/this-request context and produced subtle cross-tenant leaks in verification tests — explicit scoping is deterministic on every host (Kestrel, in-memory test server, background workers). See `docs/decisions/0003-tenant-scoping.md`.
- Platform administration (owner's staff) is a separate `scope=platform` + `PlatformAdmin` role; organization users can never reach platform endpoints (e.g. owner dashboard) — verified by integration tests.
- Refresh sessions rotate and are revoked server-side; deactivated users cannot authenticate.

## 3. Licensing

- **ES256 (ECDSA P-256 + SHA-256)** signed license payloads, versioned (`v:1`), carrying license id, product/application/customer/org ids, issue/expiry, entitlements, device/session policy, and `kid`. Public keys live in the database; private keys live in Azure Key Vault in production (`UseKeyVault`) — never in the repo. Dev seeds generate a per-environment throwaway key.
- **Device limits** and **concurrent sessions** are independent plan policies (`DeviceLimit`, `SessionLimit`; 0 = unlimited). Heartbeat renews a session lease; expiry invalidates it.
- **License state ≠ subscription state**. Revoked/suspended licenses cannot be activated even if a subscription is active (state machines in `Licensing/Domain/Rules.cs`, `Subscriptions/Domain/Rules.cs`).
- Offline licensing: ES256 payload is self-contained and verifiable offline (public key can be provisioned to the client). Strict global revocation enforcement offline is impossible; see `docs/operations/offline-sync.md` for the documented policy (lease TTL bounds offline validity).
- Transfers: self-service within plan policy (max transfers, cooldown); exceptional transfers require approval.

## 4. Audience engine (Notification Hub)

Versioned JSON rule document (`{v:1, root}`), strict validation:

- typed field registry (`customer.*`, `organization.*`, `product.*`, `app.version`, `app.role`, `subscription.*`, `license.*`, `device.*`, `purchase.lastAt`), operator whitelist per field, complexity limits (depth 8, nodes 100), no raw SQL, no expression evaluation.
- semver-aware version predicates (`eq|ne|gt|gte|lt|lte|range|family|notIn`) using proper precedence including prereleases.
- Deterministic Top-N ranking with stable tie-breaker (`entityId`) for last-N style queries.
- Execution modes: dynamic evaluation or frozen snapshot stored with rule version + content hash for reproducibility.
- Recipient semantics (per-organization/user/installation/endpoint), opt-out, quiet hours, frequency caps, dedup — all applied before dispatch.
- **Transactional outbox** with at-least-once delivery, exponential backoff + jitter, dead-letter after 5 attempts, idempotent campaign creation, `ProviderAccepted` never recorded as `Delivered`.

## 5. Reliability

- Outbox pattern for asynchronous work (campaign sends). Workers poll the outbox table; retries reschedule; poisoned messages dead-letter.
- Idempotency keys on payment confirmations and campaign creation (unique constraints + duplicate detection).
- Invoice numbering via an optimistic rowversion-guarded sequence row + bounded retry; unique index as backstop. Never `MAX()+1`.
- Monetary math is `decimal`, rounded `AwayFromZero` at defined boundaries.
- Retry-on-failure execution strategy for SQL connectivity (transient errors).

## 6. Observability & ops

- `/health` (liveness) and `/health/ready` (database) endpoints.
- Structured logging (Microsoft.Extensions.Logging); secrets are never logged.
- `PROJECT_STATUS.md` maintained after every milestone; `CHANGELOG.md` for releases.

## 7. Web platform decision

ASP.NET Core MVC + Razor + HTMX (`backend/src/SBM.Web`, port 5221). Flutter Web and the React + TypeScript SPA both remain documented alternatives; the MVC + HTMX decision is recorded in `docs/decisions/0005-mvc-htmx-web.md` and supersedes ADR 0002.

- **Staff console** at `/` — dashboard (live metrics + 6-month revenue chart + pending-approvals badge), Customers, Leads, Catalog, Subscriptions, Licenses, Invoices, Finance journal, Sales (Quotation → Send → Accept → Order → Confirm → Fulfill → Invoice), Refunds, Approvals queue, Campaigns, audience builder (rule engine with server-side validate/preview, never fake results), platform Releases (draft → publish → yank with server-side SHA-256), Resellers (commission calculation + approval), Support, Reports (nine reports with CSV/XLSX/PDF export), Audit log, Settings, MFA enrollment.
- **Customer portal** at `/portal` — separate cookie audience (`sbm.portal`), `customer_id`-scoped isolation on every query, subscription renewal/cancellation requests (surfaced in the staff approval queue), invoice listing/details/download as real PDFs (QuestPDF), self-service device deactivation, eligible software releases with per-request server-side eligibility checks, direct downloads via controlled streaming.
- **Security**: cookie auth with two audiences, antiforgery token on every state-changing POST (global filter + HTMX header), friendly bilingual 403/404 pages instead of bare `Forbid()`, explicit tenant scoping identical to the API, platform-owner operations guarded by `PlatformAdmin` policy, idempotent payment recording via the shared `PaymentService`.
- **Arabic-first RTL** with English toggle via `/lang/{ar|en}` cookie.

React SPA source (`frontend/web`) was retired to superseded status; user-owned uncommitted work there was preserved untouched. Flutter mobile/desktop apps are not built in this environment (SDK unavailable).

## 8. Known boundaries (honest)

- Windows notifications, FCM, SMTP, Web Push, Key Vault integration, ETA e-invoicing integration: **not implemented/verified** — adapters are stubbed as documented external dependencies. Everything required to wire them (provider interfaces, outbox, DLQ, idempotency) exists and is tested in-memory.
- Egyptian fiscal compliance: **not claimed** — requires official ETA specification review + professional accounting sign-off (Phase 1.5).
- Large-scale audience dispatch currently projects and ranks candidates in-process with caps; a SQL-translation execution path is the documented scaling step.

# Deployment Guide

## Environments

Development → Testing → Staging → Production. Promotion is manual and gated; **production deploys require explicit authorization** and are never automatic.

## Hosting topology (target)

- Azure App Service (Linux or Windows) running SBM.Api and SBM.Web; Application Insights.
- Azure SQL Database (General Purpose / Business Critical, paid tier; **not** Free tier for production). Zone-redundant secondary when RTO demands.
- Azure Key Vault for all secrets (JWT key, license ES256 private key, SQL connection string).
- Azure Blob Storage for file distribution (release packages, customer attachments) — or `Releases:StoragePath` on a managed disk — with short-lived signed URLs.
- Front Door / WAF for public endpoints.

## Pre-flight checklist

1. `Seed:Enable=false`, `Database:ApplyMigrationsOnStartup=false` in production appsettings.
2. Secrets injected from Key Vault: `ConnectionStrings__SbmDatabase`, `Jwt__Key` (256-bit+ random).
3. ES256 license signing key provisioned in Key Vault; `LicenseSigningKeys.UseKeyVault=true`; private PEM removed from database.
4. CORS allowlist contains only the real frontend origins.
5. HTTPS enforced (TLS 1.2+); HSTS; CSP aligned with frontend.
6. Rate limits tuned (`api`, `auth` policies in `Program.cs`).
7. Managed identity for the App Service (no credentials in config).
8. Health probes wired (`/health`, `/health/ready`).
9. Backup strategy validated: full backups + 15-min log backups; PITR enabled; restore drill executed and logged.

## Migrations

Apply migrations as a deployment step (CI/CD), never implicitly at runtime:

```bash
dotnet ef database update --project backend/src/SBM.Infrastructure --startup-project backend/src/SBM.Api --connection "<prod-conn>"
```

Rollback: EF migrations are forward-only by default; for breaking changes use a compensating migration. Test every migration against a copy of production schema in staging.

## Key rotation (license signing)

1. Create new Key Vault key; insert `LicenseSigningKeys` row `Active` with new `kid`.
2. Clients receive new public key via remote configuration / provisioning channel.
3. Old key retired (`Status=Retired`) — verification of outstanding tokens continues until their expiry.
4. Drill: verify sign/verify round-trip with both keys (covered by unit tests).

## Backup & recovery

- RPO ≤ 15 min (log backups), RTO ≤ 1 h (single instance, warm standby optional).
- Restore drill (non-production): `infrastructure/scripts/backup-drill.sh` — COPY_ONLY backup → scratch restore → row-count verification → scratch dropped. Never run against production data; log every drill in `docs/operations/`.
- File storage: geo-redundant replication + soft delete for 14 days.

## Post-deploy verification

1. `GET /health/ready` → 200.
2. Login as a smoke-test user; create a test customer; issue a test license; activate on a test device.
3. Confirm `SecurityEvent` row exists for the login.
4. Confirm structured logs carry no secrets.

## Docker

Reference topology (`docker-compose.yml`, repo root): SQL Server 2022 + JWT API on host port **5220** + MVC web on host port **8080**.

```bash
docker compose build
docker compose up -d
curl http://localhost:8080/healthz
```

Multi-stage Dockerfiles are provided: `backend/SBM.Api/Dockerfile` (JWT API) and `backend/SBM.Web/Dockerfile` (MVC web). Both are built from the repository root and publish the projects before copying into the runtime image. LocalDB is Windows-only and not containerized for prod; production uses the SQL Server container or, target state, Azure SQL.

Production deployments should still prefer CI/CD-applied migrations and Key Vault-sourced secrets (`Seed:Enable=false`, `Database:ApplyMigrationsOnStartup=false` for the API); the compose file applies migrations at startup for developer convenience and enables the dev seed. To run the MVC web with no seed at all: set `Seed__Enable=false` and `Database__ApplyMigrationsOnStartup=true` (migrate once, then set to false) — or apply migrations as a release step and set both to false.

Release assets (software releases + SHA-256) are stored outside the web root; set `Releases__StoragePath` to a persistent volume (compose maps `sbm-releases` → `/data/releases`).


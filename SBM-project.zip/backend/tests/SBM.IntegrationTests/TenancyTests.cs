using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class TenancyTests : IntegrationTestBase
{
    public TenancyTests(SbmFactory factory) : base(factory) { }

    private static Dictionary<string, JsonElement> DecodeJwtPayload(string token)
    {
        var part = token.Split('.')[1];
        part = part.Replace('-', '+').Replace('_', '/');
        part = part.PadRight(part.Length + (4 - part.Length % 4) % 4, '=');
        using var doc = JsonDocument.Parse(Convert.FromBase64String(part));
        return doc.RootElement.EnumerateObject().ToDictionary(p => p.Name, p => p.Value.Clone());
    }

    [Fact]
    public async Task Customers_AreIsolated_ByTenant()
    {
        var orgA = await Factory.CreateOrgAndOwnerAsync("tenA");
        var orgB = await Factory.CreateOrgAndOwnerAsync("tenB");
        var payload = DecodeJwtPayload(orgA.OwnerToken);
        Assert.True(payload.ContainsKey("org_id"), $"Token payload keys: {string.Join(",", payload.Keys)}");

        using var clientA = Factory.CreateClient();
        clientA.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", orgA.OwnerToken);
        var create = await clientA.PostAsJsonAsync("/api/customers",
            new { name = "Org A Secret Customer", type = "Company", email = "a@example.local" });
        var createBody = await create.Content.ReadAsStringAsync();
        Assert.True(create.IsSuccessStatusCode, $"Create failed: {create.StatusCode} {createBody}");

        using var clientB = Factory.CreateClient();
        clientB.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", orgB.OwnerToken);
        var listB = await clientB.GetAsync("/api/customers");
        var bodyB = await listB.Content.ReadAsStringAsync();
        Assert.DoesNotContain("Org A Secret Customer", bodyB);

        // Org A sees its own customer.
        var listA = await clientA.GetStringAsync("/api/customers");
        Assert.True(listA.Contains("Org A Secret Customer"),
            $"orgA={orgA.OrgId} orgB={orgB.OrgId} tokenA.org={DecodeJwtPayload(orgA.OwnerToken)["org_id"]}\nlistA={listA}\n---LOGS---\n" + Factory.Logs.DumpSince());
    }

    [Fact]
    public async Task Branch_Management_IsTenantScoped()
    {
        var orgA = await Factory.CreateOrgAndOwnerAsync("brA");
        var orgB = await Factory.CreateOrgAndOwnerAsync("brB");

        using var clientA = Factory.CreateClient();
        clientA.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", orgA.OwnerToken);

        // Org B cannot create a branch inside Org A (tenant id is derived from the token, never from the route/body).
        var response = await clientA.PostAsJsonAsync($"/api/organizations/{orgB.OrgId}/branches", new { name = "Rogue Branch" });
        Assert.NotEqual(System.Net.HttpStatusCode.Created, response.StatusCode);
    }
}

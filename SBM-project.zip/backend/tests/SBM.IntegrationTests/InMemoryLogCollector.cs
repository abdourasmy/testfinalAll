using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;

namespace SBM.IntegrationTests;

public sealed class InMemoryLogCollector : ILoggerProvider
{
    public ConcurrentQueue<string> Lines { get; } = new();

    public ILogger CreateLogger(string categoryName) => new CollectorLogger(categoryName, Lines);

    public void Dispose() { }

    public string DumpSince(int skip = 0) => string.Join("\n", Lines.TakeLast(80));

    private sealed class CollectorLogger : ILogger
    {
        private readonly string _category;
        private readonly ConcurrentQueue<string> _lines;

        public CollectorLogger(string category, ConcurrentQueue<string> lines)
        {
            _category = category;
            _lines = lines;
        }

        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information || _category.StartsWith("SBM.Api", StringComparison.Ordinal);

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel)) return;
            var message = $"[{logLevel}] {_category}: {formatter(state, exception)}";
            if (exception is not null) message += Environment.NewLine + exception;
            _lines.Enqueue(message);
        }
    }
}

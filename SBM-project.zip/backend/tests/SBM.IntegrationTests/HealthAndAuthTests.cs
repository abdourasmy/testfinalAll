using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class HealthAndAuthTests : IntegrationTestBase
{
    public HealthAndAuthTests(SbmFactory factory) : base(factory) { }

    [Fact]
    public async Task Health_ReturnsSuccess()
    {
        using var client = Factory.CreateClient();
        var response = await client.GetAsync("/health");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Customers_WithoutToken_Returns401()
    {
        using var client = Factory.CreateClient();
        var response = await client.GetAsync("/api/customers");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Dashboard_RequiresPlatformAdmin()
    {
        using var client = Factory.CreateClient();
        var orgOwner = await Factory.CreateOrgAndOwnerAsync("dash" + Guid.NewGuid().ToString("N")[..8]);
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", orgOwner.OwnerToken);
        var response = await client.GetAsync("/api/dashboard/summary");
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Dashboard_PlatformOwner_Succeeds()
    {
        using var client = Factory.CreateClient();
        var token = await Factory.LoginAsync("owner@sbm.local", "Owner!Test123");
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await client.GetAsync("/api/dashboard/summary");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.True(doc.RootElement.TryGetProperty("monthlyRecurringRevenue", out _));
        Assert.True(doc.RootElement.TryGetProperty("metricDefinitions", out _));
    }
}

using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class AudiencePreviewTests : IntegrationTestBase
{
    public AudiencePreviewTests(SbmFactory factory) : base(factory) { }

    [Fact]
    public async Task Preview_EvaluatesNestedRules()
    {
        var (orgId, token) = await Factory.CreateOrgAndOwnerAsync("aud1");
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        await client.PostAsJsonAsync("/api/customers", new { name = "Audience Co", type = "Company", country = "EG", email = "aud@example.local" });

        var rule = """
        {
          "v": 1,
          "root": {
            "type": "group",
            "op": "and",
            "children": [
              { "type": "condition", "field": "customer.type", "op": "eq", "value": "Company" },
              { "type": "group", "op": "or", "children": [
                  { "type": "condition", "field": "customer.country", "op": "eq", "value": "EG" },
                  { "type": "condition", "field": "customer.country", "op": "eq", "value": "SA" }
              ]}
            ]
          }
        }
        """;
        var response = await client.PostAsJsonAsync("/api/audiences/preview", new { documentJson = rule, maxRecipients = 10 });
        response.EnsureSuccessStatusCode();
        var doc = await response.Content.ReadFromJsonAsync<JsonDocument>();
        Assert.True(doc!.RootElement.GetProperty("matchedInSample").GetInt32() >= 1);
    }

    [Fact]
    public async Task Preview_RejectsInvalidRule()
    {
        var (orgId, token) = await Factory.CreateOrgAndOwnerAsync("aud2");
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var badRule = """{ "v": 1, "root": { "type": "condition", "field": "customer.nope", "op": "eq", "value": "x" } }""";
        var response = await client.PostAsJsonAsync("/api/audiences/preview", new { documentJson = badRule, maxRecipients = 10 });
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadAsStringAsync();
        Assert.Contains("Unknown field", body);
    }
}

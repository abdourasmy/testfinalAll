using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class LicenseLifecycleTests : IntegrationTestBase
{
    public LicenseLifecycleTests(SbmFactory factory) : base(factory) { }

    private async Task<(HttpClient Client, Guid OrgId)> NewOrgAsync(string suffix)
    {
        var (orgId, token) = await Factory.CreateOrgAndOwnerAsync(suffix);
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return (client, orgId);
    }

    [Fact]
    public async Task DeviceLimit_IsEnforced_ByPlan()
    {
        var (client, _) = await NewOrgAsync("lic1");
        // Catalog is seeded: product REPAIR-PRO, plan PRO-MONTHLY (DeviceLimit 3).
        using var catalog = await client.GetFromJsonAsync<JsonDocument>("/api/catalog/products");
        var product = catalog!.RootElement.GetProperty("items").EnumerateArray().First();
        var productId = product.GetProperty("id").GetGuid();
        var productDetail = await client.GetFromJsonAsync<JsonDocument>($"/api/catalog/products/{productId}");
        var planId = productDetail!.RootElement.GetProperty("plans").EnumerateArray().First(p => p.GetProperty("code").GetString() == "PRO-MONTHLY").GetProperty("id").GetGuid();
        var applicationId = productDetail.RootElement.GetProperty("applications").EnumerateArray().First().GetProperty("id").GetGuid();

        var customer = await client.PostAsJsonAsync("/api/customers", new { name = "Lic Customer", type = "Company" });
        var customerId = (await customer.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        var licenseResponse = await client.PostAsJsonAsync("/api/licenses",
            new { customerId, productId, applicationId, planId, validDays = 365 });
        Assert.Equal(System.Net.HttpStatusCode.Created, licenseResponse.StatusCode);
        var licenseId = (await licenseResponse.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        // 3 devices allowed by the plan.
        foreach (var deviceId in new[] { "dev-1", "dev-2", "dev-3" })
        {
            var activation = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/activate",
                new { deviceId, deviceName = deviceId, platform = "Windows" });
            var activationBody = await activation.Content.ReadAsStringAsync();
            Assert.True(activation.IsSuccessStatusCode, $"Activation {deviceId} failed: {activation.StatusCode} {activationBody}");
        }

        // 4th device must be rejected by the plan device limit.
        var rejected = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/activate",
            new { deviceId = "dev-4", deviceName = "dev-4", platform = "Windows" });
        Assert.Equal(System.Net.HttpStatusCode.Conflict, rejected.StatusCode);
        var body = await rejected.Content.ReadAsStringAsync();
        Assert.Contains("device-limit-reached", body);
    }

    [Fact]
    public async Task SessionLimit_IsEnforced_IndependentOfDevices()
    {
        var (client, _) = await NewOrgAsync("lic2");
        using var catalog = await client.GetFromJsonAsync<JsonDocument>("/api/catalog/products");
        var product = catalog!.RootElement.GetProperty("items").EnumerateArray().First();
        var productId = product.GetProperty("id").GetGuid();
        var detail = await client.GetFromJsonAsync<JsonDocument>($"/api/catalog/products/{productId}");
        var planId = detail!.RootElement.GetProperty("plans").EnumerateArray().First().GetProperty("id").GetGuid();
        var appId = detail.RootElement.GetProperty("applications").EnumerateArray().First().GetProperty("id").GetGuid();

        var customer = await client.PostAsJsonAsync("/api/customers", new { name = "Session Customer", type = "Company" });
        var customerId = (await customer.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        var licenseResponse = await client.PostAsJsonAsync("/api/licenses",
            new { customerId, productId, applicationId = appId, planId, validDays = 365 });
        var licenseId = (await licenseResponse.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        var activation = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/activate",
            new { deviceId = "laptop-1", deviceName = "laptop-1", platform = "Windows" });
        Assert.Equal(System.Net.HttpStatusCode.OK, activation.StatusCode);

        // Plan: SessionLimit 2. Two sessions succeed, the third is rejected.
        foreach (var unused in new[] { 1, 2 })
        {
            var session = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/sessions",
                new { deviceId = "laptop-1", userId = (Guid?)null, applicationId = appId });
            Assert.Equal(System.Net.HttpStatusCode.OK, session.StatusCode);
        }
        var third = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/sessions",
            new { deviceId = "laptop-1", userId = (Guid?)null, applicationId = appId });
        Assert.Equal(System.Net.HttpStatusCode.Conflict, third.StatusCode);
        Assert.Contains("session-limit-reached", await third.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task RevokedLicense_RejectsActivation()
    {
        var (client, _) = await NewOrgAsync("lic3");
        using var catalog = await client.GetFromJsonAsync<JsonDocument>("/api/catalog/products");
        var productId = catalog!.RootElement.GetProperty("items").EnumerateArray().First().GetProperty("id").GetGuid();
        var detail = await client.GetFromJsonAsync<JsonDocument>($"/api/catalog/products/{productId}");
        var planId = detail!.RootElement.GetProperty("plans").EnumerateArray().First().GetProperty("id").GetGuid();
        var appId = detail.RootElement.GetProperty("applications").EnumerateArray().First().GetProperty("id").GetGuid();

        var customer = await client.PostAsJsonAsync("/api/customers", new { name = "Revoke Customer", type = "Company" });
        var customerId = (await customer.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();
        var licenseResponse = await client.PostAsJsonAsync("/api/licenses",
            new { customerId, productId, applicationId = appId, planId, validDays = 365 });
        var licenseId = (await licenseResponse.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        var revoke = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/revoke", new { reason = "fraud-suspected" });
        Assert.Equal(System.Net.HttpStatusCode.NoContent, revoke.StatusCode);

        var activation = await client.PostAsJsonAsync($"/api/licenses/{licenseId}/activate",
            new { deviceId = "dev-x", deviceName = "dev-x", platform = "Windows" });
        Assert.Equal(System.Net.HttpStatusCode.Conflict, activation.StatusCode);
        Assert.Contains("license-revoked", await activation.Content.ReadAsStringAsync());
    }
}

using System.Data.Common;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Identity.Entities;
using Xunit;

[assembly: CollectionBehavior(DisableTestParallelization = true)]

namespace SBM.IntegrationTests;

/// <summary>
/// Integration tests run against SQL Server LocalDB — the same engine class as production
/// (SQL Server / Azure SQL) — so migrations and SQL-specific query behavior are exercised for real.
/// Each test collection gets its own scratch database, dropped on teardown.
/// </summary>
public sealed class SbmFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public string DbName { get; } = $"SBM-Test-{Guid.NewGuid():N}";
    public InMemoryLogCollector Logs { get; } = new();
    private string ConnectionString => $"Server=(localdb)\\MSSQLLocalDB;Database={DbName};Trusted_Connection=True;TrustServerCertificate=True;Connect Timeout=120;";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureLogging(logging =>
        {
            logging.ClearProviders();
            logging.AddProvider(Logs);
        });
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Database:ApplyMigrationsOnStartup"] = "false",
                ["Seed:Enable"] = "false",
                ["ConnectionStrings:SbmDatabase"] = ConnectionString,
                ["Jwt:Key"] = Convert.ToBase64String(new byte[48]),
                ["Jwt:Issuer"] = "sbm",
                ["Jwt:Audience"] = "sbm-api",
                ["Cors:AllowedOrigins:0"] = "http://localhost:5173"
            });
        });
    }

    public async Task InitializeAsync()
    {
        _ = Services; // force host construction with the Testing configuration
        await using var scope = Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var db = services.GetRequiredService<SbmDbContext>();
        await db.Database.MigrateAsync(); // apply real EF Core migrations (acceptance: migrations work)

        var roles = services.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        await DbSeeder.SeedAsync(db, users, roles, new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["Seed:OwnerEmail"] = "owner@sbm.local", ["Seed:OwnerPassword"] = "Owner!Test123" })
            .Build());
    }

    public new async Task DisposeAsync()
    {
        await base.DisposeAsync();
        try
        {
            await using var connection = new SqlConnection($"Server=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Trusted_Connection=True;TrustServerCertificate=True;");
            await connection.OpenAsync();
            await using var command = connection.CreateCommand();
            command.CommandText = $"ALTER DATABASE [{DbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{DbName}];";
            await command.ExecuteNonQueryAsync();
        }
        catch { /* best effort cleanup of scratch database */ }
    }

    public async Task<(Guid OrgId, string OwnerToken)> CreateOrgAndOwnerAsync(string suffix)
    {
        var platformToken = await LoginAsync("owner@sbm.local", "Owner!Test123");
        using var client = CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", platformToken);
        var createResponse = await client.PostAsJsonAsync("/api/organizations",
            new { name = $"Org {suffix}", country = "EG", city = "Cairo" });
        createResponse.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await createResponse.Content.ReadAsStringAsync());
        var orgId = doc.RootElement.GetProperty("id").GetGuid();

        await using var scope = Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();
        var db = services.GetRequiredService<SbmDbContext>();
        var email = $"owner-{suffix}@local.test";
        var user = new ApplicationUser { UserName = email, Email = email, DisplayName = $"Owner {suffix}", Scope = AccountScope.Organization, EmailConfirmed = true };
        var result = await users.CreateAsync(user, "OrgOwner!Test123");
        Assert.True(result.Succeeded, string.Join("; ", result.Errors.Select(e => e.Description)));
        await users.AddToRoleAsync(user, "Owner");
        db.OrganizationMemberships.Add(new OrganizationMembership { OrganizationId = orgId, UserId = user.Id, Role = "Owner" });
        await db.SaveChangesAsync();

        var token = await LoginAsync(email, "OrgOwner!Test123");
        return (orgId, token);
    }

    public async Task<string> LoginAsync(string email, string password)
    {
        using var client = CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password });
        response.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("accessToken").GetString()!;
    }
}

public abstract class IntegrationTestBase : IClassFixture<SbmFactory>
{
    protected readonly SbmFactory Factory;
    protected IntegrationTestBase(SbmFactory factory) => Factory = factory;
}

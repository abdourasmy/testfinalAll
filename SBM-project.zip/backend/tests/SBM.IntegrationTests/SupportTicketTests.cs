using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class SupportTicketTests : IntegrationTestBase
{
    public SupportTicketTests(SbmFactory factory) : base(factory) { }

    private async Task<HttpClient> ClientAsync(string email, string password)
    {
        var token = await Factory.LoginAsync(email, password);
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return client;
    }

    [Fact]
    public async Task TicketLifecycle_And_TenantIsolation()
    {
        var orgA = await Factory.CreateOrgAndOwnerAsync("supA");
        var orgB = await Factory.CreateOrgAndOwnerAsync("supB");

        using var clientA = await ClientAsync("owner-supA@local.test", "OrgOwner!Test123");
        using var clientB = await ClientAsync("owner-supB@local.test", "OrgOwner!Test123");

        // Create ticket in Org A.
        var create = await clientA.PostAsJsonAsync("/api/support/tickets",
            new { subject = "License activation fails", description = "Device limit reached too early", category = "Licensing", priority = "High" });
        Assert.Equal(System.Net.HttpStatusCode.Created, create.StatusCode);
        var ticketId = (await create.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        // Org B cannot see Org A's ticket detail.
        var getCrossTenant = await clientB.GetAsync($"/api/support/tickets/{ticketId}");
        Assert.Equal(System.Net.HttpStatusCode.NotFound, getCrossTenant.StatusCode);

        // Org B's list does not include Org A's ticket.
        var listB = await clientB.GetStringAsync("/api/support/tickets");
        Assert.DoesNotContain(ticketId.ToString(), listB);

        // Staff (Org A owner) can comment with an internal note.
        var internalComment = await clientA.PostAsJsonAsync($"/api/support/tickets/{ticketId}/comments",
            new { body = "reproduced on-prem; checking device cap", @internal = true });
        Assert.Equal(System.Net.HttpStatusCode.OK, internalComment.StatusCode);

        // Move to InProgress -> Resolved.
        var inProgress = await clientA.PostAsJsonAsync($"/api/support/tickets/{ticketId}/status", new { status = "InProgress" });
        Assert.True(inProgress.IsSuccessStatusCode);
        var resolved = await clientA.PostAsJsonAsync($"/api/support/tickets/{ticketId}/status", new { status = "Resolved" });
        Assert.True(resolved.IsSuccessStatusCode);

        // Closed is terminal: Resolved -> Closed allowed, then Closed -> Open rejected.
        var closed = await clientA.PostAsJsonAsync($"/api/support/tickets/{ticketId}/status", new { status = "Closed" });
        Assert.True(closed.IsSuccessStatusCode);
        var reopen = await clientA.PostAsJsonAsync($"/api/support/tickets/{ticketId}/status", new { status = "InProgress" });
        Assert.Equal(System.Net.HttpStatusCode.Conflict, reopen.StatusCode);
    }

    [Fact]
    public async Task Owner_CanPostInternalNote_AndVisibilityIsInternal()
    {
        var orgA = await Factory.CreateOrgAndOwnerAsync("supM");
        var client = await ClientAsync("owner-supM@local.test", "OrgOwner!Test123");

        var create = await client.PostAsJsonAsync("/api/support/tickets",
            new { subject = "Invoice wrong", description = "VAT line missing", category = "Billing", priority = "Normal" });
        var ticketId = (await create.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        // Owner IS staff here (org Owner) — but an ordinary member role would be blocked.
        // Verify the comment is stored with Customer visibility when posted by a non-manager is n/a for Owner; instead assert internal=true works for Owner.
        var ownerNote = await client.PostAsJsonAsync($"/api/support/tickets/{ticketId}/comments",
            new { body = "checked; VAT will be added in next release", @internal = true });
        Assert.Equal(System.Net.HttpStatusCode.OK, ownerNote.StatusCode);
        var doc = await ownerNote.Content.ReadFromJsonAsync<JsonDocument>();
        Assert.Equal("Internal", doc!.RootElement.GetProperty("visibility").GetString());
    }
}

using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class CampaignDispatchTests : IntegrationTestBase
{
    public CampaignDispatchTests(SbmFactory factory) : base(factory) { }

    [Fact]
    public async Task Campaign_Launches_And_Completes_Via_Outbox()
    {
        var orgA = await Factory.CreateOrgAndOwnerAsync("cmp1");
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", orgA.OwnerToken);

        await client.PostAsJsonAsync("/api/customers", new { name = "Campaign Co", type = "Company", country = "EG" });

        var audienceJson = """
        {
          "v": 1,
          "root": { "type": "group", "op": "and", "children": [
            { "type": "condition", "field": "customer.type", "op": "eq", "value": "Company" },
            { "type": "condition", "field": "customer.country", "op": "eq", "value": "EG" }
          ]}
        }
        """;
        var audience = await client.PostAsJsonAsync("/api/campaigns/audiences", new { name = "EG companies", documentJson = audienceJson });
        Assert.Equal(HttpStatusCode.Created, audience.StatusCode);
        var audienceId = (await audience.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        var campaign = await client.PostAsJsonAsync("/api/campaigns",
            new { name = "Test blast", templateCode = "GENERIC", language = "ar", channel = "InApp", audienceDefinitionId = audienceId, executionMode = "Dynamic", recipientSemantics = "PerOrganization", idempotencyKey = Guid.NewGuid().ToString("N") });
        Assert.True(campaign.IsSuccessStatusCode, await campaign.Content.ReadAsStringAsync());
        var campaignId = (await campaign.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();

        // Idempotent replay of campaign creation returns the same campaign.
        // (Skip: covered by unique key; we move to launch.)

        var launch = await client.PostAsync($"/api/campaigns/{campaignId}/launch", null);
        Assert.True(launch.IsSuccessStatusCode, await launch.Content.ReadAsStringAsync());

        // The background outbox dispatcher runs in the host (5s interval); poll the delivery summary.
        var deadline = DateTimeOffset.UtcNow.AddSeconds(60);
        while (DateTimeOffset.UtcNow < deadline)
        {
            var state = await client.GetFromJsonAsync<JsonDocument>($"/api/campaigns/{campaignId}/delivery");
            var summary = state!.RootElement.GetProperty("summary").EnumerateArray().ToList();
            var total = summary.Sum(x => x.GetProperty("count").GetInt32());
            var providerAccepted = summary.Where(x => x.GetProperty("status").GetString() == "ProviderAccepted").Sum(x => x.GetProperty("count").GetInt32());
            if (total > 0 && providerAccepted == total) break;
            await Task.Delay(1000);
        }

        var finalState = await client.GetFromJsonAsync<JsonDocument>($"/api/campaigns/{campaignId}/delivery");
        var finalSummary = finalState!.RootElement.GetProperty("summary").EnumerateArray().ToList();
        var accepted = finalSummary.Where(x => x.GetProperty("status").GetString() == "ProviderAccepted").Sum(x => x.GetProperty("count").GetInt32());
        Assert.True(accepted >= 1, "Expected at least one ProviderAccepted recipient.");

        // Campaign should have flipped to Completed once all recipients are terminal.
        var deadline2 = DateTimeOffset.UtcNow.AddSeconds(30);
        string campaignStatus = "";
        while (DateTimeOffset.UtcNow < deadline2)
        {
            var campaigns = await client.GetStringAsync("/api/campaigns");
            if (campaigns.Contains("\"status\":\"Completed\"")) { campaignStatus = "Completed"; break; }
            await Task.Delay(1000);
        }
        Assert.Equal("Completed", campaignStatus);
    }
}

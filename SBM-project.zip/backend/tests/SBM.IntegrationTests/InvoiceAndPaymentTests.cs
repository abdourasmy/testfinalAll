using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace SBM.IntegrationTests;

public class InvoiceAndPaymentTests : IntegrationTestBase
{
    public InvoiceAndPaymentTests(SbmFactory factory) : base(factory) { }

    private async Task<(HttpClient Client, Guid CustomerId)> ClientWithCustomerAsync(string suffix)
    {
        var (orgId, token) = await Factory.CreateOrgAndOwnerAsync(suffix);
        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var customer = await client.PostAsJsonAsync("/api/customers", new { name = $"Invoice Customer {suffix}", type = "Company" });
        var customerId = (await customer.Content.ReadFromJsonAsync<JsonDocument>())!.RootElement.GetProperty("id").GetGuid();
        return (client, customerId);
    }

    private static object InvoicePayload(Guid customerId, decimal unitPrice) => new
    {
        customerId,
        currency = "EGP",
        items = new[] { new { description = "Subscription month", quantity = 1, unitPrice, discountPercent = 0m, taxPercent = 14m } }
    };

    [Fact]
    public async Task InvoiceNumbering_IsUnique_UnderConcurrency()
    {
        var (client, customerId) = await ClientWithCustomerAsync("inv1");
        var tasks = Enumerable.Range(0, 5).Select(_ => client.PostAsJsonAsync("/api/invoices", InvoicePayload(customerId, 100m))).ToList();
        var responses = await Task.WhenAll(tasks);
        var details = new List<string>();
        foreach (var r in responses.Where(r => r.StatusCode != HttpStatusCode.Created))
        {
            details.Add($"{(int)r.StatusCode}: {await r.Content.ReadAsStringAsync()}");
        }
        Assert.True(responses.All(r => r.StatusCode == HttpStatusCode.Created), string.Join(" | ", details) + "\n---LOGS---\n" + Factory.Logs.DumpSince());

        var numbers = new List<string>();
        foreach (var response in responses)
        {
            var doc = await response.Content.ReadFromJsonAsync<JsonDocument>();
            numbers.Add(doc!.RootElement.GetProperty("number").GetString()!);
        }
        Assert.Equal(numbers.Count, numbers.Distinct(StringComparer.Ordinal).Count());
        Assert.All(numbers, n => Assert.Matches(@"^INV-\d{4}-\d{6}$", n));
    }

    [Fact]
    public async Task Payment_IdempotencyKey_PreventsDoubleProcessing()
    {
        var (client, customerId) = await ClientWithCustomerAsync("pay1");
        var invoiceResponse = await client.PostAsJsonAsync("/api/invoices", InvoicePayload(customerId, 500m));
        var invoiceDoc = await invoiceResponse.Content.ReadFromJsonAsync<JsonDocument>();
        var invoiceId = invoiceDoc!.RootElement.GetProperty("id").GetGuid();

        var payment = new { invoiceId, amount = 570m, currency = "EGP", method = "Manual", providerReference = "ref-1", idempotencyKey = Guid.NewGuid().ToString("N"), confirmedByProvider = true };
        var first = await client.PostAsJsonAsync("/api/invoices/payments/confirm", payment);
        first.EnsureSuccessStatusCode();
        var firstDoc = await first.Content.ReadFromJsonAsync<JsonDocument>();
        Assert.False(firstDoc!.RootElement.GetProperty("duplicate").GetBoolean());

        // Replay the exact same confirmation (provider retry).
        var second = await client.PostAsJsonAsync("/api/invoices/payments/confirm", payment);
        second.EnsureSuccessStatusCode();
        var secondDoc = await second.Content.ReadFromJsonAsync<JsonDocument>();
        Assert.True(secondDoc!.RootElement.GetProperty("duplicate").GetBoolean());

        // Invoice reflects a single payment, fully paid.
        var check = await client.GetFromJsonAsync<JsonDocument>($"/api/invoices/{invoiceId}");
        var invoice = check!.RootElement.GetProperty("invoice");
        Assert.Equal(570m, invoice.GetProperty("amountPaid").GetDecimal());
        Assert.Equal("Paid", invoice.GetProperty("status").GetString());
    }

    [Fact]
    public async Task DecimalPrecision_LargeAmounts()
    {
        var (client, customerId) = await ClientWithCustomerAsync("dec1");
        var invoiceResponse = await client.PostAsJsonAsync("/api/invoices",
            new { customerId, currency = "EGP", items = new[] { new { description = "Big", quantity = 7, unitPrice = 1999.99m, discountPercent = 7.5m, taxPercent = 14m } } });
        invoiceResponse.EnsureSuccessStatusCode();
        var doc = await invoiceResponse.Content.ReadFromJsonAsync<JsonDocument>();
        var grandTotal = doc!.RootElement.GetProperty("grandTotal").GetDecimal();
        // 7 * 1999.99 = 13999.93; 7.5% discount -> 12949.93525 -> 12949.94; 14% tax -> 1812.9916 -> 1812.99; total 14762.93
        Assert.Equal(14762.93m, grandTotal);
    }
}

using SBM.Shared.Security;
using Xunit;

namespace SBM.UnitTests;

public class ProductionSeedGuardTests
{
    [Fact]
    public void Production_SeedEnableTrue_Throws()
    {
        var ex = Assert.Throws<InvalidOperationException>(() => ProductionSeedGuard.EnsureSafe(true, true, false));
        Assert.Contains("Production startup refused", ex.Message);
    }

    [Fact]
    public void Production_DemoDataTrue_Throws()
    {
        var ex = Assert.Throws<InvalidOperationException>(() => ProductionSeedGuard.EnsureSafe(true, false, true));
        Assert.Contains("Production startup refused", ex.Message);
    }

    [Fact]
    public void Production_BothFalse_DoesNotThrow()
    {
        var exception = Record.Exception(() => ProductionSeedGuard.EnsureSafe(true, false, false));
        Assert.Null(exception);
    }

    [Fact]
    public void Development_SeedEnableTrue_DoesNotThrow()
    {
        var exception = Record.Exception(() => ProductionSeedGuard.EnsureSafe(false, true, true));
        Assert.Null(exception);
    }
}

using SBM.Modules.Subscriptions.Domain;
using SBM.Modules.Subscriptions.Entities;
using Xunit;

namespace SBM.UnitTests;

public class SubscriptionTests
{
    [Theory]
    [InlineData(SubscriptionStatus.Trial, SubscriptionStatus.Active, true)]
    [InlineData(SubscriptionStatus.Active, SubscriptionStatus.PastDue, true)]
    [InlineData(SubscriptionStatus.PastDue, SubscriptionStatus.GracePeriod, true)]
    [InlineData(SubscriptionStatus.GracePeriod, SubscriptionStatus.Active, true)]
    [InlineData(SubscriptionStatus.GracePeriod, SubscriptionStatus.Expired, true)]
    [InlineData(SubscriptionStatus.Expired, SubscriptionStatus.Active, true)]
    [InlineData(SubscriptionStatus.Cancelled, SubscriptionStatus.Active, false)] // terminal
    [InlineData(SubscriptionStatus.Active, SubscriptionStatus.Trial, false)]
    public void Transitions(SubscriptionStatus from, SubscriptionStatus to, bool expected) =>
        Assert.Equal(expected, SubscriptionStateMachine.CanTransition(from, to));

    [Fact]
    public void GracePeriod_Then_ReadOnly_DataNeverDeleted()
    {
        // Not expired yet
        var active = ExpirationPolicy.Evaluate(daysPastExpiry: -1, gracePeriodDays: 7);
        Assert.Equal(SubscriptionStatus.Active, active.Status);
        Assert.Equal(AccessMode.Full, active.Access);

        // Within 7-day grace: full access preserved
        var grace = ExpirationPolicy.Evaluate(daysPastExpiry: 7, gracePeriodDays: 7);
        Assert.Equal(SubscriptionStatus.GracePeriod, grace.Status);
        Assert.Equal(AccessMode.Full, grace.Access);

        // After grace: ReadOnly fallback, data preserved
        var expired = ExpirationPolicy.Evaluate(daysPastExpiry: 8, gracePeriodDays: 7);
        Assert.Equal(SubscriptionStatus.Expired, expired.Status);
        Assert.Equal(AccessMode.ReadOnly, expired.Access);
        Assert.True(expired.ReadOnlyApplied);
    }

    [Fact]
    public void GracePeriod_Configurable()
    {
        var grace = ExpirationPolicy.Evaluate(daysPastExpiry: 14, gracePeriodDays: 30);
        Assert.Equal(SubscriptionStatus.GracePeriod, grace.Status);
    }
}

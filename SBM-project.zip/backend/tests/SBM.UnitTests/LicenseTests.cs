using SBM.Modules.Licensing.Crypto;
using SBM.Modules.Licensing.Domain;
using SBM.Modules.Licensing.Entities;
using Xunit;

namespace SBM.UnitTests;

public class LicenseCryptoTests
{
    private static LicensePayload SamplePayload(Guid? licenseId = null, string kid = "kid-1") => new(
        LicensePayload.CurrentVersion, "sbm", licenseId ?? Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(),
        Guid.NewGuid(), Guid.NewGuid(), DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 10,
        DateTimeOffset.UtcNow.AddDays(30).ToUnixTimeSeconds(), new[] { "TICKETS.BASIC" },
        new LicensePolicy(3), new LicensePolicy(2), kid);

    private static (string PublicPem, string PrivatePem, string KeyId) MakeKey(string keyId)
    {
        var (pub, priv) = EcdsaLicenseSigner.GenerateKeyPair();
        return (pub, priv, keyId);
    }

    [Fact]
    public void SignVerify_RoundTrip()
    {
        var (pub, priv, kid) = MakeKey("kid-1");
        var signer = new EcdsaLicenseSigner();
        var token = signer.Sign(SamplePayload(kid: kid), priv, kid).Token;

        var verified = signer.Verify(token, k => k == kid ? pub : null, out var failure);
        Assert.Null(failure);
        Assert.NotNull(verified);
        Assert.Equal(kid, verified!.KeyId);
    }

    [Fact]
    public void TamperedPayload_Rejected()
    {
        var (pub, priv, kid) = MakeKey("kid-1");
        var signer = new EcdsaLicenseSigner();
        var token = signer.Sign(SamplePayload(kid: kid), priv, kid).Token;

        var parts = token.Split('.');
        var payloadJson = System.Text.Encoding.UTF8.GetString(Base64UrlDecode(parts[0]));
        var tampered = payloadJson.Replace("TICKETS.BASIC", "TICKETS.HAX"); // valid JSON, but signature no longer matches
        var forged = Base64UrlEncode(System.Text.Encoding.UTF8.GetBytes(tampered)) + "." + parts[1];

        var verified = signer.Verify(forged, k => k == kid ? pub : null, out var failure);
        Assert.Null(verified);
        Assert.Equal("invalid-signature", failure);
    }

    [Fact]
    public void WrongKeyId_Rejected()
    {
        var (pub, priv, kid) = MakeKey("kid-1");
        var signer = new EcdsaLicenseSigner();
        var token = signer.Sign(SamplePayload(kid: kid), priv, kid).Token;
        var verified = signer.Verify(token, _ => null, out var failure);
        Assert.Null(verified);
        Assert.Equal("unknown-key", failure);
    }

    [Fact]
    public void KeyRotation_OldTokenStillVerifies_AfterRotation()
    {
        var old = MakeKey("kid-old");
        var current = MakeKey("kid-new");
        var signer = new EcdsaLicenseSigner();
        var oldToken = signer.Sign(SamplePayload(kid: old.KeyId), old.PrivatePem, old.KeyId).Token;

        // Rotate: new key active, old key retired but still published for verification.
        var keys = new Dictionary<string, string> { [current.KeyId] = current.PublicPem, [old.KeyId] = old.PublicPem };
        var verified = signer.Verify(oldToken, k => keys.GetValueOrDefault(k), out var failure);
        Assert.Null(failure);
        Assert.NotNull(verified);
    }

    [Fact]
    public void GarbageToken_Rejected()
    {
        var signer = new EcdsaLicenseSigner();
        Assert.Null(signer.Verify("not-a-token", _ => null, out var failure));
        Assert.Equal("malformed-token", failure);
    }

    private static string Base64UrlEncode(byte[] bytes) => Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    private static byte[] Base64UrlDecode(string s)
    {
        var b64 = s.Replace('-', '+').Replace('_', '/');
        b64 = b64.PadRight(b64.Length + (4 - b64.Length % 4) % 4, '=');
        return Convert.FromBase64String(b64);
    }
}

public class LicenseStateMachineTests
{
    [Theory]
    [InlineData(LicenseState.Active, LicenseState.Suspended, true)]
    [InlineData(LicenseState.Active, LicenseState.Revoked, true)]
    [InlineData(LicenseState.Suspended, LicenseState.Active, true)]
    [InlineData(LicenseState.Revoked, LicenseState.Active, false)]   // revoked is terminal
    [InlineData(LicenseState.Revoked, LicenseState.Suspended, false)]
    [InlineData(LicenseState.Expired, LicenseState.Active, true)]    // renewed
    [InlineData(LicenseState.Active, LicenseState.Active, false)]
    public void Transitions(LicenseState from, LicenseState to, bool expected) =>
        Assert.Equal(expected, LicenseStateMachine.CanTransition(from, to));

    [Fact]
    public void RevokedLicense_RemainsInvalid_EvenIfSubscriptionActive()
    {
        // The license state machine has no path from Revoked to Active — a subscription being
        // active cannot reactivate a revoked license; only an explicit renewal flow applies to Expired.
        Assert.Throws<InvalidOperationException>(() => LicenseStateMachine.EnsureTransition(LicenseState.Revoked, LicenseState.Active));
    }
}

public class DeviceAndSessionPolicyTests
{
    [Theory]
    [InlineData(0, 3, true)]
    [InlineData(2, 3, true)]
    [InlineData(3, 3, false)]
    [InlineData(99, 0, true)]   // 0 = unlimited
    public void DeviceLimit(int active, int limit, bool expected) => Assert.Equal(expected, DevicePolicy.CanActivate(active, limit));

    [Theory]
    [InlineData(0, 2, true)]
    [InlineData(1, 2, true)]
    [InlineData(2, 2, false)]
    [InlineData(99, 0, true)]
    public void SessionLimit(int live, int limit, bool expected) => Assert.Equal(expected, SessionPolicy.CanStartSession(live, limit));

    [Fact]
    public void Transfer_WithinPolicy_Allowed()
    {
        var decision = TransferPolicy.Evaluate(transferCount: 0, maxTransfers: 3, lastTransferredAt: null, cooldownDays: 7, now: DateTimeOffset.UtcNow);
        Assert.True(decision.Allowed);
    }

    [Fact]
    public void Transfer_LimitReached_RequiresApproval()
    {
        var decision = TransferPolicy.Evaluate(3, 3, DateTimeOffset.UtcNow.AddDays(-30), 7, DateTimeOffset.UtcNow);
        Assert.False(decision.Allowed);
    }

    [Fact]
    public void Transfer_CooldownActive_RequiresApproval()
    {
        var decision = TransferPolicy.Evaluate(1, 3, DateTimeOffset.UtcNow.AddDays(-2), 7, DateTimeOffset.UtcNow);
        Assert.False(decision.Allowed);
    }
}

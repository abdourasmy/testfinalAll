using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using SBM.Modules.Support.Entities;
using SBM.Modules.Support.Domain;
using Xunit;

namespace SBM.UnitTests;

public class SupportRulesTests
{
    [Theory]
    [InlineData(TicketStatus.Open, TicketStatus.InProgress, true)]
    [InlineData(TicketStatus.Open, TicketStatus.Resolved, true)]
    [InlineData(TicketStatus.InProgress, TicketStatus.Closed, true)]
    [InlineData(TicketStatus.Resolved, TicketStatus.InProgress, true)]  // reopen path
    [InlineData(TicketStatus.Resolved, TicketStatus.Open, false)]
    [InlineData(TicketStatus.Closed, TicketStatus.InProgress, false)]   // terminal
    public void Transitions(TicketStatus from, TicketStatus to, bool expected) =>
        Assert.Equal(expected, TicketStateMachine.CanTransition(from, to));

    [Fact]
    public void SlaDue_DefaultsByPriority()
    {
        Assert.Equal(TimeSpan.FromHours(4), SupportTicket.DefaultSla(TicketPriority.Urgent));
        Assert.Equal(TimeSpan.FromHours(24), SupportTicket.DefaultSla(TicketPriority.High));
        Assert.Equal(TimeSpan.FromHours(72), SupportTicket.DefaultSla(TicketPriority.Normal));
        Assert.Equal(TimeSpan.FromHours(168), SupportTicket.DefaultSla(TicketPriority.Low));
    }
}

using SBM.Shared.Versioning;
using Xunit;

namespace SBM.UnitTests;

public class SemVerTests
{
    [Theory]
    [InlineData("2.1.0", 2, 1, 0)]
    [InlineData("1.0.0", 1, 0, 0)]
    [InlineData("0.0.1", 0, 0, 1)]
    public void Parse_Valid(string input, int major, int minor, int patch)
    {
        var v = SemVer.Parse(input);
        Assert.Equal(major, v.Major);
        Assert.Equal(minor, v.Minor);
        Assert.Equal(patch, v.Patch);
    }

    [Theory]
    [InlineData("banana")]
    [InlineData("1.2")]
    [InlineData("1.2.x")]
    [InlineData("01.2.3")]
    [InlineData("")]
    public void Parse_Invalid_Rejected(string input) => Assert.False(SemVer.TryParse(input, out _));

    [Fact]
    public void Ordering_NumericNotLexicographic()
    {
        Assert.True(SemVer.Parse("2.10.0") > SemVer.Parse("2.9.0"));
        Assert.True(SemVer.Parse("10.0.0") > SemVer.Parse("9.0.0"));
    }

    [Fact]
    public void Prerelease_LowerThanRelease()
    {
        Assert.True(SemVer.Parse("2.1.0-rc.1") < SemVer.Parse("2.1.0"));
        Assert.True(SemVer.Parse("2.1.0-alpha") < SemVer.Parse("2.1.0-beta"));
        Assert.True(SemVer.Parse("2.1.0-alpha.1") > SemVer.Parse("2.1.0-alpha"));
        Assert.True(SemVer.Parse("1.0.0") > SemVer.Parse("1.0.0-rc.99"));
    }

    [Fact]
    public void Range_Contains()
    {
        var range = SemVerRange.Parse(">=1.0.0 <2.0.0");
        Assert.True(range.Contains(SemVer.Parse("1.5.0")));
        Assert.True(range.Contains(SemVer.Parse("1.0.0")));
        Assert.False(range.Contains(SemVer.Parse("2.0.0")));
        Assert.False(range.Contains(SemVer.Parse("0.9.9")));
    }

    [Fact]
    public void MajorFamily_2x()
    {
        var range = SemVerRange.ParseMajorFamily(2);
        Assert.True(range.Contains(SemVer.Parse("2.0.0")));
        Assert.True(range.Contains(SemVer.Parse("2.99.1")));
        Assert.False(range.Contains(SemVer.Parse("3.0.0")));
        Assert.False(range.Contains(SemVer.Parse("2.1.0-rc.1"))); // families match stable releases
    }
}

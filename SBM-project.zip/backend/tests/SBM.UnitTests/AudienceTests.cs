using System.Text.Json;
using SBM.Modules.Notifications.Audience;
using SBM.Modules.Notifications.Delivery;
using Xunit;

namespace SBM.UnitTests;

public class AudienceRuleTests
{
    private static AudienceDocument Doc(string rootJson)
    {
        var json = $"{{ \"v\": 1, \"root\": {rootJson} }}";
        return JsonSerializer.Deserialize<AudienceDocument>(json)!;
    }

    private static AudienceCandidate Candidate(Action<AudienceCandidate>? configure = null)
    {
        var c = new AudienceCandidate
        {
            EntityId = Guid.NewGuid(),
            CustomerId = Guid.NewGuid(),
            CustomerType = "Company",
            CustomerStatus = "Active",
            CustomerRegisteredAt = new DateTimeOffset(2026, 5, 1, 0, 0, 0, TimeSpan.Zero),
            CustomerCountry = "EG",
            CustomerCity = "Cairo",
            AppVersion = "2.1.0",
            SubscriptionStatus = "Active",
            LicenseState = "Active",
            OrganizationId = Guid.NewGuid(),
            LastActivityAt = DateTimeOffset.UtcNow
        };
        configure?.Invoke(c);
        return c;
    }

    private static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = false };

    [Fact]
    public void And_Rule_Matches()
    {
        var doc = Doc("""{"type":"group","op":"and","children":[{"type":"condition","field":"customer.status","op":"eq","value":"Active"},{"type":"condition","field":"customer.country","op":"eq","value":"EG"}]}""");
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate()));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.CustomerCountry = "SA")));
    }

    [Fact]
    public void Or_Rule_Matches()
    {
        var doc = Doc("""{"type":"group","op":"or","children":[{"type":"condition","field":"customer.country","op":"eq","value":"EG"},{"type":"condition","field":"customer.country","op":"eq","value":"SA"}]}""");
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.CustomerCountry = "SA")));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.CustomerCountry = "AE")));
    }

    [Fact]
    public void Not_Rule_Negates()
    {
        var doc = Doc("""{"type":"group","op":"not","children":[{"type":"condition","field":"customer.status","op":"eq","value":"Active"}]}""");
        AudienceValidator.Validate(doc);
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.CustomerStatus = "Active")));
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.CustomerStatus = "Suspended")));
    }

    [Fact]
    public void Nested_Groups_Match()
    {
        var doc = Doc("""
        {"type":"group","op":"and","children":[
            {"type":"group","op":"or","children":[
                {"type":"condition","field":"customer.country","op":"eq","value":"EG"},
                {"type":"condition","field":"customer.country","op":"eq","value":"SA"}
            ]},
            {"type":"condition","field":"subscription.status","op":"eq","value":"Active"}
        ]}
        """);
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => { c.CustomerCountry = "SA"; c.SubscriptionStatus = "Active"; })));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => { c.CustomerCountry = "AE"; c.SubscriptionStatus = "Active"; })));
    }

    [Fact]
    public void Validation_RejectsUnknownField()
    {
        var doc = Doc("""{"type":"condition","field":"sql.injection","op":"eq","value":"x"}""");
        var ex = Assert.Throws<AudienceValidationException>(() => AudienceValidator.Validate(doc));
        Assert.Contains(ex.Errors, e => e.Contains("Unknown field"));
    }

    [Fact]
    public void Validation_RejectsOperatorNotAllowedForField()
    {
        var doc = Doc("""{"type":"condition","field":"customer.country","op":"gt","value":"EG"}""");
        Assert.Throws<AudienceValidationException>(() => AudienceValidator.Validate(doc));
    }

    [Fact]
    public void Validation_RejectsExcessiveNesting()
    {
        var inner = """{"type":"condition","field":"customer.status","op":"eq","value":"Active"}""";
        var node = inner;
        for (var i = 0; i < 9; i++)
            node = $"{{\"type\":\"group\",\"op\":\"not\",\"children\":[{node}]}}";
        var doc = Doc(node);
        Assert.Throws<AudienceValidationException>(() => AudienceValidator.Validate(doc));
    }

    [Fact]
    public void Version_ExactMatch()
    {
        var doc = Doc("""{"type":"condition","field":"app.version","op":"eq","value":"2.1.0"}""");
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.1.0")));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.1.1")));
    }

    [Fact]
    public void Version_Range()
    {
        var doc = Doc("""{"type":"condition","field":"app.version","op":"range","value":">=2.0.0 <3.0.0"}""");
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.5.3")));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "3.0.0")));
    }

    [Fact]
    public void Version_MajorFamily()
    {
        var doc = Doc("""{"type":"condition","field":"app.version","op":"family","value":"2.x"}""");
        AudienceValidator.Validate(doc);
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.9.9")));
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "3.0.0")));
    }

    [Fact]
    public void Version_PrereleaseHandled_Properly()
    {
        var doc = Doc("""{"type":"condition","field":"app.version","op":"gte","value":"2.1.0"}""");
        AudienceValidator.Validate(doc);
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.1.0-rc.1"))); // rc < release
        Assert.True(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "2.1.0")));
    }

    [Fact]
    public void InvalidVersionString_NeverMatches()
    {
        var doc = Doc("""{"type":"condition","field":"app.version","op":"eq","value":"2.1.0"}""");
        AudienceValidator.Validate(doc);
        Assert.False(AudienceEvaluator.Evaluate(doc.Root, Candidate(c => c.AppVersion = "banana")));
    }

    [Fact]
    public void TopN_Deterministic_WithStableTieBreaker()
    {
        var ts = new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
        var candidates = Enumerable.Range(0, 50).Select(i => new AudienceCandidate
        {
            EntityId = Guid.Parse($"00000000-0000-0000-0000-{i:D12}"),
            CustomerId = Guid.NewGuid(),
            CustomerRegisteredAt = ts // identical timestamps force tie-breaking by id
        }).ToList();

        var req = new TopNRequest(RankedEntity.Customer, "customer.registeredAt", Descending: true, N: 10, PreFilter: null);
        var first = TopNSelector.Select(req, candidates);
        var second = TopNSelector.Select(req, candidates.AsEnumerable().Reverse()); // input order must not matter

        Assert.Equal(first.Select(c => c.EntityId), second.Select(c => c.EntityId));
        Assert.Equal(10, first.Count);
    }

    [Fact]
    public void TopN_OrdersBySelectedField()
    {
        var baseTime = new DateTimeOffset(2026, 3, 1, 0, 0, 0, TimeSpan.Zero);
        var candidates = Enumerable.Range(0, 100).Select(i => new AudienceCandidate
        {
            EntityId = Guid.NewGuid(),
            CustomerId = Guid.NewGuid(),
            LastPurchaseAt = i % 2 == 0 ? baseTime.AddDays(i) : null,
            CustomerRegisteredAt = baseTime.AddDays(100 - i)
        }).ToList();

        var byPurchase = TopNSelector.Select(new TopNRequest(RankedEntity.Customer, "purchase.lastAt", true, 5, null), candidates);
        Assert.All(byPurchase, c => Assert.NotNull(c.LastPurchaseAt));
        Assert.True(byPurchase.Select(c => c.LastPurchaseAt).SequenceEqual(byPurchase.Select(c => c.LastPurchaseAt).OrderByDescending(x => x)));
    }

    [Fact]
    public void DeliveryPlanner_DedupesByRecipientSemantics()
    {
        var org = Guid.NewGuid();
        var candidates = new[]
        {
            new DeliveryCandidate("endpoint-a", org, "Email", false, null, null, "Africa/Cairo", 0, 5),
            new DeliveryCandidate("endpoint-b", org, "Email", false, null, null, "Africa/Cairo", 0, 5), // same org, different endpoint
        };
        var planned = DeliveryPlanner.Plan(candidates, DeliveryPlanner.RecipientSemanticsFor.PerOrganization, DateTimeOffset.UtcNow);
        Assert.Equal(2, planned.Count);
        Assert.Equal(1, planned.Count(p => !p.Suppressed));
        Assert.Equal(1, planned.Count(p => p.SuppressionReason == "duplicate-recipient"));
    }

    [Fact]
    public void DeliveryPlanner_RespectsOptOut_AndFrequencyCap_AndQuietHours()
    {
        var now = DateTimeOffset.UtcNow;
        var candidates = new[]
        {
            new DeliveryCandidate("e1", Guid.NewGuid(), "Email", true, null, null, "UTC", 0, 5),
            new DeliveryCandidate("e2", Guid.NewGuid(), "Email", false, null, null, "UTC", 5, 5),
            new DeliveryCandidate("e3", Guid.NewGuid(), "Email", false, 0, 24 * 60, "UTC", 0, 5), // quiet hours all day
        };
        var planned = DeliveryPlanner.Plan(candidates, DeliveryPlanner.RecipientSemanticsFor.PerDeviceEndpoint, now);
        Assert.Equal(new[] { "opt-out", "frequency-cap", "quiet-hours" }, planned.Select(p => p.SuppressionReason).ToArray());
    }

    [Fact]
    public void RetryPolicy_ExponentialBackoff_AndDeadLetter()
    {
        var policy = new RetryPolicy(maxAttempts: 5, baseDelay: TimeSpan.FromSeconds(10));
        Assert.True(policy.DelayForAttempt(3, 0) > policy.DelayForAttempt(2, 0));
        Assert.True(policy.DelayForAttempt(2, 0) > policy.DelayForAttempt(1, 0));
        Assert.False(policy.ShouldDeadLetter(4));
        Assert.True(policy.ShouldDeadLetter(5));
    }

    [Fact]
    public void ProviderErrorClassifier_RetryableVsPermanent()
    {
        Assert.True(ProviderErrorClassifier.IsRetryable(ProviderErrorClassifier.Classify("timeout", 504)));
        Assert.True(ProviderErrorClassifier.IsRetryable(ProviderErrorClassifier.Classify("rate_limited", 429)));
        Assert.False(ProviderErrorClassifier.IsRetryable(ProviderErrorClassifier.Classify("invalid_token", 400)));
    }
}

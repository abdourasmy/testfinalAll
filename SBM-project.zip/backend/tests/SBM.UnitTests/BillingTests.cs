using SBM.Modules.Billing.Entities;
using Xunit;

namespace SBM.UnitTests;

public class BillingMathTests
{
    [Fact]
    public void LineTotals_UseDecimalAndAwayFromZeroRounding()
    {
        var item = new InvoiceItem
        {
            Quantity = 3,
            UnitPrice = 33.33m,
            DiscountPercent = 10m,
            TaxPercent = 14m // VAT for illustrative purposes
        };
        Assert.Equal(89.99m, item.LineNet);   // 3 * 33.33 * 0.9 = 89.991 -> 89.99
        Assert.Equal(12.60m, item.LineTax);   // 89.99 * 0.14 = 12.5986 -> 12.60
        Assert.Equal(102.59m, item.LineTotal);
    }

    [Fact]
    public void MonetaryMath_IsNeverFloat()
    {
        // 0.1 + 0.2 must equal 0.3 exactly in decimal (it does not in binary floating point).
        Assert.Equal(0.3m, 0.1m + 0.2m);
        var total = Enumerable.Range(1, 10).Aggregate(0m, (acc, _) => acc + 0.1m);
        Assert.Equal(1.0m, total);
    }

    [Fact]
    public void Outstanding_Balance_IsDerived()
    {
        var invoice = new Invoice { GrandTotal = 1000m, AmountPaid = 250m };
        Assert.Equal(750m, invoice.Outstanding);
    }
}

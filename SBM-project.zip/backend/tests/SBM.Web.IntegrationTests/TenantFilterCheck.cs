using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using SBM.Shared.Abstractions;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Identity.Entities;
using SBM.Infrastructure.Persistence;
using Xunit;

namespace SBM.IntegrationTests;

/// <summary>Regression harness for the EF Core global tenant query filters (defense-in-depth; ADR 0003).</summary>
public static class TenantFilterCheck
{
    public static async Task RunAsync()
    {
        var dbName = "SBM-FilterCheck-" + Guid.NewGuid().ToString("N");
        var conn = $"Server=(localdb)\\MSSQLLocalDB;Database={dbName};Trusted_Connection=True;TrustServerCertificate=True;";
        var a = Guid.NewGuid(); var b = Guid.NewGuid();

        var options = new DbContextOptionsBuilder<SbmDbContext>().UseSqlServer(conn).Options;
        Guid orgA, orgB;
        await using (var ctx = new SbmDbContext(options, tenantContext: null))
        {
            await ctx.Database.MigrateAsync();
            ctx.Organizations.Add(new Organization { Name = "FilterOrgA" });
            ctx.Organizations.Add(new Organization { Name = "FilterOrgB" });
            ctx.Customers.Add(new Customer { OrganizationId = Guid.Empty, Name = "noop" }); // placeholder, replaced below
            await ctx.SaveChangesAsync();
            orgA = (await ctx.Organizations.FirstAsync(o => o.Name == "FilterOrgA")).Id;
            orgB = (await ctx.Organizations.FirstAsync(o => o.Name == "FilterOrgB")).Id;
            var placeholder = await ctx.Customers.FirstAsync(c => c.Name == "noop");
            ctx.Customers.Add(new Customer { OrganizationId = orgA, Name = "CustomerA", Type = CustomerType.Company });
            ctx.Customers.Add(new Customer { OrganizationId = orgB, Name = "CustomerB", Type = CustomerType.Company });
            await ctx.SaveChangesAsync();
        }

        var tenantA = new TestTenant { OrganizationId = orgA, UserId = a, UserName = "a", IsPlatformAdmin = false };
        var tenantB = new TestTenant { OrganizationId = orgB, UserId = b, UserName = "b", IsPlatformAdmin = false };
        var admin = new TestTenant { OrganizationId = null, UserId = Guid.NewGuid(), UserName = "admin", IsPlatformAdmin = true };

        await using var ctxA = new SbmDbContext(options, tenantA);
        var namesA = await ctxA.Customers.Where(c => c.Name != "noop").Select(c => c.Name).ToListAsync();
        await using var ctxB = new SbmDbContext(options, tenantB);
        var namesB = await ctxB.Customers.Where(c => c.Name != "noop").Select(c => c.Name).ToListAsync();
        await using var ctxAdmin = new SbmDbContext(options, admin);
        var namesAdmin = await ctxAdmin.Customers.Where(c => c.Name != "noop").Select(c => c.Name).ToListAsync();
        await using var ctxNone = new SbmDbContext(options, tenantContext: null);
        var namesNone = await ctxNone.Customers.Where(c => c.Name != "noop").Select(c => c.Name).ToListAsync();

        Console.WriteLine($"A: {string.Join(",", namesA)} | B: {string.Join(",", namesB)} | admin: {string.Join(",", namesAdmin)} | tenant:null {string.Join(",", namesNone)}");
        var pass = namesA.Count == 1 && namesA[0] == "CustomerA" && namesB.Count == 1 && namesB[0] == "CustomerB" && namesAdmin.Count == 2 && namesNone.Count == 2;
        Assert.True(pass, $"Global tenant filters are not tenant-safe. A={string.Join(",", namesA)} B={string.Join(",", namesB)} admin={string.Join(",", namesAdmin)} null={string.Join(",", namesNone)}");

        await using var cleanup = new SqlConnection("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Trusted_Connection=True;TrustServerCertificate=True;");
        await cleanup.OpenAsync();
        await using var cmd = cleanup.CreateCommand();
        cmd.CommandText = $"ALTER DATABASE [{dbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{dbName}];";
        await cmd.ExecuteNonQueryAsync();
    }
}

internal sealed class TestTenant : ITenantContext
{
    public Guid? OrganizationId { get; set; }
    public Guid? UserId { get; set; }
    public string? UserName { get; set; }
    public bool IsPlatformAdmin { get; set; }
    public bool IsInOrganization(Guid organizationId) => IsPlatformAdmin || OrganizationId == organizationId;
}

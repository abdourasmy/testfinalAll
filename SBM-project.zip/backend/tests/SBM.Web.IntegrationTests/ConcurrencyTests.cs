using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using Xunit;

namespace SBM.IntegrationTests;

/// <summary>Concurrency hardening tests (spec §15/§16). Real LocalDB, real HTTP + service calls.</summary>
public class ConcurrencyTests : WebIntegrationTestBase
{
    public ConcurrencyTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task DeviceActivation_ConcurrentCalls_NeverExceedDeviceLimit()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);
        var app = await db.ProductApplications.FirstAsync(a => a.Code == "repair-desktop");
        var plan = await db.PricingPlans.FirstAsync(p => p.Code == "PRO-MONTHLY");
        var license = new License
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            ProductId = plan.ProductId,
            ApplicationId = app.Id,
            PlanId = plan.Id,
            Type = SBM.Modules.Licensing.Entities.LicenseType.Hybrid,
            State = LicenseState.Active,
            DeviceLimit = 2,
            IssuedAt = DateTimeOffset.UtcNow,
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(30)
        };
        db.Licenses.Add(license);
        await db.SaveChangesAsync();

        var deviceIds = Enumerable.Range(1, 10).Select(i => $"device-{i}").ToArray();

        // 10 concurrent activation requests for a 2-device limit — each on its own DI scope/connection.
        var tasks = deviceIds.Select(async d =>
        {
            await using var perCallScope = Factory.Services.CreateAsyncScope();
            var svc = perCallScope.ServiceProvider.GetRequiredService<LicenseAppService>();
            return await svc.ActivateDeviceAsync(orgId, license.Id, d, d, "Windows");
        }).ToList();
        var results = await Task.WhenAll(tasks);

        var successes = results.Count(r => r.Success);
        Assert.True(successes <= 2, $"Device limit exceeded: {successes} activations succeeded for DeviceLimit=2");

        await using var verifyScope = Factory.Services.CreateAsyncScope();
        var verifyDb = verifyScope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var activeCount = await verifyDb.LicenseDevices.CountAsync(d => d.LicenseId == license.Id && d.DeactivatedAt == null);
        Assert.True(activeCount <= 2, $"Active devices {activeCount} exceed DeviceLimit=2");
    }

    [Fact]
    public async Task RefundApproval_NeverExceedsPaidAmount()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);
        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            Number = $"INV-RF-{suffix}",
            Prefix = "INV",
            FinancialYear = "2026",
            Status = InvoiceStatus.Paid,
            IssuedAt = DateTimeOffset.UtcNow,
            PaidAt = DateTimeOffset.UtcNow,
            Currency = "EGP",
            SubTotal = 1000m,
            GrandTotal = 1000m,
            AmountPaid = 1000m
        };
        db.Invoices.Add(invoice);
        db.Payments.Add(new Payment
        {
            OrganizationId = orgId,
            InvoiceId = invoice.Id,
            Amount = 1000m,
            Currency = "EGP",
            Method = "Manual",
            Status = PaymentStatus.Confirmed,
            ConfirmedAt = DateTimeOffset.UtcNow,
            IdempotencyKey = $"rf-{suffix}"
        });
        await db.SaveChangesAsync();

        var payments = await db.Payments.AsNoTracking().Where(p => p.InvoiceId == invoice.Id).ToListAsync();
        var payment = payments.Single();

        // Refund requests: 800 + 800 against a paid 1000 invoice. Only one can be approved.
        var r1 = new Refund { OrganizationId = orgId, PaymentId = payment.Id, Amount = 800m, Currency = "EGP", Reason = "r1" };
        var r2 = new Refund { OrganizationId = orgId, PaymentId = payment.Id, Amount = 800m, Currency = "EGP", Reason = "r2" };
        db.Refunds.AddRange(r1, r2);
        await db.SaveChangesAsync();

        // Approve the first (allowed), then the second must be rejected by the paid-amount invariant.
        var client = await Factory.LoginStaffAsync(email, password);
        var (_, approveToken) = await WebFactory.GetFormAsync(client, "http://localhost/refunds");

        var approve1 = await WebFactory.PostFormAsync(client, $"/refunds/{r1.Id}/approve", approveToken, new Dictionary<string, string?>());
        Assert.Equal(HttpStatusCode.Redirect, approve1.StatusCode);

        var (_, approveToken2) = await WebFactory.GetFormAsync(client, "http://localhost/refunds");
        var approve2 = await WebFactory.PostFormAsync(client, $"/refunds/{r2.Id}/approve", approveToken2, new Dictionary<string, string?>());

        await using var verifyScope = Factory.Services.CreateAsyncScope();
        var verifyDb = verifyScope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var approved = await verifyDb.Refunds.CountAsync(r => r.PaymentId == payment.Id && (r.Status == RefundStatus.Approved || r.Status == RefundStatus.Processed));
        Assert.True(approved <= 1, $"Refund invariant violated: {approved} refunds approved against a 1000 paid payment");
    }
}

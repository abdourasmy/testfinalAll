using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Subscriptions.Entities;
using Xunit;

namespace SBM.IntegrationTests;

public class StaffAuthTests : WebIntegrationTestBase
{
    public StaffAuthTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task StaffPost_WithoutAntiforgeryToken_Returns400()
    {
        var client = Factory.CreateCookieClient();
        var response = await client.PostAsync("/login",
            new FormUrlEncodedContent(new Dictionary<string, string> { ["Email"] = "owner@sbm.local", ["Password"] = "Owner!Test123" }));
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task StaffLogin_BadCredentials_RerendersWithBilingualError()
    {
        var client = Factory.CreateCookieClient();
        var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost/login");
        var response = await WebFactory.PostFormAsync(client, "/login", token, new Dictionary<string, string?>
        {
            ["Email"] = "owner@sbm.local",
            ["Password"] = "wrong-password"
        });
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var html = WebFactory.DecodeHtmlEntities(await response.Content.ReadAsStringAsync());
        Assert.Contains("بيانات الدخول غير صحيحة", html); // Arabic error label is always rendered
    }

    [Fact]
    public async Task AnonymousAccess_StaffConsole_RedirectsToLogin()
    {
        var client = Factory.CreateCookieClient();
        var response = await client.GetAsync("http://localhost/customers");
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.Contains("/login", response.Headers.Location?.ToString() ?? "", StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task NonManager_CannotCreateInvoice_IsRedirectedToFriendlyForbiddenPage()
    {
        // Create org + a Member-role user (no Owner/Manager role).
        var (orgId, _, _) = await Factory.CreateOrgAndManagerAsync(Guid.NewGuid().ToString("N")[..8]);
        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var users = scope.ServiceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();

        var email = $"member-{Guid.NewGuid().ToString("N")[..8]}@local.test";
        const string password = "Member!Test123";
        var user = new ApplicationUser { UserName = email, Email = email, DisplayName = "Member", Scope = AccountScope.Organization, EmailConfirmed = true };
        Assert.True((await users.CreateAsync(user, password)).Succeeded);
        await users.AddToRoleAsync(user, "Member");
        db.OrganizationMemberships.Add(new OrganizationMembership { OrganizationId = orgId, UserId = user.Id, Role = "Member" });
        await db.SaveChangesAsync();

        var client = await Factory.LoginStaffAsync(email, password);
        var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost/invoices/create");
        var response = await WebFactory.PostFormAsync(client, "/invoices/create", token, new Dictionary<string, string?>
        {
            ["CustomerId"] = Guid.Empty.ToString(),
            ["Currency"] = "EGP",
            ["Lines[0].Description"] = "x",
            ["Lines[0].Quantity"] = "1",
            ["Lines[0].UnitPrice"] = "100"
        });
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.Equal("/forbidden", response.Headers.Location?.ToString());

        var forbidden = WebFactory.DecodeHtmlEntities(await client.GetStringAsync("http://localhost/forbidden"));
        Assert.Contains("لا تملك صلاحية الوصول", forbidden); // bilingual friendly 403, not a bare Forbid()
    }
}

public class SalesWorkflowTests : WebIntegrationTestBase
{
    public SalesWorkflowTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task FullSalesWorkflow_CompletesAndWritesJournalAndEvents()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);

        var client = await Factory.LoginStaffAsync(email, password);

        // 1. Create quotation
        var (createHtml, createToken) = await WebFactory.GetFormAsync(client, "http://localhost/sales/create-quotation");
        var createResponse = await WebFactory.PostFormAsync(client, "/sales/create-quotation", createToken, new Dictionary<string, string?>
        {
            ["CustomerId"] = customer.Id.ToString(),
            ["Currency"] = "EGP",
            ["Lines[0].Description"] = "workflow line",
            ["Lines[0].Quantity"] = "2",
            ["Lines[0].UnitPrice"] = "500",
            ["Lines[0].DiscountPercent"] = "0",
            ["Lines[0].TaxPercent"] = "0"
        });
        Assert.Equal(HttpStatusCode.Redirect, createResponse.StatusCode);
        var quotationUrl = createResponse.Headers.Location!.ToString();

        async Task PostBackAsync(string pageUrl, string postUrl)
        {
            var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost" + pageUrl);
            var resp = await WebFactory.PostFormAsync(client, postUrl, token, new Dictionary<string, string?>());
            Assert.Equal(HttpStatusCode.Redirect, resp.StatusCode);
        }

        // 2. Send → Accept → Convert to order
        await PostBackAsync(quotationUrl, quotationUrl + "/send");
        await PostBackAsync(quotationUrl, quotationUrl + "/accept");
        var convertResponse = await PostAndReturn(quotationUrl + "/convert-to-order");
        var orderUrl = convertResponse.Headers.Location!.ToString();

        // 3. Confirm → Fulfill → Convert to invoice
        await PostBackAsync(orderUrl, orderUrl + "/confirm");
        await PostBackAsync(orderUrl, orderUrl + "/fulfill");
        var invoiceResponse = await PostAndReturn(orderUrl + "/convert-to-invoice");
        Assert.Contains("/invoices/", invoiceResponse.Headers.Location!.ToString());

        // Verify DB state
        await using var verifyScope = Factory.Services.CreateAsyncScope();
        var verifyDb = verifyScope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var quotation = await verifyDb.Quotations.FirstAsync(q => q.OrganizationId == orgId);
        Assert.Equal(QuotationStatus.Converted, quotation.Status);
        var order = await verifyDb.SalesOrders.FirstAsync(o => o.OrganizationId == orgId);
        Assert.Equal(SalesOrderStatus.Invoiced, order.Status);
        Assert.True(order.InvoiceId.HasValue);
        var invoice = await verifyDb.Invoices.FirstAsync(i => i.Id == order.InvoiceId!.Value);
        Assert.Equal(InvoiceStatus.Issued, invoice.Status);
        Assert.Equal(1000m, invoice.GrandTotal);

        var salesEvents = await verifyDb.SalesEvents.Where(e => e.OrganizationId == orgId).ToListAsync();
        Assert.Contains(salesEvents, e => e.EventType == "sent");
        Assert.Contains(salesEvents, e => e.EventType == "accepted");
        Assert.Contains(salesEvents, e => e.EventType == "converted");
        Assert.Contains(salesEvents, e => e.EventType == "confirmed");
        Assert.Contains(salesEvents, e => e.EventType == "fulfilled");
        Assert.Contains(salesEvents, e => e.EventType == "invoiced");

        // Sync-journal (outbox) integration: domain events flow into outbox rows.
        var outbox = await verifyDb.OutboxMessages.ToListAsync();
        Assert.Contains(outbox, m => m.Type == "sales.quotation.status");
        Assert.Contains(outbox, m => m.Type == "sales.order.status");

        async Task<HttpResponseMessage> PostAndReturn(string postUrl)
        {
            var pageUrl = postUrl.Replace("/convert-to-order", "").Replace("/convert-to-invoice", "");
            var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost" + pageUrl);
            var resp = await WebFactory.PostFormAsync(client, postUrl, token, new Dictionary<string, string?>());
            Assert.Equal(HttpStatusCode.Redirect, resp.StatusCode);
            return resp;
        }
    }
}

public class AudienceTests : WebIntegrationTestBase
{
    public AudienceTests(WebFactory factory) : base(factory) { }

    private const string ValidDoc = """{"v":1,"root":{"type":"group","op":"and","children":[{"type":"condition","field":"customer.status","op":"eq","value":"Active"},{"type":"condition","field":"subscription.status","op":"eq","value":"Active"}]}}""";
    private const string InvalidDoc = """{"v":1,"root":{"type":"condition","field":"customer.bogus","op":"eq","value":"Active"}}""";

    [Fact]
    public async Task Validate_InvalidDocument_ReturnsErrors()
    {
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(Guid.NewGuid().ToString("N")[..8]);
        var client = await Factory.LoginStaffAsync(email, password);
        var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost/audience");
        var response = await WebFactory.PostFormAsync(client, "/audience/validate", token, new Dictionary<string, string?>
        {
            ["documentJson"] = InvalidDoc
        });
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var html = await response.Content.ReadAsStringAsync();
        Assert.Contains("customer.bogus", html);
    }

    [Fact]
    public async Task ValidateAndPreview_ValidDocument_ProjectsRealCandidates()
    {
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(Guid.NewGuid().ToString("N")[..8]);
        var client = await Factory.LoginStaffAsync(email, password);

        var (_, token) = await WebFactory.GetFormAsync(client, "http://localhost/audience");
        var validResponse = await WebFactory.PostFormAsync(client, "/audience/validate", token, new Dictionary<string, string?>
        {
            ["documentJson"] = ValidDoc
        });
        var validHtml = WebFactory.DecodeHtmlEntities(await validResponse.Content.ReadAsStringAsync());
        Assert.Contains("صالحة", validHtml); // "valid" in Arabic

        var (_, previewToken) = await WebFactory.GetFormAsync(client, "http://localhost/audience");
        var previewResponse = await WebFactory.PostFormAsync(client, "/audience/preview", previewToken, new Dictionary<string, string?>
        {
            ["documentJson"] = ValidDoc,
            ["maxRecipients"] = "5"
        });
        var previewHtml = WebFactory.DecodeHtmlEntities(await previewResponse.Content.ReadAsStringAsync());
        Assert.Contains("500", previewHtml); // preview cap constant rendered
        // The org has exactly one active customer in seed; subscription.status=Active matches only
        // when an active subscription exists. Either way the page renders the projected counts.
        Assert.Contains("مطابقة", previewHtml);
    }
}

public class ReportsTests : WebIntegrationTestBase
{
    public ReportsTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task RevenueAndPaymentsReports_RunAgainstRealDatabase_WithClientSideGrouping()
    {
        // Bug 1 regression: revenue/payments used to fail with untranslatable EF GroupBy SQL.
        // Fix = client-side grouping after materializing rows. Seed data to prove grouping works.
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);
        var now = DateTimeOffset.UtcNow;
        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            Number = $"INV-TEST-{suffix}",
            Prefix = "INV",
            FinancialYear = "2026",
            Status = InvoiceStatus.Paid,
            IssuedAt = now,
            PaidAt = now,
            Currency = "EGP",
            SubTotal = 3000m,
            GrandTotal = 3000m,
            AmountPaid = 3000m
        };
        db.Invoices.Add(invoice);
        db.Payments.Add(new Payment { OrganizationId = orgId, InvoiceId = invoice.Id, Amount = 1500m, Currency = "EGP", Method = "Manual", Status = PaymentStatus.Confirmed, ConfirmedAt = now, IdempotencyKey = $"p1-{suffix}" });
        db.Payments.Add(new Payment { OrganizationId = orgId, InvoiceId = invoice.Id, Amount = 1500m, Currency = "EGP", Method = "Manual", Status = PaymentStatus.Confirmed, ConfirmedAt = now, IdempotencyKey = $"p2-{suffix}" });
        await db.SaveChangesAsync();

        var client = await Factory.LoginStaffAsync(email, password);
        var revenue = await client.GetStringAsync("http://localhost/reports/revenue");
        Assert.Contains(now.ToString("yyyy-MM"), revenue);
        Assert.Contains("3,000.00", revenue);

        var payments = await client.GetStringAsync("http://localhost/reports/payments");
        Assert.Contains("Manual", payments);
        Assert.Contains("3,000.00", payments);

        var csv = await client.GetStringAsync("http://localhost/reports/revenue/export?format=csv");
        Assert.Contains(now.ToString("yyyy-MM"), csv);
        Assert.Contains("Amount", csv);
    }

    public static TheoryData<string> ReportKeys => new()
    {
        "revenue", "payments", "outstanding-invoices", "subscriptions", "licenses",
        "top-customers", "expenses", "cancellations", "support-sla"
    };

    [Theory]
    [MemberData(nameof(ReportKeys))]
    public async Task AllReports_ExportCsvXlsxPdf(string key)
    {
        var (_, email, password) = await Factory.CreateOrgAndManagerAsync(Guid.NewGuid().ToString("N")[..8]);
        var client = await Factory.LoginStaffAsync(email, password);

        var csv = await client.GetAsync($"http://localhost/reports/{key}/export?format=csv");
        Assert.Equal(HttpStatusCode.OK, csv.StatusCode);
        Assert.Contains("text/csv", csv.Content.Headers.ContentType?.ToString() ?? "");

        var xlsx = await client.GetAsync($"http://localhost/reports/{key}/export?format=xlsx");
        Assert.Equal(HttpStatusCode.OK, xlsx.StatusCode);

        var pdf = await client.GetAsync($"http://localhost/reports/{key}/export?format=pdf");
        Assert.Equal(HttpStatusCode.OK, pdf.StatusCode);
        var pdfBytes = await pdf.Content.ReadAsByteArrayAsync();
        Assert.True(pdfBytes.Length > 1000);
        Assert.Equal("%PDF", Encoding.Latin1.GetString(pdfBytes, 0, 4));
    }
}

public class InvoicePdfAndIsolationTests : WebIntegrationTestBase
{
    public InvoicePdfAndIsolationTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task InvoicePdf_IsRealDocument_AndForeignInvoicePdf_Is404()
    {
        var suffixA = Guid.NewGuid().ToString("N")[..8];
        var suffixB = Guid.NewGuid().ToString("N")[..8];
        var (orgA, emailA, passwordA) = await Factory.CreateOrgAndManagerAsync(suffixA);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customerA = await db.Customers.FirstAsync(c => c.OrganizationId == orgA);

        var invoice = new Invoice
        {
            OrganizationId = orgA,
            CustomerId = customerA.Id,
            Number = $"INV-PDF-{suffixA}",
            Prefix = "INV",
            FinancialYear = "2026",
            Status = InvoiceStatus.Issued,
            IssuedAt = DateTimeOffset.UtcNow,
            Currency = "EGP",
            SubTotal = 1234.50m,
            TaxTotal = 0m,
            GrandTotal = 1234.50m
        };
        db.Invoices.Add(invoice);
        await db.SaveChangesAsync();

        var clientA = await Factory.LoginStaffAsync(emailA, passwordA);
        var pdf = await clientA.GetAsync($"http://localhost/invoices/{invoice.Id}/pdf");
        Assert.Equal(HttpStatusCode.OK, pdf.StatusCode);
        var bytes = await pdf.Content.ReadAsByteArrayAsync();
        Assert.Equal("%PDF", Encoding.Latin1.GetString(bytes, 0, 4));
        Assert.True(bytes.Length > 2000);

        // Tenant isolation: org B staff cannot download org A's invoice PDF (404, not 403).
        var suffixBCreds = await Factory.CreateOrgAndManagerAsync(suffixB + "-x");
        var (_, emailB, passwordB) = suffixBCreds;
        var clientB = await Factory.LoginStaffAsync(emailB, passwordB);
        var foreign = await clientB.GetAsync($"http://localhost/invoices/{invoice.Id}/pdf");
        Assert.Equal(HttpStatusCode.NotFound, foreign.StatusCode);

        var foreignDetails = await clientB.GetAsync($"http://localhost/invoices/{invoice.Id}");
        Assert.Equal(HttpStatusCode.NotFound, foreignDetails.StatusCode);
    }
}

public class PortalIsolationTests : WebIntegrationTestBase
{
    public PortalIsolationTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task PortalCustomer_CannotAccessForeignInvoiceOrPdf_OrSubscriptionActions()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, _, _) = await Factory.CreateOrgAndManagerAsync(suffix);
        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();

        var foreignCustomer = new SBM.Modules.Customers.Entities.Customer
        {
            OrganizationId = orgId,
            Name = $"Foreign {suffix}",
            Type = SBM.Modules.Customers.Entities.CustomerType.Company,
            Email = $"foreign-{suffix}@local.test"
        };
        db.Customers.Add(foreignCustomer);
        await db.SaveChangesAsync();

        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = foreignCustomer.Id,
            Number = $"INV-ISO-{suffix}",
            Prefix = "INV",
            FinancialYear = "2026",
            Status = InvoiceStatus.Issued,
            IssuedAt = DateTimeOffset.UtcNow,
            Currency = "EGP",
            SubTotal = 500m,
            GrandTotal = 500m
        };
        db.Invoices.Add(invoice);
        await db.SaveChangesAsync();

        var (portalEmail, portalPassword) = await Factory.CreatePortalUserAsync(orgId, suffix);
        var portal = await Factory.LoginPortalAsync(portalEmail, portalPassword);

        var foreignInvoice = await portal.GetAsync($"http://localhost/portal/invoices/{invoice.Id}");
        Assert.Equal(HttpStatusCode.NotFound, foreignInvoice.StatusCode);
        var foreignPdf = await portal.GetAsync($"http://localhost/portal/invoices/{invoice.Id}/pdf");
        Assert.Equal(HttpStatusCode.NotFound, foreignPdf.StatusCode);

        // Staff console cookies are not accepted on the portal (separate audiences).
        var staffConsoleWithPortalCookie = await portal.GetAsync("http://localhost/customers");
        Assert.Equal(HttpStatusCode.Redirect, staffConsoleWithPortalCookie.StatusCode);
        Assert.Contains("/login", staffConsoleWithPortalCookie.Headers.Location?.ToString() ?? "", StringComparison.OrdinalIgnoreCase);
    }
}

public class MfaTests : WebIntegrationTestBase
{
    public MfaTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task Mfa_Enroll_Confirm_And_Disable_FullFlow()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (_, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);
        var client = await Factory.LoginStaffAsync(email, password);

        // Wrong code rejected; account stays without MFA.
        var (_, badToken) = await WebFactory.GetFormAsync(client, "http://localhost/mfa/enroll");
        var badResponse = await WebFactory.PostFormAsync(client, "/mfa/confirm", badToken, new Dictionary<string, string?>
        {
            ["code"] = "000000"
        });
        Assert.Equal(HttpStatusCode.Redirect, badResponse.StatusCode);
        await using (var scope = Factory.Services.CreateAsyncScope())
        {
            var users = scope.ServiceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();
            var user = await users.FindByEmailAsync(email);
            Assert.False(await users.GetTwoFactorEnabledAsync(user!));
        }

        // Enroll with correct code (computed from the key shown on the enroll page).
        var (enrollHtml, enrollToken) = await WebFactory.GetFormAsync(client, "http://localhost/mfa/enroll");
        var keyMatch = Regex.Match(enrollHtml, "<code style=\"font-size:1\\.1rem;letter-spacing:\\.1em\">([A-Z2-7 ]+)</code>");
        Assert.True(keyMatch.Success, "enroll page must render the manual key");
        var key = keyMatch.Groups[1].Value.Replace(" ", "");

        var confirmResponse = await WebFactory.PostFormAsync(client, "/mfa/confirm", enrollToken, new Dictionary<string, string?>
        {
            ["code"] = ComputeTotp(key)
        });
        Assert.Equal(HttpStatusCode.Redirect, confirmResponse.StatusCode);

        await using (var scope = Factory.Services.CreateAsyncScope())
        {
            var users = scope.ServiceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();
            var user = await users.FindByEmailAsync(email);
            Assert.True(await users.GetTwoFactorEnabledAsync(user!));
            Assert.True(user!.MfaEnabled);
        }

        // Wrong password does not disable MFA.
        var (_, disableToken) = await WebFactory.GetFormAsync(client, "http://localhost/mfa");
        var disableResponse = await WebFactory.PostFormAsync(client, "/mfa/disable", disableToken, new Dictionary<string, string?>
        {
            ["password"] = "wrong-password"
        });
        Assert.Equal(HttpStatusCode.Redirect, disableResponse.StatusCode);
        await using (var scope = Factory.Services.CreateAsyncScope())
        {
            var users = scope.ServiceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();
            var user = await users.FindByEmailAsync(email);
            Assert.True(await users.GetTwoFactorEnabledAsync(user!));
        }

        // Correct password disables.
        var (_, disableToken2) = await WebFactory.GetFormAsync(client, "http://localhost/mfa");
        var disableResponse2 = await WebFactory.PostFormAsync(client, "/mfa/disable", disableToken2, new Dictionary<string, string?>
        {
            ["password"] = password
        });
        Assert.Equal(HttpStatusCode.Redirect, disableResponse2.StatusCode);
        await using (var scope = Factory.Services.CreateAsyncScope())
        {
            var users = scope.ServiceProvider.GetRequiredService<Microsoft.AspNetCore.Identity.UserManager<ApplicationUser>>();
            var user = await users.FindByEmailAsync(email);
            Assert.False(await users.GetTwoFactorEnabledAsync(user!));
        }
    }

    private static string ComputeTotp(string base32Secret)
    {
        const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        var sb = new StringBuilder();
        foreach (var c in base32Secret.ToUpperInvariant())
        {
            var v = alphabet.IndexOf(c);
            sb.Append(Convert.ToString(v, 2).PadLeft(5, '0'));
        }
        var bits = sb.ToString();
        var key = new byte[bits.Length / 8];
        for (var i = 0; i < key.Length; i++) key[i] = Convert.ToByte(bits.Substring(i * 8, 8), 2);

        var counter = DateTimeOffset.UtcNow.ToUnixTimeSeconds() / 30;
        var message = BitConverter.GetBytes(IPAddress.NetworkToHostOrder(counter));
        using var hmac = new HMACSHA1(key);
        var hash = hmac.ComputeHash(message);
        var offset = hash[^1] & 0x0f;
        var bin = ((hash[offset] & 0x7f) << 24) | (hash[offset + 1] << 16) | (hash[offset + 2] << 8) | hash[offset + 3];
        return (bin % 1_000_000).ToString("D6");
    }
}

public class ReleaseEligibilityTests : WebIntegrationTestBase
{
    public ReleaseEligibilityTests(WebFactory factory) : base(factory) { }

    [Fact]
    public async Task EligibleCustomer_SeesPublishedRelease_And_DownloadWorks_Then_YankBlocks()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, _, _) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();

        // Give the org's customer an active subscription to the seeded PRO-MONTHLY plan (REPAIR-PRO).
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);
        var plan = await db.PricingPlans.FirstAsync(p => p.Code == "PRO-MONTHLY");
        var subscription = new Subscription
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            ProductId = plan.ProductId,
            PlanId = plan.Id,
            Status = SubscriptionStatus.Active,
            Access = AccessMode.Full,
            CurrentPeriodStart = DateTimeOffset.UtcNow.AddDays(-1),
            CurrentPeriodEnd = DateTimeOffset.UtcNow.AddDays(30)
        };
        db.Subscriptions.Add(subscription);

        // Draft release + asset (registered without publishing).
        var storageDir = Path.Combine(Factory.Services.GetRequiredService<Microsoft.Extensions.Configuration.IConfiguration>()["Releases:StoragePath"]!, "testrepo");
        Directory.CreateDirectory(storageDir);
        var filePath = Path.Combine(storageDir, "sbm-test-asset.bin");
        var payload = Encoding.UTF8.GetBytes("SBM-TEST-PAYLOAD-" + suffix);
        await File.WriteAllBytesAsync(filePath, payload);
        var sha = Convert.ToHexString(SHA256.HashData(payload)).ToLowerInvariant();

        var release = new SoftwareRelease
        {
            ProductCode = "REPAIR-PRO",
            ApplicationCode = "repair-desktop",
            Version = "9.8.7",
            Channel = "Stable",
            Status = ReleaseStatus.Draft
        };
        db.SoftwareReleases.Add(release);
        await db.SaveChangesAsync();
        db.ReleaseAssets.Add(new ReleaseAsset
        {
            ReleaseId = release.Id,
            FileName = "sbm-test-asset.bin",
            ContentType = "application/octet-stream",
            SizeBytes = payload.Length,
            Sha256 = sha,
            StoragePath = filePath
        });
        await db.SaveChangesAsync();

        var (portalEmail, portalPassword) = await Factory.CreatePortalUserAsync(orgId, suffix);
        var portal = await Factory.LoginPortalAsync(portalEmail, portalPassword);

        // Draft: not listed, cannot download.
        var draftList = await portal.GetStringAsync("http://localhost/portal/releases");
        Assert.DoesNotContain("9.8.7", draftList);
        var draftDownload = await portal.GetAsync($"http://localhost/portal/releases/{release.Id}/assets/{(await AssetIdAsync(db, release.Id))}/download");
        Assert.Equal(HttpStatusCode.NotFound, draftDownload.StatusCode);

        // Publish as platform admin.
        var owner = await Factory.LoginStaffAsync("owner@sbm.local", "Owner!Test123");
        var (_, publishToken) = await WebFactory.GetFormAsync(owner, $"http://localhost/releases/{release.Id}");
        var publishResponse = await WebFactory.PostFormAsync(owner, $"/releases/{release.Id}/publish", publishToken, new Dictionary<string, string?>());
        Assert.Equal(HttpStatusCode.Redirect, publishResponse.StatusCode);

        // Published + eligible: listed, download works, SHA header matches.
        var publishedList = await portal.GetStringAsync("http://localhost/portal/releases");
        Assert.Contains("9.8.7", publishedList);
        var assetId = await AssetIdAsync(db, release.Id);
        var download = await portal.GetAsync($"http://localhost/portal/releases/{release.Id}/assets/{assetId}/download");
        Assert.Equal(HttpStatusCode.OK, download.StatusCode);
        Assert.Equal(sha, download.Headers.GetValues("X-Asset-Sha256").FirstOrDefault());
        Assert.Equal(payload, await download.Content.ReadAsByteArrayAsync());

        // Yank: no longer listed; download 404.
        var (_, yankToken) = await WebFactory.GetFormAsync(owner, $"http://localhost/releases/{release.Id}");
        await WebFactory.PostFormAsync(owner, $"/releases/{release.Id}/yank", yankToken, new Dictionary<string, string?> { ["reason"] = "test yank" });
        var yankedList = await portal.GetStringAsync("http://localhost/portal/releases");
        Assert.DoesNotContain("9.8.7", yankedList);
        var afterYank = await portal.GetAsync($"http://localhost/portal/releases/{release.Id}/assets/{assetId}/download");
        Assert.Equal(HttpStatusCode.NotFound, afterYank.StatusCode);

        static async Task<Guid> AssetIdAsync(SbmDbContext db, Guid releaseId) =>
            (await db.ReleaseAssets.AsNoTracking().FirstAsync(a => a.ReleaseId == releaseId)).Id;
    }

    [Fact]
    public async Task PortalSubscriptionRequest_AppearsInStaffApprovalQueue()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var (orgId, email, password) = await Factory.CreateOrgAndManagerAsync(suffix);

        await using var scope = Factory.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var customer = await db.Customers.FirstAsync(c => c.OrganizationId == orgId);
        var plan = await db.PricingPlans.FirstAsync(p => p.Code == "PRO-MONTHLY");
        var subscription = new Subscription
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            ProductId = plan.ProductId,
            PlanId = plan.Id,
            Status = SubscriptionStatus.Active,
            Access = AccessMode.Full,
            CurrentPeriodStart = DateTimeOffset.UtcNow.AddDays(-1),
            CurrentPeriodEnd = DateTimeOffset.UtcNow.AddDays(30)
        };
        db.Subscriptions.Add(subscription);
        await db.SaveChangesAsync();
        var subscriptionId = subscription.Id;

        var (portalEmail, portalPassword) = await Factory.CreatePortalUserAsync(orgId, suffix);
        var portal = await Factory.LoginPortalAsync(portalEmail, portalPassword);
        var (_, token) = await WebFactory.GetFormAsync(portal, "http://localhost/portal/subscriptions");
        var requestResponse = await WebFactory.PostFormAsync(portal, $"/portal/subscriptions/{subscriptionId}/request-renewal", token, new Dictionary<string, string?>
        {
            ["note"] = "please renew"
        });
        Assert.Equal(HttpStatusCode.Redirect, requestResponse.StatusCode);

        var manager = await Factory.LoginStaffAsync(email, password);
        var queue = await manager.GetStringAsync("http://localhost/approvals");
        Assert.Contains("SubscriptionRenewal", queue);
        Assert.Contains("please renew", queue);

        var badge = await manager.GetStringAsync("http://localhost/approvals/badge");
        Assert.Contains("badge", badge);

        // Approving renews the subscription (period extended, event logged).
        var approvalId = await db.ApprovalRequests.Where(a => a.SubscriptionId == subscriptionId && a.Status == ApprovalStatus.Pending).Select(a => a.Id).FirstAsync();
        var (_, approveToken) = await WebFactory.GetFormAsync(manager, "http://localhost/approvals");
        var approveResponse = await WebFactory.PostFormAsync(manager, $"/approvals/{approvalId}/approve", approveToken, new Dictionary<string, string?> { ["note"] = "approved by test" });
        Assert.Equal(HttpStatusCode.Redirect, approveResponse.StatusCode);

        await using var verifyScope = Factory.Services.CreateAsyncScope();
        var verifyDb = verifyScope.ServiceProvider.GetRequiredService<SbmDbContext>();
        var updated = await verifyDb.Subscriptions.FirstAsync(s => s.Id == subscriptionId);
        Assert.True(updated.CurrentPeriodEnd > DateTimeOffset.UtcNow.AddDays(55));
        Assert.Contains(await verifyDb.SubscriptionEvents.Where(e => e.SubscriptionId == subscriptionId).ToListAsync(), e => e.EventType == "renewed");
    }
}

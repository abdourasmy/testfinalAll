using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;

[assembly: CollectionBehavior(DisableTestParallelization = true)]

namespace SBM.IntegrationTests;

/// <summary>
/// Web (SBM.Web) integration tests against scratch LocalDB databases. Same isolation model as
/// SbmFactory: each factory instance migrates its own scratch database and drops it on teardown.
/// Use CookieContainer clients — the app uses cookie auth (not JWT) for the web tier.
/// </summary>
public sealed class WebFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public string DbName { get; } = $"SBM-Web-Test-{Guid.NewGuid():N}";
    public InMemoryLogCollector Logs { get; } = new();
    private string ConnectionString => $"Server=(localdb)\\MSSQLLocalDB;Database={DbName};Trusted_Connection=True;TrustServerCertificate=True;Connect Timeout=120;";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureLogging(logging =>
        {
            logging.ClearProviders();
            logging.AddProvider(Logs);
        });
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Database:ApplyMigrationsOnStartup"] = "false",
                ["Seed:Enable"] = "false",
                ["Seed:DemoData"] = "false",
                ["ConnectionStrings:SbmDatabase"] = ConnectionString,
                ["Jwt:Key"] = Convert.ToBase64String(new byte[48]),
                ["Jwt:Issuer"] = "sbm",
                ["Jwt:Audience"] = "sbm-api",
                ["Releases:StoragePath"] = Path.Combine(Path.GetTempPath(), "sbm-test-releases-" + DbName)
            });
        });
    }

    public async Task InitializeAsync()
    {
        _ = Services;
        await using var scope = Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var db = services.GetRequiredService<SbmDbContext>();
        await db.Database.MigrateAsync();

        var roles = services.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();
        await DbSeeder.SeedAsync(db, users, roles, new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["Seed:OwnerEmail"] = "owner@sbm.local", ["Seed:OwnerPassword"] = "Owner!Test123" })
            .Build());
    }

    public new async Task DisposeAsync()
    {
        await base.DisposeAsync();
        try
        {
            await using var connection = new SqlConnection("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Trusted_Connection=True;TrustServerCertificate=True;");
            await connection.OpenAsync();
            await using var command = connection.CreateCommand();
            command.CommandText = $"ALTER DATABASE [{DbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{DbName}];";
            await command.ExecuteNonQueryAsync();
        }
        catch { /* best effort */ }
    }

    /// <summary>Cookie-aware client that does NOT auto-follow redirects (302s are asserted, not swallowed).</summary>
    public HttpClient CreateCookieClient() => CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true, AllowAutoRedirect = false });

    /// <summary>Decode numeric HTML entities (Razor encodes non-ASCII as &#x...;).</summary>
    public static string DecodeHtmlEntities(string html)
    {
        return System.Text.RegularExpressions.Regex.Replace(html ?? string.Empty, "&#x([0-9a-fA-F]+);", m =>
            ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
    }

    /// <summary>GET a page, returning (html, antiforgeryToken).</summary>
    public static async Task<(string Html, string Token)> GetFormAsync(HttpClient client, string url)
    {
        var html = await client.GetStringAsync(url);
        var match = Regex.Match(html, "name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"");
        return (html, match.Groups[1].Value);
    }

    public static async Task<HttpResponseMessage> PostFormAsync(HttpClient client, string url, string? token, IDictionary<string, string?> fields)
    {
        var all = new Dictionary<string, string?>(fields)
        {
            ["__RequestVerificationToken"] = token
        };
        return await client.PostAsync(url, new FormUrlEncodedContent(all!));
    }

    /// <summary>Log in as staff (cookie). Returns the authenticated client.</summary>
    public async Task<HttpClient> LoginStaffAsync(string email, string password)
    {
        var client = CreateCookieClient();
        var (_, token) = await GetFormAsync(client, "http://localhost/login");
        var response = await PostFormAsync(client, "/login", token, new Dictionary<string, string?>
        {
            ["Email"] = email,
            ["Password"] = password
        });
        if (response.StatusCode != HttpStatusCode.Redirect)
        {
            var body = await response.Content.ReadAsStringAsync();
            throw new Xunit.Sdk.XunitException($"Staff login failed with {(int)response.StatusCode} {response.StatusCode}. Body: {DecodeHtmlEntities(body)[..Math.Min(600, body.Length)]}");
        }
        return client;
    }

    /// <summary>Log in as portal customer (cookie).</summary>
    public async Task<HttpClient> LoginPortalAsync(string email, string password)
    {
        var client = CreateCookieClient();
        var (_, token) = await GetFormAsync(client, "http://localhost/portal/login");
        var response = await PostFormAsync(client, "/portal/login", token, new Dictionary<string, string?>
        {
            ["email"] = email,
            ["password"] = password
        });
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        return client;
    }

    /// <summary>Create an organization + org manager (Owner role) user; returns (orgId, email, password).</summary>
    public async Task<(Guid OrgId, string Email, string Password)> CreateOrgAndManagerAsync(string suffix)
    {
        await using var scope = Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var db = services.GetRequiredService<SbmDbContext>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        var org = new Organization { Name = $"Test Org {suffix}", Country = "EG", City = "Cairo", Status = "Active" };
        db.Organizations.Add(org);
        await db.SaveChangesAsync();

        var email = $"manager-{suffix}@local.test";
        var password = "Manager!Test123";
        var user = new ApplicationUser { UserName = email, Email = email, DisplayName = $"Manager {suffix}", Scope = AccountScope.Organization, EmailConfirmed = true };
        var result = await users.CreateAsync(user, password);
        Assert.True(result.Succeeded, string.Join("; ", result.Errors.Select(e => e.Description)));
        await users.AddToRoleAsync(user, "Manager");
        db.OrganizationMemberships.Add(new OrganizationMembership { OrganizationId = org.Id, UserId = user.Id, Role = "Manager" });

        var customer = new SBM.Modules.Customers.Entities.Customer
        {
            OrganizationId = org.Id,
            Name = $"Customer {suffix}",
            Type = SBM.Modules.Customers.Entities.CustomerType.Company,
            Status = SBM.Modules.Customers.Entities.CustomerStatus.Active,
            Email = $"customer-{suffix}@local.test"
        };
        db.Customers.Add(customer);
        await db.SaveChangesAsync();
        return (org.Id, email, password);
    }

    /// <summary>Create a portal account linked to the org's first customer; returns portal email/password.</summary>
    public async Task<(string Email, string Password)> CreatePortalUserAsync(Guid orgId, string suffix)
    {
        await using var scope = Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var db = services.GetRequiredService<SbmDbContext>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        var customer = await db.Customers.Where(c => c.OrganizationId == orgId).OrderBy(c => c.RegisteredAt).FirstAsync();
        var email = $"portal-{suffix}@local.test";
        var password = "Portal!Test123";
        var user = new ApplicationUser { UserName = email, Email = email, DisplayName = $"Portal {suffix}", Scope = AccountScope.Organization, EmailConfirmed = true, CustomerId = customer.Id };
        var result = await users.CreateAsync(user, password);
        Assert.True(result.Succeeded, string.Join("; ", result.Errors.Select(e => e.Description)));
        await users.AddToRoleAsync(user, "Member");
        return (email, password);
    }
}

public abstract class WebIntegrationTestBase : IClassFixture<WebFactory>
{
    protected readonly WebFactory Factory;
    protected WebIntegrationTestBase(WebFactory factory) => Factory = factory;
}

using SBM.Infrastructure.Persistence;
using Xunit;
using Xunit.Abstractions;

namespace SBM.IntegrationTests;

/// <summary>Runs the EF Core global query filter harness: org A sees only A rows, org B only B rows,
/// platform admin and null tenant see all. Kept as a permanent regression test.</summary>
public class GlobalTenantFilterCheckTest
{
    [Fact]
    public async Task TenantFilters_AreConsistentAcrossTenants()
    {
        await TenantFilterCheck.RunAsync();
    }
}

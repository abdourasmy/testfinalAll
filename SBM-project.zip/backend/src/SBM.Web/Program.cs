using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Shared.Abstractions;
using SBM.Web.Middleware;
using SBM.Web.Security;
using SBM.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// ---------- Configuration ----------
builder.Services.AddDbContext<SbmDbContext>((sp, options) =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("SbmDatabase")
        ?? "Server=(localdb)\\MSSQLLocalDB;Database=SBM;Trusted_Connection=True;TrustServerCertificate=True;",
        sql => sql.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null)));

builder.Services.AddIdentity<SBM.Modules.Identity.Entities.ApplicationUser, IdentityRole<Guid>>(options =>
    {
        options.Password.RequiredLength = 10;
        options.Password.RequireNonAlphanumeric = true;
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.SignIn.RequireConfirmedEmail = false;
    })
    .AddEntityFrameworkStores<SbmDbContext>()
    .AddDefaultTokenProviders();

// Staff and portal cookies are completely separate authentication audiences.
builder.Services.AddAuthentication(options =>
    {
        options.DefaultScheme = CookieSchemes.Staff;
        options.DefaultChallengeScheme = CookieSchemes.Staff;
    })
    .AddCookie(CookieSchemes.Staff, o =>
    {
        o.Cookie.Name = "sbm.staff";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;
        o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        o.LoginPath = "/login";
        o.AccessDeniedPath = "/forbidden";
        o.ExpireTimeSpan = TimeSpan.FromHours(8);
        o.SlidingExpiration = true;
    })
    .AddCookie(CookieSchemes.Portal, o =>
    {
        o.Cookie.Name = "sbm.portal";
        o.Cookie.Path = "/portal";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;
        o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        o.LoginPath = "/portal/login";
        o.AccessDeniedPath = "/portal/forbidden";
        o.ExpireTimeSpan = TimeSpan.FromHours(4);
        o.SlidingExpiration = true;
    })
    .AddCookie(CookieSchemes.MfaPending, o =>
    {
        o.Cookie.Name = "sbm.mfa";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;
        o.ExpireTimeSpan = TimeSpan.FromMinutes(10);
        o.SlidingExpiration = false;
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("Staff", p => p.AddAuthenticationSchemes(CookieSchemes.Staff).RequireAuthenticatedUser());
    options.AddPolicy("PlatformAdmin", p => p.AddAuthenticationSchemes(CookieSchemes.Staff).RequireRole("PlatformAdmin"));
    options.AddPolicy("OrgManager", p => p.AddAuthenticationSchemes(CookieSchemes.Staff).RequireAssertion(ctx =>
        ctx.User.IsInRole("PlatformAdmin") || ctx.User.IsInRole("Owner") || ctx.User.IsInRole("Manager")));
    options.AddPolicy("PortalOnly", p => p.AddAuthenticationSchemes(CookieSchemes.Portal).RequireAuthenticatedUser().RequireClaim("customer_id"));
    options.DefaultPolicy = options.GetPolicy("Staff")!;
});
builder.Services.AddSingleton<Microsoft.AspNetCore.Authorization.IAuthorizationMiddlewareResultHandler, FriendlyForbiddenResultHandler>();

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ITenantContext, CookieTenantContext>();
builder.Services.AddScoped<LanguageService>();
builder.Services.AddScoped<SignInService>();
builder.Services.AddScoped<InvoiceNumberingService>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddScoped<LicenseAppService>();
builder.Services.AddScoped<AudienceCandidateProjector>();
builder.Services.AddScoped<CampaignLaunchService>();
builder.Services.AddScoped<ReportService>();
builder.Services.AddScoped<ExportService>();
builder.Services.AddScoped<InvoicePdfService>();
builder.Services.AddScoped<SalesService>();
builder.Services.AddScoped<ApprovalService>();
builder.Services.AddScoped<ReleaseEligibilityService>();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<SBM.Modules.Notifications.Delivery.INotificationProvider, LoggingNotificationProvider>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddAntiforgery(o => o.HeaderName = "RequestVerificationToken");
builder.Services.AddControllersWithViews(o =>
{
    // Every state-changing POST requires a valid antiforgery token.
    o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
}).AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

builder.Services.AddHealthChecks()
    .AddDbContextCheck<SbmDbContext>("database", tags: new[] { "ready" });

var app = builder.Build();

// ---------- Startup: migrate + seed (development) ----------
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var db = services.GetRequiredService<SbmDbContext>();
    if (app.Configuration.GetValue<bool>("Database:ApplyMigrationsOnStartup") || app.Environment.IsDevelopment())
    {
        try { await db.Database.MigrateAsync(); }
        catch (Exception ex) { app.Logger.LogWarning(ex, "Automatic migration failed; apply migrations manually (see docs/deployment)."); }
    }
    if (app.Configuration.GetValue("Seed:Enable", app.Environment.IsDevelopment()))
    {
        try
        {
            var users = services.GetRequiredService<UserManager<SBM.Modules.Identity.Entities.ApplicationUser>>();
            var roles = services.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
            await DbSeeder.SeedAsync(db, users, roles, app.Configuration);
        }
        catch (Exception ex) { app.Logger.LogWarning(ex, "Seeding skipped or failed."); }
    }
    if (app.Configuration.GetValue("Seed:DemoData", false))
    {
        try
        {
            var users = services.GetRequiredService<UserManager<SBM.Modules.Identity.Entities.ApplicationUser>>();
            await SBM.Web.Services.DemoSeed.SeedAsync(db, users, app.Configuration, app.Logger);
        }
        catch (Exception ex) { app.Logger.LogWarning(ex, "Demo seed skipped or failed."); }
    }
}

app.UseMiddleware<WebExceptionMiddleware>();

// Friendly, bilingual status pages (no stack traces, no internals).
app.UseStatusCodePagesWithReExecute("/status/{0}");

// Security headers.
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
    ctx.Response.Headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; form-action 'self'";
    await next();
});

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapHealthChecks("/healthz");
app.MapControllerRoute("default", "{controller=Dashboard}/{action=Index}/{id?}");

await app.RunAsync();

public partial class Program { }

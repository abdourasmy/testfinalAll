﻿(function () {
    // Send the antiforgery token with every HTMX request (header configured in Program.cs).
    document.body.addEventListener('htmx:configRequest', function (event) {
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta) {
            event.detail.headers['RequestVerificationToken'] = meta.getAttribute('content');
        }
    });
})();

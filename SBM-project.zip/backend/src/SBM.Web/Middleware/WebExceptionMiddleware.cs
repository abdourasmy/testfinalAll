using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;

namespace SBM.Web.Middleware;

/// <summary>Friendly, localized-ish error page. Never leaks stack traces or internals.</summary>
public sealed class WebExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<WebExceptionMiddleware> _logger;

    public WebExceptionMiddleware(RequestDelegate next, ILogger<WebExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try { await _next(context); }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error {TraceId}", context.TraceIdentifier);
            if (context.Response.HasStarted) throw;
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "text/html; charset=utf-8";
            await context.Response.WriteAsync(
                $"""
                <!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>خطأ — SBM</title>
                <link rel="stylesheet" href="/css/site.css"></head><body class="error-page">
                <main class="error-card"><h1>حدث خطأ غير متوقع</h1>
                <p>Unexpected error. Reference: <code>{context.TraceIdentifier}</code></p>
                <p><a class="btn" href="/">العودة إلى لوحة المعلومات — Back to dashboard</a></p>
                </main></body></html>
                """);
        }
    }
}

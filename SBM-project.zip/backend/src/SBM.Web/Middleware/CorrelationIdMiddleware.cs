namespace SBM.Web.Middleware;

/// <summary>
/// Reads (or generates) X-Correlation-ID; stores it on HttpContext.Items, echoes it on the response,
/// and keeps it available to AuditLogger and any downstream propagation (outbox/events/jobs).
/// Inbound values are validated (max 64 chars, alnum + '-') to prevent log injection.
/// </summary>
public sealed class CorrelationIdMiddleware
{
    public const string ItemsKey = "CorrelationId";
    public const string HeaderName = "X-Correlation-ID";

    private readonly RequestDelegate _next;

    public CorrelationIdMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        var id = context.Request.Headers[HeaderName].FirstOrDefault();
        if (string.IsNullOrWhiteSpace(id) || id.Length > 64 || id.Any(c => !char.IsLetterOrDigit(c) && c != '-'))
            id = Guid.NewGuid().ToString("N");

        context.Items[ItemsKey] = id;
        context.Response.Headers[HeaderName] = id;
        await _next(context);
    }
}

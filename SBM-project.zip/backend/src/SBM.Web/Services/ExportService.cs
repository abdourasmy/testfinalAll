using System.Globalization;
using System.Text;
using ClosedXML.Excel;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace SBM.Web.Services;

/// <summary>Renders a ReportResult as CSV (UTF-8 BOM), XLSX (ClosedXML) or PDF (QuestPDF).</summary>
public sealed class ExportService
{
    private const int ExportRowCap = 10_000;

    public byte[] ToCsv(ReportResult report)
    {
        var capped = new ReportResult(report.Key, report.TitleAr, report.TitleEn, report.Columns,
            report.Rows.Take(ExportRowCap).ToList());
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(',', capped.Columns.Select(Escape)));
        foreach (var row in capped.Rows)
            sb.AppendLine(string.Join(',', row.Select(Escape)));
        var bytes = Encoding.UTF8.GetBytes(sb.ToString());
        var bom = Encoding.UTF8.GetPreamble();
        return bom.Concat(bytes).ToArray();

        static string Escape(string cell)
        {
            cell ??= string.Empty;
            // CSV formula injection guard: leading = + - @ are dangerous when opened in spreadsheet apps.
            if (cell.Length > 0 && (cell[0] is '=' or '+' or '-' or '@'))
                cell = "'" + cell;
            if (cell.Contains(',') || cell.Contains('"') || cell.Contains('\n'))
                return "\"" + cell.Replace("\"", "\"\"") + "\"";
            return cell;
        }
    }

    public byte[] ToXlsx(ReportResult report)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add(SanitizeSheetName(report.TitleEn));
        var rows = report.Rows.Take(ExportRowCap).ToList();
        for (var c = 0; c < report.Columns.Count; c++)
        {
            ws.Cell(1, c + 1).Value = report.Columns[c];
            ws.Cell(1, c + 1).Style.Font.Bold = true;
        }
        for (var r = 0; r < rows.Count; r++)
            for (var c = 0; c < rows[r].Count; c++)
                ws.Cell(r + 2, c + 1).Value = rows[r][c];
        ws.Columns().AdjustToContents();
        ws.SheetView.FreezeRows(1);
        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    public byte[] ToPdf(ReportResult report)
    {
        QuestPDF.Settings.License = LicenseType.Community;
        var rows = report.Rows.Take(ExportRowCap).ToList();
        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(36);
                page.DefaultTextStyle(x => x.FontSize(9));
                page.Header().Text($"SBM — {report.TitleEn} — {report.TitleAr}").SemiBold().FontSize(14);
                page.Content().PaddingVertical(10).Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        foreach (var _ in report.Columns)
                            columns.RelativeColumn();
                    });
                    foreach (var col in report.Columns)
                        table.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text(col).SemiBold();
                    foreach (var row in rows)
                        foreach (var cell in row)
                            table.Cell().BorderBottom(1).BorderColor(Colors.Grey.Lighten2).Padding(4).Text(cell ?? string.Empty);
                });
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("Software Business Manager — ");
                    text.CurrentPageNumber();
                    text.Span(" / ");
                    text.TotalPages();
                });
            });
        });
        return doc.GeneratePdf();
    }

    private static string SanitizeSheetName(string name)
    {
        var cleaned = string.Concat(name.Where(ch => ch is not (':' or '\\' or '/' or '?' or '*' or '[' or ']')));
        return cleaned.Length > 31 ? cleaned[..31] : cleaned;
    }
}

using System.Net;
using Microsoft.AspNetCore.Http;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;

namespace SBM.Web.Services;

/// <summary>Append-only audit writer. Writes SecurityEvent rows enriched with actor/target/action/result/correlation.</summary>
public sealed class AuditLogger
{
    private readonly SbmDbContext _db;
    private readonly IHttpContextAccessor _http;

    public AuditLogger(SbmDbContext db, IHttpContextAccessor http)
    {
        _db = db;
        _http = http;
    }

    public string? CorrelationId => _http.HttpContext?.Items["CorrelationId"] as string;

    public async Task WriteAsync(
        string action, string result = "success", string? actorType = "staff",
        string? targetType = null, string? targetId = null, Guid? userId = null, Guid? organizationId = null,
        string? details = null, CancellationToken ct = default)
    {
        var ctx = _http.HttpContext;
        _db.SecurityEvents.Add(new SecurityEvent
        {
            UserId = userId,
            EventType = action,
            Action = action,
            Result = result,
            ActorType = actorType,
            TargetType = targetType,
            TargetId = targetId,
            OrganizationId = organizationId,
            Details = details,
            CorrelationId = CorrelationId,
            IpAddress = ctx?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = Truncate(ctx?.Request.Headers.UserAgent.ToString(), 512)
        });
        await _db.SaveChangesAsync(ct);
    }

    private static string? Truncate(string? value, int max) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Length <= max ? value : value[..max];
}

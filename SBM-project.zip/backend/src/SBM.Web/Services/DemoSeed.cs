using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Support.Entities;

namespace SBM.Web.Services;

/// <summary>
/// DEVELOPMENT-ONLY demo data (Seed:DemoData=true). Idempotent: re-running never duplicates.
/// Passwords come from configuration with development-only defaults; never enable in production.
/// </summary>
public static class DemoSeed
{
    public const string DemoOrgName = "شركة تصليح برو (تجريبي)";
    public const string DemoCustomerName = "عميل العرض التجريبي";
    public const string DemoPortalEmail = "portal@sbm.local";
    public const string DemoManagerEmail = "manager@demo.sbm.local";

    public static async Task SeedAsync(SbmDbContext db, UserManager<ApplicationUser> users, IConfiguration config, ILogger logger, CancellationToken ct = default)
    {
        var portalPassword = config["Seed:DemoPortalPassword"] ?? "PortalDemo!123";
        var managerPassword = config["Seed:DemoManagerPassword"] ?? "ManagerDemo!123";

        // --- demo organization ---
        var org = await db.Organizations.FirstOrDefaultAsync(o => o.Name == DemoOrgName, ct);
        if (org is null)
        {
            org = new Organization { Name = DemoOrgName, Country = "EG", City = "Cairo", Status = "Active", ContactEmail = "demo@sbm.local" };
            db.Organizations.Add(org);
            await db.SaveChangesAsync(ct);
        }

        // --- demo customer ---
        var customer = await db.Customers.FirstOrDefaultAsync(c => c.OrganizationId == org.Id && c.Name == DemoCustomerName, ct);
        if (customer is null)
        {
            customer = new Customer { OrganizationId = org.Id, Name = DemoCustomerName, Type = CustomerType.Company, Status = CustomerStatus.Active, Email = "customer@sbm.local", Country = "EG", City = "Cairo" };
            db.Customers.Add(customer);
            await db.SaveChangesAsync(ct);
        }

        // --- staff manager (org-scoped) ---
        var manager = await users.FindByEmailAsync(DemoManagerEmail);
        if (manager is null)
        {
            manager = new ApplicationUser { UserName = DemoManagerEmail, Email = DemoManagerEmail, DisplayName = "Demo Manager", EmailConfirmed = true, Scope = AccountScope.Organization };
            var result = await users.CreateAsync(manager, managerPassword);
            if (result.Succeeded)
            {
                await users.AddToRoleAsync(manager, "Manager");
            }
        }
        if (!await db.OrganizationMemberships.AnyAsync(m => m.OrganizationId == org.Id && m.UserId == manager.Id, ct))
        {
            db.OrganizationMemberships.Add(new OrganizationMembership { OrganizationId = org.Id, UserId = manager.Id, Role = "Manager", Status = "Active" });
        }

        // --- portal account ---
        var portal = await users.FindByEmailAsync(DemoPortalEmail);
        if (portal is null)
        {
            portal = new ApplicationUser { UserName = DemoPortalEmail, Email = DemoPortalEmail, DisplayName = "عميل العرض التجريبي", EmailConfirmed = true, Scope = AccountScope.Organization, CustomerId = customer.Id };
            var result = await users.CreateAsync(portal, portalPassword);
            if (result.Succeeded) await users.AddToRoleAsync(portal, "Member");
        }
        else if (portal.CustomerId is null)
        {
            portal.CustomerId = customer.Id;
            await users.UpdateAsync(portal);
        }

        // --- subscription ---
        var plan = await db.PricingPlans.AsNoTracking().FirstOrDefaultAsync(p => p.Code == "PRO-MONTHLY", ct);
        var product = plan is not null ? await db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == plan.ProductId, ct) : null;
        var subscription = await db.Subscriptions.FirstOrDefaultAsync(s => s.OrganizationId == org.Id && s.CustomerId == customer.Id, ct);
        if (subscription is null && plan is not null)
        {
            subscription = new Subscription
            {
                OrganizationId = org.Id,
                CustomerId = customer.Id,
                ProductId = plan.ProductId,
                PlanId = plan.Id,
                Status = SubscriptionStatus.Active,
                Access = AccessMode.Full,
                CurrentPeriodStart = DateTimeOffset.UtcNow.AddDays(-10),
                CurrentPeriodEnd = DateTimeOffset.UtcNow.AddDays(20)
            };
            db.Subscriptions.Add(subscription);
            db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = org.Id, SubscriptionId = subscription.Id, EventType = "activated", Details = "demo seed" });
            await db.SaveChangesAsync(ct);
        }

        // --- demo invoices (stable numbers; skip if present) ---
        if (!await db.Invoices.AnyAsync(i => i.OrganizationId == org.Id && i.Number == "INV-DEMO-0001", ct))
        {
            var inv1 = new Invoice { OrganizationId = org.Id, CustomerId = customer.Id, Number = "INV-DEMO-0001", Prefix = "INV-DEMO", FinancialYear = "2026", Status = InvoiceStatus.Issued, IssuedAt = DateTimeOffset.UtcNow.AddDays(-8), DueAt = DateTimeOffset.UtcNow.AddDays(22), Currency = "EGP", SubTotal = 1500m, TaxTotal = 0m, GrandTotal = 1500m };
            db.Invoices.Add(inv1);
            db.InvoiceItems.Add(new InvoiceItem { OrganizationId = org.Id, InvoiceId = inv1.Id, Description = "اشتراك برو شهري — Demo Pro subscription", Quantity = 1, UnitPrice = 1500m, Currency = "EGP" });
        }
        if (!await db.Invoices.AnyAsync(i => i.OrganizationId == org.Id && i.Number == "INV-DEMO-0002", ct))
        {
            var inv2 = new Invoice { OrganizationId = org.Id, CustomerId = customer.Id, Number = "INV-DEMO-0002", Prefix = "INV-DEMO", FinancialYear = "2026", Status = InvoiceStatus.Paid, IssuedAt = DateTimeOffset.UtcNow.AddDays(-38), DueAt = DateTimeOffset.UtcNow.AddDays(-8), PaidAt = DateTimeOffset.UtcNow.AddDays(-30), Currency = "EGP", SubTotal = 1500m, TaxTotal = 0m, GrandTotal = 1500m, AmountPaid = 1500m };
            db.Invoices.Add(inv2);
            db.InvoiceItems.Add(new InvoiceItem { OrganizationId = org.Id, InvoiceId = inv2.Id, Description = "اشتراك برو شهري — Demo Pro subscription", Quantity = 1, UnitPrice = 1500m, Currency = "EGP" });
            db.Payments.Add(new Payment { OrganizationId = org.Id, InvoiceId = inv2.Id, Amount = 1500m, Currency = "EGP", Method = "Manual", Status = PaymentStatus.Confirmed, ConfirmedAt = DateTimeOffset.UtcNow.AddDays(-30), IdempotencyKey = "demo-seed-inv2" });
        }

        // --- demo license ---
        if (subscription is not null && plan is not null && product is not null
            && !await db.Licenses.AnyAsync(l => l.OrganizationId == org.Id && l.CustomerId == customer.Id && l.SubscriptionId == subscription.Id, ct))
        {
            var app = await db.ProductApplications.AsNoTracking().FirstOrDefaultAsync(a => a.ProductId == product.Id, ct);
            if (app is not null)
            {
                db.Licenses.Add(new License
                {
                    OrganizationId = org.Id,
                    CustomerId = customer.Id,
                    ProductId = product.Id,
                    ApplicationId = app.Id,
                    SubscriptionId = subscription.Id,
                    PlanId = plan.Id,
                    Type = LicenseType.Hybrid,
                    State = LicenseState.Active,
                    DeviceLimit = plan.DeviceLimit,
                    SessionLimit = plan.SessionLimit,
                    IssuedAt = DateTimeOffset.UtcNow.AddDays(-10),
                    ExpiresAt = DateTimeOffset.UtcNow.AddDays(355)
                });
            }
        }

        // --- open support ticket ---
        if (!await db.SupportTickets.AnyAsync(t => t.OrganizationId == org.Id && t.Subject.StartsWith("[DEMO]"), ct))
        {
            db.SupportTickets.Add(new SupportTicket
            {
                OrganizationId = org.Id,
                CustomerId = customer.Id,
                Subject = "[DEMO] استفسار عن تجديد الاشتراك",
                Description = "أرغب في معرفة موعد تجديد اشتراكي وأجهزة التفعيل الحالية.",
                Category = TicketCategory.General,
                Priority = TicketPriority.Normal,
                Status = TicketStatus.Open,
                CreatedByUserId = portal.Id,
                SlaDueAt = DateTimeOffset.UtcNow.AddDays(3)
            });
        }

        // --- pending approval: renewal request ---
        var subForApproval = subscription ?? await db.Subscriptions.FirstOrDefaultAsync(s => s.OrganizationId == org.Id && s.CustomerId == customer.Id, ct);
        if (subForApproval is not null
            && !await db.ApprovalRequests.AnyAsync(a => a.SubscriptionId == subForApproval.Id && a.Status == ApprovalStatus.Pending, ct))
        {
            db.ApprovalRequests.Add(new ApprovalRequest
            {
                OrganizationId = org.Id,
                Kind = ApprovalKind.SubscriptionRenewal,
                Status = ApprovalStatus.Pending,
                SubscriptionId = subForApproval.Id,
                CustomerId = customer.Id,
                Reason = "طلب تجديد تجريبي من البوابة",
                RequestedByPortal = true,
                RequestedByUserId = portal.Id
            });
        }

        await db.SaveChangesAsync(ct);
        logger.LogInformation("Demo seed ensured for org {OrgId}", org.Id);
    }
}

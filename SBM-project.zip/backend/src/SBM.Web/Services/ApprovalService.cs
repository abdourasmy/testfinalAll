using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Subscriptions.Domain;
using SBM.Modules.Subscriptions.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Services;

/// <summary>
/// Staff approval queue for customer requests (renewal / cancellation). Approval executes the
/// underlying business transition; rejection only closes the request. Portal-created requests are
/// identical to staff-created ones. Renewal extends the period from the later of now/period-end;
/// cancellation applies the subscription state machine (terminal Cancelled).
/// </summary>
public sealed class ApprovalService
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public ApprovalService(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public IQueryable<ApprovalRequest> Scoped(IQueryable<ApprovalRequest> q) => TenantScope.Org(q, _tenant);

    public async Task<List<ApprovalRequest>> PendingAsync(CancellationToken ct = default) =>
        await Scoped(_db.ApprovalRequests.AsNoTracking())
            .Where(a => a.Status == ApprovalStatus.Pending)
            .OrderBy(a => a.RequestedAt)
            .Take(100)
            .ToListAsync(ct);

    public async Task<int> PendingCountAsync(CancellationToken ct = default) =>
        await Scoped(_db.ApprovalRequests.AsNoTracking())
            .CountAsync(a => a.Status == ApprovalStatus.Pending, ct);

    public async Task<ApprovalRequest> ApproveAsync(Guid id, string? note, CancellationToken ct = default)
    {
        var request = await _db.ApprovalRequests.FirstOrDefaultAsync(a => a.Id == id, ct)
            ?? throw new KeyNotFoundException("Approval request not found.");
        if (!TenantScope.Owns(request, _tenant)) throw new KeyNotFoundException("Approval request not found.");
        if (request.Status != ApprovalStatus.Pending) throw new InvalidOperationException($"Request already decided ({request.Status}).");

        var subscription = await _db.Subscriptions.FirstOrDefaultAsync(s => s.Id == request.SubscriptionId, ct)
            ?? throw new KeyNotFoundException("Subscription not found.");
        if (subscription.OrganizationId != request.OrganizationId) throw new KeyNotFoundException("Subscription not found.");

        var actorId = _tenant.UserId;
        var now = DateTimeOffset.UtcNow;

        if (request.Kind == ApprovalKind.SubscriptionRenewal)
        {
            // Renewal is a period extension, not a state transition. The state machine only guards
            // changes of status (e.g. Expired/GracePeriod/PastDue -> Active). Already-Active stays Active.
            if (subscription.Status != SubscriptionStatus.Active)
                SubscriptionStateMachine.EnsureTransition(subscription.Status, SubscriptionStatus.Active);
            var plan = await _db.PricingPlans.AsNoTracking().FirstOrDefaultAsync(p => p.Id == subscription.PlanId, ct)
                ?? throw new KeyNotFoundException("Plan not found.");
            var days = plan.Interval switch
            {
                BillingInterval.Monthly => 30,
                BillingInterval.Quarterly => 90,
                BillingInterval.Annual => 365,
                BillingInterval.Custom => plan.CustomDurationDays ?? 30,
                BillingInterval.OneTime => plan.CustomDurationDays ?? 365,
                _ => 30
            };
            var start = subscription.CurrentPeriodEnd > now ? subscription.CurrentPeriodEnd : now;
            subscription.CurrentPeriodStart = now;
            subscription.CurrentPeriodEnd = start.AddDays(days);
            subscription.Status = SubscriptionStatus.Active;
            subscription.Access = AccessMode.Full;
            subscription.CancelledAt = null;
            subscription.SuspendedAt = null;
            _db.SubscriptionEvents.Add(new SubscriptionEvent
            {
                OrganizationId = subscription.OrganizationId,
                SubscriptionId = subscription.Id,
                EventType = "renewed",
                Details = $"Approved renewal request {request.Id}",
                ActorUserId = actorId
            });
            _db.OutboxMessages.Add(new OutboxMessage { Type = "subscription.renewed", Payload = System.Text.Json.JsonSerializer.Serialize(new { subscriptionId = subscription.Id, requestId = request.Id }) });
        }
        else if (request.Kind == ApprovalKind.SubscriptionCancellation)
        {
            SubscriptionStateMachine.EnsureTransition(subscription.Status, SubscriptionStatus.Cancelled);
            subscription.Status = SubscriptionStatus.Cancelled;
            subscription.Access = AccessMode.None;
            subscription.CancelledAt = now;
            subscription.CancellationReason = request.Reason;
            _db.SubscriptionEvents.Add(new SubscriptionEvent
            {
                OrganizationId = subscription.OrganizationId,
                SubscriptionId = subscription.Id,
                EventType = "cancelled",
                Details = $"Approved cancellation request {request.Id}",
                ActorUserId = actorId
            });
            _db.OutboxMessages.Add(new OutboxMessage { Type = "subscription.cancelled", Payload = System.Text.Json.JsonSerializer.Serialize(new { subscriptionId = subscription.Id, requestId = request.Id }) });
        }

        request.Status = ApprovalStatus.Approved;
        request.DecidedByUserId = actorId;
        request.DecidedAt = now;
        request.DecisionNote = note;
        await _db.SaveChangesAsync(ct);
        return request;
    }

    public async Task<ApprovalRequest> RejectAsync(Guid id, string? note, CancellationToken ct = default)
    {
        var request = await _db.ApprovalRequests.FirstOrDefaultAsync(a => a.Id == id, ct)
            ?? throw new KeyNotFoundException("Approval request not found.");
        if (!TenantScope.Owns(request, _tenant)) throw new KeyNotFoundException("Approval request not found.");
        if (request.Status != ApprovalStatus.Pending) throw new InvalidOperationException($"Request already decided ({request.Status}).");

        request.Status = ApprovalStatus.Rejected;
        request.DecidedByUserId = _tenant.UserId;
        request.DecidedAt = DateTimeOffset.UtcNow;
        request.DecisionNote = note;
        await _db.SaveChangesAsync(ct);
        return request;
    }
}

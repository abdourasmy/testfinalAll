using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Identity.Entities;

namespace SBM.Web.Services;

/// <summary>Real invoice PDF (QuestPDF). Company header, billed-to, line items, totals, status.</summary>
public sealed class InvoicePdfService
{
    private readonly SbmDbContext _db;

    public InvoicePdfService(SbmDbContext db) => _db = db;

    public async Task<byte[]> GenerateAsync(Invoice invoice, CancellationToken ct = default)
    {
        var items = await _db.InvoiceItems.AsNoTracking()
            .Where(i => i.InvoiceId == invoice.Id)
            .ToListAsync(ct);
        var customer = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.Id == invoice.CustomerId, ct);
        var org = await _db.Organizations.AsNoTracking().FirstOrDefaultAsync(o => o.Id == invoice.OrganizationId, ct);

        RegisterArabicFontIfAvailable();
        QuestPDF.Settings.License = LicenseType.Community;

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(40);
                page.DefaultTextStyle(x => x.FontSize(10));
                page.Header().Row(row =>
                {
                    row.RelativeItem().Column(col =>
                    {
                        col.Item().Text(org?.Name ?? "SBM").Bold().FontSize(16);
                        col.Item().Text("Software Business Manager").FontSize(9).FontColor(Colors.Grey.Darken1);
                    });
                    row.ConstantItem(180).Column(col =>
                    {
                        col.Item().AlignRight().Text("INVOICE / فاتورة").Bold().FontSize(14);
                        col.Item().AlignRight().Text(invoice.Number).FontSize(12);
                    });
                });
                page.Content().PaddingVertical(16).Column(content =>
                {
                    content.Item().Row(row =>
                    {
                        row.RelativeItem().Column(col =>
                        {
                            col.Item().Text("Bill to / العميل").FontSize(8).FontColor(Colors.Grey.Darken1);
                            col.Item().Text(customer?.Name ?? "-").Bold();
                            if (customer?.Email is not null) col.Item().Text(customer.Email);
                            if (customer?.TaxIdentifier is not null) col.Item().Text($"Tax ID: {customer.TaxIdentifier}");
                        });
                        row.ConstantItem(200).Column(col =>
                        {
                            col.Item().AlignRight().Text($"Status: {invoice.Status}");
                            col.Item().AlignRight().Text($"Issued: {invoice.IssuedAt?.ToString("yyyy-MM-dd") ?? "-"}");
                            col.Item().AlignRight().Text($"Due: {invoice.DueAt?.ToString("yyyy-MM-dd") ?? "-"}");
                            col.Item().AlignRight().Text($"Currency: {invoice.Currency}");
                        });
                    });

                    content.Item().PaddingVertical(12).Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(4);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(2);
                            columns.RelativeColumn(2);
                        });
                        table.Header(header =>
                        {
                            header.Cell().Background(Colors.Grey.Lighten2).Padding(6).Text("Description / البيان").SemiBold();
                            header.Cell().Background(Colors.Grey.Lighten2).Padding(6).Text("Qty").SemiBold();
                            header.Cell().Background(Colors.Grey.Lighten2).Padding(6).Text("Unit price").SemiBold();
                            header.Cell().Background(Colors.Grey.Lighten2).Padding(6).Text("Line total").SemiBold();
                        });
                        foreach (var item in items)
                        {
                            table.Cell().Padding(6).Text(item.Description);
                            table.Cell().Padding(6).Text(item.Quantity.ToString());
                            table.Cell().Padding(6).Text(item.UnitPrice.ToString("N2"));
                            table.Cell().Padding(6).Text(item.LineTotal.ToString("N2"));
                        }
                    });

                    content.Item().AlignRight().Column(col =>
                    {
                        col.Item().Text($"Subtotal: {invoice.SubTotal:N2}");
                        col.Item().Text($"Discount: {invoice.DiscountTotal:N2}");
                        col.Item().Text($"Tax: {invoice.TaxTotal:N2}");
                        col.Item().Text($"Grand total: {invoice.GrandTotal:N2} {invoice.Currency}").Bold().FontSize(12);
                        col.Item().Text($"Amount paid: {invoice.AmountPaid:N2}");
                        col.Item().Text($"Outstanding: {invoice.GrandTotal - invoice.AmountPaid:N2}").FontColor(Colors.Red.Darken2);
                    });
                });
                page.Footer().AlignCenter().Text($"{invoice.Number} — generated by SBM — {DateTimeOffset.UtcNow:yyyy-MM-dd HH:mm} UTC")
                    .FontSize(8).FontColor(Colors.Grey.Darken1);
            });
        });

        return document.GeneratePdf();
    }

    private static bool _fontRegistered;
    private static void RegisterArabicFontIfAvailable()
    {
        if (_fontRegistered) return;
        _fontRegistered = true;
        foreach (var candidate in new[]
        {
            @"C:\Windows\Fonts\arial.ttf",
            @"C:\Windows\Fonts\tahoma.ttf",
            @"C:\Windows\Fonts\NotoNaskhArabic-Regular.ttf",
        })
        {
            try
            {
                if (File.Exists(candidate))
                    QuestPDF.Drawing.FontManager.RegisterFont(File.OpenRead(candidate));
            }
            catch { /* font registration is best-effort; default fonts still render Latin */ }
        }
    }
}

using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Billing.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Services;

/// <summary>
/// Sales pipeline: Quotation -> Send -> Accept -> Convert -> Order -> Confirm -> Fulfill -> Invoice.
/// Org-scoped by the caller's tenant context. Every transition is audited in SalesEvents and
/// raises a domain event that lands in the transactional outbox (offline-sync journal).
/// </summary>
public sealed class SalesService
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly InvoiceNumberingService _numbering;

    public SalesService(SbmDbContext db, ITenantContext tenant, InvoiceNumberingService numbering)
    {
        _db = db;
        _tenant = tenant;
        _numbering = numbering;
    }

    public sealed record LineInput(string Description, int Quantity, decimal UnitPrice, decimal DiscountPercent, decimal TaxPercent);

    private Guid OrgId => _tenant.OrganizationId ?? throw new UnauthorizedAccessException("Organization scope required.");

    private async Task<Quotation> LoadOwnedQuotationAsync(Guid id, CancellationToken ct)
    {
        var q = await _db.Quotations.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (q is null || !TenantScope.Owns(q, _tenant)) throw new KeyNotFoundException("Quotation not found.");
        return q;
    }

    private async Task<SalesOrder> LoadOwnedOrderAsync(Guid id, CancellationToken ct)
    {
        var o = await _db.SalesOrders.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (o is null || !TenantScope.Owns(o, _tenant)) throw new KeyNotFoundException("Order not found.");
        return o;
    }

    private void LogEvent(string entityType, Guid entityId, string eventType, Guid orgId, string? details, Guid? actor)
    {
        _db.SalesEvents.Add(new SalesEvent
        {
            OrganizationId = orgId,
            EntityType = entityType,
            EntityId = entityId,
            EventType = eventType,
            Details = details,
            ActorUserId = actor
        });
    }

    public async Task<Quotation> CreateQuotationAsync(Guid customerId, IReadOnlyList<LineInput> lines, DateTimeOffset? validUntil, string? notes, string currency, CancellationToken ct)
    {
        var orgId = OrgId;
        if (lines is null || lines.Count == 0) throw new ArgumentException("At least one line is required.");
        _ = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == customerId, ct)
            ?? throw new KeyNotFoundException("Customer not found.");

        var year = DateTimeOffset.UtcNow.Year.ToString();
        var number = await _numbering.NextNumberAsync(orgId, "QUO", year, ct);
        var quotation = new Quotation
        {
            OrganizationId = orgId,
            CustomerId = customerId,
            Number = number,
            Status = QuotationStatus.Draft,
            Currency = (currency ?? "EGP").ToUpperInvariant(),
            ValidUntil = validUntil,
            Notes = notes,
            CreatedByUserId = _tenant.UserId
        };
        Recalculate(quotation, lines);
        var quoteLines = lines.Select(l => new QuotationLine
        {
            OrganizationId = orgId,
            QuotationId = quotation.Id,
            Description = l.Description?.Trim() ?? "Item",
            Quantity = Math.Max(1, l.Quantity),
            UnitPrice = l.UnitPrice,
            DiscountPercent = l.DiscountPercent,
            TaxPercent = l.TaxPercent,
            Currency = quotation.Currency
        }).ToList();
        _db.Quotations.Add(quotation);
        _db.QuotationLines.AddRange(quoteLines);
        LogEvent("Quotation", quotation.Id, "created", orgId, number, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return quotation;
    }

    public async Task<Quotation> SendQuotationAsync(Guid id, CancellationToken ct)
    {
        var q = await LoadOwnedQuotationAsync(id, ct);
        if (q.Status != QuotationStatus.Draft) throw new InvalidOperationException($"Only draft quotations can be sent (current: {q.Status}).");
        q.TransitionTo(QuotationStatus.Sent);
        LogEvent("Quotation", q.Id, "sent", q.OrganizationId, null, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return q;
    }

    public async Task<Quotation> AcceptQuotationAsync(Guid id, CancellationToken ct)
    {
        var q = await LoadOwnedQuotationAsync(id, ct);
        if (q.Status != QuotationStatus.Sent) throw new InvalidOperationException($"Only sent quotations can be accepted (current: {q.Status}).");
        q.TransitionTo(QuotationStatus.Accepted);
        LogEvent("Quotation", q.Id, "accepted", q.OrganizationId, null, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return q;
    }

    public async Task<Quotation> RejectQuotationAsync(Guid id, string? reason, CancellationToken ct)
    {
        var q = await LoadOwnedQuotationAsync(id, ct);
        if (q.Status is not (QuotationStatus.Sent or QuotationStatus.Draft)) throw new InvalidOperationException($"Quotation cannot be rejected (current: {q.Status}).");
        q.TransitionTo(QuotationStatus.Rejected);
        LogEvent("Quotation", q.Id, "rejected", q.OrganizationId, reason, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return q;
    }

    /// <summary>Converts an accepted quotation into an order, copying lines 1:1.</summary>
    public async Task<SalesOrder> ConvertToOrderAsync(Guid id, CancellationToken ct)
    {
        var quotation = await LoadOwnedQuotationAsync(id, ct);
        if (quotation.Status != QuotationStatus.Accepted) throw new InvalidOperationException($"Only accepted quotations convert to orders (current: {quotation.Status}).");
        var orgId = quotation.OrganizationId;
        var lines = await _db.QuotationLines.Where(l => l.QuotationId == id).ToListAsync(ct);
        var year = DateTimeOffset.UtcNow.Year.ToString();
        var number = await _numbering.NextNumberAsync(orgId, "ORD", year, ct);
        var order = new SalesOrder
        {
            OrganizationId = orgId,
            CustomerId = quotation.CustomerId,
            QuotationId = quotation.Id,
            Number = number,
            Status = SalesOrderStatus.PendingConfirmation,
            Currency = quotation.Currency,
            SubTotal = quotation.SubTotal,
            DiscountTotal = quotation.DiscountTotal,
            TaxTotal = quotation.TaxTotal,
            GrandTotal = quotation.GrandTotal,
            CreatedByUserId = _tenant.UserId
        };
        _db.SalesOrders.Add(order);
        _db.SalesOrderLines.AddRange(lines.Select(l => new SalesOrderLine
        {
            OrganizationId = orgId,
            SalesOrderId = order.Id,
            Description = l.Description,
            Quantity = l.Quantity,
            UnitPrice = l.UnitPrice,
            DiscountPercent = l.DiscountPercent,
            TaxPercent = l.TaxPercent,
            Currency = l.Currency
        }));
        quotation.TransitionTo(QuotationStatus.Converted);
        quotation.ConvertedOrderId = order.Id;
        LogEvent("Order", order.Id, "created", orgId, $"from {quotation.Number}", _tenant.UserId);
        LogEvent("Quotation", quotation.Id, "converted", orgId, number, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return order;
    }

    public async Task<SalesOrder> ConfirmOrderAsync(Guid id, CancellationToken ct)
    {
        var o = await LoadOwnedOrderAsync(id, ct);
        if (o.Status != SalesOrderStatus.PendingConfirmation) throw new InvalidOperationException($"Only pending orders can be confirmed (current: {o.Status}).");
        o.TransitionTo(SalesOrderStatus.Confirmed);
        LogEvent("Order", o.Id, "confirmed", o.OrganizationId, null, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return o;
    }

    public async Task<SalesOrder> FulfillOrderAsync(Guid id, CancellationToken ct)
    {
        var o = await LoadOwnedOrderAsync(id, ct);
        if (o.Status != SalesOrderStatus.Confirmed) throw new InvalidOperationException($"Only confirmed orders can be fulfilled (current: {o.Status}).");
        o.TransitionTo(SalesOrderStatus.Fulfilled);
        LogEvent("Order", o.Id, "fulfilled", o.OrganizationId, null, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return o;
    }

    /// <summary>Converts a fulfilled order into an issued invoice, copying lines; links both ways.</summary>
    public async Task<Invoice> ConvertToInvoiceAsync(Guid orderId, CancellationToken ct)
    {
        var order = await LoadOwnedOrderAsync(orderId, ct);
        if (order.Status != SalesOrderStatus.Fulfilled) throw new InvalidOperationException($"Only fulfilled orders convert to invoices (current: {order.Status}).");
        var orgId = order.OrganizationId;
        var lines = await _db.SalesOrderLines.Where(l => l.SalesOrderId == orderId).ToListAsync(ct);
        var year = DateTimeOffset.UtcNow.Year.ToString();
        var number = await _numbering.NextNumberAsync(orgId, "INV", year, ct);
        var currency = order.Currency;
        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = order.CustomerId,
            Number = number,
            Prefix = "INV",
            FinancialYear = year,
            Status = InvoiceStatus.Issued,
            IssuedAt = DateTimeOffset.UtcNow,
            Currency = currency,
            SubTotal = order.SubTotal,
            DiscountTotal = order.DiscountTotal,
            TaxTotal = order.TaxTotal,
            GrandTotal = order.GrandTotal
        };
        _db.Invoices.Add(invoice);
        _db.InvoiceItems.AddRange(lines.Select(l => new InvoiceItem
        {
            OrganizationId = orgId,
            InvoiceId = invoice.Id,
            Description = l.Description,
            Quantity = l.Quantity,
            UnitPrice = l.UnitPrice,
            DiscountPercent = l.DiscountPercent,
            TaxPercent = l.TaxPercent,
            Currency = l.Currency
        }));
        order.TransitionTo(SalesOrderStatus.Invoiced);
        order.InvoiceId = invoice.Id;
        LogEvent("Order", order.Id, "invoiced", orgId, number, _tenant.UserId);
        await _db.SaveChangesAsync(ct);
        return invoice;
    }

    private static void Recalculate(Quotation q, IReadOnlyList<LineInput> lines)
    {
        decimal sub = 0, tax = 0, disc = 0;
        foreach (var l in lines)
        {
            var line = new QuotationLine
            {
                Description = l.Description, Quantity = Math.Max(1, l.Quantity), UnitPrice = l.UnitPrice,
                DiscountPercent = l.DiscountPercent, TaxPercent = l.TaxPercent
            };
            sub += line.LineNet;
            tax += line.LineTax;
            disc += decimal.Round(line.Quantity * line.UnitPrice * line.DiscountPercent / 100m, 2, MidpointRounding.AwayFromZero);
        }
        q.SubTotal = sub;
        q.TaxTotal = tax;
        q.DiscountTotal = disc;
        q.GrandTotal = sub + tax;
    }
}

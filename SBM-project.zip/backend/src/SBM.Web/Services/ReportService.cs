using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Finance.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Support.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Services;

public sealed record ReportResult(
    string Key,
    string TitleAr,
    string TitleEn,
    IReadOnlyList<string> Columns,
    IReadOnlyList<IReadOnlyList<string>> Rows);

/// <summary>
/// Database-backed reports. BUG FIX (reports SQL translation): EF Core cannot translate
/// certain GroupBy shapes (multi-part composite keys with computed members) to SQL on all
/// providers, so the revenue and payments reports materialize the source rows and group
/// client-side. Do not "simplify" this back into a single GroupBy — see ReportsTests regression tests.
/// </summary>
public sealed class ReportService
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public ReportService(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public static readonly IReadOnlyList<(string Key, string TitleAr, string TitleEn)> Catalog = new[]
    {
        ("revenue", "تقرير الإيرادات", "Revenue"),
        ("payments", "تقرير المدفوعات", "Payments"),
        ("outstanding-invoices", "الفواتير المستحقة", "Outstanding invoices"),
        ("subscriptions", "تقرير الاشتراكات", "Subscriptions"),
        ("licenses", "تقرير التراخيص", "Licenses"),
        ("top-customers", "أفضل العملاء", "Top customers"),
        ("expenses", "تقرير المصروفات", "Expenses"),
        ("cancellations", "تقرير الإلغاءات", "Cancellations"),
        ("support-sla", "تقرير الدعم والالتزام بالخدمة", "Support & SLA"),
    };

    public Task<ReportResult> RunAsync(string key, CancellationToken ct = default) => key switch
    {
        "revenue" => RevenueAsync(ct),
        "payments" => PaymentsAsync(ct),
        "outstanding-invoices" => OutstandingInvoicesAsync(ct),
        "subscriptions" => SubscriptionsAsync(ct),
        "licenses" => LicensesAsync(ct),
        "top-customers" => TopCustomersAsync(ct),
        "expenses" => ExpensesAsync(ct),
        "cancellations" => CancellationsAsync(ct),
        "support-sla" => SupportSlaAsync(ct),
        _ => throw new KeyNotFoundException($"Unknown report '{key}'.")
    };

    private IQueryable<Payment> ScopedPayments() => TenantScope.Org(_db.Payments.AsNoTracking(), _tenant);
    private IQueryable<Invoice> ScopedInvoices() => TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant);
    private IQueryable<Customer> ScopedCustomers() => TenantScope.Org(_db.Customers.AsNoTracking(), _tenant);

    private static readonly IReadOnlyList<string> MonthColumns = new[] { "الشهر / Month", "عدد المدفوعات / Payments", "المبلغ / Amount", "العملة / Currency" };

    // Client-side grouping on purpose (SQL translation bug fix).
    private async Task<ReportResult> RevenueAsync(CancellationToken ct)
    {
        var since = DateTimeOffset.UtcNow.AddMonths(-11);
        var rows = await ScopedPayments()
            .Where(p => p.Status == PaymentStatus.Confirmed && p.ConfirmedAt != null && p.ConfirmedAt >= since)
            .ToListAsync(ct);

        var grouped = rows
            .GroupBy(p => new { Month = p.ConfirmedAt!.Value.ToString("yyyy-MM"), p.Currency })
            .OrderBy(g => g.Key.Month).ThenBy(g => g.Key.Currency)
            .Select(g => (IReadOnlyList<string>)new[] { g.Key.Month, g.Count().ToString(), g.Sum(x => x.Amount).ToString("N2"), g.Key.Currency })
            .ToList();

        return new ReportResult("revenue", "تقرير الإيرادات", "Revenue", MonthColumns, grouped);
    }

    // Client-side grouping on purpose (SQL translation bug fix).
    private async Task<ReportResult> PaymentsAsync(CancellationToken ct)
    {
        var since = DateTimeOffset.UtcNow.AddMonths(-11);
        var rows = await ScopedPayments()
            .Where(p => p.ConfirmedAt != null && p.ConfirmedAt >= since)
            .ToListAsync(ct);

        var grouped = rows
            .GroupBy(p => new { Method = p.Method ?? "Manual", p.Currency })
            .OrderBy(g => g.Key.Method)
            .Select(g => (IReadOnlyList<string>)new[] { g.Key.Method, g.Count().ToString(), g.Sum(x => x.Amount).ToString("N2"), g.Key.Currency })
            .ToList();

        return new ReportResult("payments", "تقرير المدفوعات", "Payments",
            new[] { "الطريقة / Method", "العدد / Count", "المبلغ / Amount", "العملة / Currency" }, grouped);
    }

    private async Task<ReportResult> OutstandingInvoicesAsync(CancellationToken ct)
    {
        var rows = await ScopedInvoices()
            .Where(i => i.Status == InvoiceStatus.Issued || i.Status == InvoiceStatus.PartiallyPaid || i.Status == InvoiceStatus.Overdue)
            .OrderByDescending(i => i.IssuedAt)
            .Take(500)
            .ToListAsync(ct);
        var data = rows.Select(i => (IReadOnlyList<string>)new[]
        {
            i.Number, i.CustomerId.ToString()[..8], i.Status.ToString(),
            i.GrandTotal.ToString("N2"), i.AmountPaid.ToString("N2"), (i.GrandTotal - i.AmountPaid).ToString("N2"), i.Currency,
            i.DueAt?.ToString("yyyy-MM-dd") ?? "-"
        }).ToList();
        return new ReportResult("outstanding-invoices", "الفواتير المستحقة", "Outstanding invoices",
            new[] { "الرقم / Number", "العميل / Customer", "الحالة / Status", "الإجمالي / Total", "المدفوع / Paid", "المتبقي / Outstanding", "العملة / Currency", "الاستحقاق / Due" }, data);
    }

    private async Task<ReportResult> SubscriptionsAsync(CancellationToken ct)
    {
        var plans = await _db.PricingPlans.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Name, ct);
        var subs = await TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant)
            .Where(s => s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.Trial
                     || s.Status == SubscriptionStatus.PastDue || s.Status == SubscriptionStatus.GracePeriod)
            .ToListAsync(ct);
        // Composite GroupBy kept client-side for provider safety.
        var data = subs.GroupBy(s => new { Plan = plans.TryGetValue(s.PlanId, out var n) ? n : s.PlanId.ToString()[..8], s.Status })
            .OrderBy(g => g.Key.Plan)
            .Select(g => (IReadOnlyList<string>)new[] { g.Key.Plan, g.Key.Status.ToString(), g.Count().ToString() })
            .ToList();
        return new ReportResult("subscriptions", "تقرير الاشتراكات", "Subscriptions",
            new[] { "الخطة / Plan", "الحالة / Status", "العدد / Count" }, data);
    }

    private async Task<ReportResult> LicensesAsync(CancellationToken ct)
    {
        var licenses = await TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant).ToListAsync(ct);
        var data = licenses.GroupBy(l => l.State)
            .OrderBy(g => g.Key)
            .Select(g => (IReadOnlyList<string>)new[] { g.Key.ToString(), g.Count().ToString(), g.Sum(l => l.TransferCount).ToString() })
            .ToList();
        return new ReportResult("licenses", "تقرير التراخيص", "Licenses",
            new[] { "الحالة / State", "العدد / Count", "إجمالي النقل / Transfers" }, data);
    }

    private async Task<ReportResult> TopCustomersAsync(CancellationToken ct)
    {
        var invoices = await ScopedInvoices()
            .Where(i => i.Status == InvoiceStatus.Paid || i.Status == InvoiceStatus.PartiallyPaid)
            .ToListAsync(ct);
        var customers = await ScopedCustomers().ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        var data = invoices.GroupBy(i => i.CustomerId)
            .Select(g => new { Customer = customers.TryGetValue(g.Key, out var n) ? n : g.Key.ToString()[..8], Total = g.Sum(i => i.AmountPaid), Count = g.Count(), Currency = g.First().Currency })
            .OrderByDescending(x => x.Total)
            .Take(20)
            .Select(x => (IReadOnlyList<string>)new[] { x.Customer, x.Count.ToString(), x.Total.ToString("N2"), x.Currency })
            .ToList();
        return new ReportResult("top-customers", "أفضل العملاء", "Top customers",
            new[] { "العميل / Customer", "فواتير مدفوعة / Paid invoices", "الإجمالي المدفوع / Total paid", "العملة / Currency" }, data);
    }

    private async Task<ReportResult> ExpensesAsync(CancellationToken ct)
    {
        var since = DateTimeOffset.UtcNow.AddMonths(-11);
        var rows = await TenantScope.Org(_db.FinanceEntries.AsNoTracking(), _tenant)
            .Where(e => e.Type == FinanceEntryType.Expense && e.OccurredAt >= since)
            .ToListAsync(ct);
        var data = rows.GroupBy(e => new { e.Category, e.Currency })
            .OrderByDescending(g => g.Sum(x => x.Amount))
            .Select(g => (IReadOnlyList<string>)new[] { g.Key.Category, g.Count().ToString(), g.Sum(x => x.Amount).ToString("N2"), g.Key.Currency })
            .ToList();
        return new ReportResult("expenses", "تقرير المصروفات", "Expenses",
            new[] { "الفئة / Category", "العدد / Count", "المبلغ / Amount", "العملة / Currency" }, data);
    }

    private async Task<ReportResult> CancellationsAsync(CancellationToken ct)
    {
        var since = DateTimeOffset.UtcNow.AddMonths(-11);
        var rows = await TenantScope.Org(_db.SubscriptionEvents.AsNoTracking(), _tenant)
            .Where(e => e.EventType == "cancelled" && e.OccurredAtUtc >= since)
            .OrderByDescending(e => e.OccurredAtUtc)
            .Take(500)
            .ToListAsync(ct);
        var data = rows.Select(e => (IReadOnlyList<string>)new[]
        {
            e.OccurredAtUtc.ToString("yyyy-MM-dd HH:mm"), e.SubscriptionId.ToString()[..8], e.Details ?? "-"
        }).ToList();
        return new ReportResult("cancellations", "تقرير الإلغاءات", "Cancellations",
            new[] { "التاريخ / Date", "الاشتراك / Subscription", "التفاصيل / Details" }, data);
    }

    private async Task<ReportResult> SupportSlaAsync(CancellationToken ct)
    {
        var rows = await TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant).ToListAsync(ct);
        var now = DateTimeOffset.UtcNow;
        var data = rows.GroupBy(t => new { t.Status, t.Priority })
            .OrderBy(g => g.Key.Status).ThenBy(g => g.Key.Priority)
            .Select(g =>
            {
                var breached = g.Count(t => t.SlaDueAt is not null && t.SlaDueAt < now
                    && t.Status != TicketStatus.Resolved && t.Status != TicketStatus.Closed);
                return (IReadOnlyList<string>)new[] { g.Key.Status.ToString(), g.Key.Priority.ToString(), g.Count().ToString(), breached.ToString() };
            })
            .ToList();
        return new ReportResult("support-sla", "تقرير الدعم والالتزام بالخدمة", "Support & SLA",
            new[] { "الحالة / Status", "الأولوية / Priority", "العدد / Count", "تجاوز SLA / SLA breached" }, data);
    }
}

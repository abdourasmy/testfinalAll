using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;
using SBM.Web.Security;

namespace SBM.Web.Services;

/// <summary>Issues server-side staff and portal cookies. Claims are built exclusively from
/// the database and ASP.NET Identity — never from client input.</summary>
public sealed class SignInService
{
    private readonly SbmDbContext _db;
    private readonly UserManager<ApplicationUser> _users;

    public SignInService(SbmDbContext db, UserManager<ApplicationUser> users)
    {
        _db = db;
        _users = users;
    }

    public async Task SignInStaffAsync(HttpContext http, ApplicationUser user)
    {
        var roles = await _users.GetRolesAsync(user);
        var isPlatform = user.Scope == AccountScope.Platform || user.IsPlatformOwner || roles.Contains("PlatformAdmin");

        var membership = await _db.OrganizationMemberships.AsNoTracking()
            .Where(m => m.UserId == user.Id && m.Status == "Active")
            .OrderBy(m => m.JoinedAt)
            .FirstOrDefaultAsync();

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, string.IsNullOrWhiteSpace(user.DisplayName) ? user.Email! : user.DisplayName),
            new("scope", isPlatform ? "platform" : "organization"),
            new("stamp", user.SecurityStamp ?? Guid.NewGuid().ToString()),
        };
        if (membership is not null)
            claims.Add(new Claim("org_id", membership.OrganizationId.ToString()));
        foreach (var role in roles)
            claims.Add(new Claim(ClaimTypes.Role, role));

        var identity = new ClaimsIdentity(claims, CookieSchemes.Staff, ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);
        await http.SignInAsync(CookieSchemes.Staff, new ClaimsPrincipal(identity),
            new AuthenticationProperties { ExpiresUtc = DateTimeOffset.UtcNow.AddHours(8), IsPersistent = false });
    }

    public async Task SignInPortalAsync(HttpContext http, ApplicationUser user)
    {
        if (user.CustomerId is not { } customerId)
            throw new InvalidOperationException("Portal sign-in requires a customer link.");

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, string.IsNullOrWhiteSpace(user.DisplayName) ? user.Email! : user.DisplayName),
            new("scope", "portal"),
            new("customer_id", customerId.ToString()),
        };
        var identity = new ClaimsIdentity(claims, CookieSchemes.Portal, ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);
        await http.SignInAsync(CookieSchemes.Portal, new ClaimsPrincipal(identity),
            new AuthenticationProperties { ExpiresUtc = DateTimeOffset.UtcNow.AddHours(4), IsPersistent = false });
    }

    /// <summary>Short-lived cookie marking "password verified, second factor pending".</summary>
    public async Task SignInMfaPendingAsync(HttpContext http, ApplicationUser user)
    {
        var claims = new List<Claim> { new(ClaimTypes.NameIdentifier, user.Id.ToString()), new("scope", "mfa-pending") };
        var identity = new ClaimsIdentity(claims, CookieSchemes.MfaPending);
        await http.SignInAsync(CookieSchemes.MfaPending, new ClaimsPrincipal(identity),
            new AuthenticationProperties { ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10) });
    }
}

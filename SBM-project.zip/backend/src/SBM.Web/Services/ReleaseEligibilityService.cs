using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;

namespace SBM.Web.Services;

/// <summary>
/// Server-side eligibility for customer-portal software downloads. A release is eligible only when
/// it is Published (never Draft/Yanked) AND the customer has either an active-ish subscription to a
/// plan of the release's product, or an active (state = Active, unexpired) license for an application
/// of that product. Checked again on every download — never cached, never inferred client-side.
/// </summary>
public sealed class ReleaseEligibilityService
{
    private readonly SbmDbContext _db;

    public ReleaseEligibilityService(SbmDbContext db) => _db = db;

    public sealed record EligibleRelease(SoftwareRelease Release, string ProductName, string ApplicationName, List<ReleaseAsset> Assets);

    public async Task<List<EligibleRelease>> GetEligibleAsync(Guid customerId, CancellationToken ct = default)
    {
        var planIds = await _db.Subscriptions.AsNoTracking()
            .Where(s => s.CustomerId == customerId
                && (s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.Trial
                    || s.Status == SubscriptionStatus.GracePeriod || s.Status == SubscriptionStatus.PastDue))
            .Select(s => s.PlanId)
            .ToListAsync(ct);
        var productIdsFromSubs = await _db.PricingPlans.AsNoTracking()
            .Where(p => planIds.Contains(p.Id))
            .Select(p => p.ProductId)
            .Distinct()
            .ToListAsync(ct);

        var now = DateTimeOffset.UtcNow;
        var licenseAppIds = await _db.Licenses.AsNoTracking()
            .Where(l => l.CustomerId == customerId && l.State == LicenseState.Active && l.ExpiresAt > now)
            .Select(l => l.ApplicationId)
            .Distinct()
            .ToListAsync(ct);

        var products = await _db.Products.AsNoTracking().ToListAsync(ct);
        var appIdsFromLicenses = licenseAppIds;
        var appProductIds = await _db.ProductApplications.AsNoTracking()
            .Where(a => appIdsFromLicenses.Contains(a.Id))
            .Select(a => a.ProductId)
            .Distinct()
            .ToListAsync(ct);

        var eligibleProductIds = productIdsFromSubs.Union(appProductIds).ToHashSet();
        var eligibleProductCodes = products.Where(p => eligibleProductIds.Contains(p.Id)).Select(p => p.Code).ToHashSet();
        if (eligibleProductCodes.Count == 0) return new List<EligibleRelease>();

        var releases = await _db.SoftwareReleases.AsNoTracking()
            .Where(r => r.Status == ReleaseStatus.Published && eligibleProductCodes.Contains(r.ProductCode))
            .ToListAsync(ct);
        if (releases.Count == 0) return new List<EligibleRelease>();

        var releaseIds = releases.Select(r => r.Id).ToList();
        var assets = await _db.ReleaseAssets.AsNoTracking().Where(a => releaseIds.Contains(a.ReleaseId)).ToListAsync(ct);

        var productNames = products.ToDictionary(p => p.Code, p => p.Name);
        var applications = await _db.ProductApplications.AsNoTracking().ToListAsync(ct);
        var appNames = applications.GroupBy(a => a.Code).ToDictionary(g => g.Key, g => g.First().Name);

        return releases
            .Select(r => new EligibleRelease(
                r,
                productNames.TryGetValue(r.ProductCode, out var pn) ? pn : r.ProductCode,
                appNames.TryGetValue(r.ApplicationCode, out var an) ? an : r.ApplicationCode,
                assets.Where(a => a.ReleaseId == r.Id).ToList()))
            .OrderByDescending(x => x.Release.PublishedAt)
            .ToList();
    }

    public async Task<(bool Eligible, string? Reason, SoftwareRelease? Release, ReleaseAsset? Asset)> CheckDownloadAsync(Guid customerId, Guid releaseId, Guid assetId, CancellationToken ct = default)
    {
        var release = await _db.SoftwareReleases.AsNoTracking().FirstOrDefaultAsync(r => r.Id == releaseId, ct);
        if (release is null) return (false, "release-not-found", null, null);
        if (release.Status != ReleaseStatus.Published) return (false, "release-not-published", null, null); // drafts and yanked releases never download

        var asset = await _db.ReleaseAssets.AsNoTracking().FirstOrDefaultAsync(a => a.Id == assetId && a.ReleaseId == releaseId, ct);
        if (asset is null) return (false, "asset-not-found", null, null);

        var eligible = await GetEligibleAsync(customerId, ct);
        var match = eligible.FirstOrDefault(e => e.Release.Id == releaseId && e.Assets.Any(a => a.Id == assetId));
        if (match is null) return (false, "not-eligible", null, null);

        return (true, null, release, asset);
    }
}

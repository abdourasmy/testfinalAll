namespace SBM.Web.Services;

/// <summary>Arabic-first UI text. Resolves language from the sbm.lang cookie (ar|en, default ar).</summary>
public sealed class LanguageService
{
    public const string CookieName = "sbm.lang";
    private readonly IHttpContextAccessor _http;

    public LanguageService(IHttpContextAccessor http) => _http = http;

    public string Current
    {
        get
        {
            var v = _http.HttpContext?.Request.Cookies[CookieName];
            return string.Equals(v, "en", StringComparison.OrdinalIgnoreCase) ? "en" : "ar";
        }
    }

    public bool IsArabic => Current == "ar";
    public string Direction => IsArabic ? "rtl" : "ltr";

    /// <summary>Bilingual literal: T("لوحة المعلومات", "Dashboard").</summary>
    public string T(string ar, string en) => IsArabic ? ar : en;
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Subscriptions.Domain;
using SBM.Modules.Subscriptions.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class SubscriptionsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public SubscriptionsController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Subscriptions";
        ViewData["Nav"] = "subscriptions";
        var query = TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant);
        if (Enum.TryParse<SubscriptionStatus>(status, true, out var st))
            query = query.Where(s => s.Status == st);
        var subs = await query.OrderByDescending(s => s.CurrentPeriodEnd).Take(100).ToListAsync(ct);
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant)
            .Where(c => subs.Select(s => s.CustomerId).Contains(c.Id))
            .ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        var plans = await _db.PricingPlans.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Name, ct);
        return View(new SubscriptionsIndexViewModel(status, subs, customers, plans));
    }

    [HttpGet("/subscriptions/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Subscription";
        ViewData["Nav"] = "subscriptions";
        var sub = await TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant).FirstOrDefaultAsync(s => s.Id == id, ct);
        if (sub is null) return NotFound();
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == sub.CustomerId, ct);
        var plan = await _db.PricingPlans.AsNoTracking().FirstOrDefaultAsync(p => p.Id == sub.PlanId, ct);
        var product = plan is not null ? await _db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == plan.ProductId, ct) : null;
        var events = await TenantScope.Org(_db.SubscriptionEvents.AsNoTracking(), _tenant)
            .Where(e => e.SubscriptionId == id).OrderByDescending(e => e.OccurredAtUtc).Take(50).ToListAsync(ct);
        var requests = await TenantScope.Org(_db.ApprovalRequests.AsNoTracking(), _tenant)
            .Where(a => a.SubscriptionId == id).OrderByDescending(a => a.RequestedAt).ToListAsync(ct);
        return View(new SubscriptionDetailsViewModel(sub, customer?.Name, plan?.Name, product?.Name, events, requests));
    }

    public async Task<IActionResult> Create(CancellationToken ct)
    {
        ViewData["Nav"] = "subscriptions";
        return View(new CreateSubscriptionInput { Plans = await PlanOptionsAsync(ct), Customers = await CustomerOptionsAsync(ct) });
    }

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateSubscriptionInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            ModelState.AddModelError(string.Empty, "Organization scope required.");
            return View(new CreateSubscriptionInput { Plans = await PlanOptionsAsync(ct), Customers = await CustomerOptionsAsync(ct) });
        }
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == model.CustomerId, ct);
        var plan = model.PlanId == Guid.Empty ? null : await _db.PricingPlans.AsNoTracking().FirstOrDefaultAsync(p => p.Id == model.PlanId, ct);
        if (customer is null || plan is null)
        {
            ModelState.AddModelError(string.Empty, "Customer and plan are required.");
            return View(new CreateSubscriptionInput { Plans = await PlanOptionsAsync(ct), Customers = await CustomerOptionsAsync(ct), CustomerId = model.CustomerId, PlanId = model.PlanId });
        }
        var days = plan.Interval switch
        {
            BillingInterval.Monthly => 30,
            BillingInterval.Quarterly => 90,
            BillingInterval.Annual => 365,
            BillingInterval.Custom => plan.CustomDurationDays ?? 30,
            BillingInterval.OneTime => plan.CustomDurationDays ?? 365,
            _ => 30
        };
        var trial = plan.TrialDays > 0 && model.TryTrial;
        var sub = new Subscription
        {
            OrganizationId = orgId,
            CustomerId = customer.Id,
            ProductId = plan.ProductId,
            PlanId = plan.Id,
            Status = trial ? SubscriptionStatus.Trial : SubscriptionStatus.Active,
            Access = AccessMode.Full,
            CurrentPeriodStart = DateTimeOffset.UtcNow,
            CurrentPeriodEnd = DateTimeOffset.UtcNow.AddDays(trial ? plan.TrialDays : days)
        };
        _db.Subscriptions.Add(sub);
        _db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = orgId, SubscriptionId = sub.Id, EventType = trial ? "trial_started" : "activated", ActorUserId = _tenant.UserId });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم إنشاء الاشتراك — Subscription created.";
        return RedirectToAction(nameof(Details), new { id = sub.Id });
    }

    [HttpPost("/subscriptions/{id:guid}/cancel")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(Guid id, string? reason, CancellationToken ct)
    {
        var sub = await TenantScope.Org(_db.Subscriptions, _tenant).FirstOrDefaultAsync(s => s.Id == id, ct);
        if (sub is null) return NotFound();
        try
        {
            SubscriptionStateMachine.EnsureTransition(sub.Status, SubscriptionStatus.Cancelled);
        }
        catch (InvalidOperationException ex)
        {
            TempData["Flash"] = ex.Message;
            return RedirectToAction(nameof(Details), new { id });
        }
        sub.Status = SubscriptionStatus.Cancelled;
        sub.Access = AccessMode.None;
        sub.CancelledAt = DateTimeOffset.UtcNow;
        sub.CancellationReason = reason;
        _db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = sub.OrganizationId, SubscriptionId = sub.Id, EventType = "cancelled", Details = reason, ActorUserId = _tenant.UserId });
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task<List<(Guid Id, string Label)>> PlanOptionsAsync(CancellationToken ct) =>
        (await _db.PricingPlans.AsNoTracking().Where(p => p.IsActive).OrderBy(p => p.Name).ToListAsync(ct))
            .Select(p => (p.Id, $"{p.Name} ({p.Price:N2} {p.Currency})")).ToList();

    private async Task<List<(Guid Id, string Label)>> CustomerOptionsAsync(CancellationToken ct) =>
        (await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).OrderBy(c => c.Name).Take(500).ToListAsync(ct))
            .Select(c => (c.Id, c.Name)).ToList();
}

public sealed record SubscriptionsIndexViewModel(string? Status, List<Subscription> Subscriptions, Dictionary<Guid, string> Customers, Dictionary<Guid, string> Plans);
public sealed record SubscriptionDetailsViewModel(Subscription Subscription, string? CustomerName, string? PlanName, string? ProductName, List<SubscriptionEvent> Events, List<ApprovalRequest> Requests);
public sealed class CreateSubscriptionInput
{
    public Guid CustomerId { get; set; }
    public Guid PlanId { get; set; }
    public bool TryTrial { get; set; }
    public List<(Guid Id, string Label)> Plans { get; set; } = new();
    public List<(Guid Id, string Label)> Customers { get; set; } = new();
}

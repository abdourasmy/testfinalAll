using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[Authorize]
public class ReportsController : Controller
{
    private readonly ReportService _reports;
    private readonly ExportService _export;

    public ReportsController(ReportService reports, ExportService export)
    {
        _reports = reports;
        _export = export;
    }

    public IActionResult Index()
    {
        ViewData["Title"] = "Reports";
        ViewData["Nav"] = "reports";
        return View(ReportService.Catalog);
    }

    [HttpGet("/reports/{key}")]
    public async Task<IActionResult> ViewReport(string key, CancellationToken ct)
    {
        ViewData["Title"] = key;
        ViewData["Nav"] = "reports";
        try
        {
            var report = await _reports.RunAsync(key, ct);
            return View("Report", report);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpGet("/reports/{key}/export")]
    public async Task<IActionResult> Export(string key, string format, CancellationToken ct)
    {
        ReportResult report;
        try
        {
            report = await _reports.RunAsync(key, ct);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }

        return format.ToLowerInvariant() switch
        {
            "csv" => File(_export.ToCsv(report), "text/csv", $"{key}.csv"),
            "xlsx" => File(_export.ToXlsx(report), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{key}.xlsx"),
            "pdf" => File(_export.ToPdf(report), "application/pdf", $"{key}.pdf"),
            _ => BadRequest("format must be csv, xlsx or pdf")
        };
    }
}

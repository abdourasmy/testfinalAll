using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Notifications.Audience;
using SBM.Modules.Notifications.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>Campaigns: create audiences + campaigns, launch/cancel, inspect delivery.</summary>
[Authorize]
public class CampaignsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly CampaignLaunchService _launch;

    public CampaignsController(SbmDbContext db, ITenantContext tenant, CampaignLaunchService launch)
    {
        _db = db;
        _tenant = tenant;
        _launch = launch;
    }

    private Guid? CallerOrganizationId => _tenant.IsPlatformAdmin ? null : _tenant.OrganizationId;

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Campaigns";
        ViewData["Nav"] = "campaigns";
        var audiences = await AudiencesQuery().OrderByDescending(a => a.CreatedAt).Take(100).ToListAsync(ct);
        var campaigns = await CampaignsQuery().OrderByDescending(c => c.CreatedAt).Take(100).ToListAsync(ct);
        return View(new CampaignsIndexViewModel(audiences, campaigns));
    }

    private IQueryable<AudienceDefinition> AudiencesQuery() =>
        _tenant.IsPlatformAdmin
            ? _db.AudienceDefinitions.AsNoTracking()
            : _db.AudienceDefinitions.AsNoTracking().Where(a => a.OrganizationId == null || a.OrganizationId == _tenant.OrganizationId);

    private IQueryable<Campaign> CampaignsQuery() =>
        _tenant.IsPlatformAdmin
            ? _db.Campaigns.AsNoTracking()
            : _db.Campaigns.AsNoTracking().Where(c => c.OrganizationId == null || c.OrganizationId == _tenant.OrganizationId);

    [HttpPost("/campaigns/audiences")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateAudience(string name, string documentJson, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            TempData["Flash"] = "Audience name is required.";
            return RedirectToAction(nameof(Index));
        }
        AudienceDocument? doc;
        try
        {
            doc = JsonSerializer.Deserialize<AudienceDocument>(documentJson ?? string.Empty, new JsonSerializerOptions { PropertyNameCaseInsensitive = false });
        }
        catch (JsonException ex)
        {
            TempData["Flash"] = $"Invalid audience JSON: {ex.Message}";
            return RedirectToAction(nameof(Index));
        }
        if (doc is null)
        {
            TempData["Flash"] = "Audience document could not be parsed.";
            return RedirectToAction(nameof(Index));
        }
        try
        {
            AudienceValidator.Validate(doc);
        }
        catch (AudienceValidationException ex)
        {
            TempData["Flash"] = "Audience validation failed: " + string.Join("; ", ex.Errors);
            return RedirectToAction(nameof(Index));
        }
        _db.AudienceDefinitions.Add(new AudienceDefinition
        {
            Name = name.Trim(),
            DocumentJson = documentJson!,
            RuleVersion = doc.Version,
            OrganizationId = CallerOrganizationId
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ الجمهور — Audience saved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/campaigns")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CampaignCreateInput model, CancellationToken ct)
    {
        if (!Enum.TryParse<NotificationChannel>(model.Channel, true, out var channel)
            || !Enum.TryParse<AudienceExecutionMode>(model.ExecutionMode, true, out var executionMode)
            || !Enum.TryParse<RecipientSemanticsMode>(model.RecipientSemantics, true, out var semantics))
        {
            TempData["Flash"] = "Invalid channel / execution mode / recipient semantics.";
            return RedirectToAction(nameof(Index));
        }
        if (string.IsNullOrWhiteSpace(model.IdempotencyKey))
        {
            TempData["Flash"] = "Idempotency key is required.";
            return RedirectToAction(nameof(Index));
        }
        var audience = await _db.AudienceDefinitions.AsNoTracking().FirstOrDefaultAsync(a => a.Id == model.AudienceDefinitionId, ct);
        if (audience is null)
        {
            TempData["Flash"] = "Audience not found.";
            return RedirectToAction(nameof(Index));
        }
        if (!_tenant.IsPlatformAdmin && audience.OrganizationId is not null && audience.OrganizationId != _tenant.OrganizationId)
        {
            TempData["Flash"] = "Audience belongs to another organization.";
            return RedirectToAction(nameof(Index));
        }

        var existing = await _db.Campaigns.AsNoTracking().FirstOrDefaultAsync(c => c.IdempotencyKey == model.IdempotencyKey, ct);
        if (existing is not null)
        {
            TempData["Flash"] = "Campaign with this idempotency key already exists.";
            return RedirectToAction(nameof(Details), new { id = existing.Id });
        }

        var campaign = new Campaign
        {
            Name = model.Name?.Trim() ?? "Campaign",
            OrganizationId = CallerOrganizationId,
            TemplateCode = model.TemplateCode?.Trim() ?? "default",
            Language = model.Language ?? "ar",
            Channel = channel,
            AudienceDefinitionId = audience.Id,
            ExecutionMode = executionMode,
            RecipientSemantics = semantics,
            Status = model.ScheduledAt is not null ? CampaignStatus.Scheduled : CampaignStatus.Draft,
            IdempotencyKey = model.IdempotencyKey,
            ScheduledAt = model.ScheduledAt
        };
        _db.Campaigns.Add(campaign);
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم إنشاء الحملة — Campaign created.";
        return RedirectToAction(nameof(Details), new { id = campaign.Id });
    }

    [HttpGet("/campaigns/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Campaign";
        ViewData["Nav"] = "campaigns";
        var campaign = await _db.Campaigns.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id, ct);
        if (campaign is null) return NotFound();
        if (!_tenant.IsPlatformAdmin && campaign.OrganizationId is not null && campaign.OrganizationId != _tenant.OrganizationId) return NotFound();

        var audience = await _db.AudienceDefinitions.AsNoTracking().FirstOrDefaultAsync(a => a.Id == campaign.AudienceDefinitionId, ct);
        var summary = await _db.CampaignRecipients.AsNoTracking()
            .Where(r => r.CampaignId == id)
            .GroupBy(r => r.Status)
            .Select(g => new RecipientSummary(g.Key.ToString(), g.Count()))
            .ToListAsync(ct);

        return View(new CampaignDetailsViewModel(campaign, audience?.Name, summary));
    }

    [HttpPost("/campaigns/{id:guid}/launch")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Launch(Guid id, CancellationToken ct)
    {
        var campaign = await _db.Campaigns.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id, ct);
        if (campaign is null) return NotFound();
        if (!_tenant.IsPlatformAdmin && campaign.OrganizationId is not null && campaign.OrganizationId != _tenant.OrganizationId) return NotFound();

        var result = await _launch.LaunchAsync(id, ct);
        TempData["Flash"] = result.Success
            ? $"تم إطلاق الحملة — {result.Planned} planned, {result.Suppressed} suppressed, {result.Duplicates} duplicates."
            : $"Launch failed: {result.Error}";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/campaigns/{id:guid}/cancel")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct)
    {
        var campaign = await _db.Campaigns.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (campaign is null) return NotFound();
        if (!_tenant.IsPlatformAdmin && campaign.OrganizationId is not null && campaign.OrganizationId != _tenant.OrganizationId) return NotFound();
        if (campaign.Status == CampaignStatus.Completed || campaign.Status == CampaignStatus.Cancelled)
        {
            TempData["Flash"] = "Campaign already finished.";
            return RedirectToAction(nameof(Details), new { id });
        }
        campaign.Status = CampaignStatus.Cancelled;
        campaign.CompletedAt = DateTimeOffset.UtcNow;
        var queued = await _db.CampaignRecipients.Where(r => r.CampaignId == id && r.Status == RecipientStatus.Queued).ToListAsync(ct);
        foreach (var recipient in queued) recipient.Status = RecipientStatus.Cancelled;
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = $"Cancelled {queued.Count} queued recipients.";
        return RedirectToAction(nameof(Details), new { id });
    }
}

public sealed record CampaignsIndexViewModel(List<AudienceDefinition> Audiences, List<Campaign> Campaigns);
public sealed record CampaignDetailsViewModel(Campaign Campaign, string? AudienceName, List<RecipientSummary> Summary);
public sealed record RecipientSummary(string Status, int Count);
public sealed class CampaignCreateInput
{
    public string? Name { get; set; }
    public string? TemplateCode { get; set; }
    public string? Language { get; set; } = "ar";
    public string? Channel { get; set; } = "InApp";
    public Guid AudienceDefinitionId { get; set; }
    public string? ExecutionMode { get; set; } = "Dynamic";
    public string? RecipientSemantics { get; set; } = "PerOrganization";
    public string? IdempotencyKey { get; set; } = Guid.NewGuid().ToString("N");
    public DateTimeOffset? ScheduledAt { get; set; }
}

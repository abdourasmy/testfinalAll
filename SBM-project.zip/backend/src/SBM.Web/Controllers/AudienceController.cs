using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Notifications.Audience;
using SBM.Modules.Notifications.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>
/// Real audience rule-engine UI. Validation and preview both hit the actual
/// AudienceValidator / AudienceEvaluator — no fake results. Previews are capped.
/// </summary>
[Authorize]
public class AudienceController : Controller
{
    private readonly AudienceCandidateProjector _projector;
    private readonly ITenantContext _tenant;
    private readonly SbmDbContext _db;

    public const string ExampleDocument = """
    {
      "v": 1,
      "root": {
        "type": "group",
        "op": "and",
        "children": [
          { "type": "condition", "field": "customer.status", "op": "eq", "value": "Active" },
          { "type": "condition", "field": "subscription.status", "op": "eq", "value": "Active" }
        ]
      }
    }
    """;

    public AudienceController(AudienceCandidateProjector projector, ITenantContext tenant, SbmDbContext db)
    {
        _projector = projector;
        _tenant = tenant;
        _db = db;
    }

    public IActionResult Index()
    {
        ViewData["Title"] = "Audience builder";
        ViewData["Nav"] = "audience";
        return View(new AudienceBuilderViewModel(ExampleDocument, AudienceFieldRegistry.All.Select(f => new AudienceFieldRow(f.Name, f.Type.ToString(), string.Join(" | ", f.AllowedOperators))).ToList()));
    }

    [HttpPost("/audience/validate")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public IActionResult Validate(string documentJson)
    {
        var (doc, error) = TryParse(documentJson);
        if (doc is null)
            return PartialView("_ValidationResult", new AudienceValidationViewModel(false, new[] { error ?? "Invalid document." }));
        try
        {
            AudienceValidator.Validate(doc);
            return PartialView("_ValidationResult", new AudienceValidationViewModel(true, Array.Empty<string>()));
        }
        catch (AudienceValidationException ex)
        {
            return PartialView("_ValidationResult", new AudienceValidationViewModel(false, ex.Errors));
        }
    }

    [HttpPost("/audience/preview")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Preview(string documentJson, int maxRecipients = 25, CancellationToken ct = default)
    {
        var (doc, error) = TryParse(documentJson);
        if (doc is null)
            return PartialView("_PreviewResult", new AudiencePreviewViewModel(0, 0, new List<AudienceCandidate>(), error ?? "Invalid document."));
        try
        {
            AudienceValidator.Validate(doc);
        }
        catch (AudienceValidationException ex)
        {
            return PartialView("_PreviewResult", new AudiencePreviewViewModel(0, 0, new List<AudienceCandidate>(), string.Join("; ", ex.Errors)));
        }

        maxRecipients = Math.Clamp(maxRecipients, 1, 100);
        var orgId = _tenant.IsPlatformAdmin ? (Guid?)null : _tenant.OrganizationId;
        var candidates = await _projector.ProjectAsync(orgId, AudienceCandidateProjector.PreviewCap, ct);
        var matched = candidates.Where(c => AudienceEvaluator.Evaluate(doc.Root, c)).ToList();

        return PartialView("_PreviewResult", new AudiencePreviewViewModel(
            candidates.Count,
            matched.Count,
            matched.Take(maxRecipients).ToList(),
            null));
    }

    [HttpPost("/audience/save")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(string name, string documentJson, CancellationToken ct)
    {
        var (doc, error) = TryParse(documentJson);
        if (doc is null)
        {
            TempData["Flash"] = error ?? "Invalid document.";
            return RedirectToAction(nameof(Index));
        }
        try { AudienceValidator.Validate(doc); }
        catch (AudienceValidationException ex)
        {
            TempData["Flash"] = "Validation failed: " + string.Join("; ", ex.Errors);
            return RedirectToAction(nameof(Index));
        }
        if (string.IsNullOrWhiteSpace(name))
        {
            TempData["Flash"] = "Name is required.";
            return RedirectToAction(nameof(Index));
        }
        _db.AudienceDefinitions.Add(new AudienceDefinition
        {
            Name = name.Trim(),
            DocumentJson = documentJson!,
            RuleVersion = doc.Version,
            OrganizationId = _tenant.IsPlatformAdmin ? null : _tenant.OrganizationId
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ الجمهور — Audience saved.";
        return RedirectToAction("Index", "Campaigns");
    }

    private static (AudienceDocument? Document, string? Error) TryParse(string? json)
    {
        try
        {
            var doc = JsonSerializer.Deserialize<AudienceDocument>(json ?? string.Empty);
            return doc is null ? (null, "Audience document is empty.") : (doc, null);
        }
        catch (JsonException ex)
        {
            return (null, $"JSON parse error: {ex.Message}");
        }
    }
}

public sealed record AudienceBuilderViewModel(string DocumentJson, List<AudienceFieldRow> Fields);
public sealed record AudienceFieldRow(string Name, string Type, string Operators);
public sealed record AudienceValidationViewModel(bool Valid, IReadOnlyList<string> Errors);
public sealed record AudiencePreviewViewModel(int SampleSize, int Matched, IReadOnlyList<AudienceCandidate> Sample, string? Error);

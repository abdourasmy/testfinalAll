using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Customers.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class CustomersController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public CustomersController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? search, CancellationToken ct)
    {
        ViewData["Title"] = "Customers";
        ViewData["Nav"] = "customers";
        var query = TenantScope.Org(_db.Customers.AsNoTracking(), _tenant);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(c => c.Name.Contains(s) || (c.Email != null && c.Email.Contains(s)) || (c.Phone != null && c.Phone.Contains(s)) || (c.TaxIdentifier != null && c.TaxIdentifier.Contains(s)));
        }
        var customers = await query.OrderByDescending(c => c.RegisteredAt).Take(100).ToListAsync(ct);
        return View(new CustomersIndexViewModel(search, customers));
    }

    [HttpGet("/customers/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Customer";
        ViewData["Nav"] = "customers";
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == id, ct);
        if (customer is null) return NotFound();

        var subscriptions = await TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant).Where(s => s.CustomerId == id).ToListAsync(ct);
        var licenses = await TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant).Where(l => l.CustomerId == id).ToListAsync(ct);
        var invoices = await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).Where(i => i.CustomerId == id).OrderByDescending(i => i.IssuedAt).Take(20).ToListAsync(ct);
        var notes = await TenantScope.Org(_db.CustomerNotes.AsNoTracking(), _tenant).Where(n => n.CustomerId == id).OrderByDescending(n => n.CreatedAt).ToListAsync(ct);
        var reseller = customer.ResellerId is { } rid ? await _db.Resellers.AsNoTracking().FirstOrDefaultAsync(r => r.Id == rid, ct) : null;

        return View(new CustomerDetailsViewModel(customer, subscriptions, licenses, invoices, notes, reseller?.Name));
    }

    public IActionResult Create()
    {
        ViewData["Nav"] = "customers";
        return View(new CreateCustomerInput());
    }

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateCustomerInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            ModelState.AddModelError(string.Empty, "Organization scope required.");
            return View(model);
        }
        if (string.IsNullOrWhiteSpace(model.Name))
        {
            ModelState.AddModelError(nameof(model.Name), "Name is required.");
            return View(model);
        }
        if (!Enum.TryParse<CustomerType>(model.Type, out var type)) type = CustomerType.Company;

        var resellerId = model.ResellerId;
        if (resellerId is not null && !await _db.Resellers.AnyAsync(r => r.Id == resellerId, ct)) resellerId = null;

        var customer = new Customer
        {
            OrganizationId = orgId,
            Name = model.Name.Trim(),
            Type = type,
            Email = model.Email?.Trim(),
            Phone = model.Phone?.Trim(),
            Country = model.Country?.Trim(),
            City = model.City?.Trim(),
            TaxIdentifier = model.TaxIdentifier?.Trim(),
            Classification = model.Classification?.Trim(),
            Tags = model.Tags?.Trim(),
            ResellerId = resellerId
        };
        _db.Customers.Add(customer);
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم إنشاء العميل — Customer created.";
        return RedirectToAction(nameof(Details), new { id = customer.Id });
    }

    [HttpPost("/customers/{id:guid}/notes")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddNote(Guid id, string body, CancellationToken ct)
    {
        var customer = await TenantScope.Org(_db.Customers, _tenant).FirstOrDefaultAsync(c => c.Id == id, ct);
        if (customer is null) return NotFound();
        if (!string.IsNullOrWhiteSpace(body))
        {
            _db.CustomerNotes.Add(new CustomerNote { OrganizationId = customer.OrganizationId, CustomerId = customer.Id, Body = body.Trim(), AuthorUserId = _tenant.UserId ?? Guid.Empty });
            await _db.SaveChangesAsync(ct);
        }
        return RedirectToAction(nameof(Details), new { id });
    }
}

public sealed record CustomersIndexViewModel(string? Search, List<Customer> Customers);
public sealed record CustomerDetailsViewModel(Customer Customer, List<Modules.Subscriptions.Entities.Subscription> Subscriptions, List<Modules.Licensing.Entities.License> Licenses, List<Modules.Billing.Entities.Invoice> Invoices, List<CustomerNote> Notes, string? ResellerName);
public sealed class CreateCustomerInput
{
    public string? Name { get; set; }
    public string? Type { get; set; } = "Company";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Country { get; set; } = "EG";
    public string? City { get; set; }
    public string? TaxIdentifier { get; set; }
    public string? Classification { get; set; }
    public string? Tags { get; set; }
    public Guid? ResellerId { get; set; }
}

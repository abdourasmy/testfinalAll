using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Subscriptions.Entities;
using SBM.Shared.Abstractions;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[Authorize]
public class ApprovalsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly ApprovalService _approvals;

    public ApprovalsController(SbmDbContext db, ITenantContext tenant, ApprovalService approvals)
    {
        _db = db;
        _tenant = tenant;
        _approvals = approvals;
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Approvals";
        ViewData["Nav"] = "approvals";
        var pending = await _approvals.PendingAsync(ct);
        var decided = await TenantScope.Org(_db.ApprovalRequests.AsNoTracking(), _tenant)
            .Where(a => a.Status != ApprovalStatus.Pending)
            .OrderByDescending(a => a.DecidedAt)
            .Take(25)
            .ToListAsync(ct);
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant)
            .Where(c => pending.Select(a => a.CustomerId).Union(decided.Select(a => a.CustomerId)).Contains(c.Id))
            .ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        var subscriptions = await _db.Subscriptions.AsNoTracking()
            .Where(s => pending.Select(a => a.SubscriptionId).Union(decided.Select(a => a.SubscriptionId)).Contains(s.Id))
            .ToDictionaryAsync(s => s.Id, s => s.CurrentPeriodEnd, ct);
        return View(new ApprovalsViewModel(pending, decided, customers, subscriptions));
    }

    /// <summary>HTMX badge rendered in the sidebar; polls every 30s.</summary>
    [HttpGet("/approvals/badge")]
    public async Task<IActionResult> Badge(CancellationToken ct)
    {
        var count = await _approvals.PendingCountAsync(ct);
        return Content(count > 0 ? $"<span class=\"badge\">{count}</span>" : string.Empty, "text/html");
    }

    [HttpPost("/approvals/{id:guid}/approve")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Approve(Guid id, string? note, CancellationToken ct)
    {
        try { await _approvals.ApproveAsync(id, note, ct); TempData["Flash"] = "تمت الموافقة — Approved."; }
        catch (Exception ex) when (ex is InvalidOperationException or KeyNotFoundException) { TempData["Flash"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/approvals/{id:guid}/reject")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(Guid id, string? note, CancellationToken ct)
    {
        try { await _approvals.RejectAsync(id, note, ct); TempData["Flash"] = "تم الرفض — Rejected."; }
        catch (Exception ex) when (ex is InvalidOperationException or KeyNotFoundException) { TempData["Flash"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}

public sealed record ApprovalsViewModel(List<ApprovalRequest> Pending, List<ApprovalRequest> Decided, Dictionary<Guid, string> Customers, Dictionary<Guid, DateTimeOffset> SubscriptionPeriodEnds);

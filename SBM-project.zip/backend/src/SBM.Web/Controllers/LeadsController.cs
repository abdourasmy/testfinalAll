using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Customers.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class LeadsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public LeadsController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? search, string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Leads";
        ViewData["Nav"] = "leads";
        var query = TenantScope.Org(_db.Leads.AsNoTracking(), _tenant);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(l => l.Name.Contains(s) || (l.Company != null && l.Company.Contains(s)) || (l.Email != null && l.Email.Contains(s)) || (l.Phone != null && l.Phone.Contains(s)));
        }
        if (Enum.TryParse<LeadStatus>(status, true, out var st))
            query = query.Where(l => l.Status == st);
        var leads = await query.OrderByDescending(l => l.CreatedAtUtc).Take(100).ToListAsync(ct);
        return View(new LeadsIndexViewModel(search, status, leads));
    }

    public IActionResult Create()
    {
        ViewData["Nav"] = "leads";
        return View();
    }

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateLeadInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            ModelState.AddModelError(string.Empty, "Organization scope required.");
            return View(model);
        }
        if (string.IsNullOrWhiteSpace(model.Name))
        {
            ModelState.AddModelError(nameof(model.Name), "Name is required.");
            return View(model);
        }
        if (!Enum.TryParse<LeadStatus>(model.Status, true, out var status)) status = LeadStatus.New;
        var lead = new Lead
        {
            OrganizationId = orgId,
            Name = model.Name.Trim(),
            Company = model.Company?.Trim(),
            Source = model.Source?.Trim(),
            Phone = model.Phone?.Trim(),
            Email = model.Email?.Trim(),
            Status = status,
            OwnerUserId = _tenant.UserId
        };
        _db.Leads.Add(lead);
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ العميل المحتمل — Lead saved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/leads/{id:guid}/status")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SetStatus(Guid id, string status, CancellationToken ct)
    {
        var lead = await TenantScope.Org(_db.Leads, _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NotFound();
        if (!Enum.TryParse<LeadStatus>(status, true, out var parsed)) return BadRequest();
        if (lead.Status == LeadStatus.Won || lead.Status == LeadStatus.Lost)
        {
            TempData["Flash"] = "هذا العميل محسوم — Lead already closed.";
            return RedirectToAction(nameof(Index));
        }
        lead.Status = parsed;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/leads/{id:guid}/convert")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Convert(Guid id, CancellationToken ct)
    {
        var lead = await TenantScope.Org(_db.Leads, _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NotFound();
        if (lead.ConvertedCustomerId is not null) return RedirectToAction(nameof(Index));

        var customer = new Customer
        {
            OrganizationId = lead.OrganizationId,
            Name = string.IsNullOrWhiteSpace(lead.Company) ? lead.Name : lead.Company!,
            Type = CustomerType.Company,
            Email = lead.Email,
            Phone = lead.Phone,
            OwnerUserId = lead.OwnerUserId
        };
        _db.Customers.Add(customer);
        lead.Status = LeadStatus.Won;
        lead.ConvertedCustomerId = customer.Id;
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم تحويل العميل المحتمل إلى عميل — Lead converted to customer.";
        return RedirectToAction("Details", "Customers", new { id = customer.Id });
    }
}

public sealed record LeadsIndexViewModel(string? Search, string? Status, List<Lead> Leads);
public sealed class CreateLeadInput
{
    public string? Name { get; set; }
    public string? Company { get; set; }
    public string? Source { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? Status { get; set; } = "New";
}

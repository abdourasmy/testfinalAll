using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>
/// Audit log = SecurityEvent trail. Platform admins see everything; organization managers see
/// events belonging to members of their own organization only.
/// </summary>
[Authorize(Policy = "OrgManager")]
public class AuditController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public AuditController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? type, DateTimeOffset? from, DateTimeOffset? to, CancellationToken ct)
    {
        ViewData["Title"] = "Audit log";
        ViewData["Nav"] = "audit";
        var query = _db.SecurityEvents.AsNoTracking().AsQueryable();

        if (!_tenant.IsPlatformAdmin)
        {
            if (_tenant.OrganizationId is not { } orgId) return Forbid();
            var memberIds = await _db.OrganizationMemberships.AsNoTracking()
                .Where(m => m.OrganizationId == orgId)
                .Select(m => m.UserId)
                .ToListAsync(ct);
            query = query.Where(e => e.UserId != null && memberIds.Contains(e.UserId.Value));
        }

        if (!string.IsNullOrWhiteSpace(type))
            query = query.Where(e => e.EventType.Contains(type.Trim()));
        if (from is not null) query = query.Where(e => e.OccurredAtUtc >= from);
        if (to is not null) query = query.Where(e => e.OccurredAtUtc <= to);

        var events = await query.OrderByDescending(e => e.OccurredAtUtc).Take(200).ToListAsync(ct);
        return View(new AuditViewModel(type, from, to, events));
    }
}

public sealed record AuditViewModel(string? Type, DateTimeOffset? From, DateTimeOffset? To, List<Modules.Identity.Entities.SecurityEvent> Events);

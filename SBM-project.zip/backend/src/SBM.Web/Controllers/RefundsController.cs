using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Finance.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>
/// Refund lifecycle: PendingApproval -> Approved/Rejected -> Processed (paid out).
/// Approval marks the payment (Partially)Refunded and records nothing financial;
/// processing posts the offsetting FinanceEntry exactly once (ExternalRef idempotency).
/// </summary>
[Authorize]
public class RefundsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public RefundsController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Refunds";
        ViewData["Nav"] = "refunds";
        var query = TenantScope.Org(_db.Refunds.AsNoTracking(), _tenant);
        if (Enum.TryParse<RefundStatus>(status, true, out var st))
            query = query.Where(r => r.Status == st);
        var refunds = await query.OrderByDescending(r => r.CreatedAt).Take(100).ToListAsync(ct);
        var payments = await _db.Payments.AsNoTracking().Where(p => refunds.Select(r => r.PaymentId).Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.Amount, ct);
        var paymentInvoice = await _db.Payments.AsNoTracking().Where(p => refunds.Select(r => r.PaymentId).Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.InvoiceId, ct);
        var invoiceIds = paymentInvoice.Values.Distinct().ToList();
        var invoiceNumbers = await _db.Invoices.AsNoTracking().Where(i => invoiceIds.Contains(i.Id))
            .ToDictionaryAsync(i => i.Id, i => i.Number, ct);
        return View(new RefundsIndexViewModel(status, refunds, payments, paymentInvoice, invoiceNumbers));
    }

    [HttpPost("/refunds/request")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RequestRefund(Guid paymentId, decimal amount, string reason, CancellationToken ct)
    {
        var payment = await TenantScope.Org(_db.Payments.AsNoTracking(), _tenant).FirstOrDefaultAsync(p => p.Id == paymentId, ct);
        if (payment is null) return NotFound();
        if (amount <= 0 || amount > payment.Amount)
        {
            TempData["Flash"] = "المبلغ غير صالح — Invalid amount.";
            return RedirectToAction("Details", "Invoices", new { id = payment.InvoiceId });
        }
        if (string.IsNullOrWhiteSpace(reason))
        {
            TempData["Flash"] = "Reason is required.";
            return RedirectToAction("Details", "Invoices", new { id = payment.InvoiceId });
        }

        var invoicePaid = await _db.Invoices.AsNoTracking()
            .Where(i => i.Id == payment.InvoiceId && i.OrganizationId == payment.OrganizationId)
            .Select(i => i.AmountPaid)
            .FirstOrDefaultAsync(ct);
        var alreadyRefunded = await _db.Refunds
            .Where(r => r.PaymentId == payment.Id && (r.Status == RefundStatus.Approved || r.Status == RefundStatus.Processed))
            .SumAsync(r => (decimal?)r.Amount, ct) ?? 0m;
        if (alreadyRefunded + amount > invoicePaid)
        {
            TempData["Flash"] = $"يتجاوز المرتجع المتبقي — Refund exceeds remaining paid amount ({(invoicePaid - alreadyRefunded):N2}).";
            return RedirectToAction("Details", "Invoices", new { id = payment.InvoiceId });
        }
        _db.Refunds.Add(new Refund
        {
            OrganizationId = payment.OrganizationId,
            PaymentId = payment.Id,
            Amount = decimal.Round(amount, 2, MidpointRounding.AwayFromZero),
            Currency = payment.Currency,
            Reason = reason.Trim(),
            RequestedByUserId = _tenant.UserId ?? Guid.Empty
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم تقديم طلب المرتجع — Refund requested.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/approve")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Approve(Guid id, CancellationToken ct)
    {
        // Serializable: two concurrent approvals cannot over-refund the payment.
        // Invariant: sum(approved + processed refunds for the payment) <= paid amount of the invoice.
        var strategy = _db.Database.CreateExecutionStrategy();
        var decision = await strategy.ExecuteAsync(async ctArg =>
        {
            await using var tx = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, ctArg);

            var target = await _db.Refunds.FirstOrDefaultAsync(r => r.Id == id, ctArg);
            if (target is null || !TenantScope.Owns(target, _tenant)) return RefundDecision.NotFound;
            if (target.Status != RefundStatus.PendingApproval) return RefundDecision.AlreadyDecided;

            var payment = await _db.Payments.FirstOrDefaultAsync(p => p.Id == target.PaymentId, ctArg);
            if (payment is null) return RefundDecision.NotFound;

            var invoicePaid = await _db.Invoices.AsNoTracking()
                .Where(i => i.Id == payment.InvoiceId && i.OrganizationId == payment.OrganizationId)
                .Select(i => i.AmountPaid)
                .FirstOrDefaultAsync(ctArg);

            var alreadyRefunded = await _db.Refunds
                .Where(r => r.PaymentId == payment.Id && (r.Status == RefundStatus.Approved || r.Status == RefundStatus.Processed))
                .SumAsync(r => (decimal?)r.Amount, ctArg) ?? 0m;

            if (alreadyRefunded + target.Amount > invoicePaid)
                return RefundDecision.ExceedsPaid;

            target.Status = RefundStatus.Approved;
            target.ApprovedByUserId = _tenant.UserId;
            target.ApprovedAt = DateTimeOffset.UtcNow;
            payment.Status = (alreadyRefunded + target.Amount) >= invoicePaid ? PaymentStatus.Refunded : PaymentStatus.PartiallyRefunded;
            await _db.SaveChangesAsync(ctArg);
            await tx.CommitAsync(ctArg);
            return RefundDecision.Approved;
        }, ct);

        TempData["Flash"] = decision switch
        {
            RefundDecision.Approved => "تمت الموافقة — Refund approved.",
            RefundDecision.AlreadyDecided => "Already decided.",
            RefundDecision.ExceedsPaid => "المرتجع يتجاوز المدفوع — Refund exceeds paid amount.",
            _ => "Refund not found."
        };
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/reject")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(Guid id, CancellationToken ct)
    {
        var refund = await TenantScope.Org(_db.Refunds, _tenant).FirstOrDefaultAsync(r => r.Id == id, ct);
        if (refund is null) return NotFound();
        if (refund.Status != RefundStatus.PendingApproval) { TempData["Flash"] = "Already decided."; return RedirectToAction(nameof(Index)); }
        refund.Status = RefundStatus.Rejected;
        refund.ApprovedByUserId = _tenant.UserId;
        refund.ApprovedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/process")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Process(Guid id, CancellationToken ct)
    {
        var refund = await TenantScope.Org(_db.Refunds, _tenant).FirstOrDefaultAsync(r => r.Id == id, ct);
        if (refund is null) return NotFound();
        if (refund.Status != RefundStatus.Approved) { TempData["Flash"] = "Only approved refunds can be processed."; return RedirectToAction(nameof(Index)); }

        var externalRef = $"refund:{refund.Id}";
        if (!await _db.FinanceEntries.AnyAsync(e => e.ExternalRef == externalRef, ct))
        {
            _db.FinanceEntries.Add(new FinanceEntry
            {
                OrganizationId = refund.OrganizationId,
                Type = FinanceEntryType.Expense,
                Category = "Refund",
                Description = $"Refund {refund.Id}: {refund.Reason}",
                Amount = refund.Amount,
                Currency = refund.Currency,
                PaymentMethod = "BankTransfer",
                ExternalRef = externalRef,
                CreatedByUserId = _tenant.UserId,
                OccurredAt = DateTimeOffset.UtcNow
            });
        }
        refund.Status = RefundStatus.Processed;
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم تنفيذ المرتجع — Refund processed.";
        return RedirectToAction(nameof(Index));
    }
}

internal enum RefundDecision { Approved, AlreadyDecided, ExceedsPaid, NotFound }

public sealed record RefundsIndexViewModel(string? Status, List<Refund> Refunds, Dictionary<Guid, decimal> PaymentAmounts, Dictionary<Guid, Guid> PaymentInvoiceIds, Dictionary<Guid, string> InvoiceNumbers);

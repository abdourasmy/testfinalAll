using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Finance.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>
/// Refund lifecycle: PendingApproval -> Approved/Rejected -> Processed (paid out).
/// Approval marks the payment (Partially)Refunded and records nothing financial;
/// processing posts the offsetting FinanceEntry exactly once (ExternalRef idempotency).
/// </summary>
[Authorize]
public class RefundsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public RefundsController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Refunds";
        ViewData["Nav"] = "refunds";
        var query = TenantScope.Org(_db.Refunds.AsNoTracking(), _tenant);
        if (Enum.TryParse<RefundStatus>(status, true, out var st))
            query = query.Where(r => r.Status == st);
        var refunds = await query.OrderByDescending(r => r.CreatedAt).Take(100).ToListAsync(ct);
        var payments = await _db.Payments.AsNoTracking().Where(p => refunds.Select(r => r.PaymentId).Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.Amount, ct);
        var paymentInvoice = await _db.Payments.AsNoTracking().Where(p => refunds.Select(r => r.PaymentId).Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.InvoiceId, ct);
        var invoiceIds = paymentInvoice.Values.Distinct().ToList();
        var invoiceNumbers = await _db.Invoices.AsNoTracking().Where(i => invoiceIds.Contains(i.Id))
            .ToDictionaryAsync(i => i.Id, i => i.Number, ct);
        return View(new RefundsIndexViewModel(status, refunds, payments, paymentInvoice, invoiceNumbers));
    }

    [HttpPost("/refunds/request")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RequestRefund(Guid paymentId, decimal amount, string reason, CancellationToken ct)
    {
        var payment = await TenantScope.Org(_db.Payments.AsNoTracking(), _tenant).FirstOrDefaultAsync(p => p.Id == paymentId, ct);
        if (payment is null) return NotFound();
        if (amount <= 0 || amount > payment.Amount)
        {
            TempData["Flash"] = "المبلغ غير صالح — Invalid amount.";
            return RedirectToAction("Details", "Invoices", new { id = payment.InvoiceId });
        }
        if (string.IsNullOrWhiteSpace(reason))
        {
            TempData["Flash"] = "Reason is required.";
            return RedirectToAction("Details", "Invoices", new { id = payment.InvoiceId });
        }
        _db.Refunds.Add(new Refund
        {
            OrganizationId = payment.OrganizationId,
            PaymentId = payment.Id,
            Amount = decimal.Round(amount, 2, MidpointRounding.AwayFromZero),
            Currency = payment.Currency,
            Reason = reason.Trim(),
            RequestedByUserId = _tenant.UserId ?? Guid.Empty
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم تقديم طلب المرتجع — Refund requested.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/approve")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Approve(Guid id, CancellationToken ct)
    {
        var refund = await TenantScope.Org(_db.Refunds, _tenant).FirstOrDefaultAsync(r => r.Id == id, ct);
        if (refund is null) return NotFound();
        if (refund.Status != RefundStatus.PendingApproval) { TempData["Flash"] = "Already decided."; return RedirectToAction(nameof(Index)); }

        var payment = await _db.Payments.FirstOrDefaultAsync(p => p.Id == refund.PaymentId, ct);
        refund.Status = RefundStatus.Approved;
        refund.ApprovedByUserId = _tenant.UserId;
        refund.ApprovedAt = DateTimeOffset.UtcNow;
        if (payment is not null)
            payment.Status = refund.Amount >= payment.Amount ? PaymentStatus.Refunded : PaymentStatus.PartiallyRefunded;
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تمت الموافقة — Refund approved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/reject")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(Guid id, CancellationToken ct)
    {
        var refund = await TenantScope.Org(_db.Refunds, _tenant).FirstOrDefaultAsync(r => r.Id == id, ct);
        if (refund is null) return NotFound();
        if (refund.Status != RefundStatus.PendingApproval) { TempData["Flash"] = "Already decided."; return RedirectToAction(nameof(Index)); }
        refund.Status = RefundStatus.Rejected;
        refund.ApprovedByUserId = _tenant.UserId;
        refund.ApprovedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/refunds/{id:guid}/process")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Process(Guid id, CancellationToken ct)
    {
        var refund = await TenantScope.Org(_db.Refunds, _tenant).FirstOrDefaultAsync(r => r.Id == id, ct);
        if (refund is null) return NotFound();
        if (refund.Status != RefundStatus.Approved) { TempData["Flash"] = "Only approved refunds can be processed."; return RedirectToAction(nameof(Index)); }

        var externalRef = $"refund:{refund.Id}";
        if (!await _db.FinanceEntries.AnyAsync(e => e.ExternalRef == externalRef, ct))
        {
            _db.FinanceEntries.Add(new FinanceEntry
            {
                OrganizationId = refund.OrganizationId,
                Type = FinanceEntryType.Expense,
                Category = "Refund",
                Description = $"Refund {refund.Id}: {refund.Reason}",
                Amount = refund.Amount,
                Currency = refund.Currency,
                PaymentMethod = "BankTransfer",
                ExternalRef = externalRef,
                CreatedByUserId = _tenant.UserId,
                OccurredAt = DateTimeOffset.UtcNow
            });
        }
        refund.Status = RefundStatus.Processed;
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم تنفيذ المرتجع — Refund processed.";
        return RedirectToAction(nameof(Index));
    }
}

public sealed record RefundsIndexViewModel(string? Status, List<Refund> Refunds, Dictionary<Guid, decimal> PaymentAmounts, Dictionary<Guid, Guid> PaymentInvoiceIds, Dictionary<Guid, string> InvoiceNumbers);

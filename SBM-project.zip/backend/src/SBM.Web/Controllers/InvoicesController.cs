using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Billing.Entities;
using SBM.Shared.Abstractions;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[Authorize]
public class InvoicesController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly InvoiceNumberingService _numbering;
    private readonly PaymentService _payments;
    private readonly InvoicePdfService _pdf;

    public InvoicesController(SbmDbContext db, ITenantContext tenant, InvoiceNumberingService numbering, PaymentService payments, InvoicePdfService pdf)
    {
        _db = db;
        _tenant = tenant;
        _numbering = numbering;
        _payments = payments;
        _pdf = pdf;
    }

    public async Task<IActionResult> Index(string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Invoices";
        ViewData["Nav"] = "invoices";
        var query = TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant);
        if (Enum.TryParse<InvoiceStatus>(status, true, out var st))
            query = query.Where(i => i.Status == st);
        var invoices = await query.OrderByDescending(i => i.IssuedAt).Take(100).ToListAsync(ct);
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant)
            .Where(c => invoices.Select(i => i.CustomerId).Contains(c.Id))
            .ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        return View(new InvoicesIndexViewModel(status, invoices, customers));
    }

    [HttpGet("/invoices/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Invoice";
        ViewData["Nav"] = "invoices";
        var invoice = await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).FirstOrDefaultAsync(i => i.Id == id, ct);
        if (invoice is null) return NotFound();
        var items = await _db.InvoiceItems.AsNoTracking().Where(i => i.OrganizationId == invoice.OrganizationId && i.InvoiceId == id).ToListAsync(ct);
        var payments = await _db.Payments.AsNoTracking().Where(p => p.OrganizationId == invoice.OrganizationId && p.InvoiceId == id).OrderByDescending(p => p.ConfirmedAt).ToListAsync(ct);
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == invoice.CustomerId, ct);
        return View(new InvoiceDetailsViewModel(invoice, items, payments, customer?.Name));
    }

    public async Task<IActionResult> Create(CancellationToken ct)
    {
        ViewData["Nav"] = "invoices";
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).OrderBy(c => c.Name).Take(500).Select(c => new CustomerOption(c.Id, c.Name)).ToListAsync(ct);
        return View(new CreateInvoiceInput { Customers = customers });
    }

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateInvoiceInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            ModelState.AddModelError(string.Empty, "Organization scope required.");
            return View(new CreateInvoiceInput { Customers = await CustomerOptionsAsync(ct) });
        }
        var lines = (model.Lines ?? new List<CreateInvoiceLineInput>())
            .Where(l => !string.IsNullOrWhiteSpace(l.Description) && l.Quantity > 0 && l.UnitPrice >= 0)
            .ToList();
        if (lines.Count == 0 || model.CustomerId == Guid.Empty || !await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).AnyAsync(c => c.Id == model.CustomerId, ct))
        {
            ModelState.AddModelError(string.Empty, "Select a customer and at least one valid line.");
            return View(new CreateInvoiceInput { Customers = await CustomerOptionsAsync(ct) });
        }
        var year = DateTimeOffset.UtcNow.Year.ToString();
        var number = await _numbering.NextNumberAsync(orgId, "INV", year, ct);
        var currency = (model.Currency ?? "EGP").ToUpperInvariant();

        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = model.CustomerId,
            Number = number,
            Prefix = "INV",
            FinancialYear = year,
            Status = InvoiceStatus.Issued,
            IssuedAt = DateTimeOffset.UtcNow,
            DueAt = model.DueAt,
            Currency = currency
        };
        decimal sub = 0, tax = 0, disc = 0;
        foreach (var line in lines)
        {
            var item = new InvoiceItem
            {
                OrganizationId = orgId,
                InvoiceId = invoice.Id,
                Description = line.Description!.Trim(),
                Quantity = line.Quantity,
                UnitPrice = line.UnitPrice,
                DiscountPercent = line.DiscountPercent,
                TaxPercent = line.TaxPercent,
                Currency = currency
            };
            sub += item.LineNet;
            tax += item.LineTax;
            disc += decimal.Round(item.Quantity * item.UnitPrice * item.DiscountPercent / 100m, 2, MidpointRounding.AwayFromZero);
            _db.InvoiceItems.Add(item);
        }
        invoice.SubTotal = sub;
        invoice.TaxTotal = tax;
        invoice.DiscountTotal = disc;
        invoice.GrandTotal = sub + tax;
        _db.Invoices.Add(invoice);
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = $"تم إنشاء الفاتورة {number} — Invoice created.";
        return RedirectToAction(nameof(Details), new { id = invoice.Id });
    }

    [HttpPost("/invoices/{id:guid}/payments")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RecordPayment(Guid id, RecordPaymentInput model, CancellationToken ct)
    {
        var invoice = await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).FirstOrDefaultAsync(i => i.Id == id, ct);
        if (invoice is null) return NotFound();
        if (model.Amount <= 0)
        {
            TempData["Flash"] = "Amount must be positive.";
            return RedirectToAction(nameof(Details), new { id });
        }
        try
        {
            var outcome = await _payments.ProcessConfirmationAsync(new PaymentConfirmation(
                invoice.OrganizationId, id, model.Amount, (model.Currency ?? invoice.Currency).ToUpperInvariant(),
                model.Method ?? "Manual", model.ProviderReference, model.IdempotencyKey ?? Guid.NewGuid().ToString("N"), model.ConfirmedByProvider), ct);
            TempData["Flash"] = outcome.Duplicate
                ? "دفعة مكررة — Duplicate confirmation ignored."
                : $"تم تسجيل الدفعة — Payment recorded ({outcome.Outcome}).";
        }
        catch (KeyNotFoundException)
        {
            TempData["Flash"] = "Invoice not found.";
        }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpGet("/invoices/{id:guid}/pdf")]
    public async Task<IActionResult> Pdf(Guid id, CancellationToken ct)
    {
        var invoice = await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).FirstOrDefaultAsync(i => i.Id == id, ct);
        if (invoice is null) return NotFound();
        var bytes = await _pdf.GenerateAsync(invoice, ct);
        return File(bytes, "application/pdf", $"{invoice.Number}.pdf");
    }

    private async Task<List<CustomerOption>> CustomerOptionsAsync(CancellationToken ct) =>
        await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).OrderBy(c => c.Name).Take(500).Select(c => new CustomerOption(c.Id, c.Name)).ToListAsync(ct);
}

public sealed record InvoicesIndexViewModel(string? Status, List<Invoice> Invoices, Dictionary<Guid, string> Customers);
public sealed record InvoiceDetailsViewModel(Invoice Invoice, List<InvoiceItem> Items, List<Payment> Payments, string? CustomerName);
public sealed record CustomerOption(Guid Id, string Name);
public sealed class CreateInvoiceInput
{
    public Guid CustomerId { get; set; }
    public string? Currency { get; set; } = "EGP";
    public DateTimeOffset? DueAt { get; set; }
    public List<CreateInvoiceLineInput>? Lines { get; set; }
    public List<CustomerOption> Customers { get; set; } = new();
}
public sealed class CreateInvoiceLineInput
{
    public string? Description { get; set; }
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
}
public sealed class RecordPaymentInput
{
    public decimal Amount { get; set; }
    public string? Currency { get; set; }
    public string? Method { get; set; } = "Manual";
    public string? ProviderReference { get; set; }
    public string? IdempotencyKey { get; set; }
    public bool ConfirmedByProvider { get; set; } = true;
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SBM.Web.Controllers;

[AllowAnonymous]
public class StatusController : Controller
{
    // No HTTP verb restriction: UseStatusCodePagesWithReExecute re-runs the ORIGINAL HTTP method,
    // so a POST that produces a non-success status re-executes this action as POST.
    [Route("/status/{code:int}")]
    public IActionResult Code(int code)
    {
        ViewData["Title"] = code.ToString();
        ViewData["StatusCode"] = code;
        return View();
    }
}

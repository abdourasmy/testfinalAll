using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Support.Domain;
using SBM.Modules.Support.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class SupportController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public SupportController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    private bool CanSeeInternal => _tenant.IsPlatformAdmin || User.IsInRole("Owner") || User.IsInRole("Manager");

    public async Task<IActionResult> Index(string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Support";
        ViewData["Nav"] = "support";
        var query = TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant);
        if (Enum.TryParse<TicketStatus>(status, true, out var st))
            query = query.Where(t => t.Status == st);
        var tickets = await query.OrderByDescending(t => t.CreatedAt).Take(100).ToListAsync(ct);
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant)
            .Where(c => tickets.Where(t => t.CustomerId != null).Select(t => t.CustomerId!.Value).Contains(c.Id))
            .ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        return View(new SupportIndexViewModel(status, tickets, customers));
    }

    [HttpGet("/support/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Ticket";
        ViewData["Nav"] = "support";
        var ticket = await TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        var comments = TenantScope.Org(_db.TicketComments.AsNoTracking(), _tenant).Where(c => c.TicketId == id);
        if (!CanSeeInternal) comments = comments.Where(c => c.Visibility == CommentVisibility.Customer);
        var list = await comments.OrderBy(c => c.CreatedAt).ToListAsync(ct);
        var customer = ticket.CustomerId is { } cid ? await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == cid, ct) : null;
        return View(new SupportDetailsViewModel(ticket, list, customer?.Name, CanSeeInternal));
    }

    [HttpPost("/support/tickets")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateTicketInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            TempData["Flash"] = "Organization scope required.";
            return RedirectToAction(nameof(Index));
        }
        if (string.IsNullOrWhiteSpace(model.Subject) || string.IsNullOrWhiteSpace(model.Description))
        {
            TempData["Flash"] = "Subject and description are required.";
            return RedirectToAction(nameof(Index));
        }
        if (!Enum.TryParse<TicketCategory>(model.Category, true, out var category)) category = TicketCategory.General;
        if (!Enum.TryParse<TicketPriority>(model.Priority, true, out var priority)) priority = TicketPriority.Normal;

        Guid? customerId = model.CustomerId;
        if (customerId is not null && !await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).AnyAsync(c => c.Id == customerId, ct))
            customerId = null;

        var ticket = new SupportTicket
        {
            OrganizationId = orgId,
            CustomerId = customerId,
            Subject = model.Subject.Trim(),
            Description = model.Description.Trim(),
            Category = category,
            Priority = priority,
            Status = TicketStatus.Open,
            CreatedByUserId = _tenant.UserId ?? Guid.Empty,
            SlaDueAt = DateTimeOffset.UtcNow + SupportTicket.DefaultSla(priority)
        };
        _db.SupportTickets.Add(ticket);
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id = ticket.Id });
    }

    [HttpPost("/support/tickets/{id:guid}/comments")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddComment(Guid id, string body, bool internalNote, CancellationToken ct)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        if (string.IsNullOrWhiteSpace(body)) return RedirectToAction(nameof(Details), new { id });
        var visibility = internalNote && CanSeeInternal ? CommentVisibility.Internal : CommentVisibility.Customer;
        _db.TicketComments.Add(new TicketComment
        {
            OrganizationId = ticket.OrganizationId,
            TicketId = ticket.Id,
            AuthorUserId = _tenant.UserId,
            Body = body.Trim(),
            Visibility = visibility
        });
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/support/tickets/{id:guid}/status")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangeStatus(Guid id, string status, CancellationToken ct)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        if (!Enum.TryParse<TicketStatus>(status, true, out var parsed)) return BadRequest();
        try
        {
            TicketStateMachine.EnsureTransition(ticket.Status, parsed);
        }
        catch (InvalidOperationException ex)
        {
            TempData["Flash"] = ex.Message;
            return RedirectToAction(nameof(Details), new { id });
        }
        ticket.Status = parsed;
        if (parsed is TicketStatus.Resolved or TicketStatus.Closed) ticket.ResolvedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/support/tickets/{id:guid}/assign")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Assign(Guid id, Guid? assignedToUserId, CancellationToken ct)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        ticket.AssignedToUserId = assignedToUserId ?? _tenant.UserId;
        if (ticket.Status == TicketStatus.Open) ticket.Status = TicketStatus.InProgress;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }
}

public sealed record SupportIndexViewModel(string? Status, List<SupportTicket> Tickets, Dictionary<Guid, string> Customers);
public sealed record SupportDetailsViewModel(SupportTicket Ticket, List<TicketComment> Comments, string? CustomerName, bool CanSeeInternal);
public sealed class CreateTicketInput
{
    public Guid? CustomerId { get; set; }
    public string? Subject { get; set; }
    public string? Description { get; set; }
    public string? Category { get; set; } = "General";
    public string? Priority { get; set; } = "Normal";
}

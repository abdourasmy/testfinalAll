using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Catalog.Entities;
using SBM.Shared.Versioning;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

/// <summary>
/// Platform-owner release engineering: create releases, register assets (SHA-256 computed server-side),
/// publish, yank. Storage lives outside the web root; downloads happen through eligibility-checked actions.
/// </summary>
[Authorize(Policy = "PlatformAdmin")]
public class ReleasesController : Controller
{
    private readonly SbmDbContext _db;
    private readonly IConfiguration _config;
    private readonly IWebHostEnvironment _env;

    public ReleasesController(SbmDbContext db, IConfiguration config, IWebHostEnvironment env)
    {
        _db = db;
        _config = config;
        _env = env;
    }

    private string StorageRoot
    {
        get
        {
            var configured = _config["Releases:StoragePath"];
            return string.IsNullOrWhiteSpace(configured) ? Path.Combine(_env.ContentRootPath, "App_Data", "releases") : configured;
        }
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Releases";
        ViewData["Nav"] = "releases";
        var releases = await _db.SoftwareReleases.AsNoTracking().OrderByDescending(r => r.CreatedAt).Take(100).ToListAsync(ct);
        var assets = await _db.ReleaseAssets.AsNoTracking()
            .Where(a => releases.Select(r => r.Id).Contains(a.ReleaseId))
            .GroupBy(a => a.ReleaseId)
            .ToDictionaryAsync(g => g.Key, g => g.Count(), ct);
        return View(new ReleasesIndexViewModel(releases, assets));
    }

    [HttpGet("/releases/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Release";
        ViewData["Nav"] = "releases";
        var release = await _db.SoftwareReleases.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id, ct);
        if (release is null) return NotFound();
        var assets = await _db.ReleaseAssets.AsNoTracking().Where(a => a.ReleaseId == id).OrderBy(a => a.FileName).ToListAsync(ct);
        var products = await _db.Products.AsNoTracking().OrderBy(p => p.Name).Select(p => p.Code).ToListAsync(ct);
        return View(new ReleaseDetailsViewModel(release, assets, products));
    }

    [HttpPost("/releases")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateReleaseInput model, CancellationToken ct)
    {
        if (ReleaseAssetChecks.HasErrors(model, out var error))
        {
            TempData["Flash"] = error;
            return RedirectToAction(nameof(Index));
        }
        var productCode = model.ProductCode!.Trim().ToUpperInvariant();
        var applicationCode = model.ApplicationCode!.Trim().ToLowerInvariant();
        if (!await _db.Products.AsNoTracking().AnyAsync(p => p.Code == productCode, ct))
        {
            TempData["Flash"] = "Unknown product code.";
            return RedirectToAction(nameof(Index));
        }
        if (!SemVer.TryParse(model.Version, out _))
        {
            TempData["Flash"] = "Version must be valid SemVer (e.g. 2.1.0).";
            return RedirectToAction(nameof(Index));
        }
        var version = SemVer.Parse(model.Version!).ToString();
        if (await _db.SoftwareReleases.AnyAsync(r => r.ProductCode == productCode && r.ApplicationCode == applicationCode && r.Version == version, ct))
        {
            TempData["Flash"] = "Release already exists for (product, application, version).";
            return RedirectToAction(nameof(Index));
        }
        var release = new SoftwareRelease
        {
            ProductCode = productCode,
            ApplicationCode = applicationCode,
            Version = version,
            Channel = model.Channel ?? "Stable",
            ReleaseNotes = model.ReleaseNotes?.Trim(),
            MinimumSupportedVersion = string.IsNullOrWhiteSpace(model.MinimumSupportedVersion) ? null : model.MinimumSupportedVersion!.Trim(),
            Status = ReleaseStatus.Draft,
            CreatedByUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier) is { } claim && Guid.TryParse(claim.Value, out var uid) ? uid : null
        };
        _db.SoftwareReleases.Add(release);
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id = release.Id });
    }

    [HttpPost("/releases/{id:guid}/assets")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadAsset(Guid id, IFormFile? file, CancellationToken ct)
    {
        var release = await _db.SoftwareReleases.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (release is null) return NotFound();
        if (release.Status == ReleaseStatus.Yanked)
        {
            TempData["Flash"] = "Yanked releases cannot accept assets.";
            return RedirectToAction(nameof(Details), new { id });
        }
        if (file is null || file.Length == 0)
        {
            TempData["Flash"] = "Choose a file.";
            return RedirectToAction(nameof(Details), new { id });
        }
        var safeName = Path.GetFileName(file.FileName);
        if (string.IsNullOrWhiteSpace(safeName)) safeName = "asset.bin";

        var dir = Path.Combine(StorageRoot, id.ToString("N"));
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, Guid.NewGuid().ToString("N") + "-" + safeName);

        string sha;
        long size;
        await using (var output = System.IO.File.Create(path))
        {
            using var sha256 = SHA256.Create();
            await using var crypto = new CryptoStream(output, sha256, CryptoStreamMode.Write);
            await file.CopyToAsync(crypto, ct);
            await crypto.FlushFinalBlockAsync(ct);
            sha = Convert.ToHexString(sha256.Hash!).ToLowerInvariant();
            size = new FileInfo(path).Length;
        }

        _db.ReleaseAssets.Add(new ReleaseAsset
        {
            ReleaseId = id,
            FileName = safeName,
            ContentType = string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType,
            SizeBytes = size,
            Sha256 = sha,
            StoragePath = path
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = $"تم تسجيل الأصل — Asset registered (SHA-256 {sha[..12]}…).";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/releases/{id:guid}/publish")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Publish(Guid id, CancellationToken ct)
    {
        var release = await _db.SoftwareReleases.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (release is null) return NotFound();
        if (release.Status == ReleaseStatus.Published) { TempData["Flash"] = "Already published."; return RedirectToAction(nameof(Details), new { id }); }
        if (release.Status == ReleaseStatus.Yanked) { TempData["Flash"] = "Yanked releases cannot be republished; create a new release."; return RedirectToAction(nameof(Details), new { id }); }
        if (!await _db.ReleaseAssets.AnyAsync(a => a.ReleaseId == id, ct))
        {
            TempData["Flash"] = "Register at least one downloadable asset before publishing.";
            return RedirectToAction(nameof(Details), new { id });
        }
        release.Status = ReleaseStatus.Published;
        release.PublishedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/releases/{id:guid}/yank")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Yank(Guid id, string? reason, CancellationToken ct)
    {
        var release = await _db.SoftwareReleases.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (release is null) return NotFound();
        release.Status = ReleaseStatus.Yanked;
        release.YankedAt = DateTimeOffset.UtcNow;
        release.YankReason = string.IsNullOrWhiteSpace(reason) ? "yanked by platform admin" : reason!.Trim();
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id });
    }
}

internal static class ReleaseAssetChecks
{
    public static bool HasErrors(CreateReleaseInput model, out string error)
    {
        if (string.IsNullOrWhiteSpace(model.ProductCode)) { error = "Product code is required."; return true; }
        if (string.IsNullOrWhiteSpace(model.ApplicationCode)) { error = "Application code is required."; return true; }
        if (string.IsNullOrWhiteSpace(model.Version)) { error = "Version is required."; return true; }
        error = string.Empty;
        return false;
    }
}

public sealed record ReleasesIndexViewModel(List<SoftwareRelease> Releases, Dictionary<Guid, int> AssetCounts);
public sealed record ReleaseDetailsViewModel(SoftwareRelease Release, List<ReleaseAsset> Assets, List<string> ProductCodes);
public sealed class CreateReleaseInput
{
    public string? ProductCode { get; set; }
    public string? ApplicationCode { get; set; }
    public string? Version { get; set; }
    public string? Channel { get; set; } = "Stable";
    public string? ReleaseNotes { get; set; }
    public string? MinimumSupportedVersion { get; set; }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Support.Entities;
using SBM.Shared.Abstractions;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[Authorize]
public class DashboardController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly ReportService _reports;

    public DashboardController(SbmDbContext db, ITenantContext tenant, ReportService reports)
    {
        _db = db;
        _tenant = tenant;
        _reports = reports;
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var customers = TenantScope.Org(_db.Customers.AsNoTracking(), _tenant);
        var subscriptions = TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant);
        var invoices = TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant);
        var tickets = TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant);
        var payments = TenantScope.Org(_db.Payments.AsNoTracking(), _tenant);

        var now = DateTimeOffset.UtcNow;
        var monthStart = new DateTimeOffset(now.Year, now.Month, 1, 0, 0, 0, TimeSpan.Zero);

        var model = new DashboardViewModel
        {
            TotalCustomers = await customers.CountAsync(ct),
            ActiveSubscriptions = await subscriptions.CountAsync(s => s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.Trial, ct),
            ExpiringSubscriptions = await subscriptions.CountAsync(s => s.Status == SubscriptionStatus.Active && s.CurrentPeriodEnd <= now.AddDays(30), ct),
            ActiveLicenses = await TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant).CountAsync(l => l.State == LicenseState.Active, ct),
            InvoiceOutstanding = await invoices.Where(i => i.Status != InvoiceStatus.Paid && i.Status != InvoiceStatus.Void).SumAsync(i => (decimal?)(i.GrandTotal - i.AmountPaid), ct) ?? 0m,
            MonthPayments = await payments.Where(p => p.Status == PaymentStatus.Confirmed && p.ConfirmedAt >= monthStart).SumAsync(p => (decimal?)p.Amount, ct) ?? 0m,
            OpenTickets = await tickets.CountAsync(t => t.Status != TicketStatus.Resolved && t.Status != TicketStatus.Closed, ct),
            PendingApprovals = await TenantScope.Org(_db.ApprovalRequests.AsNoTracking(), _tenant).CountAsync(a => a.Status == SBM.Modules.Subscriptions.Entities.ApprovalStatus.Pending, ct),
        };

        // Six-month revenue from confirmed payments (client-side grouping; see ReportService bug fix).
        var since = now.AddMonths(-5);
        var rows = await payments.Where(p => p.Status == PaymentStatus.Confirmed && p.ConfirmedAt != null && p.ConfirmedAt >= new DateTimeOffset(since.Year, since.Month, 1, 0, 0, 0, TimeSpan.Zero)).ToListAsync(ct);
        var max = 0m;
        var months = new List<(string Label, decimal Total)>();
        for (var i = 5; i >= 0; i--)
        {
            var month = now.AddMonths(-i);
            var key = month.ToString("yyyy-MM");
            var total = rows.Where(p => p.ConfirmedAt!.Value.ToString("yyyy-MM") == key).Sum(p => p.Amount);
            months.Add((month.ToString("MMM"), total));
            if (total > max) max = total;
        }
        model.Chart = months.Select(m => new DashboardViewModel.ChartBar(m.Label, m.Total, max == 0 ? 2 : Math.Max(2, (int)(m.Total / max * 140)))).ToList();

        ViewData["Title"] = "Dashboard";
        ViewData["Nav"] = "dashboard";
        return View(model);
    }
}

public sealed class DashboardViewModel
{
    public int TotalCustomers { get; set; }
    public int ActiveSubscriptions { get; set; }
    public int ExpiringSubscriptions { get; set; }
    public int ActiveLicenses { get; set; }
    public decimal InvoiceOutstanding { get; set; }
    public decimal MonthPayments { get; set; }
    public int OpenTickets { get; set; }
    public int PendingApprovals { get; set; }
    public List<ChartBar> Chart { get; set; } = new();

    public sealed record ChartBar(string Label, decimal Total, int HeightPx);
}

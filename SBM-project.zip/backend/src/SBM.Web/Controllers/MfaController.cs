using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QRCoder;
using SBM.Modules.Identity.Entities;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

/// <summary>
/// TOTP MFA for staff. Enrollment is two-step: (1) show secret + QR, (2) confirm a valid code.
/// Recovery codes are generated once on enable and may be regenerated (invalidating old ones).
/// Disabling requires the account password. MfaEnabled on the user row mirrors Identity's flag.
/// </summary>
[Authorize]
public class MfaController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly LanguageService _lang;

    public MfaController(UserManager<ApplicationUser> users, LanguageService lang)
    {
        _users = users;
        _lang = lang;
    }

    [HttpGet("/mfa")]
    public async Task<IActionResult> Index()
    {
        ViewData["Title"] = "MFA";
        ViewData["Nav"] = "mfa";
        var user = await CurrentUserAsync();
        if (user is null) return Challenge();
        var enabled = await _users.GetTwoFactorEnabledAsync(user);
        return View(new MfaStatusViewModel(enabled, await _users.CountRecoveryCodesAsync(user)));
    }

    [HttpGet("/mfa/enroll")]
    public async Task<IActionResult> Enroll()
    {
        ViewData["Title"] = "MFA";
        ViewData["Nav"] = "mfa";
        var user = await CurrentUserAsync();
        if (user is null) return Challenge();
        var key = await _users.GetAuthenticatorKeyAsync(user);
        if (string.IsNullOrEmpty(key))
        {
            await _users.ResetAuthenticatorKeyAsync(user);
            key = await _users.GetAuthenticatorKeyAsync(user);
        }

        var otpAuthUri = BuildOtpAuthUri(user.Email!, key!);
        using var qrGenerator = new QRCodeGenerator();
        using var qrData = qrGenerator.CreateQrCode(otpAuthUri, QRCodeGenerator.ECCLevel.Q);
        using var png = new PngByteQRCode(qrData);
        var qrBase64 = Convert.ToBase64String(png.GetGraphic(10));

        return View(new MfaEnrollViewModel(FormatKey(key!), otpAuthUri, qrBase64));
    }

    [HttpPost("/mfa/confirm")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Confirm(string code)
    {
        var user = await CurrentUserAsync();
        if (user is null) return Challenge();
        var ok = await _users.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultAuthenticatorProvider, (code ?? string.Empty).Replace(" ", string.Empty));
        if (!ok)
        {
            TempData["Flash"] = _lang.T("الرمز غير صحيح — حاول مرة أخرى.", "Invalid code — try again.");
            return RedirectToAction(nameof(Enroll));
        }
        await _users.SetTwoFactorEnabledAsync(user, true);
        user.MfaEnabled = true;
        await _users.UpdateAsync(user);
        var recoveryCodes = await _users.GenerateNewTwoFactorRecoveryCodesAsync(user, 10);
        TempData["RecoveryCodes"] = string.Join(',', recoveryCodes ?? Enumerable.Empty<string>());
        TempData["Flash"] = _lang.T("تم تفعيل التحقق بخطوتين.", "Two-factor enabled.");
        return LocalRedirect("/mfa/recovery-codes");
    }

    [HttpPost("/mfa/disable")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Disable(string password)
    {
        var user = await CurrentUserAsync();
        if (user is null) return Challenge();
        if (!await _users.CheckPasswordAsync(user, password ?? string.Empty))
        {
            TempData["Flash"] = _lang.T("كلمة المرور غير صحيحة.", "Invalid password.");
            return RedirectToAction(nameof(Index));
        }
        await _users.SetTwoFactorEnabledAsync(user, false);
        user.MfaEnabled = false;
        await _users.UpdateAsync(user);
        TempData["Flash"] = _lang.T("تم إيقاف التحقق بخطوتين.", "Two-factor disabled.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/mfa/recovery-codes/regenerate")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RegenerateRecoveryCodes(string password)
    {
        var user = await CurrentUserAsync();
        if (user is null) return Challenge();
        if (!await _users.CheckPasswordAsync(user, password ?? string.Empty))
        {
            TempData["Flash"] = _lang.T("كلمة المرور غير صحيحة.", "Invalid password.");
            return RedirectToAction(nameof(Index));
        }
        var enabled = await _users.GetTwoFactorEnabledAsync(user);
        if (!enabled)
        {
            TempData["Flash"] = _lang.T("فعّل التحقق بخطوتين أولاً.", "Enable two-factor first.");
            return RedirectToAction(nameof(Index));
        }
        var codes = await _users.GenerateNewTwoFactorRecoveryCodesAsync(user, 10);
        TempData["RecoveryCodes"] = string.Join(',', codes ?? Enumerable.Empty<string>());
        return LocalRedirect("/mfa/recovery-codes");
    }

    [HttpGet("/mfa/recovery-codes")]
    public IActionResult RecoveryCodes()
    {
        ViewData["Title"] = "MFA";
        ViewData["Nav"] = "mfa";
        var raw = TempData["RecoveryCodes"] as string;
        if (string.IsNullOrWhiteSpace(raw))
            return RedirectToAction(nameof(Index));
        return View(new RecoveryCodesViewModel(raw.Split(',', StringSplitOptions.RemoveEmptyEntries)));
    }

    private async Task<ApplicationUser?> CurrentUserAsync()
    {
        var id = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        return id is not null ? await _users.FindByIdAsync(id) : null;
    }

    private static string BuildOtpAuthUri(string email, string key)
    {
        var issuer = Uri.EscapeDataString("SBM");
        var label = Uri.EscapeDataString($"SBM:{email}");
        return $"otpauth://totp/{label}?secret={key}&issuer={issuer}&digits=6&period=30";
    }

    private static string FormatKey(string key) => string.Join(" ", Enumerable.Range(0, key.Length / 4).Select(i => key.Substring(i * 4, 4)));
}

public sealed record MfaStatusViewModel(bool Enabled, int RecoveryCodesRemaining);
public sealed record MfaEnrollViewModel(string FormattedKey, string OtpAuthUri, string QrBase64);
public sealed record RecoveryCodesViewModel(IReadOnlyList<string> Codes);

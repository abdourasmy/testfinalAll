using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;

namespace SBM.Web.Controllers;

[Authorize]
public class SettingsController : Controller
{
    private readonly SbmDbContext _db;
    private readonly IWebHostEnvironment _env;
    private readonly IConfiguration _config;

    public SettingsController(SbmDbContext db, IWebHostEnvironment env, IConfiguration config)
    {
        _db = db;
        _env = env;
        _config = config;
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Settings";
        ViewData["Nav"] = "settings";
        var isPlatformAdmin = User.IsInRole("PlatformAdmin");
        var settings = isPlatformAdmin
            ? await _db.SystemSettings.AsNoTracking().OrderBy(s => s.Key).ToListAsync(ct)
            : new List<SystemSetting>();
        return View(new SettingsViewModel(settings, isPlatformAdmin, _env.EnvironmentName, _config["Release:Version"] ?? "dev"));
    }

    [HttpPost("/settings")]
    [Authorize(Policy = "PlatformAdmin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(string key, string? value, string? description, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(key)) { TempData["Flash"] = "Key is required."; return RedirectToAction(nameof(Index)); }
        var normalized = key.Trim().ToUpperInvariant();
        var existing = await _db.SystemSettings.FirstOrDefaultAsync(s => s.Key == normalized && s.OrganizationId == null, ct);
        if (existing is null)
        {
            _db.SystemSettings.Add(new SystemSetting { Key = normalized, Value = value?.Trim(), Description = description?.Trim() });
        }
        else
        {
            existing.Value = value?.Trim();
            if (description is not null) existing.Description = description.Trim();
            existing.UpdatedAt = DateTimeOffset.UtcNow;
        }
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ الإعداد — Setting saved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/settings/{id:guid}/delete")]
    [Authorize(Policy = "PlatformAdmin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        var setting = await _db.SystemSettings.FirstOrDefaultAsync(s => s.Id == id, ct);
        if (setting is not null)
        {
            _db.SystemSettings.Remove(setting);
            await _db.SaveChangesAsync(ct);
        }
        return RedirectToAction(nameof(Index));
    }
}

public sealed record SettingsViewModel(List<SystemSetting> Settings, bool IsPlatformAdmin, string Environment, string Version);

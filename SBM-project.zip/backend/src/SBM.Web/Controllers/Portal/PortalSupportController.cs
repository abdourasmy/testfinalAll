using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Support.Entities;

namespace SBM.Web.Controllers.Portal;

/// <summary>Customer portal support desk: strictly the caller's own tickets, customer-visible comments only.</summary>
[Authorize(Policy = "PortalOnly")]
public class PortalSupportController : Controller
{
    private readonly SbmDbContext _db;

    public PortalSupportController(SbmDbContext db) => _db = db;

    private Guid CustomerId => Guid.Parse(User.FindFirstValue("customer_id")!);
    private Guid UserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet("/portal/support")]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Support";
        var cid = CustomerId;
        var tickets = await _db.SupportTickets.AsNoTracking().Where(t => t.CustomerId == cid).OrderByDescending(t => t.CreatedAt).Take(50).ToListAsync(ct);
        return View("~/Views/Portal/Support.cshtml", tickets);
    }

    [HttpPost("/portal/support/tickets")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(string subject, string description, string? category, string? priority, CancellationToken ct)
    {
        var cid = CustomerId;
        if (string.IsNullOrWhiteSpace(subject) || string.IsNullOrWhiteSpace(description))
        {
            TempData["Flash"] = "Subject and description are required.";
            return RedirectToAction(nameof(Index));
        }
        if (!Enum.TryParse<TicketCategory>(category, true, out var cat)) cat = TicketCategory.General;
        if (!Enum.TryParse<TicketPriority>(priority, true, out var prio)) prio = TicketPriority.Normal;

        // The organization owning the customer: resolved from the customer row, never from the client.
        var customer = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.Id == cid, ct);
        if (customer is null) return NotFound();

        var ticket = new SupportTicket
        {
            OrganizationId = customer.OrganizationId,
            CustomerId = cid,
            Subject = subject.Trim(),
            Description = description.Trim(),
            Category = cat,
            Priority = prio,
            Status = TicketStatus.Open,
            CreatedByUserId = UserId,
            SlaDueAt = DateTimeOffset.UtcNow + SupportTicket.DefaultSla(prio)
        };
        _db.SupportTickets.Add(ticket);
        await _db.SaveChangesAsync(ct);
        return RedirectToAction(nameof(Details), new { id = ticket.Id });
    }

    [HttpGet("/portal/support/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Ticket";
        var cid = CustomerId;
        var ticket = await _db.SupportTickets.AsNoTracking().FirstOrDefaultAsync(t => t.Id == id && t.CustomerId == cid, ct);
        if (ticket is null) return NotFound();

        var comments = await _db.TicketComments.AsNoTracking()
            .Where(c => c.TicketId == id && c.Visibility == CommentVisibility.Customer)
            .OrderBy(c => c.CreatedAt)
            .ToListAsync(ct);
        return View("~/Views/Portal/SupportDetails.cshtml", new PortalTicketViewModel(ticket, comments));
    }

    [HttpPost("/portal/support/{id:guid}/reply")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reply(Guid id, string body, CancellationToken ct)
    {
        var cid = CustomerId;
        var ticket = await _db.SupportTickets.FirstOrDefaultAsync(t => t.Id == id && t.CustomerId == cid, ct);
        if (ticket is null) return NotFound();
        if (!string.IsNullOrWhiteSpace(body))
        {
            _db.TicketComments.Add(new TicketComment
            {
                OrganizationId = ticket.OrganizationId,
                TicketId = ticket.Id,
                AuthorUserId = UserId,
                Body = body.Trim(),
                Visibility = CommentVisibility.Customer
            });
            await _db.SaveChangesAsync(ct);
        }
        return RedirectToAction(nameof(Details), new { id });
    }
}

public sealed record PortalTicketViewModel(SupportTicket Ticket, List<TicketComment> Comments);

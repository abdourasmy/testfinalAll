using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;
using SBM.Web.Security;
using SBM.Web.Services;

namespace SBM.Web.Controllers.Portal;

[AllowAnonymous]
public class PortalAccountController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SbmDbContext _db;
    private readonly SignInService _signIn;
    private readonly LanguageService _lang;

    public PortalAccountController(UserManager<ApplicationUser> users, SbmDbContext db, SignInService signIn, LanguageService lang)
    {
        _users = users;
        _db = db;
        _signIn = signIn;
        _lang = lang;
    }

    [HttpGet("/portal/login")]
    public IActionResult Login() => View("~/Views/Portal/Login.cshtml");

    [HttpPost("/portal/login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string? email, string? password)
    {
        var returnUrl = "/portal";
        var user = await _users.FindByEmailAsync(email?.Trim() ?? string.Empty);
        if (user is null || user.DeactivatedAt is not null || user.CustomerId is null
            || !await _users.CheckPasswordAsync(user, password ?? string.Empty))
        {
            _db.SecurityEvents.Add(new SecurityEvent { UserId = user?.Id, EventType = "portal.login.failed", Details = "portal login failed", IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() });
            await _db.SaveChangesAsync();
            ModelState.AddModelError(string.Empty, _lang.T("بيانات الدخول غير صحيحة.", "Invalid credentials."));
            return View("~/Views/Portal/Login.cshtml");
        }

        await _signIn.SignInPortalAsync(HttpContext, user);
        _db.SecurityEvents.Add(new SecurityEvent { UserId = user.Id, EventType = "portal.login.success", Details = "portal login", IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() });
        await _db.SaveChangesAsync();
        return LocalRedirect(returnUrl);
    }

    [HttpPost("/portal/logout")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieSchemes.Portal);
        return LocalRedirect("/portal/login");
    }

    [HttpGet("/portal/forbidden")]
    public IActionResult Forbidden() => View("~/Views/Portal/Forbidden.cshtml");
}

using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SBM.Web.Services;

namespace SBM.Web.Controllers.Portal;

/// <summary>Customer portal software distribution. Eligibility is re-checked server-side on every request —
/// listing shows only eligible releases, and each asset download re-verifies.</summary>
[Authorize(Policy = "PortalOnly")]
public class PortalReleasesController : Controller
{
    private readonly ReleaseEligibilityService _eligibility;

    public PortalReleasesController(ReleaseEligibilityService eligibility) => _eligibility = eligibility;

    private Guid CustomerId => Guid.Parse(User.FindFirstValue("customer_id")!);

    [HttpGet("/portal/releases")]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Downloads";
        var releases = await _eligibility.GetEligibleAsync(CustomerId, ct);
        return View("~/Views/Portal/Releases.cshtml", releases);
    }

    [HttpGet("/portal/releases/{releaseId:guid}/assets/{assetId:guid}/download")]
    public async Task<IActionResult> Download(Guid releaseId, Guid assetId, CancellationToken ct)
    {
        var (eligible, _, _, asset) = await _eligibility.CheckDownloadAsync(CustomerId, releaseId, assetId, ct);
        if (!eligible)
        {
            // 404 semantics: non-eligible releases are indistinguishable from missing ones.
            return NotFound();
        }

        var stream = System.IO.File.OpenRead(asset!.StoragePath);
        Response.Headers["X-Asset-Sha256"] = asset.Sha256;
        return File(stream, asset.ContentType, asset.FileName);
    }
}

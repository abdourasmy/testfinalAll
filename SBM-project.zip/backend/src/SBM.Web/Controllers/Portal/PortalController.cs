using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Support.Entities;
using SBM.Web.Services;

namespace SBM.Web.Controllers.Portal;

/// <summary>
/// Customer portal. EVERY query is scoped to the customer_id claim in the portal cookie;
/// staff identity cannot be used here and staff cookies are never honored on these actions.
/// </summary>
[Authorize(Policy = "PortalOnly")]
public class PortalController : Controller
{
    private readonly SbmDbContext _db;
    private readonly LicenseAppService _licenses;
    private readonly ReleaseEligibilityService _eligibility;
    private readonly InvoicePdfService _pdf;

    public PortalController(SbmDbContext db, LicenseAppService licenses, ReleaseEligibilityService eligibility, InvoicePdfService pdf)
    {
        _db = db;
        _licenses = licenses;
        _eligibility = eligibility;
        _pdf = pdf;
    }

    private Guid CustomerId => Guid.Parse(User.FindFirstValue("customer_id")!);
    private Guid UserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Portal";
        var cid = CustomerId;
        var subscriptions = await _db.Subscriptions.AsNoTracking().Where(s => s.CustomerId == cid).ToListAsync(ct);
        var invoices = await _db.Invoices.AsNoTracking().Where(i => i.CustomerId == cid).OrderByDescending(i => i.IssuedAt).Take(5).ToListAsync(ct);
        var licenses = await _db.Licenses.AsNoTracking().Where(l => l.CustomerId == cid).ToListAsync(ct);
        var outstanding = await _db.Invoices.AsNoTracking().Where(i => i.CustomerId == cid && i.Status != InvoiceStatus.Paid && i.Status != InvoiceStatus.Void).SumAsync(i => (decimal?)(i.GrandTotal - i.AmountPaid), ct) ?? 0m;
        var openTickets = await _db.SupportTickets.AsNoTracking().CountAsync(t => t.CustomerId == cid && t.Status != TicketStatus.Resolved && t.Status != TicketStatus.Closed, ct);
        var pendingRequests = await _db.ApprovalRequests.AsNoTracking().CountAsync(a => a.CustomerId == cid && a.Status == ApprovalStatus.Pending, ct);
        return View(new PortalHomeViewModel(subscriptions, invoices, licenses.Count, outstanding, openTickets, pendingRequests));
    }

    [HttpGet("/portal/subscriptions")]
    public async Task<IActionResult> Subscriptions(CancellationToken ct)
    {
        ViewData["Title"] = "Subscriptions";
        var cid = CustomerId;
        var subs = await _db.Subscriptions.AsNoTracking().Where(s => s.CustomerId == cid).OrderByDescending(s => s.CurrentPeriodEnd).ToListAsync(ct);
        var plans = await _db.PricingPlans.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Name, ct);
        var requests = await _db.ApprovalRequests.AsNoTracking().Where(a => a.CustomerId == cid).OrderByDescending(a => a.RequestedAt).ToListAsync(ct);
        return View("Subscriptions", new PortalSubscriptionsViewModel(subs, plans, requests));
    }

    [HttpPost("/portal/subscriptions/{id:guid}/request-renewal")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RequestRenewal(Guid id, string? note, CancellationToken ct) => await CreateSubscriptionRequest(id, ApprovalKind.SubscriptionRenewal, note, ct);

    [HttpPost("/portal/subscriptions/{id:guid}/request-cancellation")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RequestCancellation(Guid id, string? note, CancellationToken ct) => await CreateSubscriptionRequest(id, ApprovalKind.SubscriptionCancellation, note, ct);

    private async Task<IActionResult> CreateSubscriptionRequest(Guid id, ApprovalKind kind, string? note, CancellationToken ct)
    {
        var cid = CustomerId;
        // Per-customer isolation: non-owned subscription ids are indistinguishable from missing ones.
        var subscription = await _db.Subscriptions.FirstOrDefaultAsync(s => s.Id == id && s.CustomerId == cid, ct);
        if (subscription is null) return NotFound();

        var alreadyPending = await _db.ApprovalRequests.AnyAsync(a => a.SubscriptionId == id && a.Kind == kind && a.Status == ApprovalStatus.Pending, ct);
        if (alreadyPending)
        {
            TempData["Flash"] = "يوجد طلب معلّق بالفعل — A request is already pending.";
            return RedirectToAction(nameof(Subscriptions));
        }
        _db.ApprovalRequests.Add(new ApprovalRequest
        {
            OrganizationId = subscription.OrganizationId,
            Kind = kind,
            Status = ApprovalStatus.Pending,
            SubscriptionId = id,
            CustomerId = cid,
            Reason = note,
            RequestedByPortal = true,
            RequestedByUserId = UserId
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم إرسال طلبك إلى فريق الإدارة — Your request was sent to the staff queue.";
        return RedirectToAction(nameof(Subscriptions));
    }

    [HttpGet("/portal/licenses")]
    public async Task<IActionResult> Licenses(CancellationToken ct)
    {
        ViewData["Title"] = "Licenses";
        var cid = CustomerId;
        var licenses = await _db.Licenses.AsNoTracking().Where(l => l.CustomerId == cid).OrderByDescending(l => l.IssuedAt).ToListAsync(ct);
        var licenseIds = licenses.Select(l => l.Id).ToList();
        var devices = await _db.LicenseDevices.AsNoTracking().Where(d => licenseIds.Contains(d.LicenseId)).ToListAsync(ct);
        var applications = await _db.ProductApplications.AsNoTracking().ToDictionaryAsync(a => a.Id, a => a.Name, ct);
        return View("Licenses", new PortalLicensesViewModel(licenses, devices, applications));
    }

    [HttpPost("/portal/licenses/{licenseId:guid}/devices/{deviceId}/deactivate")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeactivateDevice(Guid licenseId, string deviceId, CancellationToken ct)
    {
        var cid = CustomerId;
        var license = await _db.Licenses.AsNoTracking().FirstOrDefaultAsync(l => l.Id == licenseId && l.CustomerId == cid, ct);
        if (license is null) return NotFound();

        var ok = await _licenses.DeactivateDeviceAsync(license.OrganizationId, licenseId, deviceId, ct);
        TempData["Flash"] = ok ? "تم تعطيل الجهاز — Device deactivated." : "الجهاز غير موجود أو معطل بالفعل — Device not found or already inactive.";
        return RedirectToAction(nameof(Licenses));
    }

    [HttpGet("/portal/invoices")]
    public async Task<IActionResult> Invoices(CancellationToken ct)
    {
        ViewData["Title"] = "Invoices";
        var cid = CustomerId;
        var invoices = await _db.Invoices.AsNoTracking().Where(i => i.CustomerId == cid).OrderByDescending(i => i.IssuedAt).ToListAsync(ct);
        return View("Invoices", invoices);
    }

    [HttpGet("/portal/invoices/{id:guid}")]
    public async Task<IActionResult> InvoiceDetails(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Invoice";
        var cid = CustomerId;
        var invoice = await _db.Invoices.AsNoTracking().FirstOrDefaultAsync(i => i.Id == id && i.CustomerId == cid, ct);
        if (invoice is null) return NotFound();
        var items = await _db.InvoiceItems.AsNoTracking().Where(i => i.OrganizationId == invoice.OrganizationId && i.InvoiceId == id).ToListAsync(ct);
        var payments = await _db.Payments.AsNoTracking().Where(p => p.OrganizationId == invoice.OrganizationId && p.InvoiceId == id).ToListAsync(ct);
        return View("InvoiceDetails", new PortalInvoiceDetailsViewModel(invoice, items, payments));
    }

    [HttpGet("/portal/invoices/{id:guid}/pdf")]
    public async Task<IActionResult> InvoicePdf(Guid id, CancellationToken ct)
    {
        var cid = CustomerId;
        var invoice = await _db.Invoices.AsNoTracking().FirstOrDefaultAsync(i => i.Id == id && i.CustomerId == cid, ct);
        if (invoice is null) return NotFound();
        var bytes = await _pdf.GenerateAsync(invoice, ct);
        return File(bytes, "application/pdf", $"{invoice.Number}.pdf");
    }
}

public sealed record PortalHomeViewModel(List<Subscription> Subscriptions, List<Invoice> RecentInvoices, int LicenseCount, decimal Outstanding, int OpenTickets, int PendingRequests);
public sealed record PortalSubscriptionsViewModel(List<Subscription> Subscriptions, Dictionary<Guid, string> PlanNames, List<ApprovalRequest> Requests);
public sealed record PortalLicensesViewModel(List<License> Licenses, List<LicenseDevice> Devices, Dictionary<Guid, string> ApplicationNames);
public sealed record PortalInvoiceDetailsViewModel(Invoice Invoice, List<InvoiceItem> Items, List<Payment> Payments);

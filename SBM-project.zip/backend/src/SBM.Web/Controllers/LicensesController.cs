using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Licensing.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class LicensesController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly LicenseAppService _licenses;

    public LicensesController(SbmDbContext db, ITenantContext tenant, LicenseAppService licenses)
    {
        _db = db;
        _tenant = tenant;
        _licenses = licenses;
    }

    public async Task<IActionResult> Index(string? search, CancellationToken ct)
    {
        ViewData["Title"] = "Licenses";
        ViewData["Nav"] = "licenses";
        var query = TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant);
        if (!string.IsNullOrWhiteSpace(search) && Guid.TryParse(search.Trim(), out var cid))
            query = query.Where(l => l.CustomerId == cid);
        var licenses = await query.OrderByDescending(l => l.IssuedAt).Take(100).ToListAsync(ct);
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant)
            .Where(c => licenses.Select(l => l.CustomerId).Contains(c.Id))
            .ToDictionaryAsync(c => c.Id, c => c.Name, ct);
        var devices = await TenantScope.Org(_db.LicenseDevices.AsNoTracking(), _tenant)
            .Where(d => licenses.Select(l => l.Id).Contains(d.LicenseId) && d.DeactivatedAt == null)
            .GroupBy(d => d.LicenseId)
            .ToDictionaryAsync(g => g.Key, g => g.Count(), ct);
        return View(new LicensesIndexViewModel(search, licenses, customers, devices));
    }

    [HttpGet("/licenses/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "License";
        ViewData["Nav"] = "licenses";
        var license = await TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (license is null) return NotFound();
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == license.CustomerId, ct);
        var devices = await TenantScope.Org(_db.LicenseDevices.AsNoTracking(), _tenant).Where(d => d.LicenseId == id).OrderByDescending(d => d.ActivatedAt).ToListAsync(ct);
        var events = await TenantScope.Org(_db.LicenseEvents.AsNoTracking(), _tenant).Where(e => e.LicenseId == id).OrderByDescending(e => e.OccurredAtUtc).Take(50).ToListAsync(ct);
        return View(new LicenseDetailsViewModel(license, customer?.Name, devices, events));
    }

    [HttpPost("/licenses/{id:guid}/revoke")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Revoke(Guid id, string? reason, CancellationToken ct)
    {
        var license = await TenantScope.Org(_db.Licenses, _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (license is null) return NotFound();
        var ok = await _licenses.RevokeAsync(license.OrganizationId, id, reason ?? "manual", _tenant.UserId, ct);
        TempData["Flash"] = ok ? "تم إلغاء الترخيص — License revoked." : "الترخيص ملغى بالفعل — Already revoked.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/licenses/{id:guid}/devices/{deviceId}/deactivate")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeactivateDevice(Guid id, string deviceId, CancellationToken ct)
    {
        var license = await TenantScope.Org(_db.Licenses, _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (license is null) return NotFound();
        await _licenses.DeactivateDeviceAsync(license.OrganizationId, id, deviceId, ct);
        TempData["Flash"] = "تم تعطيل الجهاز — Device deactivated.";
        return RedirectToAction(nameof(Details), new { id });
    }
}

public sealed record LicensesIndexViewModel(string? Search, List<License> Licenses, Dictionary<Guid, string> Customers, Dictionary<Guid, int> ActiveDevices);
public sealed record LicenseDetailsViewModel(License License, string? CustomerName, List<LicenseDevice> Devices, List<LicenseEvent> Events);

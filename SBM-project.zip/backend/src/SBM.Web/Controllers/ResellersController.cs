using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;

namespace SBM.Web.Controllers;

/// <summary>
/// Reseller (partner) management — platform-level. Commissions are computed from paid invoices
/// of customers attributed to the reseller (Customer.ResellerId), rounded to 2dp, and are
/// idempotent per (reseller, invoice) via a unique index.
/// </summary>
[Authorize(Policy = "PlatformAdmin")]
public class ResellersController : Controller
{
    private readonly SbmDbContext _db;

    public ResellersController(SbmDbContext db) => _db = db;

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Resellers";
        ViewData["Nav"] = "resellers";
        var resellers = await _db.Resellers.AsNoTracking().OrderBy(r => r.Name).ToListAsync(ct);
        var commissionCount = await _db.ResellerCommissions.AsNoTracking()
            .GroupBy(c => c.ResellerId)
            .ToDictionaryAsync(g => g.Key, g => g.Count(), ct);
        return View(new ResellersIndexViewModel(resellers, commissionCount));
    }

    [HttpGet("/resellers/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Reseller";
        ViewData["Nav"] = "resellers";
        var reseller = await _db.Resellers.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id, ct);
        if (reseller is null) return NotFound();
        var commissions = await _db.ResellerCommissions.AsNoTracking()
            .Where(c => c.ResellerId == id)
            .OrderByDescending(c => c.CalculatedAt)
            .Take(200)
            .ToListAsync(ct);
        var invoiceNumbers = await _db.Invoices.AsNoTracking()
            .Where(i => commissions.Select(c => c.InvoiceId).Contains(i.Id))
            .ToDictionaryAsync(i => i.Id, i => i.Number, ct);
        return View(new ResellerDetailsViewModel(reseller, commissions, invoiceNumbers));
    }

    [HttpPost("/resellers")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateResellerInput model, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(model.Name) || model.CommissionPercent is < 0 or > 100)
        {
            TempData["Flash"] = "Name and a commission percent between 0 and 100 are required.";
            return RedirectToAction(nameof(Index));
        }
        _db.Resellers.Add(new Reseller
        {
            Name = model.Name.Trim(),
            ContactEmail = model.ContactEmail?.Trim(),
            ContactPhone = model.ContactPhone?.Trim(),
            CommissionPercent = decimal.Round(model.CommissionPercent ?? 0m, 2),
            LinkedOrganizationId = model.LinkedOrganizationId
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ الموزع — Reseller saved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/resellers/{id:guid}/calculate")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Calculate(Guid id, string period, CancellationToken ct)
    {
        var reseller = await _db.Resellers.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (reseller is null) return NotFound();
        if (reseller.Status != ResellerStatus.Active) { TempData["Flash"] = "Reseller is suspended."; return RedirectToAction(nameof(Details), new { id }); }
        if (string.IsNullOrWhiteSpace(period) || !System.Text.RegularExpressions.Regex.IsMatch(period, @"^\d{4}-\d{2}$"))
        {
            TempData["Flash"] = "Period must be YYYY-MM.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var (start, end) = PeriodRange(period);
        var customerIds = await _db.Customers.AsNoTracking().Where(c => c.ResellerId == id).Select(c => c.Id).ToListAsync(ct);
        if (customerIds.Count == 0)
        {
            TempData["Flash"] = "No customers attributed to this reseller.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var invoices = await _db.Invoices.AsNoTracking()
            .Where(i => customerIds.Contains(i.CustomerId)
                && (i.Status == InvoiceStatus.Paid || i.Status == InvoiceStatus.PartiallyPaid)
                && i.AmountPaid > 0
                && i.PaidAt >= start && i.PaidAt < end)
            .ToListAsync(ct);

        var existing = await _db.ResellerCommissions.AsNoTracking()
            .Where(c => c.ResellerId == id)
            .Select(c => c.InvoiceId)
            .ToListAsync(ct);
        var existingSet = existing.ToHashSet();

        var created = 0;
        foreach (var invoice in invoices)
        {
            if (existingSet.Contains(invoice.Id)) continue;
            var commission = decimal.Round(invoice.AmountPaid * reseller.CommissionPercent / 100m, 2, MidpointRounding.AwayFromZero);
            _db.ResellerCommissions.Add(new ResellerCommission
            {
                ResellerId = id,
                OrganizationId = invoice.OrganizationId,
                CustomerId = invoice.CustomerId,
                InvoiceId = invoice.Id,
                InvoiceAmount = invoice.AmountPaid,
                CommissionAmount = commission,
                Currency = invoice.Currency,
                Period = period,
                Status = CommissionStatus.PendingApproval
            });
            created++;
        }
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = $"تم حساب {created} عمولة جديدة للفترة {period} — {created} new commissions for {period}.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/resellers/commissions/{id:guid}/approve")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ApproveCommission(Guid id, CancellationToken ct)
    {
        var commission = await _db.ResellerCommissions.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (commission is null) return NotFound();
        if (commission.Status == CommissionStatus.PendingApproval)
        {
            commission.Status = CommissionStatus.Approved;
            commission.ApprovedAt = DateTimeOffset.UtcNow;
            commission.ApprovedByUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier) is { } claim && Guid.TryParse(claim.Value, out var uid) ? uid : null;
            await _db.SaveChangesAsync(ct);
        }
        return RedirectToAction("Details", new { id = commission.ResellerId });
    }

    [HttpPost("/resellers/commissions/{id:guid}/reject")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RejectCommission(Guid id, CancellationToken ct)
    {
        var commission = await _db.ResellerCommissions.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (commission is null) return NotFound();
        if (commission.Status == CommissionStatus.PendingApproval)
        {
            commission.Status = CommissionStatus.Rejected;
            commission.ApprovedAt = DateTimeOffset.UtcNow;
            await _db.SaveChangesAsync(ct);
        }
        return RedirectToAction("Details", new { id = commission.ResellerId });
    }

    private static (DateTimeOffset Start, DateTimeOffset End) PeriodRange(string period)
    {
        var parts = period.Split('-');
        var year = int.Parse(parts[0]);
        var month = int.Parse(parts[1]);
        var start = new DateTimeOffset(year, month, 1, 0, 0, 0, TimeSpan.Zero);
        return (start, start.AddMonths(1));
    }
}

public sealed record ResellersIndexViewModel(List<Reseller> Resellers, Dictionary<Guid, int> CommissionCounts);
public sealed record ResellerDetailsViewModel(Reseller Reseller, List<ResellerCommission> Commissions, Dictionary<Guid, string> InvoiceNumbers);
public sealed class CreateResellerInput
{
    public string? Name { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public decimal? CommissionPercent { get; set; }
    public Guid? LinkedOrganizationId { get; set; }
}

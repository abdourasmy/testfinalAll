using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Identity.Permissions;
using SBM.Web.Security;
using SBM.Web.Services;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

/// <summary>
/// Organization user management ("Users &amp; Permissions"). Tenant-scoped: targets must belong to the
/// caller's organization (or the caller is a platform admin). Every mutation is permission-checked,
/// must not break the last-Owner rule, and is audited. PlatformAdmin is not assignable from this screen.
/// </summary>
[Authorize(Policy = "OrgManager")]
[RequiresPermission("users.read")]
public class UsersController : Controller
{
    private readonly SbmDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly RoleManager<IdentityRole<Guid>> _roles;
    private readonly ITenantContext _tenant;
    private readonly PermissionService _permissions;
    private readonly StampValidationCache _stamps;
    private readonly AuditLogger _audit;

    // Tenant-owned roles that can be granted from this screen. PlatformAdmin excluded by design.
    private static readonly string[] AssignableRoles = new[]
    {
        "Owner", "Manager", "Member", "Cashier", "Accountant",
        "Technician", "Salesperson", "Support", "Finance"
    };

    public UsersController(SbmDbContext db, UserManager<ApplicationUser> users, RoleManager<IdentityRole<Guid>> roles,
        ITenantContext tenant, PermissionService permissions, StampValidationCache stamps, AuditLogger audit)
    {
        _db = db;
        _users = users;
        _roles = roles;
        _tenant = tenant;
        _permissions = permissions;
        _stamps = stamps;
        _audit = audit;
    }

    private Guid CallerOrgId => _tenant.OrganizationId ?? throw new UnauthorizedAccessException();
    private Guid? CallerUserId => _tenant.UserId;

    private async Task<(ApplicationUser? target, OrganizationMembership? membership)> ResolveTargetAsync(Guid id, CancellationToken ct)
    {
        var target = await _users.FindByIdAsync(id.ToString());
        if (target is null) return (null, null);
        var memberships = await _db.OrganizationMemberships.AsNoTracking()
            .Where(m => m.UserId == target.Id && m.Status == "Active")
            .ToListAsync(ct);
        var membership = _tenant.IsPlatformAdmin
            ? memberships.FirstOrDefault()
            : memberships.FirstOrDefault(m => m.OrganizationId == CallerOrgId);
        return (target, membership);
    }

    public async Task<IActionResult> Index(string? search, string? role, bool? active, CancellationToken ct)
    {
        ViewData["Title"] = "Users & Permissions";
        ViewData["Nav"] = "users";
        var orgId = _tenant.IsPlatformAdmin ? (Guid?)null : CallerOrgId;

        // Members of the caller's org (or of any org for platform admin).
        var membershipQuery = _db.OrganizationMemberships.AsNoTracking().Where(m => m.Status == "Active");
        if (orgId is { } oid) membershipQuery = membershipQuery.Where(m => m.OrganizationId == oid);
        var memberships = await membershipQuery.OrderBy(m => m.JoinedAt).ToListAsync(ct);
        var custIds = memberships.Select(m => m.UserId).Distinct().ToList();

        var users = await _users.Users.AsNoTracking().Where(u => custIds.Contains(u.Id)).ToListAsync(ct);
        var rolesByUser = new Dictionary<Guid, List<string>>();
        foreach (var u in users)
            rolesByUser[u.Id] = (await _users.GetRolesAsync(u)).ToList();

        var lastLogin = await _db.SecurityEvents.AsNoTracking()
            .Where(e => e.EventType == "login.success" && e.UserId != null && custIds.Contains(e.UserId.Value))
            .GroupBy(e => e.UserId)
            .Select(g => new { UserId = g.Key!.Value, Last = g.Max(x => x.OccurredAtUtc) })
            .ToDictionaryAsync(x => x.UserId, x => x.Last, ct);

        var view = users.Select(u => new UserListRow(
            u.Id, u.Email ?? "", u.DisplayName, rolesByUser.GetValueOrDefault(u.Id, new List<string>()),
            u.DeactivatedAt is null, u.MfaEnabled,
            lastLogin.TryGetValue(u.Id, out var l) ? l : (DateTimeOffset?)null,
            memberships.First(m => m.UserId == u.Id).OrganizationId))
            .Where(r => (search is null || r.Email.Contains(search, StringComparison.OrdinalIgnoreCase) || r.DisplayName.Contains(search, StringComparison.OrdinalIgnoreCase))
                     && (role is null || r.Roles.Contains(role))
                     && (active is null || r.IsActive == active))
            .OrderBy(r => r.DisplayName)
            .ToList();

        return View(new UsersIndexViewModel(search, role, active, view, AssignableRoles));
    }

    [HttpGet("/users/create")]
    [RequiresPermission("users.create")]
    public async Task<IActionResult> Create(CancellationToken ct)
    {
        ViewData["Nav"] = "users";
        if (_tenant.OrganizationId is null && _tenant.IsPlatformAdmin)
        {
            var orgs = await _db.Organizations.AsNoTracking().OrderBy(o => o.Name).Select(o => new OrgOption(o.Id, o.Name)).ToListAsync(ct);
            return View(CreateUserInput.WithOrgsAndRoles(orgs));
        }
        return View(CreateUserInput.WithRoles());
    }

    [HttpPost("/users/create")]
    [RequiresPermission("users.create")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateUserInput model, CancellationToken ct)
    {
        var orgId = _tenant.OrganizationId ?? model.OrgId ?? Guid.Empty;
        if (orgId == Guid.Empty || !await _db.Organizations.AnyAsync(o => o.Id == orgId, ct))
        {
            ModelState.AddModelError(string.Empty, "Select an organization.");
            return View(CreateUserInput.WithOrgsAndRoles(await OrgOptionsAsync(ct), model));
        }
        if (string.IsNullOrWhiteSpace(model.Email) || string.IsNullOrWhiteSpace(model.DisplayName) || model.Roles is null || model.Roles.Length == 0)
        {
            ModelState.AddModelError(string.Empty, "Email, display name and at least one role are required.");
            return View(CreateUserInput.WithOrgsAndRoles(await OrgOptionsAsync(ct), model));
        }
        var invalidRole = model.Roles.FirstOrDefault(r => !AssignableRoles.Contains(r));
        if (invalidRole is not null)
        {
            ModelState.AddModelError(string.Empty, $"Role {invalidRole} cannot be assigned here.");
            return View(CreateUserInput.WithRoles(model));
        }

        // Caller must be able to grant every requested role's permission set (unless platform admin / owner).
        var callerUser = await _users.FindByIdAsync(CallerUserId!.Value.ToString());
        var callerRoles = callerUser is not null ? (await _users.GetRolesAsync(callerUser)).ToList() : new List<string>();
        var callerIsOwner = callerRoles.Contains("Owner") || _tenant.IsPlatformAdmin;
        if (!callerIsOwner)
        {
            var callerPerms = await _permissions.GetEffectiveAsync(CallerUserId.Value, callerRoles, false, ct);
            var targetPerms = RoleDefaults(model.Roles);
            var missing = targetPerms.Where(p => !callerPerms.Contains(p)).ToList();
            if (missing.Count > 0)
            {
                ModelState.AddModelError(string.Empty, $"You can only grant capabilities you possess. Missing: {string.Join(", ", missing)}");
                return View(CreateUserInput.WithRoles(model));
            }
        }

        var tempPassword = GenerateTemporaryPassword();
        var email = model.Email.Trim();
        var user = new ApplicationUser
        {
            UserName = email, Email = email, DisplayName = model.DisplayName.Trim(),
            Scope = AccountScope.Organization, EmailConfirmed = true, MustChangePassword = true
        };
        var created = await _users.CreateAsync(user, tempPassword);
        if (!created.Succeeded)
        {
            foreach (var error in created.Errors) ModelState.AddModelError(string.Empty, error.Description);
            return View(CreateUserInput.WithRoles(model));
        }

        await _users.AddToRolesAsync(user, model.Roles);
        _db.OrganizationMemberships.Add(new OrganizationMembership { OrganizationId = orgId, UserId = user.Id, Role = model.Roles.First(), Status = "Active" });
        await _db.SaveChangesAsync(ct);
        await _users.UpdateSecurityStampAsync(user);
        _stamps.Invalidate(user.Id);
        await _audit.WriteAsync("UserCreated", "success", "staff", "User", user.Id.ToString(), CallerUserId, orgId, $"Created {email} with roles {string.Join(",", model.Roles)}", ct);

        TempData["Flash"] = $"تم إنشاء الحساب. كلمة المرور المؤقتة: {tempPassword} — ستُعرض مرة واحدة فقط.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/users/{id:guid}")]
    [RequiresPermission("users.read")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Nav"] = "users";
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        return View(await BuildDetailsAsync(target, membership, ct));
    }

    [HttpPost("/users/{id:guid}/disable")]
    [RequiresPermission("users.disable")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Disable(Guid id, CancellationToken ct) => await SetEnabled(id, false, ct);

    [HttpPost("/users/{id:guid}/enable")]
    [RequiresPermission("users.disable")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Enable(Guid id, CancellationToken ct) => await SetEnabled(id, true, ct);

    private async Task<IActionResult> SetEnabled(Guid id, bool enable, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        var guard = await GuardLastOwnerAsync(target, ct, "toggle-disable");
        if (guard is not null) return guard;

        target.DeactivatedAt = enable ? null : DateTimeOffset.UtcNow;
        await _users.UpdateAsync(target);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync(enable ? "UserEnabled" : "UserDisabled", "success", "staff", "User", target.Id.ToString(), CallerUserId, membership.OrganizationId, $"Active={enable}", ct);
        TempData["Flash"] = enable ? "User enabled." : "User disabled.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/roles/add")]
    [RequiresPermission("roles.assign")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddRole(Guid id, string? role, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        if (role is null || !AssignableRoles.Contains(role)) { TempData["Flash"] = "Invalid role."; return RedirectToAction(nameof(Details), new { id }); }

        var callerUser = await _users.FindByIdAsync(CallerUserId!.Value.ToString());
        var callerRoles = callerUser is not null ? (await _users.GetRolesAsync(callerUser)).ToList() : new List<string>();
        if (!callerRoles.Contains("Owner") && !_tenant.IsPlatformAdmin)
        {
            var callerPerms = await _permissions.GetEffectiveAsync(CallerUserId.Value, callerRoles, false, ct);
            var roleDefaults = PermissionRegistry.Defaults.GetValueOrDefault(role, Array.Empty<string>());
            var missing = roleDefaults.Where(p => !callerPerms.Contains(p)).ToList();
            if (missing.Count > 0)
            {
                TempData["Flash"] = $"You can only grant capabilities you possess. Missing: {string.Join(", ", missing)}";
                return RedirectToAction(nameof(Details), new { id });
            }
        }

        await _users.AddToRoleAsync(target, role);
        // promote the highest role label on the membership to the newly granted one if it outranks the old
        membership.Role = role;
        await _db.SaveChangesAsync(ct);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync("RoleAssigned", "success", "staff", "Role", role, CallerUserId, membership.OrganizationId, $"user={target.Email}", ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/roles/remove")]
    [RequiresPermission("roles.assign")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RemoveRole(Guid id, string? role, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        if (string.IsNullOrWhiteSpace(role)) { TempData["Flash"] = "Invalid role."; return RedirectToAction(nameof(Details), new { id }); }

        // Last-Owner protection: removing the Owner role from the org's final owner is forbidden.
        if (role == "Owner")
        {
            var guard = await GuardLastOwnerAsync(target, ct, "demote-owner");
            if (guard is not null) return guard;
        }

        await _users.RemoveFromRoleAsync(target, role);
        await _db.SaveChangesAsync(ct);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync("RoleRevoked", "success", "staff", "Role", role, CallerUserId, membership.OrganizationId, $"user={target.Email}", ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/permissions/grant")]
    [RequiresPermission("permissions.assign")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> GrantPermission(Guid id, string? code, CancellationToken ct) => await SetPermission(id, code, true, ct);

    [HttpPost("/users/{id:guid}/permissions/revoke")]
    [RequiresPermission("permissions.revoke")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RevokePermission(Guid id, string? code, CancellationToken ct) => await SetPermission(id, code, false, ct);

    private async Task<IActionResult> SetPermission(Guid id, string? code, bool isGrant, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        if (code is null || !PermissionRegistry.All.Contains(code, StringComparer.OrdinalIgnoreCase))
        {
            TempData["Flash"] = "Unknown permission.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var callerUser = await _users.FindByIdAsync(CallerUserId!.Value.ToString());
        var callerRoles = callerUser is not null ? (await _users.GetRolesAsync(callerUser)).ToList() : new List<string>();
        if (!_tenant.IsPlatformAdmin)
        {
            var callerPerms = await _permissions.GetEffectiveAsync(CallerUserId.Value, callerRoles, false, ct);
            if (isGrant && !callerPerms.Contains(code, StringComparer.OrdinalIgnoreCase))
            {
                TempData["Flash"] = $"You cannot grant a permission you do not possess: {code}";
                return RedirectToAction(nameof(Details), new { id });
            }
        }

        var existing = await _db.UserPermissions.FirstOrDefaultAsync(p => p.UserId == target.Id && p.PermissionCode == code, ct);
        if (existing is null)
            _db.UserPermissions.Add(new UserPermission { UserId = target.Id, PermissionCode = code, IsGranted = isGrant });
        else
            existing.IsGranted = isGrant;
        await _db.SaveChangesAsync(ct);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync(isGrant ? "PermissionGranted" : "PermissionRevoked", "success", "staff", "Permission", code, CallerUserId, membership.OrganizationId, $"user={target.Email}", ct);
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/reset-password")]
    [RequiresPermission("users.reset_password")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetPassword(Guid id, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        var tempPassword = GenerateTemporaryPassword();
        var token = await _users.GeneratePasswordResetTokenAsync(target);
        var result = await _users.ResetPasswordAsync(target, token, tempPassword);
        if (!result.Succeeded) { TempData["Flash"] = "Password reset failed."; return RedirectToAction(nameof(Details), new { id }); }
        target.MustChangePassword = true;
        await _users.UpdateAsync(target);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync("PasswordResetInitiatedByOwner", "success", "staff", "User", target.Id.ToString(), CallerUserId, membership.OrganizationId, $"Force reset by owner for {target.Email}", ct);
        TempData["Flash"] = $"كلمة المرور المؤقتة: {tempPassword} — تُفرض على المستخدم عند الدخول ولمرة واحدة.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/reset-mfa")]
    [RequiresPermission("users.reset_mfa")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetMfa(Guid id, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        await _users.SetTwoFactorEnabledAsync(target, false);
        await _users.ResetAuthenticatorKeyAsync(target);
        target.MfaEnabled = false;
        await _users.UpdateAsync(target);
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync("MfaReset", "success", "staff", "User", target.Id.ToString(), CallerUserId, membership.OrganizationId, $"MFA reset for {target.Email}", ct);
        TempData["Flash"] = "MFA has been reset. The user must enroll again.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost("/users/{id:guid}/revoke-sessions")]
    [RequiresPermission("users.revoke_sessions")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RevokeSessions(Guid id, CancellationToken ct)
    {
        var (target, membership) = await ResolveTargetAsync(id, ct);
        if (target is null || membership is null) return NotFound();
        await _users.UpdateSecurityStampAsync(target);
        _stamps.Invalidate(target.Id);
        await _audit.WriteAsync("SessionRevoked", "success", "staff", "User", target.Id.ToString(), CallerUserId, membership.OrganizationId, $"All sessions revoked for {target.Email}", ct);
        TempData["Flash"] = "All sessions revoked.";
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task<IActionResult?> GuardLastOwnerAsync(ApplicationUser target, CancellationToken ct, string action)
    {
        var targetRoles = await _users.GetRolesAsync(target);
        if (!targetRoles.Contains("Owner")) return null;

        var memberships = await _db.OrganizationMemberships.AsNoTracking()
            .Where(m => m.Status == "Active" && m.Role == "Owner")
            .Select(m => m.UserId)
            .Distinct()
            .ToListAsync(ct);

        // Only count owners in the target user's org(s)
        var orgIds = await _db.OrganizationMemberships.AsNoTracking()
            .Where(m => m.UserId == target.Id && m.Status == "Active")
            .Select(m => m.OrganizationId)
            .ToListAsync(ct);
        var ownersInOrg = await _db.OrganizationMemberships.AsNoTracking()
            .Where(m => orgIds.Contains(m.OrganizationId) && m.Role == "Owner" && m.Status == "Active")
            .Select(m => m.UserId)
            .Distinct()
            .ToListAsync(ct);

        if (ownersInOrg.Count <= 1)
        {
            await _audit.WriteAsync("LastOwnerRemovalBlocked", "blocked", "staff", "User", target.Id.ToString(), CallerUserId, null, $"Blocked {action} on final org owner", ct);
            return BadRequest(new { error = "Cannot remove the last Owner of the organization." });
        }
        return null;
    }

    private async Task<List<OrgOption>> OrgOptionsAsync(CancellationToken ct) =>
        _tenant.IsPlatformAdmin
            ? await _db.Organizations.AsNoTracking().OrderBy(o => o.Name).Select(o => new OrgOption(o.Id, o.Name)).ToListAsync(ct)
            : new List<OrgOption>();

    private async Task<UserDetailsViewModel> BuildDetailsAsync(ApplicationUser target, OrganizationMembership membership, CancellationToken ct)
    {
        var roles = (await _users.GetRolesAsync(target)).ToList();
        var roleIds = await _db.Roles.AsNoTracking().Where(r => roles.Contains(r.Name!)).Select(r => r.Id).ToListAsync(ct);
        var rolePerms = await _db.RolePermissions.AsNoTracking().Where(rp => roleIds.Contains(rp.RoleId)).Select(rp => rp.PermissionCode).Distinct().ToListAsync(ct);
        var direct = await _db.UserPermissions.AsNoTracking().Where(p => p.UserId == target.Id).ToListAsync(ct);
        var directGranted = direct.Where(d => d.IsGranted).Select(d => d.PermissionCode).ToList();
        var directRevoked = direct.Where(d => !d.IsGranted).Select(d => d.PermissionCode).ToList();
        var effective = await _permissions.GetEffectiveAsync(target.Id, roles, _tenant.IsPlatformAdmin, ct);
        var events = await _db.SecurityEvents.AsNoTracking().Where(e => e.UserId == target.Id)
            .OrderByDescending(e => e.OccurredAtUtc).Take(30).ToListAsync(ct);

        return new UserDetailsViewModel(
            target.Id, target.Email ?? "", target.DisplayName, membership.OrganizationId, membership.JoinedAt,
            target.DeactivatedAt is null, roles,
            rolePerms.OrderBy(p => p).ToList(), directGranted, directRevoked, effective.OrderBy(p => p).ToList(),
            events);
    }

    private static string[] RoleDefaults(IEnumerable<string> roleNames) =>
        roleNames.SelectMany(r => PermissionRegistry.Defaults.GetValueOrDefault(r, Array.Empty<string>())).Distinct().ToArray();

    private static string GenerateTemporaryPassword()
    {
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@$%";
        var bytes = new byte[16];
        System.Security.Cryptography.RandomNumberGenerator.Fill(bytes);
        return new string(bytes.Select(b => alphabet[b % alphabet.Length]).ToArray());
    }
}

public sealed record UsersIndexViewModel(string? Search, string? Role, bool? Active, List<UserListRow> Users, string[] AssignableRoles);
public sealed record UserListRow(Guid Id, string Email, string DisplayName, List<string> Roles, bool IsActive, bool MfaEnabled, DateTimeOffset? LastLogin, Guid OrgId);
public sealed record UserDetailsViewModel(Guid Id, string Email, string DisplayName, Guid OrgId, DateTimeOffset JoinedAt, bool IsActive, IReadOnlyList<string> Roles, IReadOnlyList<string> RolePermissions, IReadOnlyList<string> DirectGranted, IReadOnlyList<string> DirectRevoked, IReadOnlyList<string> EffectivePermissions, List<SBM.Modules.Identity.Entities.SecurityEvent> SecurityEvents);
public sealed record OrgOption(Guid Id, string Name);
public sealed class CreateUserInput
{
    public string? Email { get; set; }
    public string? DisplayName { get; set; }
    public string[] Roles { get; set; } = Array.Empty<string>();
    public string[] AssignableRoles { get; set; } = Array.Empty<string>();
    public Guid? OrgId { get; set; }
    public List<OrgOption> Orgs { get; set; } = new();

    public static CreateUserInput WithRoles() => new() { Roles = new[] { "Member" } };

    public static CreateUserInput WithRoles(CreateUserInput input) => new()
    {
        Email = input.Email,
        DisplayName = input.DisplayName,
        Roles = input.Roles,
        AssignableRoles = input.AssignableRoles,
        OrgId = input.OrgId
    };

    public static CreateUserInput WithOrgsAndRoles(IReadOnlyList<OrgOption> orgs, CreateUserInput? input = null) => new()
    {
        Email = input?.Email,
        DisplayName = input?.DisplayName,
        Roles = input?.Roles ?? new[] { "Member" },
        AssignableRoles = AssignableRolesStatic,
        OrgId = input?.OrgId,
        Orgs = orgs.ToList()
    };

    private static string[] AssignableRolesStatic => new[]
    {
        "Owner", "Manager", "Member", "Cashier", "Accountant",
        "Technician", "Salesperson", "Support", "Finance"
    };
}

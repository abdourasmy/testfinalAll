using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;
using SBM.Web.Security;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SbmDbContext _db;
    private readonly SignInService _signIn;
    private readonly LanguageService _lang;

    public AccountController(UserManager<ApplicationUser> users, SbmDbContext db, SignInService signIn, LanguageService lang)
    {
        _users = users;
        _db = db;
        _signIn = signIn;
        _lang = lang;
    }

    [HttpGet("/login")]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel(returnUrl));

    [HttpPost("/login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, CancellationToken ct)
    {
        var returnUrl = string.IsNullOrWhiteSpace(model.ReturnUrl) ? "/" : model.ReturnUrl;
        if (!Url.IsLocalUrl(returnUrl)) returnUrl = "/";

        var user = await _users.FindByEmailAsync(model.Email?.Trim() ?? string.Empty);
        if (user is null || user.DeactivatedAt is not null || !await _users.CheckPasswordAsync(user, model.Password ?? string.Empty))
        {
            await LogSecurityEventAsync(user?.Id, "login.failed", "staff login failed");
            ModelState.AddModelError(string.Empty, _lang.T("بيانات الدخول غير صحيحة.", "Invalid credentials."));
            return View(model);
        }

        if (user.MfaEnabled)
        {
            await _signIn.SignInMfaPendingAsync(HttpContext, user);
            return RedirectToAction("MfaLogin", new { returnUrl });
        }

        await _signIn.SignInStaffAsync(HttpContext, user);
        await LogSecurityEventAsync(user.Id, "login.success", "staff login");
        return Redirect(returnUrl);
    }

    [HttpGet("/mfa-login")]
    public IActionResult MfaLogin(string? returnUrl = null) => View(new MfaLoginViewModel(returnUrl ?? "/"));

    [HttpPost("/mfa-login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> MfaLogin(MfaLoginViewModel model, CancellationToken ct)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
                     ?? (await HttpContext.AuthenticateAsync(CookieSchemes.MfaPending)).Principal?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var user = userId is not null ? await _users.FindByIdAsync(userId) : null;
        if (user is null) return RedirectToAction(nameof(Login));

        var code = (model.Code ?? string.Empty).Trim().Replace(" ", string.Empty);
        var ok = await _users.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultAuthenticatorProvider, code);
        if (!ok)
        {
            var redeemed = await _users.RedeemTwoFactorRecoveryCodeAsync(user, code);
            ok = redeemed.Succeeded;
        }
        if (!ok)
        {
            await LogSecurityEventAsync(user.Id, "mfa.failed", "staff MFA verification failed");
            ModelState.AddModelError(string.Empty, _lang.T("رمز التحقق غير صحيح.", "Invalid verification code."));
            return View(model);
        }

        await HttpContext.SignOutAsync(CookieSchemes.MfaPending);
        await _signIn.SignInStaffAsync(HttpContext, user);
        await LogSecurityEventAsync(user.Id, "mfa.success", "staff MFA verified");
        return Redirect(string.IsNullOrWhiteSpace(model.ReturnUrl) ? "/" : model.ReturnUrl);
    }

    [HttpPost("/logout")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieSchemes.Staff);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet("/forbidden")]
    public IActionResult Forbidden() => View();

    [HttpGet("/lang/{culture}")]
    public IActionResult Lang(string culture, string? returnUrl = null)
    {
        var value = culture == "en" ? "en" : "ar";
        Response.Cookies.Append(LanguageService.CookieName, value, new CookieOptions { HttpOnly = false, SameSite = SameSiteMode.Lax, MaxAge = TimeSpan.FromDays(365) });
        var target = string.IsNullOrWhiteSpace(returnUrl) ? Request.Headers.Referer.ToString() : returnUrl;
        if (string.IsNullOrWhiteSpace(target) || !Url.IsLocalUrl(target)) target = "/";
        return LocalRedirect(target);
    }

    private async Task LogSecurityEventAsync(Guid? userId, string type, string? details)
    {
        _db.SecurityEvents.Add(new SecurityEvent { UserId = userId, EventType = type, Details = details, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() });
        await _db.SaveChangesAsync();
    }
}

public sealed record LoginViewModel(string? ReturnUrl)
{
    public string? Email { get; set; }
    public string? Password { get; set; }
}

public sealed record MfaLoginViewModel(string ReturnUrl)
{
    public string? Code { get; set; }
}

using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;
using SBM.Web.Security;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SbmDbContext _db;
    private readonly SignInService _signIn;
    private readonly LanguageService _lang;
    private readonly Microsoft.Extensions.Logging.ILogger<AccountController> _logger;

    public AccountController(UserManager<ApplicationUser> users, SbmDbContext db, SignInService signIn, LanguageService lang, Microsoft.Extensions.Logging.ILogger<AccountController> logger)
    {
        _users = users;
        _db = db;
        _signIn = signIn;
        _lang = lang;
        _logger = logger;
    }

    [HttpGet("/login")]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel(returnUrl));

    [HttpPost("/login")]
    [ValidateAntiForgeryToken]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("auth")]
    public async Task<IActionResult> Login(LoginViewModel model, CancellationToken ct)
    {
        var returnUrl = string.IsNullOrWhiteSpace(model.ReturnUrl) ? "/" : model.ReturnUrl;
        if (!Url.IsLocalUrl(returnUrl)) returnUrl = "/";

        var user = await _users.FindByEmailAsync(model.Email?.Trim() ?? string.Empty);
        if (user is null || user.DeactivatedAt is not null || !await _users.CheckPasswordAsync(user, model.Password ?? string.Empty))
        {
            await LogSecurityEventAsync(user?.Id, "login.failed", "staff login failed");
            ModelState.AddModelError(string.Empty, _lang.T("بيانات الدخول غير صحيحة.", "Invalid credentials."));
            return View(model);
        }

        if (user.MfaEnabled)
        {
            await _signIn.SignInMfaPendingAsync(HttpContext, user);
            return RedirectToAction("MfaLogin", new { returnUrl });
        }

        await _signIn.SignInStaffAsync(HttpContext, user);
        await LogSecurityEventAsync(user.Id, "login.success", "staff login");
        if (user.MustChangePassword)
            return RedirectToAction(nameof(ChangePassword), new { returnUrl });
        return Redirect(returnUrl);
    }

    [HttpGet("/mfa-login")]
    public IActionResult MfaLogin(string? returnUrl = null) => View(new MfaLoginViewModel(returnUrl ?? "/"));

    [HttpPost("/mfa-login")]
    [ValidateAntiForgeryToken]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("auth")]
    public async Task<IActionResult> MfaLogin(MfaLoginViewModel model, CancellationToken ct)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
                     ?? (await HttpContext.AuthenticateAsync(CookieSchemes.MfaPending)).Principal?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var user = userId is not null ? await _users.FindByIdAsync(userId) : null;
        if (user is null) return RedirectToAction(nameof(Login));

        var code = (model.Code ?? string.Empty).Trim().Replace(" ", string.Empty);
        var ok = await _users.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultAuthenticatorProvider, code);
        if (!ok)
        {
            var redeemed = await _users.RedeemTwoFactorRecoveryCodeAsync(user, code);
            ok = redeemed.Succeeded;
        }
        if (!ok)
        {
            await LogSecurityEventAsync(user.Id, "mfa.failed", "staff MFA verification failed");
            ModelState.AddModelError(string.Empty, _lang.T("رمز التحقق غير صحيح.", "Invalid verification code."));
            return View(model);
        }

        await HttpContext.SignOutAsync(CookieSchemes.MfaPending);
        await _signIn.SignInStaffAsync(HttpContext, user);
        await LogSecurityEventAsync(user.Id, "mfa.success", "staff MFA verified");
        return Redirect(string.IsNullOrWhiteSpace(model.ReturnUrl) ? "/" : model.ReturnUrl);
    }

    [HttpPost("/logout")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieSchemes.Staff);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet("/forbidden")]
    public IActionResult Forbidden() => View();

    [HttpGet("/lang/{culture}")]
    public IActionResult Lang(string culture, string? returnUrl = null)
    {
        var value = culture == "en" ? "en" : "ar";
        Response.Cookies.Append(LanguageService.CookieName, value, new CookieOptions { HttpOnly = false, SameSite = SameSiteMode.Lax, MaxAge = TimeSpan.FromDays(365) });
        var target = string.IsNullOrWhiteSpace(returnUrl) ? Request.Headers.Referer.ToString() : returnUrl;
        if (string.IsNullOrWhiteSpace(target) || !Url.IsLocalUrl(target)) target = "/";
        return LocalRedirect(target);
    }

    [HttpGet("/change-password")]
    [Authorize]
    public IActionResult ChangePassword(string? returnUrl = null)
    {
        ViewData["Nav"] = null;
        return View(new ChangePasswordViewModel(returnUrl));
    }

    [HttpPost("/change-password")]
    [Authorize]
    [ValidateAntiForgeryToken]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("auth")]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model, CancellationToken ct)
    {
        var user = await CurrentUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));

        var returnUrl = string.IsNullOrWhiteSpace(model.ReturnUrl) ? "/" : model.ReturnUrl;
        if (!Url.IsLocalUrl(returnUrl)) returnUrl = "/";

        if (!await _users.CheckPasswordAsync(user, model.CurrentPassword ?? string.Empty))
        {
            ModelState.AddModelError(string.Empty, _lang.T("كلمة المرور الحالية غير صحيحة.", "Current password is incorrect."));
            return View(model);
        }
        if (string.Equals(model.NewPassword, model.CurrentPassword, StringComparison.Ordinal))
        {
            ModelState.AddModelError(string.Empty, _lang.T("اختر كلمة مرور مختلفة.", "Choose a different password."));
            return View(model);
        }

        var result = await _users.ChangePasswordAsync(user, model.CurrentPassword!, model.NewPassword!);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors) ModelState.AddModelError(string.Empty, error.Description);
            return View(model);
        }

        user.MustChangePassword = false;
        await _users.UpdateAsync(user);
        await _users.UpdateSecurityStampAsync(user); // invalidate every existing session
        await _signIn.SignInStaffAsync(HttpContext, user); // re-issue cookie with the new stamp
        _db.SecurityEvents.Add(new SecurityEvent { UserId = user.Id, EventType = "password.changed", Action = "PasswordCompleted", Result = "success", ActorType = "staff", TargetType = "User", TargetId = user.Id.ToString(), IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), Details = "Staff password changed" });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = _lang.T("تم تغيير كلمة المرور.", "Password changed.");
        return Redirect(returnUrl);
    }

    [HttpGet("/forgot-password")]
    public IActionResult ForgotPassword() => View();

    [HttpPost("/forgot-password")]
    [ValidateAntiForgeryToken]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("auth")]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model, CancellationToken ct)
    {
        // Anti-enumeration: always the same response, whether or not the account exists.
        var user = await _users.FindByEmailAsync(model.Email?.Trim() ?? string.Empty);
        if (user is not null && user.DeactivatedAt is null)
        {
            var token = await _users.GeneratePasswordResetTokenAsync(user);
            var link = $"/reset-password?userId={user.Id}&code={Uri.EscapeDataString(token)}";
            _db.SecurityEvents.Add(new SecurityEvent { UserId = user.Id, EventType = "password.reset.requested", Action = "PasswordResetRequested", Result = "success", ActorType = "staff", TargetType = "User", TargetId = user.Id.ToString(), IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), Details = "Reset link issued (delivery: logged)" });
            await _db.SaveChangesAsync(ct);
            ViewBag.ResetLink = link;
            ViewBag.ShowLink = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
            _logger.LogInformation("Password reset link for {Email}: {Link}", user.Email, link);
        }
        return View("ForgotPasswordConfirmation");
    }

    [HttpGet("/reset-password")]
    public IActionResult ResetPassword(string? userId, string? code)
    {
        if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(code))
            return RedirectToAction(nameof(ForgotPassword));
        return View(new ResetPasswordViewModel(userId, code));
    }

    [HttpPost("/reset-password")]
    [ValidateAntiForgeryToken]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("auth")]
    public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model, CancellationToken ct)
    {
        if (!Guid.TryParse(model.UserId, out var userId))
            return View("ResetPasswordInvalid");
        var user = await _users.FindByIdAsync(userId.ToString());
        if (user is null)
            return View("ResetPasswordInvalid");

        var result = await _users.ResetPasswordAsync(user, model.Code ?? string.Empty, model.NewPassword ?? string.Empty);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors) ModelState.AddModelError(string.Empty, error.Description);
            return View(model);
        }

        user.MustChangePassword = false;
        await _users.UpdateAsync(user);
        await _users.UpdateSecurityStampAsync(user); // invalidate all sessions
        _db.SecurityEvents.Add(new SecurityEvent { UserId = user.Id, EventType = "password.reset.completed", Action = "PasswordResetCompleted", Result = "success", ActorType = "staff", TargetType = "User", TargetId = user.Id.ToString(), IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), Details = "Password reset via token" });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = _lang.T("تم تعيين كلمة المرور الجديدة. سجل دخولك.", "Password reset. Sign in with your new password.");
        return RedirectToAction(nameof(Login));
    }

    private async Task<ApplicationUser?> CurrentUserAsync()
    {
        var id = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        return id is not null ? await _users.FindByIdAsync(id) : null;
    }

    private async Task LogSecurityEventAsync(Guid? userId, string type, string? details)
    {
        _db.SecurityEvents.Add(new SecurityEvent { UserId = userId, EventType = type, Details = details, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() });
        await _db.SaveChangesAsync();
    }
}

public sealed record ChangePasswordViewModel(string? ReturnUrl)
{
    public string? CurrentPassword { get; set; }
    public string? NewPassword { get; set; }
}

public sealed record ForgotPasswordViewModel
{
    public string? Email { get; set; }
}

public sealed record ResetPasswordViewModel(string UserId, string Code)
{
    public string? NewPassword { get; set; }
}

public sealed record LoginViewModel(string? ReturnUrl)
{
    public string? Email { get; set; }
    public string? Password { get; set; }
}

public sealed record MfaLoginViewModel(string ReturnUrl)
{
    public string? Code { get; set; }
}

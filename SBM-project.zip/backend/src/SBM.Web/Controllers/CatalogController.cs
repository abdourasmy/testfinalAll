using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Catalog.Entities;

namespace SBM.Web.Controllers;

[Authorize]
public class CatalogController : Controller
{
    private readonly SbmDbContext _db;

    public CatalogController(SbmDbContext db) => _db = db;

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewData["Title"] = "Catalog";
        ViewData["Nav"] = "catalog";
        var products = await _db.Products.AsNoTracking().OrderBy(p => p.Name).ToListAsync(ct);
        return View(products);
    }

    [HttpGet("/catalog/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Product";
        ViewData["Nav"] = "catalog";
        var product = await _db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id, ct);
        if (product is null) return NotFound();
        var apps = await _db.ProductApplications.AsNoTracking().Where(a => a.ProductId == id).ToListAsync(ct);
        var features = await _db.Features.AsNoTracking().Where(f => f.ProductId == id).ToListAsync(ct);
        var plans = await _db.PricingPlans.AsNoTracking().Where(p => p.ProductId == id).ToListAsync(ct);
        return View(new CatalogDetailsViewModel(product, apps, features, plans));
    }

    [Authorize(Policy = "PlatformAdmin")]
    public IActionResult Create()
    {
        ViewData["Nav"] = "catalog";
        return View();
    }

    [HttpPost]
    [Authorize(Policy = "PlatformAdmin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateProductInput model, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(model.Code) || string.IsNullOrWhiteSpace(model.Name))
        {
            ModelState.AddModelError(string.Empty, "Code and name are required.");
            return View(model);
        }
        var code = model.Code.Trim().ToUpperInvariant();
        if (await _db.Products.AnyAsync(p => p.Code == code, ct))
        {
            ModelState.AddModelError(nameof(model.Code), "Code already exists.");
            return View(model);
        }
        if (!Enum.TryParse<ProductStatus>(model.Status, true, out var status)) status = ProductStatus.Draft;
        var product = new Product { Code = code, Name = model.Name.Trim(), Description = model.Description?.Trim(), Category = model.Category?.Trim() ?? "Management", Status = status };
        _db.Products.Add(product);
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ المنتج — Product saved.";
        return RedirectToAction(nameof(Details), new { id = product.Id });
    }

    [HttpPost("/catalog/{productId:guid}/plans")]
    [Authorize(Policy = "PlatformAdmin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddPlan(Guid productId, CreatePlanInput model, CancellationToken ct)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == productId, ct);
        if (product is null) return NotFound();
        if (string.IsNullOrWhiteSpace(model.Code) || string.IsNullOrWhiteSpace(model.Name))
        {
            TempData["Flash"] = "Code and name are required.";
            return RedirectToAction(nameof(Details), new { id = productId });
        }
        var code = model.Code.Trim().ToUpperInvariant();
        if (await _db.PricingPlans.AnyAsync(p => p.ProductId == productId && p.Code == code, ct))
        {
            TempData["Flash"] = "Code already exists for this product.";
            return RedirectToAction(nameof(Details), new { id = productId });
        }
        if (!Enum.TryParse<BillingInterval>(model.Interval, true, out var interval)) interval = BillingInterval.Monthly;
        _db.PricingPlans.Add(new PricingPlan
        {
            ProductId = productId,
            Code = code,
            Name = model.Name.Trim(),
            Interval = interval,
            Price = model.Price,
            Currency = (model.Currency ?? "EGP").ToUpperInvariant(),
            DeviceLimit = model.DeviceLimit,
            SessionLimit = model.SessionLimit,
            TrialDays = model.TrialDays,
            IsTrial = model.TrialDays > 0,
            IsActive = true
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تمت إضافة الخطة — Plan added.";
        return RedirectToAction(nameof(Details), new { id = productId });
    }
}

public sealed record CatalogDetailsViewModel(Product Product, List<ProductApplication> Apps, List<Feature> Features, List<PricingPlan> Plans);
public sealed class CreateProductInput
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? Category { get; set; }
    public string? Status { get; set; } = "Active";
}
public sealed class CreatePlanInput
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? Interval { get; set; } = "Monthly";
    public decimal Price { get; set; }
    public string? Currency { get; set; } = "EGP";
    public int DeviceLimit { get; set; } = 1;
    public int SessionLimit { get; set; } = 1;
    public int TrialDays { get; set; }
}

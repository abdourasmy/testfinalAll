using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Finance.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Web.Controllers;

[Authorize]
public class FinanceController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public FinanceController(SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public async Task<IActionResult> Index(string? type, DateTimeOffset? from, DateTimeOffset? to, CancellationToken ct)
    {
        ViewData["Title"] = "Finance";
        ViewData["Nav"] = "finance";
        var query = TenantScope.Org(_db.FinanceEntries.AsNoTracking(), _tenant);
        if (Enum.TryParse<FinanceEntryType>(type, true, out var t))
            query = query.Where(e => e.Type == t);
        if (from is not null) query = query.Where(e => e.OccurredAt >= from);
        if (to is not null) query = query.Where(e => e.OccurredAt <= to);
        var entries = await query.OrderByDescending(e => e.OccurredAt).Take(200).ToListAsync(ct);

        var monthStart = new DateTimeOffset(DateTimeOffset.UtcNow.Year, DateTimeOffset.UtcNow.Month, 1, 0, 0, 0, TimeSpan.Zero);
        var scoped = TenantScope.Org(_db.FinanceEntries.AsNoTracking(), _tenant).Where(e => e.OccurredAt >= monthStart);
        var summary = new FinanceSummaryViewModel(
            Type: type, From: from, To: to,
            Entries: entries,
            MonthIncome: await scoped.Where(e => e.Type == FinanceEntryType.Income).SumAsync(e => (decimal?)e.Amount, ct) ?? 0m,
            MonthExpenses: await scoped.Where(e => e.Type == FinanceEntryType.Expense).SumAsync(e => (decimal?)e.Amount, ct) ?? 0m);
        return View(summary);
    }

    [HttpPost("/finance/entries")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateFinanceEntryInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is not { } orgId)
        {
            TempData["Flash"] = "Organization scope required.";
            return RedirectToAction(nameof(Index));
        }
        if (!Enum.TryParse<FinanceEntryType>(model.Type, true, out var type))
        {
            TempData["Flash"] = "Invalid type.";
            return RedirectToAction(nameof(Index));
        }
        if (string.IsNullOrWhiteSpace(model.Category) || model.Amount <= 0)
        {
            TempData["Flash"] = "Category and a positive amount are required.";
            return RedirectToAction(nameof(Index));
        }
        if (model.ExternalRef is not null && await _db.FinanceEntries.AnyAsync(e => e.ExternalRef == model.ExternalRef, ct))
        {
            TempData["Flash"] = "External reference already recorded — skipped.";
            return RedirectToAction(nameof(Index));
        }
        _db.FinanceEntries.Add(new FinanceEntry
        {
            OrganizationId = orgId,
            Type = type,
            Category = model.Category.Trim(),
            Description = model.Description?.Trim(),
            Amount = decimal.Round(model.Amount, 2, MidpointRounding.AwayFromZero),
            Currency = (model.Currency ?? "EGP").ToUpperInvariant(),
            PaymentMethod = string.IsNullOrWhiteSpace(model.PaymentMethod) ? "BankTransfer" : model.PaymentMethod.Trim(),
            Account = model.Account?.Trim(),
            Reference = model.Reference?.Trim(),
            ExternalRef = model.ExternalRef?.Trim(),
            CreatedByUserId = _tenant.UserId,
            OccurredAt = model.OccurredAt ?? DateTimeOffset.UtcNow
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم حفظ القيد — Entry saved.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/finance/entries/{id:guid}/reverse")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reverse(Guid id, string? reason, CancellationToken ct)
    {
        var original = await TenantScope.Org(_db.FinanceEntries, _tenant).FirstOrDefaultAsync(e => e.Id == id, ct);
        if (original is null) return NotFound();
        _db.FinanceEntries.Add(new FinanceEntry
        {
            OrganizationId = original.OrganizationId,
            Type = FinanceEntryType.Reversal,
            Category = original.Category,
            Description = $"Reversal of {original.Id}: {reason}",
            Amount = original.Amount,
            Currency = original.Currency,
            PaymentMethod = original.PaymentMethod,
            ReversalOfEntryId = original.Id,
            CreatedByUserId = _tenant.UserId,
            OccurredAt = DateTimeOffset.UtcNow
        });
        await _db.SaveChangesAsync(ct);
        TempData["Flash"] = "تم إنشاء قيد عكسي — Reversal recorded.";
        return RedirectToAction(nameof(Index));
    }
}

public sealed record FinanceSummaryViewModel(string? Type, DateTimeOffset? From, DateTimeOffset? To, List<FinanceEntry> Entries, decimal MonthIncome, decimal MonthExpenses);
public sealed class CreateFinanceEntryInput
{
    public string? Type { get; set; } = "Income";
    public string? Category { get; set; }
    public string? Description { get; set; }
    public decimal Amount { get; set; }
    public string? Currency { get; set; } = "EGP";
    public string? PaymentMethod { get; set; }
    public string? Account { get; set; }
    public string? Reference { get; set; }
    public string? ExternalRef { get; set; }
    public DateTimeOffset? OccurredAt { get; set; }
}

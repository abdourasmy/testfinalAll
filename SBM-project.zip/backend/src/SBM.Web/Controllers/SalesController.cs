using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Billing.Entities;
using SBM.Shared.Abstractions;
using SBM.Web.Services;

namespace SBM.Web.Controllers;

[Authorize]
public class SalesController : Controller
{
    private readonly SbmDbContext _db;
    private readonly ITenantContext _tenant;
    private readonly SalesService _sales;

    public SalesController(SbmDbContext db, ITenantContext tenant, SalesService sales)
    {
        _db = db;
        _tenant = tenant;
        _sales = sales;
    }

    public async Task<IActionResult> Index(string? tab, string? status, CancellationToken ct)
    {
        ViewData["Title"] = "Sales";
        ViewData["Nav"] = "sales";
        tab ??= "quotations";
        if (tab == "orders")
        {
            var q = TenantScope.Org(_db.SalesOrders.AsNoTracking(), _tenant);
            if (Enum.TryParse<SalesOrderStatus>(status, true, out var st)) q = q.Where(o => o.Status == st);
            var orders = await q.OrderByDescending(o => o.CreatedAt).Take(100).ToListAsync(ct);
            var customers = await CustomerLookupAsync(orders.Select(o => o.CustomerId), ct);
            return View(new SalesOrdersViewModel(status, orders, customers, await PendingQuoteCountAsync(ct)));
        }
        var quotes = TenantScope.Org(_db.Quotations.AsNoTracking(), _tenant);
        if (Enum.TryParse<QuotationStatus>(status, true, out var qst)) quotes = quotes.Where(o => o.Status == qst);
        var quotations = await quotes.OrderByDescending(o => o.CreatedAt).Take(100).ToListAsync(ct);
        var quoteCustomers = await CustomerLookupAsync(quotations.Select(o => o.CustomerId), ct);
        return View(new SalesQuotationsViewModel(status, quotations, quoteCustomers));
    }

    [HttpGet("/sales/create-quotation")]
    public async Task<IActionResult> CreateQuotation(CancellationToken ct)
    {
        ViewData["Nav"] = "sales";
        var customers = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).OrderBy(c => c.Name).Take(500).Select(c => new CustomerOption(c.Id, c.Name)).ToListAsync(ct);
        return View(new CreateQuotationInput { Customers = customers });
    }

    [HttpPost("/sales/create-quotation")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateQuotation(CreateQuotationInput model, CancellationToken ct)
    {
        if (_tenant.OrganizationId is null)
        {
            ModelState.AddModelError(string.Empty, "Organization scope required.");
            return View(new CreateQuotationInput { Customers = await CustomerOptionsAsync(ct) });
        }
        var lines = (model.Lines ?? new List<CreateInvoiceLineInput>())
            .Where(l => !string.IsNullOrWhiteSpace(l.Description) && l.Quantity > 0 && l.UnitPrice >= 0)
            .Select(l => new SalesService.LineInput(l.Description!, l.Quantity, l.UnitPrice, l.DiscountPercent, l.TaxPercent))
            .ToList();
        if (lines.Count == 0 || model.CustomerId == Guid.Empty)
        {
            ModelState.AddModelError(string.Empty, "Select a customer and at least one valid line.");
            return View(new CreateQuotationInput { Customers = await CustomerOptionsAsync(ct) });
        }
        try
        {
            var quotation = await _sales.CreateQuotationAsync(model.CustomerId, lines, model.ValidUntil, model.Notes, model.Currency ?? "EGP", ct);
            TempData["Flash"] = $"تم إنشاء عرض السعر {quotation.Number} — Quotation created.";
            return RedirectToAction(nameof(Quotation), new { id = quotation.Id });
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(new CreateQuotationInput { Customers = await CustomerOptionsAsync(ct) });
        }
    }

    [HttpGet("/sales/quotation/{id:guid}")]
    public async Task<IActionResult> Quotation(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Quotation";
        ViewData["Nav"] = "sales";
        var quotation = await TenantScope.Org(_db.Quotations.AsNoTracking(), _tenant).FirstOrDefaultAsync(q => q.Id == id, ct);
        if (quotation is null) return NotFound();
        var lines = await _db.QuotationLines.AsNoTracking().Where(l => l.OrganizationId == quotation.OrganizationId && l.QuotationId == id).ToListAsync(ct);
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == quotation.CustomerId, ct);
        var events = await TenantScope.Org(_db.SalesEvents.AsNoTracking(), _tenant).Where(e => e.EntityId == id).OrderBy(e => e.OccurredAtUtc).ToListAsync(ct);
        return View(new QuotationDetailsViewModel(quotation, lines, customer?.Name, events));
    }

    [HttpGet("/sales/order/{id:guid}")]
    public async Task<IActionResult> Order(Guid id, CancellationToken ct)
    {
        ViewData["Title"] = "Order";
        ViewData["Nav"] = "sales";
        var order = await TenantScope.Org(_db.SalesOrders.AsNoTracking(), _tenant).FirstOrDefaultAsync(o => o.Id == id, ct);
        if (order is null) return NotFound();
        var lines = await _db.SalesOrderLines.AsNoTracking().Where(l => l.OrganizationId == order.OrganizationId && l.SalesOrderId == id).ToListAsync(ct);
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == order.CustomerId, ct);
        var events = await TenantScope.Org(_db.SalesEvents.AsNoTracking(), _tenant).Where(e => e.EntityId == id).OrderBy(e => e.OccurredAtUtc).ToListAsync(ct);
        var invoice = order.InvoiceId is { } invId ? await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).FirstOrDefaultAsync(i => i.Id == invId, ct) : null;
        return View(new OrderDetailsViewModel(order, lines, customer?.Name, events, invoice?.Number));
    }

    [HttpPost("/sales/quotation/{id:guid}/send")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Send(Guid id, CancellationToken ct) => await Transition(async () => await _sales.SendQuotationAsync(id, ct), () => RedirectToAction(nameof(Quotation), new { id }));

    [HttpPost("/sales/quotation/{id:guid}/accept")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Accept(Guid id, CancellationToken ct) => await Transition(async () => await _sales.AcceptQuotationAsync(id, ct), () => RedirectToAction(nameof(Quotation), new { id }));

    [HttpPost("/sales/quotation/{id:guid}/reject")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(Guid id, string? reason, CancellationToken ct) => await Transition(async () => await _sales.RejectQuotationAsync(id, reason, ct), () => RedirectToAction(nameof(Quotation), new { id }));

    [HttpPost("/sales/quotation/{id:guid}/convert-to-order")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConvertToOrder(Guid id, CancellationToken ct)
    {
        try
        {
            var order = await _sales.ConvertToOrderAsync(id, ct);
            TempData["Flash"] = $"تم إنشاء الطلب {order.Number} — Order created.";
            return RedirectToAction(nameof(Order), new { id = order.Id });
        }
        catch (InvalidOperationException ex) { TempData["Flash"] = ex.Message; return RedirectToAction(nameof(Quotation), new { id }); }
        catch (KeyNotFoundException) { return NotFound(); }
    }

    [HttpPost("/sales/order/{id:guid}/confirm")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmOrder(Guid id, CancellationToken ct) => await Transition(async () => await _sales.ConfirmOrderAsync(id, ct), () => RedirectToAction(nameof(Order), new { id }));

    [HttpPost("/sales/order/{id:guid}/fulfill")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> FulfillOrder(Guid id, CancellationToken ct) => await Transition(async () => await _sales.FulfillOrderAsync(id, ct), () => RedirectToAction(nameof(Order), new { id }));

    [HttpPost("/sales/order/{id:guid}/convert-to-invoice")]
    [Authorize(Policy = "OrgManager")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConvertToInvoice(Guid id, CancellationToken ct)
    {
        try
        {
            var invoice = await _sales.ConvertToInvoiceAsync(id, ct);
            TempData["Flash"] = $"تم إنشاء الفاتورة {invoice.Number} — Invoice created.";
            return RedirectToAction("Details", "Invoices", new { id = invoice.Id });
        }
        catch (InvalidOperationException ex) { TempData["Flash"] = ex.Message; return RedirectToAction(nameof(Order), new { id }); }
        catch (KeyNotFoundException) { return NotFound(); }
    }

    private async Task<IActionResult> Transition<T>(Func<Task<T>> action, Func<IActionResult> redirect)
    {
        try { await action(); }
        catch (InvalidOperationException ex) { TempData["Flash"] = ex.Message; }
        catch (KeyNotFoundException) { return NotFound(); }
        return redirect();
    }

    private async Task<int> PendingQuoteCountAsync(CancellationToken ct) =>
        await TenantScope.Org(_db.Quotations.AsNoTracking(), _tenant).CountAsync(q => q.Status == QuotationStatus.Sent, ct);

    private async Task<Dictionary<Guid, string>> CustomerLookupAsync(IEnumerable<Guid> ids, CancellationToken ct) =>
        await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).Where(c => ids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name, ct);

    private async Task<List<CustomerOption>> CustomerOptionsAsync(CancellationToken ct) =>
        await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).OrderBy(c => c.Name).Take(500).Select(c => new CustomerOption(c.Id, c.Name)).ToListAsync(ct);
}

public sealed record SalesQuotationsViewModel(string? Status, List<Quotation> Quotations, Dictionary<Guid, string> Customers);
public sealed record SalesOrdersViewModel(string? Status, List<SalesOrder> Orders, Dictionary<Guid, string> Customers, int AwaitingOrders);
public sealed record QuotationDetailsViewModel(Quotation Quotation, List<QuotationLine> Lines, string? CustomerName, List<SalesEvent> Events);
public sealed record OrderDetailsViewModel(SalesOrder Order, List<SalesOrderLine> Lines, string? CustomerName, List<SalesEvent> Events, string? InvoiceNumber);
public sealed class CreateQuotationInput
{
    public Guid CustomerId { get; set; }
    public string? Currency { get; set; } = "EGP";
    public DateTimeOffset? ValidUntil { get; set; }
    public string? Notes { get; set; }
    public List<CreateInvoiceLineInput>? Lines { get; set; }
    public List<CustomerOption> Customers { get; set; } = new();
}

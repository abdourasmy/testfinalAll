using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SBM.Infrastructure.Services;
using SBM.Shared.Abstractions;

namespace SBM.Web.Security;

/// <summary>
/// [RequiresPermission("users.read")] — enforces a granular permission from the caller's effective set
/// (role permissions ∪ direct grants − direct revokes). PlatformAdmin bypasses (implicit full access).
/// Org managers without the permission are redirected to the friendly /forbidden page.
/// </summary>
public sealed class RequiresPermissionAttribute : TypeFilterAttribute
{
    public RequiresPermissionAttribute(string permissionCode) : base(typeof(PermissionAuthorizationFilter))
    {
        Arguments = new object[] { permissionCode };
    }
}

public sealed class PermissionAuthorizationFilter : IAsyncAuthorizationFilter
{
    private readonly string _code;
    private readonly PermissionService _permissions;
    private readonly ITenantContext _tenant;

    public PermissionAuthorizationFilter(string code, PermissionService permissions, ITenantContext tenant)
    {
        _code = code;
        _permissions = permissions;
        _tenant = tenant;
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var user = context.HttpContext.User;
        if (user.Identity?.IsAuthenticated != true) return;
        if (user.IsInRole("PlatformAdmin")) return; // implicit full access

        if (_tenant.OrganizationId is not { } orgId)
        {
            context.Result = new RedirectToActionResult("Forbidden", "Account", null);
            return;
        }

        var userIdText = user.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (!Guid.TryParse(userIdText, out var userId))
        {
            context.Result = new RedirectToActionResult("Forbidden", "Account", null);
            return;
        }

        var roles = user.FindAll(System.Security.Claims.ClaimTypes.Role).Select(c => c.Value).ToList();
        var effective = await _permissions.GetEffectiveAsync(userId, roles, false);
        if (!effective.Contains(_code))
        {
            context.Result = new RedirectToActionResult("Forbidden", "Account", null);
        }
    }
}

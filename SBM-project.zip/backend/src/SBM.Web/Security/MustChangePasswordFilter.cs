using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Authorization;
using SBM.Web.Security;

namespace SBM.Web.Security;

/// <summary>
/// Global filter: authenticated staff users flagged MustChangePassword are redirected to
/// /change-password for everything except the password change flow itself and sign-out.
/// </summary>
public sealed class MustChangePasswordFilter : IAsyncAuthorizationFilter
{
    private static readonly string[] Allowlist =
    {
        "/change-password", "/logout", "/lang/", "/login", "/forbidden", "/status/", "/healthz",
        "/mfa-login", "/forgot-password", "/reset-password"
    };

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var http = context.HttpContext;
        if (http.Request.Path.StartsWithSegments("/portal")) return; // portal handled by its own policy

        var user = http.User;
        if (user.Identity?.IsAuthenticated != true) return;
        if (user.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier) is null) return;
        if (Allowlist.Any(p => http.Request.Path.StartsWithSegments(p))) return;

        var idText = user.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (!Guid.TryParse(idText, out var userId)) return;

        var snapshot = await http.RequestServices.GetRequiredService<StampValidationCache>()
            .GetAsync(userId, http.RequestServices, http.RequestAborted);

        if (snapshot?.MustChangePassword == true)
        {
            context.Result = new RedirectResult(
                "/change-password?returnUrl=" + Uri.EscapeDataString(http.Request.Path.Value ?? "/"));
        }
    }
}

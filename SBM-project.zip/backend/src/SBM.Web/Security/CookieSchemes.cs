namespace SBM.Web.Security;

/// <summary>Authentication audience identifiers. Staff and portal never share a cookie or a scheme.</summary>
public static class CookieSchemes
{
    public const string Staff = "StaffCookie";
    public const string Portal = "PortalCookie";
    public const string MfaPending = "MfaPendingCookie";
}

using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;

namespace SBM.Web.Security;

/// <summary>
/// Renders a friendly, localized-agnostic forbidden experience instead of an empty 403.
/// Authentication challenges (not signed in) still redirect to the appropriate login page.
/// </summary>
public sealed class FriendlyForbiddenResultHandler : IAuthorizationMiddlewareResultHandler
{
    public async Task HandleAsync(RequestDelegate next, HttpContext context, AuthorizationPolicy policy, PolicyAuthorizationResult authorizeResult)
    {
        if (authorizeResult.Succeeded)
        {
            await next(context);
            return;
        }

        if (authorizeResult.Forbidden)
        {
            var path = context.Request.Path.Value ?? string.Empty;
            context.Response.Redirect(path.StartsWith("/portal", StringComparison.OrdinalIgnoreCase) ? "/portal/forbidden" : "/forbidden");
            return;
        }

        // Not authenticated: challenge the scheme appropriate for the area.
        var pathValue = context.Request.Path.Value ?? string.Empty;
        var scheme = pathValue.StartsWith("/portal", StringComparison.OrdinalIgnoreCase) ? CookieSchemes.Portal : CookieSchemes.Staff;
        await context.ChallengeAsync(scheme);
    }
}

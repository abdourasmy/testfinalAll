using System.Collections.Concurrent;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using SBM.Modules.Identity.Entities;

namespace SBM.Web.Security;

/// <summary>
/// Caches (SecurityStamp, MustChangePassword, MfaEnabled) per user with a short TTL so cookie
/// validation (session revocation) and the forced-password-change filter avoid a database hit per request.
/// Revocation and lockout become effective within the TTL (default 45s).
/// </summary>
public sealed class StampValidationCache
{
    private readonly ConcurrentDictionary<Guid, (string stamp, bool mustChange, bool mfaEnabled, DateTimeOffset expiresAt)> _cache = new();
    private static readonly TimeSpan Ttl = TimeSpan.FromSeconds(45);

    public sealed record IdentitySnapshot(string SecurityStamp, bool MustChangePassword, bool MfaEnabled);

    public async Task<IdentitySnapshot?> GetAsync(Guid userId, IServiceProvider services, CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        if (_cache.TryGetValue(userId, out var entry) && entry.expiresAt > now)
            return new IdentitySnapshot(entry.stamp, entry.mustChange, entry.mfaEnabled);

        await using var scope = services.CreateAsyncScope();
        var users = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var user = await users.FindByIdAsync(userId.ToString());
        if (user is null)
        {
            _cache.TryRemove(userId, out _);
            return null;
        }

        var stamp = await users.GetSecurityStampAsync(user);
        var snapshot = new IdentitySnapshot(stamp ?? string.Empty, user.MustChangePassword, user.MfaEnabled);
        _cache[userId] = (snapshot.SecurityStamp, snapshot.MustChangePassword, snapshot.MfaEnabled, now.Add(Ttl));
        return snapshot;
    }

    /// <summary>Drop a cached entry so revocations/lockouts take effect immediately.</summary>
    public void Invalidate(Guid userId) => _cache.TryRemove(userId, out _);
}

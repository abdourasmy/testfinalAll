using System.Security.Claims;
using SBM.Shared.Abstractions;

namespace SBM.Web.Security;

/// <summary>ITenantContext for the staff cookie audience. Built only from server-issued cookie claims;
/// never from client input. Portal requests use the customer_id claim directly instead.</summary>
public sealed class CookieTenantContext : ITenantContext
{
    private readonly IHttpContextAccessor _http;
    public CookieTenantContext(IHttpContextAccessor http) => _http = http;

    public Guid? OrganizationId
    {
        get
        {
            var raw = _http.HttpContext?.User?.FindFirstValue("org_id");
            return Guid.TryParse(raw, out var id) ? id : null;
        }
    }

    public Guid? UserId
    {
        get
        {
            var raw = _http.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
            return Guid.TryParse(raw, out var id) ? id : null;
        }
    }

    public string? UserName => _http.HttpContext?.User?.Identity?.Name;

    public bool IsPlatformAdmin
    {
        get
        {
            var user = _http.HttpContext?.User;
            return user is not null
                && string.Equals(user.FindFirstValue("scope"), "platform", StringComparison.OrdinalIgnoreCase)
                && user.IsInRole("PlatformAdmin");
        }
    }

    public bool IsInOrganization(Guid organizationId) => IsPlatformAdmin || OrganizationId == organizationId;
}

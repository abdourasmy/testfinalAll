using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Licensing.Crypto;
using SBM.Modules.Licensing.Entities;

namespace SBM.Infrastructure.Persistence;

/// <summary>Development seed data only. Never contains production secrets or real customer data.</summary>
public static class DbSeeder
{
    public const string PlatformAdminRole = "PlatformAdmin";
    public const string OwnerRole = "Owner";
    public const string ManagerRole = "Manager";
    public const string MemberRole = "Member";

    public static async Task SeedAsync(SbmDbContext db, UserManager<ApplicationUser> users, RoleManager<IdentityRole<Guid>> roles, IConfiguration configuration, CancellationToken ct = default)
    {
        await EnsureRolesAsync(roles, ct);
        var ownerEmail = configuration["Seed:OwnerEmail"] ?? "owner@sbm.local";
        var ownerPassword = configuration["Seed:OwnerPassword"] ?? "ChangeMe!Dev123"; // dev-only, overridable via env
        var owner = await users.FindByEmailAsync(ownerEmail);
        if (owner is null)
        {
            owner = new ApplicationUser
            {
                UserName = ownerEmail,
                Email = ownerEmail,
                DisplayName = "Platform Owner",
                EmailConfirmed = true,
                Scope = AccountScope.Platform,
                IsPlatformOwner = true
            };
            var result = await users.CreateAsync(owner, ownerPassword);
            if (!result.Succeeded) throw new InvalidOperationException("Failed to seed owner: " + string.Join("; ", result.Errors.Select(e => e.Description)));
            await users.AddToRoleAsync(owner, PlatformAdminRole);
        }

        // Dev ES256 signing key for license tokens (regenerate per environment; production uses Key Vault).
        if (!await db.LicenseSigningKeys.AnyAsync(k => k.Status == "Active", ct))
        {
            var (pub, priv) = EcdsaLicenseSigner.GenerateKeyPair();
            db.LicenseSigningKeys.Add(new LicenseSigningKey
            {
                KeyId = "dev-" + DateTimeOffset.UtcNow.ToString("yyyyMMdd"),
                Algorithm = "ES256",
                PublicKeyPem = pub,
                PrivateKeyPem = priv,
                UseKeyVault = false,
                Status = "Active"
            });
        }

        await SeedCatalogAsync(db, ct);
        await SeedPermissionsAsync(db, roles, ct);
        await db.SaveChangesAsync(ct);
    }

    private static async Task SeedPermissionsAsync(SbmDbContext db, RoleManager<IdentityRole<Guid>> roles, CancellationToken ct)
    {
        // Upsert the full permission catalog.
        var existing = await db.Permissions.ToListAsync(ct);
        var existingCodes = existing.Select(p => p.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var code in SBM.Modules.Identity.Permissions.PermissionRegistry.All)
        {
            if (existingCodes.Contains(code)) continue;
            db.Permissions.Add(new Permission
            {
                Code = code,
                Category = SBM.Modules.Identity.Permissions.PermissionRegistry.Category(code),
                Description = code
            });
        }

        // Upsert role → permission defaults (org roles only). PlatformAdmin is implicit full access.
        var roleByName = (await roles.Roles.ToListAsync(ct)).ToDictionary(r => r.Name!, r => r.Id, StringComparer.OrdinalIgnoreCase);
        var current = await db.RolePermissions.ToListAsync(ct);
        var currentSet = current.Select(rp => (rp.RoleId, rp.PermissionCode)).ToHashSet();
        foreach (var (roleName, permissions) in SBM.Modules.Identity.Permissions.PermissionRegistry.Defaults)
        {
            if (!roleByName.TryGetValue(roleName, out var roleId)) continue;
            foreach (var permissionCode in permissions)
            {
                if (currentSet.Contains((roleId, permissionCode))) continue;
                db.RolePermissions.Add(new RolePermission { RoleId = roleId, PermissionCode = permissionCode });
            }
        }
    }

    private static async Task EnsureRolesAsync(RoleManager<IdentityRole<Guid>> roles, CancellationToken ct)
    {
        foreach (var role in new[] { PlatformAdminRole, OwnerRole, ManagerRole, MemberRole, "Cashier", "Accountant", "Technician", "Salesperson", "Support", "Finance" })
        {
            if (!await roles.RoleExistsAsync(role))
                await roles.CreateAsync(new IdentityRole<Guid>(role));
        }
    }

    private static async Task SeedCatalogAsync(SbmDbContext db, CancellationToken ct)
    {
        if (await db.Products.AnyAsync(ct)) return;
        var product = new Product
        {
            Code = "REPAIR-PRO",
            Name = "Repair Center Pro",
            Description = "Repair center management product (seed sample).",
            Category = "RepairCenter",
            Status = ProductStatus.Active
        };
        db.Products.Add(product);
        var app = new ProductApplication
        {
            ProductId = product.Id,
            Code = "repair-desktop",
            Name = "Repair Center Pro Desktop",
            Type = "Desktop",
            Platforms = new() { "Windows" },
            Status = ApplicationStatus.Active,
            ReleaseChannel = "Stable",
            CurrentVersion = "2.1.0",
            MinimumSupportedVersion = "2.0.0"
        };
        db.ProductApplications.Add(app);
        var features = new[]
        {
            new Feature { ProductId = product.Id, Code = "TICKETS.BASIC", Name = "Basic ticketing" },
            new Feature { ProductId = product.Id, Code = "INVENTORY.BASIC", Name = "Basic inventory", Dependencies = new() { "TICKETS.BASIC" } },
            new Feature { ProductId = product.Id, Code = "REPORTING.ADVANCED", Name = "Advanced reporting" },
        };
        db.Features.AddRange(features);
        var plan = new PricingPlan
        {
            ProductId = product.Id,
            Code = "PRO-MONTHLY",
            Name = "Pro Monthly",
            Interval = BillingInterval.Monthly,
            Price = 1500m,
            Currency = "EGP",
            DeviceLimit = 3,
            SessionLimit = 2,
            IsActive = true
        };
        db.PricingPlans.Add(plan);
        foreach (var f in features) db.PlanFeatures.Add(new PlanFeature { PlanId = plan.Id, FeatureId = f.Id });
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SBM.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class ProductionHardening : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_PaymentIdempotencyRecords_OrganizationId_IdempotencyKey",
                table: "PaymentIdempotencyRecords");

            migrationBuilder.AddColumn<string>(
                name: "Action",
                table: "SecurityEvents",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActorType",
                table: "SecurityEvents",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CorrelationId",
                table: "SecurityEvents",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "OrganizationId",
                table: "SecurityEvents",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Result",
                table: "SecurityEvents",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TargetId",
                table: "SecurityEvents",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TargetType",
                table: "SecurityEvents",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserAgent",
                table: "SecurityEvents",
                type: "nvarchar(512)",
                maxLength: 512,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OperationType",
                table: "PaymentIdempotencyRecords",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "payment.confirm");

            migrationBuilder.AddColumn<string>(
                name: "RequestHash",
                table: "PaymentIdempotencyRecords",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MustChangePassword",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "ApprovalRequests",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Permissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Category = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Permissions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RolePermissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PermissionCode = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RolePermissions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserPermissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PermissionCode = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    IsGranted = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserPermissions", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SecurityEvents_OrganizationId_OccurredAtUtc",
                table: "SecurityEvents",
                columns: new[] { "OrganizationId", "OccurredAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_PaymentIdempotencyRecords_OrganizationId_OperationType_IdempotencyKey",
                table: "PaymentIdempotencyRecords",
                columns: new[] { "OrganizationId", "OperationType", "IdempotencyKey" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_Code",
                table: "Permissions",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RolePermissions_RoleId_PermissionCode",
                table: "RolePermissions",
                columns: new[] { "RoleId", "PermissionCode" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserPermissions_UserId_PermissionCode",
                table: "UserPermissions",
                columns: new[] { "UserId", "PermissionCode" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Permissions");

            migrationBuilder.DropTable(
                name: "RolePermissions");

            migrationBuilder.DropTable(
                name: "UserPermissions");

            migrationBuilder.DropIndex(
                name: "IX_SecurityEvents_OrganizationId_OccurredAtUtc",
                table: "SecurityEvents");

            migrationBuilder.DropIndex(
                name: "IX_PaymentIdempotencyRecords_OrganizationId_OperationType_IdempotencyKey",
                table: "PaymentIdempotencyRecords");

            migrationBuilder.DropColumn(
                name: "Action",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "ActorType",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "CorrelationId",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "OrganizationId",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "Result",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "TargetId",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "TargetType",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "UserAgent",
                table: "SecurityEvents");

            migrationBuilder.DropColumn(
                name: "OperationType",
                table: "PaymentIdempotencyRecords");

            migrationBuilder.DropColumn(
                name: "RequestHash",
                table: "PaymentIdempotencyRecords");

            migrationBuilder.DropColumn(
                name: "MustChangePassword",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "ApprovalRequests");

            migrationBuilder.CreateIndex(
                name: "IX_PaymentIdempotencyRecords_OrganizationId_IdempotencyKey",
                table: "PaymentIdempotencyRecords",
                columns: new[] { "OrganizationId", "IdempotencyKey" },
                unique: true);
        }
    }
}

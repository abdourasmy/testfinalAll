﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SBM.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class CampaignAndAudienceOrganizationScope : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "OrganizationId",
                table: "Campaigns",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "OrganizationId",
                table: "AudienceDefinitions",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Campaigns_OrganizationId",
                table: "Campaigns",
                column: "OrganizationId");

            migrationBuilder.CreateIndex(
                name: "IX_AudienceDefinitions_OrganizationId",
                table: "AudienceDefinitions",
                column: "OrganizationId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Campaigns_OrganizationId",
                table: "Campaigns");

            migrationBuilder.DropIndex(
                name: "IX_AudienceDefinitions_OrganizationId",
                table: "AudienceDefinitions");

            migrationBuilder.DropColumn(
                name: "OrganizationId",
                table: "Campaigns");

            migrationBuilder.DropColumn(
                name: "OrganizationId",
                table: "AudienceDefinitions");
        }
    }
}

using System.Text.Json;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SBM.Shared.Abstractions;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Catalog.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Finance.Entities;
using SBM.Modules.Notifications.Entities;

namespace SBM.Infrastructure.Persistence;

/// <summary>Transactional outbox record. Dispatched by a background worker; delivery is at-least-once with idempotency keys.</summary>
public class OutboxMessage : AggregateRoot<Guid>
{
    public string Type { get; set; } = string.Empty;
    public string Payload { get; set; } = string.Empty;
    public DateTimeOffset? ProcessedAt { get; set; }
    public int Attempts { get; set; }
    public DateTimeOffset? NextAttemptAt { get; set; }
    public DateTimeOffset? DeadLetteredAt { get; set; }
    public string? LastError { get; set; }
    public string? CorrelationId { get; set; }
}

/// <summary>Platform/organization-level key-value configuration. Values are never secrets;
/// secrets belong in environment configuration / a secret store.</summary>
public class SystemSetting : AggregateRoot<Guid>
{
    public string Key { get; set; } = string.Empty;
    public string? Value { get; set; }
    public string? Description { get; set; }
    public Guid? OrganizationId { get; set; } // null = platform-wide
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class SbmDbContext : IdentityDbContext<ApplicationUser, IdentityRole<Guid>, Guid>
{
    private readonly string? _userName;
    private readonly SBM.Shared.Abstractions.ITenantContext? _tenantContext;
    private readonly bool _hasTenant;
    private readonly bool _isPlatformAdmin;
    private readonly bool _tenantOrgIdUnset;
    private readonly Guid _tenantOrgId;

    public SbmDbContext(DbContextOptions<SbmDbContext> options, SBM.Shared.Abstractions.ITenantContext? tenantContext = null)
        : base(options)
    {
        _userName = tenantContext?.UserName;
        _tenantContext = tenantContext;
        _hasTenant = tenantContext is not null;
        _isPlatformAdmin = tenantContext?.IsPlatformAdmin == true;
        _tenantOrgIdUnset = tenantContext is null || !tenantContext.OrganizationId.HasValue;
        _tenantOrgId = tenantContext?.OrganizationId ?? Guid.Empty; // safe: Guid.Empty never belongs to a real org
    }

    // Identity / Tenancy
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<OrganizationMembership> OrganizationMemberships => Set<OrganizationMembership>();
    public DbSet<Invitation> Invitations => Set<Invitation>();
    public DbSet<UserSession> UserSessions => Set<UserSession>();
    public DbSet<SecurityEvent> SecurityEvents => Set<SecurityEvent>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserPermission> UserPermissions => Set<UserPermission>();

    // Customers / CRM
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<CustomerContact> CustomerContacts => Set<CustomerContact>();
    public DbSet<CustomerNote> CustomerNotes => Set<CustomerNote>();
    public DbSet<Lead> Leads => Set<Lead>();
    public DbSet<Opportunity> Opportunities => Set<Opportunity>();

    // Catalog
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductApplication> ProductApplications => Set<ProductApplication>();
    public DbSet<Feature> Features => Set<Feature>();
    public DbSet<PricingPlan> PricingPlans => Set<PricingPlan>();
    public DbSet<PlanFeature> PlanFeatures => Set<PlanFeature>();

    // Licensing
    public DbSet<License> Licenses => Set<License>();
    public DbSet<LicenseDevice> LicenseDevices => Set<LicenseDevice>();
    public DbSet<LicenseSession> LicenseSessions => Set<LicenseSession>();
    public DbSet<LicenseEvent> LicenseEvents => Set<LicenseEvent>();
    public DbSet<LicenseSigningKey> LicenseSigningKeys => Set<LicenseSigningKey>();

    // Subscriptions
    public DbSet<Subscription> Subscriptions => Set<Subscription>();
    public DbSet<SubscriptionEvent> SubscriptionEvents => Set<SubscriptionEvent>();
    public DbSet<AddOn> AddOns => Set<AddOn>();
    public DbSet<SubscriptionAddOn> SubscriptionAddOns => Set<SubscriptionAddOn>();

    // Billing
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<InvoiceItem> InvoiceItems => Set<InvoiceItem>();
    public DbSet<InvoiceSequence> InvoiceSequences => Set<InvoiceSequence>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<PaymentIdempotencyRecord> PaymentIdempotencyRecords => Set<PaymentIdempotencyRecord>();
    public DbSet<Refund> Refunds => Set<Refund>();

    // Finance
    public DbSet<FinanceEntry> FinanceEntries => Set<FinanceEntry>();
    public DbSet<FinanceAccount> FinanceAccounts => Set<FinanceAccount>();

    // Notifications
    public DbSet<NotificationTemplate> NotificationTemplates => Set<NotificationTemplate>();
    public DbSet<AudienceDefinition> AudienceDefinitions => Set<AudienceDefinition>();
    public DbSet<AudienceSnapshot> AudienceSnapshots => Set<AudienceSnapshot>();
    public DbSet<Campaign> Campaigns => Set<Campaign>();
    public DbSet<CampaignRecipient> CampaignRecipients => Set<CampaignRecipient>();
    public DbSet<DeliveryAttempt> DeliveryAttempts => Set<DeliveryAttempt>();
    public DbSet<NotificationPreference> NotificationPreferences => Set<NotificationPreference>();

    public DbSet<SystemSetting> SystemSettings => Set<SystemSetting>();

    // Sales / resellers
    public DbSet<SBM.Modules.Billing.Entities.Quotation> Quotations => Set<SBM.Modules.Billing.Entities.Quotation>();
    public DbSet<SBM.Modules.Billing.Entities.QuotationLine> QuotationLines => Set<SBM.Modules.Billing.Entities.QuotationLine>();
    public DbSet<SBM.Modules.Billing.Entities.SalesOrder> SalesOrders => Set<SBM.Modules.Billing.Entities.SalesOrder>();
    public DbSet<SBM.Modules.Billing.Entities.SalesOrderLine> SalesOrderLines => Set<SBM.Modules.Billing.Entities.SalesOrderLine>();
    public DbSet<SBM.Modules.Billing.Entities.SalesEvent> SalesEvents => Set<SBM.Modules.Billing.Entities.SalesEvent>();
    public DbSet<SBM.Modules.Billing.Entities.Reseller> Resellers => Set<SBM.Modules.Billing.Entities.Reseller>();
    public DbSet<SBM.Modules.Billing.Entities.ResellerCommission> ResellerCommissions => Set<SBM.Modules.Billing.Entities.ResellerCommission>();

    // Approvals / releases
    public DbSet<SBM.Modules.Subscriptions.Entities.ApprovalRequest> ApprovalRequests => Set<SBM.Modules.Subscriptions.Entities.ApprovalRequest>();
    public DbSet<SBM.Modules.Catalog.Entities.SoftwareRelease> SoftwareReleases => Set<SBM.Modules.Catalog.Entities.SoftwareRelease>();
    public DbSet<SBM.Modules.Catalog.Entities.ReleaseAsset> ReleaseAssets => Set<SBM.Modules.Catalog.Entities.ReleaseAsset>();

    // Infrastructure
    public DbSet<OutboxMessage> OutboxMessages => Set<OutboxMessage>();
    public DbSet<SBM.Modules.Support.Entities.SupportTicket> SupportTickets => Set<SBM.Modules.Support.Entities.SupportTicket>();
    public DbSet<SBM.Modules.Support.Entities.TicketComment> TicketComments => Set<SBM.Modules.Support.Entities.TicketComment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<ApplicationUser>(e =>
        {
            e.HasIndex(u => u.NormalizedEmail).IsUnique(false);
            e.Property(u => u.DisplayName).HasMaxLength(200);
        });

        // ---- Permissions ----
        b.Entity<Permission>(e =>
        {
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.Description).HasMaxLength(256);
            e.Property(x => x.Category).HasMaxLength(64);
        });
        b.Entity<RolePermission>(e =>
        {
            e.HasIndex(x => new { x.RoleId, x.PermissionCode }).IsUnique();
            e.Property(x => x.PermissionCode).HasMaxLength(64).IsRequired();
        });
        b.Entity<UserPermission>(e =>
        {
            e.HasIndex(x => new { x.UserId, x.PermissionCode }).IsUnique();
            e.Property(x => x.PermissionCode).HasMaxLength(64).IsRequired();
        });

        // ---- Tenancy ----
        b.Entity<Organization>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.Status).HasMaxLength(20);
            e.Property(x => x.TimezoneId).HasMaxLength(64);
            e.HasIndex(x => x.Name);
        });
        b.Entity<Branch>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.HasIndex(x => new { x.OrganizationId, x.Code }).IsUnique().HasFilter("[Code] IS NOT NULL");
        });
        b.Entity<OrganizationMembership>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.UserId }).IsUnique();
            e.Property(x => x.Role).HasMaxLength(50);
        });
        b.Entity<Invitation>(e =>
        {
            e.Property(x => x.Email).HasMaxLength(256).IsRequired();
            e.Property(x => x.TokenHash).HasMaxLength(200);
            e.HasIndex(x => new { x.OrganizationId, x.Status });
        });
        b.Entity<UserSession>(e =>
        {
            e.Property(x => x.RefreshTokenHash).HasMaxLength(200);
            e.HasIndex(x => x.UserId);
            e.HasIndex(x => x.RefreshTokenHash).IsUnique();
        });
        b.Entity<SecurityEvent>(e =>
        {
            e.HasIndex(x => new { x.UserId, x.OccurredAtUtc });
            e.HasIndex(x => new { x.OrganizationId, x.OccurredAtUtc });
            e.Property(x => x.Action).HasMaxLength(128);
            e.Property(x => x.ActorType).HasMaxLength(32);
            e.Property(x => x.TargetType).HasMaxLength(64);
            e.Property(x => x.TargetId).HasMaxLength(64);
            e.Property(x => x.Result).HasMaxLength(32);
            e.Property(x => x.CorrelationId).HasMaxLength(64);
            e.Property(x => x.UserAgent).HasMaxLength(512);
        });

        // ---- Customers ----
        b.Entity<Customer>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(300).IsRequired();
            e.HasIndex(x => new { x.OrganizationId, x.Name });
            e.HasIndex(x => new { x.OrganizationId, x.Status });
        });
        b.Entity<CustomerContact>(e => e.Property(x => x.Name).HasMaxLength(200).IsRequired());
        b.Entity<CustomerNote>(e => e.Property(x => x.Body).HasMaxLength(4000).IsRequired());
        b.Entity<Lead>(e => e.Property(x => x.Name).HasMaxLength(200).IsRequired());
        b.Entity<Opportunity>(e =>
        {
            e.Property(x => x.Title).HasMaxLength(300).IsRequired();
            e.Property(x => x.ExpectedValue).HasPrecision(18, 2);
            e.Property(x => x.Currency).HasMaxLength(3);
        });

        // ---- Catalog ----
        b.Entity<Product>(e =>
        {
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
        });
        b.Entity<ProductApplication>(e =>
        {
            e.HasIndex(x => new { x.ProductId, x.Code }).IsUnique();
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.Platforms).HasMaxLength(400); // primitive collection -> JSON
            e.Property(x => x.ReleaseChannel).HasMaxLength(32);
        });
        b.Entity<Feature>(e =>
        {
            e.HasIndex(x => new { x.ProductId, x.Code }).IsUnique();
            e.Property(x => x.Code).HasMaxLength(128).IsRequired();
            e.Property(x => x.Dependencies).HasMaxLength(2000);
        });
        b.Entity<PricingPlan>(e =>
        {
            e.HasIndex(x => new { x.ProductId, x.Code }).IsUnique();
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.Price).HasPrecision(18, 2);
            e.Property(x => x.Currency).HasMaxLength(3);
        });
        b.Entity<PlanFeature>(e => e.HasIndex(x => new { x.PlanId, x.FeatureId }).IsUnique());

        // ---- Licensing ----
        b.Entity<License>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.State });
            e.HasIndex(x => x.SubscriptionId);
            e.Property(x => x.RevocationReason).HasMaxLength(500);
        });
        b.Entity<LicenseDevice>(e =>
        {
            e.HasIndex(x => new { x.LicenseId, x.DeviceId }).IsUnique();
            e.Property(x => x.DeviceId).HasMaxLength(256).IsRequired();
            e.Property(x => x.DeviceName).HasMaxLength(200);
            e.Property(x => x.Platform).HasMaxLength(32);
        });
        b.Entity<LicenseSession>(e =>
        {
            e.HasIndex(x => x.SessionId).IsUnique();
            e.HasIndex(x => new { x.LicenseId, x.RevokedAt });
        });
        b.Entity<LicenseEvent>(e => e.HasIndex(x => new { x.LicenseId, x.OccurredAtUtc }));
        b.Entity<LicenseSigningKey>(e => e.HasIndex(x => x.KeyId).IsUnique());

        // ---- Subscriptions ----
        b.Entity<Subscription>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Status });
            e.HasIndex(x => x.CurrentPeriodEnd);
        });
        b.Entity<SubscriptionEvent>(e => e.HasIndex(x => new { x.SubscriptionId, x.OccurredAtUtc }));
        b.Entity<AddOn>(e => { e.HasIndex(x => new { x.ProductId, x.Code }).IsUnique(); e.Property(x => x.Price).HasPrecision(18, 2); });
        b.Entity<SubscriptionAddOn>(e =>
        {
            e.HasIndex(x => new { x.SubscriptionId, x.AddOnId }).IsUnique();
            e.Property(x => x.PriceAtPurchase).HasPrecision(18, 2);
        });

        // ---- Billing ----
        b.Entity<Invoice>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Number }).IsUnique(); // final backstop for numbering uniqueness
            e.Property(x => x.Number).HasMaxLength(64).IsRequired();
            e.Property(x => x.SubTotal).HasPrecision(18, 2);
            e.Property(x => x.DiscountTotal).HasPrecision(18, 2);
            e.Property(x => x.TaxTotal).HasPrecision(18, 2);
            e.Property(x => x.GrandTotal).HasPrecision(18, 2);
            e.Property(x => x.AmountPaid).HasPrecision(18, 2);
            e.Property(x => x.Currency).HasMaxLength(3);
        });
        b.Entity<InvoiceItem>(e =>
        {
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.DiscountPercent).HasPrecision(5, 2);
            e.Property(x => x.TaxPercent).HasPrecision(5, 2);
        });
        b.Entity<InvoiceSequence>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Prefix, x.FinancialYear }).IsUnique();
            e.Property(x => x.Prefix).HasMaxLength(16);
            e.Property(x => x.FinancialYear).HasMaxLength(8);
        });
        b.Entity<Payment>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.InvoiceId });
            e.HasIndex(x => x.IdempotencyKey).IsUnique().HasFilter("[IdempotencyKey] IS NOT NULL");
            e.Property(x => x.Amount).HasPrecision(18, 2);
            e.Property(x => x.Currency).HasMaxLength(3);
        });
        b.Entity<PaymentIdempotencyRecord>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.OperationType, x.IdempotencyKey }).IsUnique();
            e.Property(x => x.IdempotencyKey).HasMaxLength(128).IsRequired();
            e.Property(x => x.OperationType).HasMaxLength(64).HasDefaultValue("payment.confirm");
            e.Property(x => x.RequestHash).HasMaxLength(64);
        });
        b.Entity<Refund>(e =>
        {
            e.HasIndex(x => x.PaymentId);
            e.Property(x => x.Amount).HasPrecision(18, 2);
            e.Property(x => x.Reason).HasMaxLength(1000);
        });

        // ---- Finance ----
        b.Entity<FinanceEntry>(e =>
        {
            e.Property(x => x.Amount).HasPrecision(18, 2);
            e.Property(x => x.Category).HasMaxLength(100);
            e.Property(x => x.Currency).HasMaxLength(3);
            e.HasIndex(x => new { x.OrganizationId, x.OccurredAt });
            e.HasIndex(x => x.ExternalRef).IsUnique().HasFilter("[ExternalRef] IS NOT NULL");
        });
        b.Entity<FinanceAccount>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.OpeningBalance).HasPrecision(18, 2);
            e.Property(x => x.Currency).HasMaxLength(3);
        });

        // ---- Notifications ----
        b.Entity<NotificationTemplate>(e =>
        {
            e.HasIndex(x => new { x.Code, x.Language, x.Channel }).IsUnique();
            e.Property(x => x.Code).HasMaxLength(128).IsRequired();
        });
        b.Entity<AudienceDefinition>(e => { e.Property(x => x.Name).HasMaxLength(200).IsRequired(); e.HasIndex(x => x.OrganizationId); });
        b.Entity<AudienceSnapshot>(e => e.HasIndex(x => x.CampaignId));
        b.Entity<Campaign>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.HasIndex(x => x.IdempotencyKey).IsUnique().HasFilter("[IdempotencyKey] IS NOT NULL");
            e.HasIndex(x => x.Status);
            e.HasIndex(x => x.OrganizationId);
        });
        b.Entity<CampaignRecipient>(e =>
        {
            e.HasIndex(x => new { x.CampaignId, x.RecipientKey }).IsUnique(); // no duplicate deliveries per campaign
            e.HasIndex(x => new { x.CampaignId, x.Status });
            e.Property(x => x.RecipientKey).HasMaxLength(400).IsRequired();
            e.Property(x => x.Endpoint).HasMaxLength(512);
        });
        b.Entity<DeliveryAttempt>(e => e.HasIndex(x => x.CampaignRecipientId));
        b.Entity<NotificationPreference>(e => e.HasIndex(x => new { x.UserId, x.OrganizationId, x.Channel }));

        // ---- Sales / resellers ----
        b.Entity<SBM.Modules.Billing.Entities.Quotation>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Number }).IsUnique();
            e.HasIndex(x => new { x.OrganizationId, x.Status });
            e.Property(x => x.Number).HasMaxLength(64).IsRequired();
            e.Property(x => x.Notes).HasMaxLength(4000);
            e.Property(x => x.SubTotal).HasPrecision(18, 2);
            e.Property(x => x.DiscountTotal).HasPrecision(18, 2);
            e.Property(x => x.TaxTotal).HasPrecision(18, 2);
            e.Property(x => x.GrandTotal).HasPrecision(18, 2);
        });
        b.Entity<SBM.Modules.Billing.Entities.QuotationLine>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.QuotationId });
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.DiscountPercent).HasPrecision(5, 2);
            e.Property(x => x.TaxPercent).HasPrecision(5, 2);
        });
        b.Entity<SBM.Modules.Billing.Entities.SalesOrder>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Number }).IsUnique();
            e.HasIndex(x => new { x.OrganizationId, x.Status });
            e.Property(x => x.Number).HasMaxLength(64).IsRequired();
            e.Property(x => x.SubTotal).HasPrecision(18, 2);
            e.Property(x => x.DiscountTotal).HasPrecision(18, 2);
            e.Property(x => x.TaxTotal).HasPrecision(18, 2);
            e.Property(x => x.GrandTotal).HasPrecision(18, 2);
        });
        b.Entity<SBM.Modules.Billing.Entities.SalesOrderLine>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.SalesOrderId });
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.DiscountPercent).HasPrecision(5, 2);
            e.Property(x => x.TaxPercent).HasPrecision(5, 2);
        });
        b.Entity<SBM.Modules.Billing.Entities.SalesEvent>(e => e.HasIndex(x => new { x.OrganizationId, x.EntityType, x.EntityId }));
        b.Entity<SBM.Modules.Billing.Entities.Reseller>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.CommissionPercent).HasPrecision(5, 2);
        });
        b.Entity<SBM.Modules.Billing.Entities.ResellerCommission>(e =>
        {
            e.HasIndex(x => new { x.ResellerId, x.InvoiceId }).IsUnique();
            e.Property(x => x.InvoiceAmount).HasPrecision(18, 2);
            e.Property(x => x.CommissionAmount).HasPrecision(18, 2);
            e.Property(x => x.Period).HasMaxLength(8);
        });

        // ---- Approvals / releases / settings ----
        b.Entity<SBM.Modules.Subscriptions.Entities.ApprovalRequest>(e =>
        {
            e.HasIndex(x => new { x.OrganizationId, x.Status });
            e.HasIndex(x => new { x.SubscriptionId, x.Status });
            e.Property(x => x.Reason).HasMaxLength(1000);
            e.Property(x => x.DecisionNote).HasMaxLength(1000);
        });
        b.Entity<SBM.Modules.Catalog.Entities.SoftwareRelease>(e =>
        {
            e.HasIndex(x => new { x.ProductCode, x.ApplicationCode, x.Version }).IsUnique();
            e.HasIndex(x => new { x.Status, x.Channel });
            e.Property(x => x.ProductCode).HasMaxLength(64).IsRequired();
            e.Property(x => x.ApplicationCode).HasMaxLength(64).IsRequired();
            e.Property(x => x.Version).HasMaxLength(32).IsRequired();
            e.Property(x => x.Channel).HasMaxLength(32);
        });
        b.Entity<SBM.Modules.Catalog.Entities.ReleaseAsset>(e =>
        {
            e.HasIndex(x => x.ReleaseId);
            e.Property(x => x.FileName).HasMaxLength(256).IsRequired();
            e.Property(x => x.Sha256).HasMaxLength(64).IsRequired();
            e.Property(x => x.StoragePath).HasMaxLength(1024).IsRequired();
        });
        b.Entity<SystemSetting>(e =>
        {
            e.HasIndex(x => x.Key).IsUnique().HasFilter("[OrganizationId] IS NULL");
            e.HasIndex(x => new { x.OrganizationId, x.Key }).IsUnique().HasFilter("[OrganizationId] IS NOT NULL");
            e.Property(x => x.Key).HasMaxLength(128).IsRequired();
            e.Property(x => x.Value).HasMaxLength(4000);
        });

        b.Entity<OutboxMessage>(e =>
        {
            e.HasIndex(x => new { x.ProcessedAt, x.NextAttemptAt });
            e.Property(x => x.Type).HasMaxLength(300).IsRequired();
        });

        // ---- Support ----
        b.Entity<SBM.Modules.Support.Entities.SupportTicket>(e =>
        {
            e.Property(x => x.Subject).HasMaxLength(300).IsRequired();
            e.Property(x => x.Description).HasMaxLength(4000).IsRequired();
            e.HasIndex(x => new { x.OrganizationId, x.Status });
            e.HasIndex(x => x.SlaDueAt);
        });
        b.Entity<SBM.Modules.Support.Entities.TicketComment>(e =>
        {
            e.Property(x => x.Body).HasMaxLength(4000).IsRequired();
            e.HasIndex(x => new { x.TicketId, x.CreatedAt });
        });

        ApplyTenantQueryFilters(b);

        // NOTE: tenant isolation is enforced BOTH explicitly at every service/controller query boundary
        // AND (defense-in-depth) by EF Core global query filters below. Background workers without an
        // HTTP context are unaffected (tenant == null → unfiltered). See ADR 0003.
    }

    /// <summary>
    /// Defense-in-depth EF Core global query filters for IOrganizationScoped entities.
    /// Semantics: when there is no tenant (background workers, startup seeding) OR the caller is a
    /// platform administrator, the filter is a no-op; organization callers only see their own rows.
    /// </summary>
    private void ApplyTenantQueryFilters(ModelBuilder b)
    {
        foreach (var entityType in b.Model.GetEntityTypes())
        {
            var clrType = entityType.ClrType;
            if (!typeof(IOrganizationScoped).IsAssignableFrom(clrType)) continue;
            if (clrType == typeof(Organization)) continue; // the tenant root is not filtered

            var orgIdProperty = clrType.GetProperty("OrganizationId");
            if (orgIdProperty is null) continue;

            var parameter = System.Linq.Expressions.Expression.Parameter(clrType, "e");
            var orgIdAccess = System.Linq.Expressions.Expression.Property(parameter, orgIdProperty);

            // Scalar fields of THIS context; evaluated per query by EF (no member access on tenant -> null-safe).
            var ctxType = typeof(SbmDbContext);
            var bindingFlags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
            var constantThis = System.Linq.Expressions.Expression.Constant(this, ctxType);
            var tenantField = (string name) => System.Linq.Expressions.Expression.Field(constantThis, ctxType.GetField(name, bindingFlags)!);

            // e => !hasTenant || isPlatformAdmin || orgIdUnset || e.OrganizationId == tenantOrgId (Guid == Guid)
            var noTenant = System.Linq.Expressions.Expression.Not(tenantField("_hasTenant"));
            var platformAdmin = tenantField("_isPlatformAdmin");
            var orgIdUnset = tenantField("_tenantOrgIdUnset");
            var orgId = tenantField("_tenantOrgId");
            var orgIdMatch = System.Linq.Expressions.Expression.Equal(orgIdAccess, orgId);
            var body = System.Linq.Expressions.Expression.OrElse(noTenant,
                System.Linq.Expressions.Expression.OrElse(platformAdmin,
                    System.Linq.Expressions.Expression.OrElse(orgIdUnset, orgIdMatch)));

            var lambda = System.Linq.Expressions.Expression.Lambda(body, parameter);
            entityType.SetQueryFilter(lambda);
        }
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        // Transactional outbox: serialize domain events into outbox rows in the same transaction.
        var aggregatesWithEvents = ChangeTracker.Entries<AggregateRoot<Guid>>()
            .Where(e => e.Entity.DomainEvents.Count > 0)
            .ToList();
        foreach (var entry in aggregatesWithEvents)
        {
            foreach (var domainEvent in entry.Entity.DomainEvents)
            {
                OutboxMessages.Add(new OutboxMessage
                {
                    Type = domainEvent.EventType,
                    Payload = JsonSerializer.Serialize(domainEvent, domainEvent.GetType())
                });
            }
            entry.Entity.ClearDomainEvents();
        }

        foreach (var entry in ChangeTracker.Entries<AggregateRoot<Guid>>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAt = DateTimeOffset.UtcNow;
                entry.Entity.CreatedBy ??= _userName;
            }
        }
        return await base.SaveChangesAsync(cancellationToken);
    }
}

using Microsoft.EntityFrameworkCore;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Subscriptions.Entities;

namespace SBM.Infrastructure.Services;

public sealed record PaymentConfirmation(
    Guid OrganizationId,
    Guid InvoiceId,
    decimal Amount,
    string Currency,
    string Method,
    string? ProviderReference,
    string IdempotencyKey,
    bool ConfirmedByProvider);

public sealed record PaymentOutcome(Guid PaymentId, string Outcome, bool Duplicate);

/// <summary>
/// Payment processing with idempotency. A confirmation is only recorded after trusted
/// server-side provider confirmation (or an explicit manual confirmation by authorized staff).
/// Client-side "success" callbacks alone never mark an invoice paid.
/// </summary>
public class PaymentService
{
    private readonly Persistence.SbmDbContext _db;

    public PaymentService(Persistence.SbmDbContext db) => _db = db;

    public async Task<PaymentOutcome> ProcessConfirmationAsync(PaymentConfirmation confirmation, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(confirmation.IdempotencyKey))
            throw new ArgumentException("IdempotencyKey is required.", nameof(confirmation));

        // Fast path: already processed.
        var existing = await _db.PaymentIdempotencyRecords
            .FirstOrDefaultAsync(r => r.OrganizationId == confirmation.OrganizationId && r.IdempotencyKey == confirmation.IdempotencyKey, ct);
        if (existing is not null)
            return new PaymentOutcome(existing.PaymentId ?? Guid.Empty, existing.Outcome, Duplicate: true);

        var invoice = await _db.Invoices
            .FirstOrDefaultAsync(i => i.Id == confirmation.InvoiceId && i.OrganizationId == confirmation.OrganizationId, ct);
        if (invoice is null) throw new KeyNotFoundException("Invoice not found.");
        if (confirmation.Amount <= 0) throw new ArgumentOutOfRangeException(nameof(confirmation), "Payment amount must be positive.");

        var payment = new Payment
        {
            OrganizationId = confirmation.OrganizationId,
            InvoiceId = invoice.Id,
            Amount = confirmation.Amount,
            Currency = confirmation.Currency,
            Method = confirmation.Method,
            ProviderReference = confirmation.ProviderReference,
            IdempotencyKey = confirmation.IdempotencyKey,
            Status = confirmation.ConfirmedByProvider ? PaymentStatus.Confirmed : PaymentStatus.Pending,
            ConfirmedAt = confirmation.ConfirmedByProvider ? DateTimeOffset.UtcNow : null
        };
        _db.Payments.Add(payment);
        _db.PaymentIdempotencyRecords.Add(new PaymentIdempotencyRecord
        {
            OrganizationId = confirmation.OrganizationId,
            IdempotencyKey = confirmation.IdempotencyKey,
            PaymentId = payment.Id,
            Outcome = confirmation.ConfirmedByProvider ? "processed" : "recorded-unconfirmed"
        });

        if (payment.Status == PaymentStatus.Confirmed)
        {
            ApplyToInvoice(invoice, payment.Amount);
            await TryRestoreEntitlementsForInvoiceAsync(invoice, ct);
        }

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException)
        {
            // Unique constraint on IdempotencyKey hit by a concurrent request: report duplicate.
            var winner = await _db.PaymentIdempotencyRecords
                .FirstAsync(r => r.OrganizationId == confirmation.OrganizationId && r.IdempotencyKey == confirmation.IdempotencyKey, ct);
            return new PaymentOutcome(winner.PaymentId ?? Guid.Empty, winner.Outcome, Duplicate: true);
        }

        return new PaymentOutcome(payment.Id, payment.Status == PaymentStatus.Confirmed ? "processed" : "recorded-unconfirmed", Duplicate: false);
    }

    private static void ApplyToInvoice(Invoice invoice, decimal amount)
    {
        invoice.AmountPaid = decimal.Round(invoice.AmountPaid + amount, 2, MidpointRounding.AwayFromZero);
        invoice.Status = invoice.AmountPaid >= invoice.GrandTotal
            ? InvoiceStatus.Paid
            : invoice.AmountPaid > 0 ? InvoiceStatus.PartiallyPaid : invoice.Status;
        if (invoice.Status == InvoiceStatus.Paid) invoice.PaidAt = DateTimeOffset.UtcNow;
    }

    /// <summary>Confirmed payment restores applicable entitlements (subscription reactivation path).</summary>
    private async Task TryRestoreEntitlementsForInvoiceAsync(Invoice invoice, CancellationToken ct)
    {
        var subscription = await _db.Subscriptions
            .Where(s => s.OrganizationId == invoice.OrganizationId && s.CustomerId == invoice.CustomerId)
            .OrderByDescending(s => s.CurrentPeriodEnd)
            .FirstOrDefaultAsync(ct);
        if (subscription is null) return;
        if (subscription.Status is SubscriptionStatus.GracePeriod or SubscriptionStatus.PastDue or SubscriptionStatus.Suspended)
        {
            SBM.Modules.Subscriptions.Domain.SubscriptionStateMachine.EnsureTransition(subscription.Status, SubscriptionStatus.Active);
            subscription.Status = SubscriptionStatus.Active;
            subscription.Access = AccessMode.Full;
            subscription.SuspendedAt = null;
            _db.SubscriptionEvents.Add(new SubscriptionEvent
            {
                OrganizationId = subscription.OrganizationId,
                SubscriptionId = subscription.Id,
                EventType = "reactivated",
                Details = $"Payment confirmed for invoice {invoice.Number}."
            });
        }
    }
}

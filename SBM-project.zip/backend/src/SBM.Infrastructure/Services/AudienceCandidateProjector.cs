using Microsoft.EntityFrameworkCore;
using SBM.Modules.Customers.Entities;
using SBM.Modules.Licensing.Entities;
using SBM.Modules.Subscriptions.Entities;
using SBM.Modules.Billing.Entities;
using SBM.Modules.Notifications.Audience;

namespace SBM.Infrastructure.Services;

/// <summary>
/// Projects database rows into audience candidates. Preview and dispatch use this with a hard cap.
/// NOTE: For very large tenants this should be replaced by a batched, parameterized SQL projection
/// implementing the same validated rule tree; the cap keeps preview responsive meanwhile.
/// </summary>
public class AudienceCandidateProjector
{
    public const int PreviewCap = 500;
    public const int DispatchCap = 50_000;

    private readonly Persistence.SbmDbContext _db;

    public AudienceCandidateProjector(Persistence.SbmDbContext db) => _db = db;

    public async Task<List<AudienceCandidate>> ProjectAsync(Guid? organizationId, int cap, CancellationToken ct = default)
    {
        var customersQuery = _db.Customers.AsNoTracking().AsQueryable();
        if (organizationId.HasValue) customersQuery = customersQuery.Where(c => c.OrganizationId == organizationId);
        var customers = await customersQuery.OrderBy(c => c.Id).Take(cap).ToListAsync(ct);

        var orgsQuery = _db.Organizations.AsNoTracking().AsQueryable();
        if (organizationId.HasValue) orgsQuery = orgsQuery.Where(o => o.Id == organizationId);
        var orgs = await orgsQuery.ToListAsync(ct);
        var branchQuery = _db.Branches.AsNoTracking().AsQueryable();
        if (organizationId.HasValue) branchQuery = branchQuery.Where(b => b.OrganizationId == organizationId);
        var branchCounts = await branchQuery
            .GroupBy(b => b.OrganizationId).Select(g => new { OrgId = g.Key, Count = g.Count() }).ToListAsync(ct);
        var branchCountMap = branchCounts.ToDictionary(x => x.OrgId, x => x.Count);

        var customerIds = customers.Select(c => c.Id).ToList();
        var subscriptions = await _db.Subscriptions.AsNoTracking()
            .Where(s => customerIds.Contains(s.CustomerId)).ToListAsync(ct);
        var licenses = await _db.Licenses.AsNoTracking()
            .Where(l => customerIds.Contains(l.CustomerId)).ToListAsync(ct);
        var licenseIds = licenses.Select(l => l.Id).ToList();
        var devices = await _db.LicenseDevices.AsNoTracking()
            .Where(d => licenseIds.Contains(d.LicenseId) && d.DeactivatedAt == null).ToListAsync(ct);
        var invoices = await _db.Invoices.AsNoTracking()
            .Where(i => customerIds.Contains(i.CustomerId) && i.Status == InvoiceStatus.Paid).ToListAsync(ct);
        var planIds = subscriptions.Select(s => s.PlanId).Distinct().ToList();
        var plans = await _db.PricingPlans.AsNoTracking().Where(p => planIds.Contains(p.Id)).ToListAsync(ct);
        var planMap = plans.ToDictionary(p => p.Id, p => p.Code);

        var candidates = new List<AudienceCandidate>(customers.Count);
        foreach (var c in customers)
        {
            var org = orgs.FirstOrDefault(o => o.Id == c.OrganizationId);
            var sub = subscriptions.Where(s => s.CustomerId == c.Id).OrderByDescending(s => s.CurrentPeriodEnd).FirstOrDefault();
            var lic = licenses.Where(l => l.CustomerId == c.Id).OrderByDescending(l => l.IssuedAt).FirstOrDefault();
            var dev = devices.Where(d => lic is not null && d.LicenseId == lic.Id).OrderByDescending(d => d.LastSeenAt).FirstOrDefault();
            var activationCount = lic is null ? 0 : devices.Count(d => d.LicenseId == lic.Id);
            var lastPurchase = invoices.Where(i => i.CustomerId == c.Id).Select(i => i.PaidAt).Max();

            candidates.Add(new AudienceCandidate
            {
                EntityId = c.Id,
                CustomerId = c.Id,
                CustomerType = c.Type.ToString(),
                CustomerStatus = c.Status.ToString(),
                CustomerRegisteredAt = c.RegisteredAt,
                CustomerCountry = c.Country,
                CustomerCity = c.City,
                CustomerTags = (c.Tags ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList(),
                CustomerClassification = c.Classification,
                OrganizationId = c.OrganizationId,
                OrganizationStatus = org?.Status,
                OrganizationBranchCount = branchCountMap.GetValueOrDefault(c.OrganizationId, 0),
                OrganizationRegisteredAt = org?.RegisteredAt,
                ProductId = lic?.ProductId,
                ApplicationId = lic?.ApplicationId,
                Platform = dev?.Platform,
                AppVersion = dev?.LastKnownAppVersion,
                SubscriptionStatus = sub?.Status.ToString(),
                SubscriptionExpiration = sub?.CurrentPeriodEnd,
                PlanCode = sub is null ? null : planMap.GetValueOrDefault(sub.PlanId),
                LicenseState = lic?.State.ToString(),
                LicenseType = lic?.Type.ToString(),
                DeviceLimit = lic?.DeviceLimit,
                ActivationCount = activationCount,
                DeviceType = dev?.DeviceType,
                DevicePlatform = dev?.Platform,
                DeviceActivatedAt = dev?.ActivatedAt,
                LastActivityAt = dev?.LastSeenAt,
                LastSyncAt = dev?.LastSyncAt,
                LastPurchaseAt = lastPurchase
            });
        }
        return candidates;
    }
}

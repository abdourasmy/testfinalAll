using Microsoft.Extensions.Logging;
using SBM.Modules.Notifications.Delivery;

namespace SBM.Infrastructure.Services;

/// <summary>
/// Development provider that logs instead of sending. Real FCM/SMTP/WebPush adapters are wired
/// via configuration when credentials are available (see docs/deployment). Never reports Delivered.
/// </summary>
public sealed class LoggingNotificationProvider : INotificationProvider
{
    private readonly ILogger<LoggingNotificationProvider> _logger;

    public LoggingNotificationProvider(ILogger<LoggingNotificationProvider> logger) => _logger = logger;

    public string Channel => "InApp";

    public Task<ProviderSendResult> SendAsync(string endpoint, string subject, string body, CancellationToken ct = default)
    {
        _logger.LogInformation("DEV-NOTIFICATION to={Endpoint} subject={Subject} bodyLength={BodyLength}", endpoint, subject, body?.Length ?? 0);
        return Task.FromResult(new ProviderSendResult(true, "dev-" + Guid.NewGuid().ToString("N"), null, 200, "accepted-by-dev-provider"));
    }
}

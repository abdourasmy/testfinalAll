using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Notifications.Audience;
using SBM.Modules.Notifications.Delivery;
using SBM.Modules.Notifications.Entities;

namespace SBM.Infrastructure.Services;

public sealed record LaunchResult(bool Success, string? Error, int Planned, int Suppressed, int Duplicates, Guid? CampaignId);

/// <summary>
/// Materializes a campaign's recipients, applying dedup (recipient semantics), opt-out,
/// quiet hours and frequency caps, then writes one transactional-outbox message per recipient.
/// ProviderAccepted is never treated as Delivered downstream.
/// </summary>
public class CampaignLaunchService
{
    private readonly Persistence.SbmDbContext _db;
    private readonly AudienceCandidateProjector _projector;

    public CampaignLaunchService(Persistence.SbmDbContext db, AudienceCandidateProjector projector)
    {
        _db = db;
        _projector = projector;
    }

    public async Task<LaunchResult> LaunchAsync(Guid campaignId, CancellationToken ct = default)
    {
        var campaign = await _db.Campaigns.FirstOrDefaultAsync(c => c.Id == campaignId, ct);
        if (campaign is null) return new(false, "campaign-not-found", 0, 0, 0, null);
        if (campaign.Status is not (CampaignStatus.Draft or CampaignStatus.Scheduled))
            return new(false, $"campaign-{campaign.Status.ToString().ToLowerInvariant()}", 0, 0, 0, campaign.Id);

        var definition = await _db.AudienceDefinitions.FirstOrDefaultAsync(a => a.Id == campaign.AudienceDefinitionId, ct);
        if (definition is null) return new(false, "audience-definition-not-found", 0, 0, 0, campaign.Id);
        if (definition.OrganizationId is { } defOrg && defOrg != campaign.OrganizationId)
            return new(false, "audience-definition-forbidden", 0, 0, 0, campaign.Id);

        AudienceDocument doc;
        try { doc = JsonSerializer.Deserialize<AudienceDocument>(definition.DocumentJson)!; }
        catch (JsonException) { return new(false, "audience-document-invalid", 0, 0, 0, campaign.Id); }
        AudienceValidator.Validate(doc);

        var strategy = _db.Database.CreateExecutionStrategy();
        return await strategy.ExecuteAsync(() => LaunchInternalAsync(campaign, definition, doc, ct));
    }

    private async Task<LaunchResult> LaunchInternalAsync(Campaign campaign, AudienceDefinition definition, AudienceDocument doc, CancellationToken ct)
    {
        var candidates = await _projector.ProjectAsync(campaign.OrganizationId, AudienceCandidateProjector.DispatchCap, ct);
        var matched = candidates.Where(c => AudienceEvaluator.Evaluate(doc.Root, c)).ToList();

        var prefs = await _db.NotificationPreferences.AsNoTracking().ToListAsync(ct);
        var deliveryCandidates = matched.Select(c =>
        {
            var pref = prefs.FirstOrDefault(p =>
                (p.OrganizationId.HasValue && p.OrganizationId == c.OrganizationId) ||
                (p.UserId.HasValue && p.UserId == c.EntityId));
            return new DeliveryCandidate(
                Endpoint: c.EntityId.ToString(), // In-app endpoint; real adapters resolve concrete addresses
                EntityId: c.OrganizationId ?? c.EntityId,
                Channel: campaign.Channel.ToString(),
                OptOut: pref?.OptOut ?? false,
                QuietStartLocalMinutes: pref?.QuietHoursStartLocalMinutes,
                QuietEndLocalMinutes: pref?.QuietHoursEndLocalMinutes,
                TimezoneId: pref?.TimezoneId ?? "Africa/Cairo",
                SentTodayForRecipient: 0, // production tuning: count from DeliveryAttempt rows for the UTC day
                FrequencyCapPerDay: pref?.FrequencyCapPerDay ?? 5);
        }).ToList();

        // Plan preserves input order 1:1 (one output per input, suppressed or not).
        var planning = campaign.RecipientSemantics switch
        {
            RecipientSemanticsMode.PerOrganization => DeliveryPlanner.RecipientSemanticsFor.PerOrganization,
            RecipientSemanticsMode.PerUser => DeliveryPlanner.RecipientSemanticsFor.PerUser,
            RecipientSemanticsMode.PerInstallation => DeliveryPlanner.RecipientSemanticsFor.PerInstallation,
            _ => DeliveryPlanner.RecipientSemanticsFor.PerDeviceEndpoint
        };
        var planned = DeliveryPlanner.Plan(deliveryCandidates, planning, DateTimeOffset.UtcNow);

        var suppressed = planned.Count(p => p.Suppressed);
        var duplicates = planned.Count(p => p.SuppressionReason == "duplicate-recipient");

        await using var tx = await _db.Database.BeginTransactionAsync(ct);

        campaign.Status = CampaignStatus.Processing;
        campaign.StartedAt = DateTimeOffset.UtcNow;

        var recipients = new List<CampaignRecipient>();
        for (int i = 0; i < planned.Count; i++)
        {
            if (planned[i].Suppressed) continue;
            var candidate = matched[i];
            recipients.Add(new CampaignRecipient
            {
                CampaignId = campaign.Id,
                RecipientKey = campaign.RecipientSemantics switch
                {
                    RecipientSemanticsMode.PerOrganization => $"org:{candidate.OrganizationId}",
                    RecipientSemanticsMode.PerUser => $"user:{candidate.EntityId}",
                    RecipientSemanticsMode.PerInstallation => $"inst:{candidate.EntityId}",
                    _ => $"endpoint:{planned[i].Endpoint}"
                },
                Channel = planned[i].Channel,
                Endpoint = planned[i].Endpoint,
                TargetEntityId = candidate.EntityId,
                Status = RecipientStatus.Queued
            });
        }
        _db.CampaignRecipients.AddRange(recipients);
        campaign.TotalRecipients = recipients.Count;

        if (campaign.ExecutionMode == AudienceExecutionMode.FrozenSnapshot)
        {
            var keys = recipients.Select(r => r.RecipientKey).ToList();
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join(",", keys))));
            _db.AudienceSnapshots.Add(new AudienceSnapshot
            {
                AudienceDefinitionId = definition.Id,
                CampaignId = campaign.Id,
                RuleVersion = definition.RuleVersion,
                CandidateCount = keys.Count,
                ContentHash = hash,
                RecipientKeysJson = JsonSerializer.Serialize(keys)
            });
        }

        await _db.SaveChangesAsync(ct);

        // One transactional-outbox message per recipient.
        foreach (var recipient in recipients)
        {
            _db.OutboxMessages.Add(new Persistence.OutboxMessage
            {
                Type = "campaign.send",
                Payload = JsonSerializer.Serialize(new { recipientId = recipient.Id }),
                CorrelationId = campaign.Id.ToString()
            });
        }
        await _db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);

        return new LaunchResult(true, null, recipients.Count, suppressed, duplicates, campaign.Id);
    }
}

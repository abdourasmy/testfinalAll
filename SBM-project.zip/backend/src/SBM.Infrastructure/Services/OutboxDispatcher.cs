using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SBM.Modules.Notifications.Delivery;
using SBM.Modules.Notifications.Entities;

namespace SBM.Infrastructure.Services;

/// <summary>
/// Processes the transactional outbox: at-least-once delivery with idempotency, exponential
/// backoff and dead-lettering. A successful provider call sets ProviderAccepted — never Delivered.
/// </summary>
public sealed class OutboxDispatcher : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<OutboxDispatcher> _logger;
    private readonly RetryPolicy _retry = new(maxAttempts: 5, baseDelay: TimeSpan.FromSeconds(30));

    public OutboxDispatcher(IServiceScopeFactory scopeFactory, ILogger<OutboxDispatcher> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await ProcessBatchAsync(stoppingToken); }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) { _logger.LogError(ex, "Outbox batch failed; will retry."); }
            await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
        }
    }

    public async Task ProcessBatchAsync(CancellationToken ct, int batchSize = 20)
    {
        using var scope = _scopeFactory.CreateScope();
        var services = scope.ServiceProvider;
        var db = services.GetRequiredService<Persistence.SbmDbContext>();
        var provider = services.GetRequiredService<INotificationProvider>();

        var now = DateTimeOffset.UtcNow;
        var batch = await db.OutboxMessages
            .Where(m => m.ProcessedAt == null && m.DeadLetteredAt == null && (m.NextAttemptAt == null || m.NextAttemptAt <= now))
            .OrderBy(m => m.CreatedAt)
            .Take(batchSize)
            .ToListAsync(ct);

        foreach (var message in batch)
        {
            try
            {
                await ProcessMessageAsync(db, provider, message, ct);
                message.ProcessedAt = DateTimeOffset.UtcNow;
                message.LastError = null;
            }
            catch (Exception ex)
            {
                message.Attempts += 1;
                message.LastError = ex.Message;
                if (_retry.ShouldDeadLetter(message.Attempts))
                {
                    message.DeadLetteredAt = DateTimeOffset.UtcNow;
                    _logger.LogError("Outbox message {MessageId} dead-lettered after {Attempts} attempts: {Error}", message.Id, message.Attempts, ex.Message);
                }
                else
                {
                    message.NextAttemptAt = DateTimeOffset.UtcNow + _retry.DelayForAttempt(message.Attempts);
                    _logger.LogWarning("Outbox message {MessageId} attempt {Attempts} failed: {Error}", message.Id, message.Attempts, ex.Message);
                }
            }
        }
        await db.SaveChangesAsync(ct);
        await FinalizeCampaignsAsync(db, ct);
    }

    /// <summary>Flips Processing campaigns to Completed / PartiallyFailed once every recipient reached a terminal state.</summary>
    private static async Task FinalizeCampaignsAsync(Persistence.SbmDbContext db, CancellationToken ct)
    {
        var processingIds = await db.Campaigns
            .Where(c => c.Status == CampaignStatus.Processing)
            .Select(c => c.Id)
            .ToListAsync(ct);
        if (processingIds.Count == 0) return;

        foreach (var campaignId in processingIds)
        {
            var counts = await db.CampaignRecipients
                .Where(r => r.CampaignId == campaignId)
                .GroupBy(r => r.Status)
                .Select(g => new { Status = g.Key, Count = g.Count() })
                .ToListAsync(ct);

            var all = counts.Sum(g => g.Count);
            if (all == 0)
            {
                // Zero recipients matched (empty audience) — campaign is done.
                await db.Campaigns.Where(c => c.Id == campaignId)
                    .ExecuteUpdateAsync(s => s.SetProperty(c => c.Status, CampaignStatus.Completed)
                        .SetProperty(c => c.CompletedAt, DateTimeOffset.UtcNow)
                        .SetProperty(c => c.SentCount, 0), ct);
                continue;
            }

            var terminal = counts.Where(g => g.Status is RecipientStatus.ProviderAccepted or RecipientStatus.Delivered or RecipientStatus.Opened or RecipientStatus.Failed or RecipientStatus.Cancelled or RecipientStatus.Expired).Sum(g => g.Count);
            if (terminal != all) continue; // still in flight

            var failed = counts.Where(g => g.Status == RecipientStatus.Failed).Sum(g => g.Count);
            var sent = counts.Where(g => g.Status is RecipientStatus.ProviderAccepted or RecipientStatus.Delivered or RecipientStatus.Opened).Sum(g => g.Count);
            await db.Campaigns.Where(c => c.Id == campaignId)
                .ExecuteUpdateAsync(s => s.SetProperty(c => c.Status, failed > 0 ? CampaignStatus.PartiallyFailed : CampaignStatus.Completed)
                    .SetProperty(c => c.CompletedAt, DateTimeOffset.UtcNow)
                    .SetProperty(c => c.SentCount, sent)
                    .SetProperty(c => c.FailedCount, failed), ct);
        }
    }

    private static async Task ProcessMessageAsync(Persistence.SbmDbContext db, INotificationProvider provider, Persistence.OutboxMessage message, CancellationToken ct)
    {
        switch (message.Type)
        {
            case "campaign.send":
                {
                    using var doc = JsonDocument.Parse(message.Payload);
                    var recipientId = doc.RootElement.GetProperty("recipientId").GetGuid();
                    var recipient = await db.CampaignRecipients.FirstOrDefaultAsync(r => r.Id == recipientId, ct)
                        ?? throw new InvalidOperationException("Recipient not found.");
                    if (recipient.Status is not (RecipientStatus.Queued or RecipientStatus.Failed))
                        return; // already handled (provider accepted / cancelled / ...)

                    recipient.Status = RecipientStatus.Processing;
                    recipient.AttemptCount += 1;

                    var template = await db.NotificationTemplates.AsNoTracking()
                        .Where(t => t.IsActive)
                        .OrderByDescending(t => t.Version)
                        .FirstOrDefaultAsync(ct);

                    var result = await provider.SendAsync(recipient.Endpoint, template?.Subject ?? "Notification", template?.Body ?? "You have a notification.", ct);
                    var attempt = new DeliveryAttempt
                    {
                        CampaignRecipientId = recipient.Id,
                        AttemptNo = recipient.AttemptCount,
                        Result = result.Success ? "accepted" : "failed",
                        ErrorClass = result.Success ? null : ProviderErrorClassifier.Classify(result.ErrorCode, result.HttpStatus).ToString(),
                        ProviderMessageId = result.ProviderMessageId,
                        ResponseSummary = result.ResponseSummary
                    };
                    db.DeliveryAttempts.Add(attempt);

                    if (result.Success)
                    {
                        // ProviderAccepted is NOT Delivered. Delivered is set only from provider delivery confirmation.
                        recipient.Status = RecipientStatus.ProviderAccepted;
                        recipient.ProviderAcceptedAt = DateTimeOffset.UtcNow;
                        recipient.ProviderMessageId = result.ProviderMessageId;
                        recipient.LastErrorClass = null;
                    }
                    else
                    {
                        var errorClass = ProviderErrorClassifier.Classify(result.ErrorCode, result.HttpStatus);
                        recipient.LastErrorClass = errorClass.ToString();
                        if (ProviderErrorClassifier.IsRetryable(errorClass) && recipient.AttemptCount < 5)
                        {
                            recipient.Status = RecipientStatus.Failed; // eligible for retry via outbox message reschedule
                            throw new TransientSendException($"Retryable provider error: {result.ErrorCode ?? result.HttpStatus?.ToString()}");
                        }
                        recipient.Status = RecipientStatus.Failed;
                    }
                    break;
                }
            default:
                // Unknown message type: acknowledge to avoid poison-looping.
                break;
        }
    }

    private sealed class TransientSendException : Exception
    {
        public TransientSendException(string message) : base(message) { }
    }
}

using Microsoft.EntityFrameworkCore;
using SBM.Modules.Licensing.Crypto;
using SBM.Modules.Licensing.Domain;
using SBM.Modules.Licensing.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Infrastructure.Services;

/// <summary>License issuance, activation, session leases and transfers. Server-side authority for all licensing decisions.</summary>
public class LicenseAppService
{
    private readonly Persistence.SbmDbContext _db;
    private readonly EcdsaLicenseSigner _signer = new();
    private readonly TimeProvider _clock;

    public LicenseAppService(Persistence.SbmDbContext db, TimeProvider? clock = null)
    {
        _db = db;
        _clock = clock ?? TimeProvider.System;
    }

    // ---------- Activation ----------

    public sealed record ActivationResult(bool Success, string? Error, int ActiveDevices, int DeviceLimit, string? Token, string? KeyId);

    public async Task<ActivationResult> ActivateDeviceAsync(Guid organizationId, Guid licenseId, string deviceId, string deviceName, string platform, CancellationToken ct = default)
    {
        var license = await _db.Licenses.FirstOrDefaultAsync(l => l.Id == licenseId && l.OrganizationId == organizationId, ct);
        if (license is null) return new(false, "license-not-found", 0, 0, null, null);
        if (license.State != LicenseState.Active) return new(false, $"license-{license.State.ToString().ToLowerInvariant()}", 0, license.DeviceLimit, null, null);
        if (license.ExpiresAt <= _clock.GetUtcNow())
        {
            license.State = LicenseState.Expired;
            _db.LicenseEvents.Add(NewEvent(license, "expired", "License expired at activation attempt."));
            await _db.SaveChangesAsync(ct);
            return new(false, "license-expired", 0, license.DeviceLimit, null, null);
        }

        var devices = await _db.LicenseDevices.Where(d => d.LicenseId == licenseId && d.DeactivatedAt == null).ToListAsync(ct);
        var existing = devices.FirstOrDefault(d => d.DeviceId == deviceId);
        if (existing is null)
        {
            if (!DevicePolicy.CanActivate(devices.Count, license.DeviceLimit))
                return new(false, "device-limit-reached", devices.Count, license.DeviceLimit, null, null);

            existing = new LicenseDevice
            {
                OrganizationId = organizationId,
                LicenseId = licenseId,
                DeviceId = deviceId.Trim(),
                DeviceName = deviceName?.Trim() ?? "Unknown",
                Platform = platform?.Trim() ?? "Unknown"
            };
            _db.LicenseDevices.Add(existing);
            _db.LicenseEvents.Add(NewEvent(license, "activated", $"Device {existing.DeviceId} ({existing.Platform})"));
        }
        else
        {
            existing.LastSeenAt = _clock.GetUtcNow();
        }
        await _db.SaveChangesAsync(ct);

        var (token, keyId) = await IssueTokenAsync(license, ct);
        var activeCount = await _db.LicenseDevices.CountAsync(d => d.LicenseId == licenseId && d.DeactivatedAt == null, ct);
        return new ActivationResult(true, null, activeCount, license.DeviceLimit, token, keyId);
    }

    public async Task<bool> DeactivateDeviceAsync(Guid organizationId, Guid licenseId, string deviceId, CancellationToken ct = default)
    {
        var device = await _db.LicenseDevices
            .FirstOrDefaultAsync(d => d.OrganizationId == organizationId && d.LicenseId == licenseId && d.DeviceId == deviceId && d.DeactivatedAt == null, ct);
        if (device is null) return false;
        device.DeactivatedAt = _clock.GetUtcNow();
        var license = await _db.Licenses.FindAsync(new object?[] { licenseId }, ct);
        if (license is not null) _db.LicenseEvents.Add(NewEvent(license, "deactivated", $"Device {deviceId}"));
        await _db.SaveChangesAsync(ct);
        return true;
    }

    // ---------- Session leases (concurrent sessions) ----------

    public sealed record SessionLeaseResult(bool Success, string? Error, Guid? SessionId, DateTimeOffset? ExpiresAt, int LiveSessions, int SessionLimit);

    public async Task<SessionLeaseResult> StartSessionAsync(Guid organizationId, Guid licenseId, string deviceId, Guid? userId, Guid applicationId, TimeSpan? leaseDuration = null, CancellationToken ct = default)
    {
        var license = await _db.Licenses.FirstOrDefaultAsync(l => l.Id == licenseId && l.OrganizationId == organizationId, ct);
        if (license is null) return new(false, "license-not-found", null, null, 0, 0);
        if (license.State != LicenseState.Active) return new(false, $"license-{license.State.ToString().ToLowerInvariant()}", null, null, 0, license.SessionLimit);

        var device = await _db.LicenseDevices.FirstOrDefaultAsync(d => d.LicenseId == licenseId && d.DeviceId == deviceId && d.DeactivatedAt == null, ct);
        if (device is null) return new(false, "device-not-activated", null, null, 0, license.SessionLimit);

        var now = _clock.GetUtcNow();
        var live = await _db.LicenseSessions.CountAsync(s => s.LicenseId == licenseId && s.RevokedAt == null && s.ExpiresAt > now, ct);
        if (!SessionPolicy.CanStartSession(live, license.SessionLimit))
            return new(false, "session-limit-reached", null, null, live, license.SessionLimit);

        var session = new LicenseSession
        {
            OrganizationId = organizationId,
            LicenseId = licenseId,
            DeviceActivationId = device.Id,
            UserId = userId,
            ApplicationId = applicationId,
            IssuedAt = now,
            LastHeartbeatAt = now,
            ExpiresAt = now + (leaseDuration ?? TimeSpan.FromMinutes(15))
        };
        _db.LicenseSessions.Add(session);
        _db.LicenseEvents.Add(NewEvent(license, "lease.issued", $"Session {session.SessionId} for device {deviceId}"));
        await _db.SaveChangesAsync(ct);
        return new(true, null, session.SessionId, session.ExpiresAt, live + 1, license.SessionLimit);
    }

    public async Task<SessionLeaseResult> HeartbeatAsync(Guid organizationId, Guid sessionId, TimeSpan? leaseDuration = null, CancellationToken ct = default)
    {
        var now = _clock.GetUtcNow();
        var session = await _db.LicenseSessions.FirstOrDefaultAsync(s => s.OrganizationId == organizationId && s.SessionId == sessionId, ct);
        if (session is null) return new(false, "session-not-found", null, null, 0, 0);
        if (session.RevokedAt is not null) return new(false, "session-revoked", sessionId, null, 0, 0);
        if (session.ExpiresAt <= now) return new(false, "session-expired", sessionId, null, 0, 0);

        var license = await _db.Licenses.FindAsync(new object?[] { session.LicenseId }, ct);
        if (license is null || license.State != LicenseState.Active)
        {
            session.RevokedAt = now; // license no longer valid: drop lease
            await _db.SaveChangesAsync(ct);
            return new(false, "license-not-active", sessionId, null, 0, license?.SessionLimit ?? 0);
        }

        session.LastHeartbeatAt = now;
        session.ExpiresAt = now + (leaseDuration ?? TimeSpan.FromMinutes(15));
        await _db.SaveChangesAsync(ct);
        var live = await _db.LicenseSessions.CountAsync(s => s.LicenseId == session.LicenseId && s.RevokedAt == null && s.ExpiresAt > now, ct);
        return new(true, null, sessionId, session.ExpiresAt, live, license.SessionLimit);
    }

    // ---------- Transfer (self-service within policy) ----------

    public sealed record TransferResult(bool Success, string? Error, bool RequiresApproval);

    public async Task<TransferResult> RequestTransferAsync(Guid organizationId, Guid licenseId, Guid targetCustomerId, Guid requestedByUserId, CancellationToken ct = default)
    {
        var license = await _db.Licenses.FirstOrDefaultAsync(l => l.Id == licenseId && l.OrganizationId == organizationId, ct);
        if (license is null) return new(false, "license-not-found", false);
        var now = _clock.GetUtcNow();
        var decision = TransferPolicy.Evaluate(license.TransferCount, license.MaxTransfers, license.LastTransferredAt, license.TransferCooldownDays, now);
        if (!decision.Allowed)
            return new(false, decision.Reason, RequiresApproval: true); // exceptional path requires management approval

        license.CustomerId = targetCustomerId;
        license.TransferCount += 1;
        license.LastTransferredAt = now;
        _db.LicenseEvents.Add(NewEvent(license, "transferred", $"Transferred to customer {targetCustomerId}", requestedByUserId));
        await _db.SaveChangesAsync(ct);
        return new(true, null, false);
    }

    // ---------- Revocation ----------

    public async Task<bool> RevokeAsync(Guid organizationId, Guid licenseId, string reason, Guid? actorUserId, CancellationToken ct = default)
    {
        var license = await _db.Licenses.FirstOrDefaultAsync(l => l.Id == licenseId && l.OrganizationId == organizationId, ct);
        if (license is null) return false;
        LicenseStateMachine.EnsureTransition(license.State, LicenseState.Revoked);
        license.State = LicenseState.Revoked;
        license.RevokedAt = _clock.GetUtcNow();
        license.RevocationReason = reason?.Trim();
        var sessions = await _db.LicenseSessions.Where(s => s.LicenseId == licenseId && s.RevokedAt == null).ToListAsync(ct);
        foreach (var s in sessions) s.RevokedAt = _clock.GetUtcNow();
        _db.LicenseEvents.Add(NewEvent(license, "revoked", reason, actorUserId));
        await _db.SaveChangesAsync(ct);
        return true;
    }

    // ---------- Token issuance ----------

    public async Task<(string Token, string KeyId)> IssueTokenAsync(License license, CancellationToken ct = default)
    {
        var key = await _db.LicenseSigningKeys
            .Where(k => k.Status == "Active" && k.NotBefore <= _clock.GetUtcNow())
            .OrderByDescending(k => k.CreatedAt)
            .FirstOrDefaultAsync(ct)
            ?? throw new InvalidOperationException("No active license signing key. Seed or rotate keys via admin tooling.");
        if (key.UseKeyVault || key.PrivateKeyPem is null)
            throw new InvalidOperationException("Active signing key is Key Vault-backed; private key never leaves Key Vault. Configure IKeyVaultSigner.");

        var entitlements = await _db.PlanFeatures
            .Where(pf => pf.PlanId == license.PlanId)
            .Join(_db.Features, pf => pf.FeatureId, f => f.Id, (pf, f) => f.Code)
            .ToListAsync(ct);

        var now = _clock.GetUtcNow();
        var payload = new LicensePayload(
            LicensePayload.CurrentVersion,
            "sbm",
            license.Id,
            license.ProductId,
            license.ApplicationId,
            license.CustomerId,
            license.OrganizationId,
            now.ToUnixTimeSeconds(),
            license.ExpiresAt.ToUnixTimeSeconds(),
            entitlements,
            new LicensePolicy(license.DeviceLimit),
            new LicensePolicy(license.SessionLimit),
            key.KeyId);

        var signed = _signer.Sign(payload, key.PrivateKeyPem, key.KeyId);
        return (signed.Token, signed.KeyId);
    }

    private static LicenseEvent NewEvent(License license, string type, string? details, Guid? actor = null) => new()
    {
        OrganizationId = license.OrganizationId,
        LicenseId = license.Id,
        EventType = type,
        Details = details,
        ActorUserId = actor
    };
}

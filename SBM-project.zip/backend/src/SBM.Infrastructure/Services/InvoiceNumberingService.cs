using Microsoft.EntityFrameworkCore;
using SBM.Modules.Billing.Entities;

namespace SBM.Infrastructure.Services;

/// <summary>
/// Concurrency-safe invoice numbering via an optimistic read-increment-write cycle on a
/// per-organization/prefix/financial-year sequence row guarded by a rowversion token.
/// Conflicts are retried; the (OrganizationId, Number) unique index on Invoice is the final backstop.
/// Never uses MAX(number)+1 and never holds long-lived Serializable locks.
/// </summary>
public class InvoiceNumberingService
{
    private readonly Persistence.SbmDbContext _db;

    public InvoiceNumberingService(Persistence.SbmDbContext db) => _db = db;

    public async Task<string> NextNumberAsync(Guid organizationId, string prefix, string financialYear, CancellationToken ct = default)
    {
        prefix = string.IsNullOrWhiteSpace(prefix) ? "INV" : prefix.Trim().ToUpperInvariant();
        financialYear = string.IsNullOrWhiteSpace(financialYear) ? DateTimeOffset.UtcNow.Year.ToString() : financialYear.Trim();

        var strategy = _db.Database.CreateExecutionStrategy();
        return await strategy.ExecuteAsync(() => AllocateAsync(organizationId, prefix, financialYear, ct));
    }

    private async Task<string> AllocateAsync(Guid organizationId, string prefix, string financialYear, CancellationToken ct)
    {
        for (var attempt = 1; ; attempt++)
        {
            var seq = await _db.InvoiceSequences
                .FirstOrDefaultAsync(s => s.OrganizationId == organizationId && s.Prefix == prefix && s.FinancialYear == financialYear, ct);

            if (seq is null)
            {
                var created = new InvoiceSequence { OrganizationId = organizationId, Prefix = prefix, FinancialYear = financialYear, NextValue = 2 };
                _db.InvoiceSequences.Add(created);
                try
                {
                    await _db.SaveChangesAsync(ct);
                    return Format(prefix, financialYear, 1);
                }
                catch (Exception ex) when (attempt < 6 && IsSequenceConflict(ex))
                {
                    _db.Entry(created).State = EntityState.Detached;
                    await Task.Delay(15 * attempt, ct); // lost the insert race; re-read the winner's row
                    continue;
                }
            }

            var allocated = seq.NextValue;
            seq.NextValue = allocated + 1;
            try
            {
                await _db.SaveChangesAsync(ct);
                return Format(prefix, financialYear, allocated);
            }
            catch (DbUpdateConcurrencyException) when (attempt < 6)
            {
                _db.Entry(seq).State = EntityState.Detached; // drop stale tracked entity
                await Task.Delay(10 * attempt, ct);
            }
            catch (Exception ex) when (attempt < 6 && IsSequenceConflict(ex))
            {
                _db.Entry(seq).State = EntityState.Detached;
                await Task.Delay(15 * attempt, ct);
            }
        }
    }

    private static string Format(string prefix, string year, long value) => $"{prefix}-{year}-{value:D6}";

    private static bool IsSequenceConflict(Exception ex)
    {
        var msg = ex.ToString();
        return msg.Contains("2601", StringComparison.OrdinalIgnoreCase)
            || msg.Contains("2627", StringComparison.OrdinalIgnoreCase)
            || msg.Contains("1205", StringComparison.OrdinalIgnoreCase)
            || msg.Contains("duplicate", StringComparison.OrdinalIgnoreCase)
            || msg.Contains("deadlock", StringComparison.OrdinalIgnoreCase);
    }
}

using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Modules.Identity.Entities;
using SBM.Modules.Identity.Permissions;

namespace SBM.Infrastructure.Services;

/// <summary>Computes effective permissions; enforces "you cannot grant a permission you do not possess".</summary>
public sealed class PermissionService
{
    private readonly SbmDbContext _db;

    public PermissionService(SbmDbContext db) => _db = db;

    public async Task<HashSet<string>> GetEffectiveAsync(Guid userId, IList<string> roleNames, bool isPlatformAdmin, CancellationToken ct = default)
    {
        if (isPlatformAdmin) return PermissionRegistry.All.ToHashSet(StringComparer.OrdinalIgnoreCase);

        var roleIds = await _db.Roles.AsNoTracking()
            .Where(r => roleNames.Contains(r.Name!))
            .Select(r => r.Id)
            .ToListAsync(ct);

        var fromRoles = await _db.RolePermissions.AsNoTracking()
            .Where(rp => roleIds.Contains(rp.RoleId))
            .Select(rp => rp.PermissionCode)
            .Distinct()
            .ToListAsync(ct);

        var direct = await _db.UserPermissions.AsNoTracking()
            .Where(up => up.UserId == userId)
            .ToListAsync(ct);

        var granted = fromRoles.ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var g in direct.Where(d => d.IsGranted)) granted.Add(g.PermissionCode);
        foreach (var r in direct.Where(d => !d.IsGranted)) granted.Remove(r.PermissionCode);
        return granted;
    }

    /// <summary>Throws when the actor does not possess <paramref name="requested"/> (unless platform admin).</summary>
    public async Task EnsureCanGrantAsync(Guid actorUserId, IList<string> actorRoles, bool actorIsPlatformAdmin, IEnumerable<string> requestedPermissions, CancellationToken ct = default)
    {
        var effective = await GetEffectiveAsync(actorUserId, actorRoles, actorIsPlatformAdmin, ct);
        var missing = requestedPermissions.Where(p => !effective.Contains(p)).Distinct().ToList();
        if (missing.Count > 0)
            throw new UnauthorizedAccessException($"You cannot grant permissions you do not possess: {string.Join(", ", missing)}");
    }
}

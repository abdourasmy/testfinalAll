using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SBM.Modules.Notifications.Audience;

namespace SBM.Infrastructure.Middleware;

/// <summary>Maps exceptions to ProblemDetails; never leaks internals or stack traces.</summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try { await _next(context); }
        catch (Exception ex)
        {
            var (status, title, errors) = Map(ex);
            if (status >= 500) _logger.LogError(ex, "Unhandled error {TraceId}", context.TraceIdentifier);
            else _logger.LogWarning("Request {TraceId} failed: {Message}", context.TraceIdentifier, ex.Message);

            context.Response.ContentType = "application/problem+json";
            context.Response.StatusCode = status;
            await context.Response.WriteAsync(JsonSerializer.Serialize(new
            {
                type = "about:blank",
                title,
                status,
                traceId = context.TraceIdentifier,
                errors
            }));
        }
    }

    private static (int, string, IReadOnlyList<string>?) Map(Exception ex) => ex switch
    {
        KeyNotFoundException => (404, "Resource not found", null),
        ArgumentException => (400, "Invalid request", new[] { ex.Message }),
        AudienceValidationException ave => (400, "Audience rule validation failed", ave.Errors),
        UnauthorizedAccessException => (401, "Unauthorized", null),
        InvalidOperationException => (409, "Conflict", new[] { ex.Message }),
        _ => (500, "An unexpected error occurred", null)
    };
}

namespace SBM.Shared.Abstractions;

/// <summary>Provides the current request context (tenant, user, platform scope). Never trust client-supplied tenant ids.</summary>
public interface ITenantContext
{
    Guid? OrganizationId { get; }
    Guid? UserId { get; }
    string? UserName { get; }
    bool IsPlatformAdmin { get; }
    bool IsInOrganization(Guid organizationId);
}

namespace SBM.Shared.Abstractions;

/// <summary>
/// Base class for aggregate roots. Domain events raised by aggregates are collected
/// here and dispatched (via the transactional outbox) when the unit of work commits.
/// </summary>
public abstract class AggregateRoot<TId>
{
    private readonly List<IDomainEvent> _domainEvents = new();

    public TId Id { get; protected set; } = default!;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public string? CreatedBy { get; set; }

    public IReadOnlyList<IDomainEvent> DomainEvents => _domainEvents;

    protected void Raise(IDomainEvent domainEvent) => _domainEvents.Add(domainEvent);

    public void ClearDomainEvents() => _domainEvents.Clear();
}

/// <summary>Marker for entities that belong to a customer organization (tenant scope).</summary>
public interface IOrganizationScoped
{
    Guid OrganizationId { get; }
}

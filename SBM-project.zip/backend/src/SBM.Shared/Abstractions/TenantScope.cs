namespace SBM.Shared.Abstractions;

/// <summary>
/// Explicit tenant scoping for organization-owned rows. Platform administrators see all tenants;
/// organization users see only their own. This is the single source of truth for row scoping -
/// do not rely on implicit query filters.
/// </summary>
public static class TenantScope
{
    public static IQueryable<T> Org<T>(IQueryable<T> queryable, ITenantContext tenant) where T : IOrganizationScoped =>
        tenant.IsPlatformAdmin || tenant.OrganizationId is null
            ? (tenant.IsPlatformAdmin ? queryable : queryable.Where(_ => false))
            : queryable.Where(x => x.OrganizationId == tenant.OrganizationId);

    /// <summary>Validates that an organization-scoped row belongs to the caller's tenant (or caller is platform admin).</summary>
    public static bool Owns<T>(T? entity, ITenantContext tenant) where T : IOrganizationScoped =>
        entity is not null && (tenant.IsPlatformAdmin || tenant.OrganizationId == entity.OrganizationId);
}

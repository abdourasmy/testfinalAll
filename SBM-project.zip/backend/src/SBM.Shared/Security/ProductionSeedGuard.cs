namespace SBM.Shared.Security;

/// <summary>Production-safety gate. The Development demo seed must never activate in production.</summary>
public static class ProductionSeedGuard
{
    /// <summary>Throws in production when development seed accounts would be created.</summary>
    public static void EnsureSafe(bool isProduction, bool seedEnable, bool seedDemoData)
    {
        if (isProduction && (seedEnable || seedDemoData))
        {
            throw new InvalidOperationException(
                "Production startup refused: Seed:Enable and Seed:DemoData must be false in production. " +
                "Set Seed__Enable=false (and Seed__DemoData=false) to run in production.");
        }
    }
}

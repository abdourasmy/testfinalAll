using System.Globalization;
using System.Text.RegularExpressions;

namespace SBM.Shared.Versioning;

/// <summary>
/// Semantic Version (SemVer 2.0.0) value type with proper precedence rules,
/// including prerelease handling. Build metadata is retained but ignored for precedence.
/// Invalid version strings are rejected by <see cref="TryParse"/> rather than silently mis-compared.
/// </summary>
public sealed record SemVer : IComparable<SemVer>
{
    private static readonly Regex Pattern = new(
        @"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|[0-9a-zA-Z-]*[0-9a-zA-Z])(?:\.(?:0|[1-9]\d*|[0-9a-zA-Z-]*[0-9a-zA-Z]))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public int Major { get; }
    public int Minor { get; }
    public int Patch { get; }
    public string? Prerelease { get; }
    public string? BuildMetadata { get; }

    private SemVer(int major, int minor, int patch, string? prerelease, string? buildMetadata)
    {
        Major = major; Minor = minor; Patch = patch;
        Prerelease = string.IsNullOrEmpty(prerelease) ? null : prerelease;
        BuildMetadata = string.IsNullOrEmpty(buildMetadata) ? null : buildMetadata;
    }

    public bool IsPrerelease => Prerelease is not null;

    public static SemVer Parse(string value) =>
        TryParse(value, out var v) ? v! : throw new FormatException($"'{value}' is not a valid SemVer 2.0.0 version.");

    public static bool TryParse(string? value, out SemVer? version)
    {
        version = null;
        if (string.IsNullOrWhiteSpace(value)) return false;
        var m = Pattern.Match(value.Trim());
        if (!m.Success) return false;
        version = new SemVer(
            int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture),
            int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture),
            int.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture),
            m.Groups[4].Success ? m.Groups[4].Value : null,
            m.Groups[5].Success ? m.Groups[5].Value : null);
        return true;
    }

    public int CompareTo(SemVer? other)
    {
        if (other is null) return 1;
        int c = Major.CompareTo(other.Major);
        if (c != 0) return c;
        c = Minor.CompareTo(other.Minor);
        if (c != 0) return c;
        c = Patch.CompareTo(other.Patch);
        if (c != 0) return c;
        return ComparePrerelease(Prerelease, other.Prerelease);
    }

    private static int ComparePrerelease(string? a, string? b)
    {
        // A release is greater than a prerelease of the same core version.
        if (a is null && b is null) return 0;
        if (a is null) return 1;
        if (b is null) return -1;

        var aParts = a.Split('.');
        var bParts = b.Split('.');
        for (int i = 0; i < Math.Max(aParts.Length, bParts.Length); i++)
        {
            if (i >= aParts.Length) return -1; // smaller set of identifiers wins when all preceding are equal
            if (i >= bParts.Length) return 1;
            var ap = aParts[i]; var bp = bParts[i];
            bool aNum = int.TryParse(ap, NumberStyles.None, CultureInfo.InvariantCulture, out var an);
            bool bNum = int.TryParse(bp, NumberStyles.None, CultureInfo.InvariantCulture, out var bn);
            if (aNum && bNum) { int c = an.CompareTo(bn); if (c != 0) return c; continue; }
            if (aNum) return -1; // numeric identifiers are lower than alphanumeric
            if (bNum) return 1;
            int sc = string.CompareOrdinal(ap, bp);
            if (sc != 0) return sc;
        }
        return 0;
    }

    public static bool operator <(SemVer a, SemVer b) => a.CompareTo(b) < 0;
    public static bool operator >(SemVer a, SemVer b) => a.CompareTo(b) > 0;
    public static bool operator <=(SemVer a, SemVer b) => a.CompareTo(b) <= 0;
    public static bool operator >=(SemVer a, SemVer b) => a.CompareTo(b) >= 0;

    public override string ToString() =>
        $"{Major}.{Minor}.{Patch}" + (Prerelease is null ? "" : $"-{Prerelease}") + (BuildMetadata is null ? "" : $"+{BuildMetadata}");
}

/// <summary>A version range such as ">=1.2.0 <2.0.0" or a major/minor family like "2.x".</summary>
public sealed record SemVerRange
{
    private readonly List<(string Op, SemVer Version)> _constraints;

    private SemVerRange(List<(string Op, SemVer Version)> constraints, int? majorFamily, string? minorFamily)
    {
        _constraints = constraints;
        MajorFamily = majorFamily;
        MinorFamily = minorFamily;
    }

    public int? MajorFamily { get; }
    public string? MinorFamily { get; }
    public bool IsMajorFamily => MajorFamily.HasValue;

    public static SemVerRange ParseMajorFamily(int major) => new(new(), major, null);
    public static SemVerRange ParseMajorMinorFamily(int major, int minor) => new(new(), major, minor.ToString(CultureInfo.InvariantCulture));

    public static SemVerRange Parse(string range)
    {
        if (string.IsNullOrWhiteSpace(range)) throw new FormatException("Version range cannot be empty.");
        var constraints = new List<(string, SemVer)>();
        foreach (var token in range.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            var match = Regex.Match(token, @"^(>=|<=|>|<|=|!=)\s*v?(\S+)$");
            if (!match.Success)
                throw new FormatException($"Unsupported range constraint '{token}'. Use operators >=, <=, >, <, =, != followed by a SemVer.");
            constraints.Add((match.Groups[1].Value, SemVer.Parse(match.Groups[2].Value)));
        }
        if (constraints.Count == 0) throw new FormatException("Version range must contain at least one constraint.");
        return new SemVerRange(constraints, null, null);
    }

    public bool Contains(SemVer version)
    {
        if (IsMajorFamily)
        {
            if (version.Major != MajorFamily!.Value) return false;
            if (MinorFamily is not null && version.Minor.ToString(CultureInfo.InvariantCulture) != MinorFamily) return false;
            return !version.IsPrerelease; // families track stable releases by default
        }
        foreach (var (op, v) in _constraints)
        {
            int c = version.CompareTo(v);
            bool ok = op switch
            {
                ">=" => c >= 0,
                "<=" => c <= 0,
                ">" => c > 0,
                "<" => c < 0,
                "=" => c == 0,
                "!=" => c != 0,
                _ => false
            };
            if (!ok) return false;
        }
        return true;
    }
}

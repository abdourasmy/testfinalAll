using System.Security.Claims;
using SBM.Shared.Abstractions;

namespace SBM.Api;

/// <summary>Builds the tenant context from trusted JWT claims. Client-supplied tenant ids are never used.</summary>
public sealed class HttpTenantContext : ITenantContext
{
    private readonly IHttpContextAccessor _http;

    public HttpTenantContext(IHttpContextAccessor http)
    {
        _http = http;
    }

    public Guid? UserId =>
        Guid.TryParse(_http.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;

    public string? UserName => _http.HttpContext?.User.Identity?.Name;

    public bool IsPlatformAdmin =>
        _http.HttpContext?.User.FindFirstValue("scope") == "platform" &&
        _http.HttpContext?.User.IsInRole("PlatformAdmin") == true;

    public Guid? OrganizationId =>
        Guid.TryParse(_http.HttpContext?.User.FindFirstValue("org_id"), out var id) ? id : null;

    public bool IsInOrganization(Guid organizationId) =>
        IsPlatformAdmin || OrganizationId == organizationId;
}

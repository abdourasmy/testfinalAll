using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Api;
using SBM.Modules.Support.Domain;
using SBM.Modules.Support.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/support/tickets")]
[Authorize]
public class SupportTicketsController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public SupportTicketsController(SBM.Infrastructure.Persistence.SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateTicketRequest(Guid? CustomerId, string Subject, string Description, string Category, string Priority);
    public sealed record AddCommentRequest(string Body, bool Internal);
    public sealed record ChangeStatusRequest(string Status);
    public sealed record AssignRequest(Guid? AssignedToUserId);

    private Guid RequireOrganization() =>
        _tenant.OrganizationId ?? throw new UnauthorizedAccessException("Organization scope required.");

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTicketRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Subject)) return ValidationProblem("Subject is required.");
        if (!Enum.TryParse<TicketCategory>(request.Category, true, out var category)) category = TicketCategory.General;
        if (!Enum.TryParse<TicketPriority>(request.Priority, true, out var priority)) priority = TicketPriority.Normal;

        var ticket = new SupportTicket
        {
            OrganizationId = orgId,
            CustomerId = request.CustomerId,
            Subject = request.Subject.Trim(),
            Description = request.Description?.Trim() ?? string.Empty,
            Category = category,
            Priority = priority,
            CreatedByUserId = _tenant.UserId ?? Guid.Empty,
            SlaDueAt = DateTimeOffset.UtcNow + SupportTicket.DefaultSla(priority)
        };
        _db.SupportTickets.Add(ticket);
        await _db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = ticket.Id }, ticket);
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var query = TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant);
        if (Enum.TryParse<TicketStatus>(status, true, out var s)) query = query.Where(t => t.Status == s);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(t => t.CreatedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets.AsNoTracking(), _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        var commentsQuery = _db.TicketComments.AsNoTracking().Where(c => c.TicketId == id);
        // Internal notes only visible to staff (OrgManager+); customers see public replies only.
        if (!User.IsInRole("Owner") && !User.IsInRole("Manager") && !_tenant.IsPlatformAdmin)
            commentsQuery = commentsQuery.Where(c => c.Visibility == CommentVisibility.Customer);
        var comments = await commentsQuery.OrderBy(c => c.CreatedAt).ToListAsync(ct);
        return Ok(new { ticket, comments });
    }

    [HttpPost("{id:guid}/comments")]
    public async Task<IActionResult> AddComment(Guid id, [FromBody] AddCommentRequest request, CancellationToken ct = default)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        if (string.IsNullOrWhiteSpace(request.Body)) return ValidationProblem("Body is required.");
        // Only staff (OrgManager+) can write internal notes; everyone else writes public comments.
        var canWriteInternal = User.IsInRole("Owner") || User.IsInRole("Manager") || _tenant.IsPlatformAdmin;
        var visibility = request.Internal && canWriteInternal ? CommentVisibility.Internal : CommentVisibility.Customer;
        var comment = new TicketComment
        {
            OrganizationId = ticket.OrganizationId,
            TicketId = ticket.Id,
            AuthorUserId = _tenant.UserId,
            Body = request.Body.Trim(),
            Visibility = visibility
        };
        _db.TicketComments.Add(comment);
        await _db.SaveChangesAsync(ct);
        return Ok(comment);
    }

    [HttpPost("{id:guid}/status")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> ChangeStatus(Guid id, [FromBody] ChangeStatusRequest request, CancellationToken ct = default)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        if (!Enum.TryParse<TicketStatus>(request.Status, true, out var target))
            return ValidationProblem("Status must be Open, InProgress, OnHold, Resolved or Closed.");
        TicketStateMachine.EnsureTransition(ticket.Status, target);
        ticket.Status = target;
        if (target is TicketStatus.Resolved or TicketStatus.Closed) ticket.ResolvedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return Ok(ticket);
    }

    [HttpPost("{id:guid}/assign")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Assign(Guid id, [FromBody] AssignRequest request, CancellationToken ct = default)
    {
        var ticket = await TenantScope.Org(_db.SupportTickets, _tenant).FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null) return NotFound();
        ticket.AssignedToUserId = request.AssignedToUserId;
        if (ticket.Status == TicketStatus.Open) ticket.Status = TicketStatus.InProgress;
        await _db.SaveChangesAsync(ct);
        return Ok(ticket);
    }
}

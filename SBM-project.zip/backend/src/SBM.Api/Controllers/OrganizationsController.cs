using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/organizations")]
[Authorize]
public class OrganizationsController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    public OrganizationsController(SBM.Infrastructure.Persistence.SbmDbContext db) => _db = db;

    public sealed record CreateOrganizationRequest(string Name, string? LegalName, string? Country, string? City, string? TaxIdentifier, string? ContactEmail);

    [HttpPost]
    [Authorize(Policy = "PlatformAdmin")]
    public async Task<IActionResult> Create([FromBody] CreateOrganizationRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) return ValidationProblem("Name is required.");
        var org = new SBM.Modules.Identity.Entities.Organization
        {
            Name = request.Name.Trim(),
            LegalName = request.LegalName?.Trim(),
            Country = request.Country?.Trim() ?? "EG",
            City = request.City?.Trim(),
            TaxIdentifier = request.TaxIdentifier?.Trim(),
            ContactEmail = request.ContactEmail?.Trim()
        };
        _db.Organizations.Add(org);
        await _db.SaveChangesAsync(ct);
        return Created($"/api/organizations/{org.Id}", org);
    }

    [HttpGet]
    [Authorize(Policy = "PlatformAdmin")]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var total = await _db.Organizations.CountAsync(ct);
        var items = await _db.Organizations.OrderByDescending(o => o.RegisteredAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("{id:guid}/branches")]
    public async Task<IActionResult> Branches(Guid id, [FromServices] SBM.Shared.Abstractions.ITenantContext tenant, CancellationToken ct = default)
    {
        if (!tenant.IsInOrganization(id)) return Forbid();
        var items = await _db.Branches.Where(b => b.OrganizationId == id).OrderBy(b => b.Name).ToListAsync(ct);
        return Ok(items);
    }

    public sealed record CreateBranchRequest(string Name, string? Code, string? City);

    [HttpPost("{id:guid}/branches")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> CreateBranch(Guid id, [FromBody] CreateBranchRequest request, [FromServices] SBM.Shared.Abstractions.ITenantContext tenant, CancellationToken ct = default)
    {
        if (!tenant.IsInOrganization(id)) return Forbid(); // IDOR protection: route org must match token tenant
        var orgExists = await _db.Organizations.AnyAsync(o => o.Id == id, ct);
        if (!orgExists) return NotFound();
        var branch = new SBM.Modules.Identity.Entities.Branch
        {
            OrganizationId = id,
            Name = request.Name.Trim(),
            Code = request.Code?.Trim(),
            City = request.City?.Trim()
        };
        _db.Branches.Add(branch);
        await _db.SaveChangesAsync(ct);
        return Created($"/api/organizations/{id}/branches/{branch.Id}", branch);
    }
}

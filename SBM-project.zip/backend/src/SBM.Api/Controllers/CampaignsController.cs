using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Notifications.Audience;
using SBM.Modules.Notifications.Entities;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/campaigns")]
[Authorize]
public class CampaignsController : ControllerBase
{
    private readonly SbmDbContext _db;
    private readonly CampaignLaunchService _launch;
    private readonly SBM.Shared.Abstractions.ITenantContext _tenant;

    public CampaignsController(SbmDbContext db, CampaignLaunchService launch, SBM.Shared.Abstractions.ITenantContext tenant)
    {
        _db = db;
        _launch = launch;
        _tenant = tenant;
    }

    private Guid? CallerOrganizationId => _tenant.IsPlatformAdmin ? null : _tenant.OrganizationId;

    public sealed record CreateAudienceRequest(string Name, string DocumentJson);
    public sealed record CreateCampaignRequest(string Name, string TemplateCode, string Language, string Channel, Guid AudienceDefinitionId, string ExecutionMode, string RecipientSemantics, string? IdempotencyKey, DateTimeOffset? ScheduledAt);

    [HttpPost("audiences")]
    public async Task<IActionResult> CreateAudience([FromBody] CreateAudienceRequest request, CancellationToken ct = default)
    {
        var doc = JsonSerializer.Deserialize<AudienceDocument>(request.DocumentJson);
        if (doc is null) return BadRequest(new { error = "Audience document is required." });
        AudienceValidator.Validate(doc);
        var audience = new AudienceDefinition
        {
            Name = request.Name?.Trim() ?? "Untitled audience",
            DocumentJson = request.DocumentJson,
            RuleVersion = doc.Version,
            OrganizationId = CallerOrganizationId
        };
        _db.AudienceDefinitions.Add(audience);
        await _db.SaveChangesAsync(ct);
        return Created($"/api/campaigns/audiences/{audience.Id}", audience);
    }

    [HttpGet("audiences")]
    public async Task<IActionResult> ListAudiences(CancellationToken ct = default)
    {
        var orgId = CallerOrganizationId;
        var query = _db.AudienceDefinitions.AsNoTracking();
        if (!_tenant.IsPlatformAdmin)
            query = query.Where(a => a.OrganizationId == orgId || a.OrganizationId == null);
        return Ok(await query.OrderByDescending(a => a.CreatedAt).Take(100).ToListAsync(ct));
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateCampaignRequest request, CancellationToken ct = default)
    {
        if (!Enum.TryParse<NotificationChannel>(request.Channel, true, out var channel)) return ValidationProblem("Invalid channel.");
        if (!Enum.TryParse<AudienceExecutionMode>(request.ExecutionMode, true, out var mode)) return ValidationProblem("ExecutionMode must be Dynamic or FrozenSnapshot.");
        if (!Enum.TryParse<RecipientSemanticsMode>(request.RecipientSemantics, true, out var semantics)) return ValidationProblem("RecipientSemantics must be PerOrganization, PerUser, PerInstallation or PerDeviceEndpoint.");
        if (string.IsNullOrWhiteSpace(request.IdempotencyKey)) return ValidationProblem("IdempotencyKey is required.");

        // Idempotency: a campaign with this key already exists?
        var existing = await _db.Campaigns.FirstOrDefaultAsync(c => c.IdempotencyKey == request.IdempotencyKey, ct);
        if (existing is not null) return Ok(new { duplicate = true, campaign = existing });

        if (!await _db.AudienceDefinitions.AnyAsync(a => a.Id == request.AudienceDefinitionId, ct))
            return NotFound(new { error = "Audience definition not found." });
        if (!_tenant.IsPlatformAdmin)
        {
            var audience = await _db.AudienceDefinitions.AsNoTracking().FirstAsync(a => a.Id == request.AudienceDefinitionId, ct);
            if (audience.OrganizationId is { } audOrg && audOrg != _tenant.OrganizationId)
                return Forbid(); // may not bind another organization's private audience
        }

        var campaign = new Campaign
        {
            Name = request.Name?.Trim() ?? "Untitled campaign",
            TemplateCode = request.TemplateCode?.Trim() ?? "GENERIC",
            Language = request.Language ?? "ar",
            Channel = channel,
            AudienceDefinitionId = request.AudienceDefinitionId,
            ExecutionMode = mode,
            RecipientSemantics = semantics,
            IdempotencyKey = request.IdempotencyKey,
            ScheduledAt = request.ScheduledAt,
            Status = request.ScheduledAt.HasValue ? CampaignStatus.Scheduled : CampaignStatus.Draft,
            OrganizationId = CallerOrganizationId
        };
        _db.Campaigns.Add(campaign);
        try { await _db.SaveChangesAsync(ct); }
        catch (DbUpdateException) // unique index on IdempotencyKey raced
        {
            var winner = await _db.Campaigns.FirstAsync(c => c.IdempotencyKey == request.IdempotencyKey, ct);
            return Ok(new { duplicate = true, campaign = winner });
        }
        return Created($"/api/campaigns/{campaign.Id}", campaign);
    }

    [HttpPost("{id:guid}/launch")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Launch(Guid id, CancellationToken ct = default)
    {
        if (!await OwnsCampaignAsync(id, ct)) return NotFound();
        var result = await _launch.LaunchAsync(id, ct);
        if (!result.Success) return Conflict(new { error = result.Error });
        return Ok(result);
    }

    [HttpPost("{id:guid}/cancel")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct = default)
    {
        if (!await OwnsCampaignAsync(id, ct)) return NotFound();
        var campaign = await _db.Campaigns.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (campaign is null) return NotFound();
        if (campaign.Status is CampaignStatus.Completed or CampaignStatus.Cancelled) return Conflict(new { error = "Campaign already finished." });
        campaign.Status = CampaignStatus.Cancelled;
        campaign.CompletedAt = DateTimeOffset.UtcNow;
        var queued = await _db.CampaignRecipients.Where(r => r.CampaignId == id && r.Status == RecipientStatus.Queued).ToListAsync(ct);
        foreach (var r in queued) r.Status = RecipientStatus.Cancelled;
        await _db.SaveChangesAsync(ct);
        return Ok(new { cancelled = queued.Count });
    }

    private async Task<bool> OwnsCampaignAsync(Guid id, CancellationToken ct)
    {
        var campaign = await _db.Campaigns.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id, ct);
        if (campaign is null) return false;
        return _tenant.IsPlatformAdmin || campaign.OrganizationId == _tenant.OrganizationId;
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var orgId = CallerOrganizationId;
        var query = _db.Campaigns.AsNoTracking();
        if (!_tenant.IsPlatformAdmin)
            query = query.Where(c => c.OrganizationId == orgId || c.OrganizationId == null);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(c => c.CreatedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("{id:guid}/delivery")]
    public async Task<IActionResult> Delivery(Guid id, CancellationToken ct = default)
    {
        if (!await OwnsCampaignAsync(id, ct)) return NotFound();
        var summary = await _db.CampaignRecipients.AsNoTracking()
            .Where(r => r.CampaignId == id)
            .GroupBy(r => r.Status)
            .Select(g => new { Status = g.Key.ToString(), Count = g.Count() })
            .ToListAsync(ct);
        return Ok(new { campaignId = id, summary });
    }
}

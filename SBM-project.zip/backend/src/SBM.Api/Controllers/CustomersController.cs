using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Customers.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

/// <summary>Customer management. All rows are tenant-scoped by the global query filter — org id comes from the token.</summary>
[ApiController]
[Route("api/customers")]
[Authorize]
public class CustomersController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public CustomersController(SBM.Infrastructure.Persistence.SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateCustomerRequest(string Name, string Type, string? Email, string? Phone, string? Country, string? City, string? TaxIdentifier, string? Classification, string? Tags);

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? search = null, CancellationToken ct = default)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = TenantScope.Org(_db.Customers.AsNoTracking(), _tenant);
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(c => c.Name.Contains(search) || (c.Email != null && c.Email.Contains(search)) || (c.Phone != null && c.Phone.Contains(search)));
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(c => c.RegisteredAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == id, ct);
        return customer is null ? NotFound() : Ok(customer);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateCustomerRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name)) return ValidationProblem("Name is required.");
        var customer = new Customer
        {
            OrganizationId = orgId,
            Name = request.Name.Trim(),
            Type = Enum.TryParse<CustomerType>(request.Type, true, out var t) ? t : CustomerType.Company,
            Email = request.Email?.Trim(),
            Phone = request.Phone?.Trim(),
            Country = request.Country?.Trim(),
            City = request.City?.Trim(),
            TaxIdentifier = request.TaxIdentifier?.Trim(),
            Classification = request.Classification?.Trim(),
            Tags = request.Tags
        };
        _db.Customers.Add(customer);
        await _db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = customer.Id }, customer);
    }

    [HttpGet("{id:guid}/profile")]
    public async Task<IActionResult> Profile(Guid id, CancellationToken ct = default)
    {
        var customer = await TenantScope.Org(_db.Customers.AsNoTracking(), _tenant).FirstOrDefaultAsync(c => c.Id == id, ct);
        if (customer is null) return NotFound();
        var subscriptions = await _db.Subscriptions.AsNoTracking().CountAsync(s => s.OrganizationId == customer.OrganizationId && s.CustomerId == id, ct);
        var licenses = await _db.Licenses.AsNoTracking().CountAsync(l => l.OrganizationId == customer.OrganizationId && l.CustomerId == id, ct);
        var devices = await _db.LicenseDevices.AsNoTracking().CountAsync(d => d.OrganizationId == customer.OrganizationId && d.DeactivatedAt == null && _db.Licenses.Any(l => l.OrganizationId == customer.OrganizationId && l.Id == d.LicenseId && l.CustomerId == id), ct);
        var invoices = await _db.Invoices.AsNoTracking().Where(i => i.OrganizationId == customer.OrganizationId && i.CustomerId == id)
            .Select(i => new { i.Id, i.Number, i.Status, i.GrandTotal, i.AmountPaid, i.Currency }).ToListAsync(ct);
        var tickets = 0; // support module lands in Phase 5
        return Ok(new { customer, subscriptions, licenses, activeDevices = devices, invoices, supportTickets = tickets });
    }
}

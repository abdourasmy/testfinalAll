using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Identity.Entities;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly TokenService _tokens;
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;

    public AuthController(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn, TokenService tokens, SBM.Infrastructure.Persistence.SbmDbContext db)
    {
        _users = users;
        _signIn = signIn;
        _tokens = tokens;
        _db = db;
    }

    public sealed record LoginRequest(string Email, string Password);
    public sealed record RefreshRequest(string RefreshToken);
    public sealed record LogoutRequest(string RefreshToken);

    [HttpPost("login")]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken ct)
    {
        var user = await _users.FindByEmailAsync(request.Email);
        if (user is null)
        {
            await LogSecurityEvent(null, "login.failed", $"Unknown email {request.Email}");
            return Unauthorized(new { error = "Invalid credentials." });
        }
        var result = await _signIn.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: true);
        if (!result.Succeeded)
        {
            await LogSecurityEvent(user.Id, "login.failed", result.IsLockedOut ? "locked-out" : "bad-password");
            return Unauthorized(new { error = "Invalid credentials." });
        }
        if (user.DeactivatedAt is not null) return Unauthorized(new { error = "Account deactivated." });

        var roles = await _users.GetRolesAsync(user);
        var (access, refresh, expires) = await _tokens.IssueAsync(user, roles.ToList(), ct);
        await LogSecurityEvent(user.Id, "login.success", null);
        return Ok(new { accessToken = access, refreshToken = refresh, expiresAt = expires, user = new { user.Id, user.Email, user.DisplayName } });
    }

    [HttpPost("refresh")]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Refresh([FromBody] RefreshRequest request, CancellationToken ct)
    {
        var (ok, user, _) = await _tokens.ValidateRefreshAsync(request.RefreshToken, ct);
        if (!ok || user is null) return Unauthorized(new { error = "Refresh session invalid or revoked." });
        var roles = await _users.GetRolesAsync(user);
        var (access, refresh, expires) = await _tokens.IssueAsync(user, roles.ToList(), ct);
        return Ok(new { accessToken = access, refreshToken = refresh, expiresAt = expires });
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout([FromBody] LogoutRequest request, CancellationToken ct)
    {
        await _tokens.RevokeAsync(request.RefreshToken, ct);
        return NoContent();
    }

    [HttpGet("me")]
    [Microsoft.AspNetCore.Authorization.Authorize]
    public async Task<IActionResult> Me()
    {
        var user = await _users.GetUserAsync(User);
        if (user is null) return Unauthorized();
        var org = await _db.OrganizationMemberships
            .Where(m => m.UserId == user.Id && m.Status == "Active")
            .Select(m => m.OrganizationId)
            .FirstOrDefaultAsync();
        return Ok(new { user.Id, user.Email, user.DisplayName, scope = user.Scope.ToString(), organizationId = org == Guid.Empty ? (Guid?)null : org });
    }

    private async Task LogSecurityEvent(Guid? userId, string type, string? details)
    {
        _db.SecurityEvents.Add(new SecurityEvent
        {
            UserId = userId,
            EventType = type,
            Details = details,
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
        });
        await _db.SaveChangesAsync();
    }
}

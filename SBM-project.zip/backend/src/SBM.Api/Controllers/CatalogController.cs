using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/catalog")]
[Authorize]
public class CatalogController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    public CatalogController(SBM.Infrastructure.Persistence.SbmDbContext db) => _db = db;

    [HttpGet("products")]
    public async Task<IActionResult> Products([FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var total = await _db.Products.CountAsync(ct);
        var items = await _db.Products.OrderBy(p => p.Name).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("products/{id:guid}")]
    public async Task<IActionResult> Product(Guid id, CancellationToken ct = default)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id, ct);
        if (product is null) return NotFound();
        var applications = await _db.ProductApplications.Where(a => a.ProductId == id).ToListAsync(ct);
        var features = await _db.Features.Where(f => f.ProductId == id).ToListAsync(ct);
        var plans = await _db.PricingPlans.Where(p => p.ProductId == id).ToListAsync(ct);
        return Ok(new { product, applications, features, plans });
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

/// <summary>Owner Command Center metrics. Every metric is defined here explicitly; no fake financials.</summary>
[ApiController]
[Route("api/dashboard")]
[Authorize(Policy = "PlatformAdmin")]
public class DashboardController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;

    public DashboardController(SBM.Infrastructure.Persistence.SbmDbContext db) => _db = db;

    [HttpGet("summary")]
    public async Task<IActionResult> Summary(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var in30 = now.AddDays(30);
        var monthStart = new DateTimeOffset(now.Year, now.Month, 1, 0, 0, 0, TimeSpan.Zero);

        var totalCustomers = await _db.Customers.CountAsync(ct);
        var activeOrganizations = await _db.Organizations.CountAsync(o => o.Status == "Active", ct);
        var activeSubscriptions = await _db.Subscriptions.CountAsync(s => s.Status == SBM.Modules.Subscriptions.Entities.SubscriptionStatus.Active, ct);
        var expiringSubscriptions = await _db.Subscriptions.CountAsync(s => s.Status == SBM.Modules.Subscriptions.Entities.SubscriptionStatus.Active && s.CurrentPeriodEnd <= in30, ct);
        var activeLicenses = await _db.Licenses.CountAsync(l => l.State == SBM.Modules.Licensing.Entities.LicenseState.Active, ct);
        var revokedLicenses = await _db.Licenses.CountAsync(l => l.State == SBM.Modules.Licensing.Entities.LicenseState.Revoked, ct);
        var activeDevices = await _db.LicenseDevices.CountAsync(d => d.DeactivatedAt == null, ct);
        var liveSessions = await _db.LicenseSessions.CountAsync(s => s.RevokedAt == null && s.ExpiresAt > now, ct);
        var mrr = await _db.Subscriptions.Where(s => s.Status == SBM.Modules.Subscriptions.Entities.SubscriptionStatus.Active)
            .Join(_db.PricingPlans, s => s.PlanId, p => p.Id, (s, p) => p)
            .Where(p => p.Interval == SBM.Modules.Catalog.Entities.BillingInterval.Monthly)
            .SumAsync(p => p.Price, ct);
        var outstanding = await _db.Invoices.SumAsync(i => i.GrandTotal - i.AmountPaid, ct);
        var monthPayments = await _db.Payments.Where(p => p.Status == SBM.Modules.Billing.Entities.PaymentStatus.Confirmed && p.ConfirmedAt >= monthStart).SumAsync(p => p.Amount, ct);
        var monthExpenses = await _db.FinanceEntries.Where(e => e.OccurredAt >= monthStart && e.Type == SBM.Modules.Finance.Entities.FinanceEntryType.Expense).SumAsync(e => e.Amount, ct);
        var openSupportTickets = await _db.SupportTickets.CountAsync(t => t.Status != Modules.Support.Entities.TicketStatus.Resolved && t.Status != Modules.Support.Entities.TicketStatus.Closed, ct);
        var campaignCount = await _db.Campaigns.CountAsync(ct);

        return Ok(new
        {
            totalCustomers,
            activeOrganizations,
            activeSubscriptions,
            expiringSubscriptions,
            activeLicenses,
            revokedLicenses,
            activeDevices,
            liveSessions,
            monthlyRecurringRevenue = mrr,
            outstandingBalances = outstanding,
            monthConfirmedPayments = monthPayments,
            monthExpenses = monthExpenses,
            openSupportTickets,
            campaigns = campaignCount,
            metricDefinitions = new object[]
            {
                new { metric = "mrr", definition = "Sum of monthly plan price for all Active subscriptions whose plan interval is Monthly (snapshot, not cash-basis)." },
                new { metric = "outstandingBalances", definition = "Sum of (GrandTotal - AmountPaid) across all invoices." },
                new { metric = "liveSessions", definition = "License sessions with RevokedAt null and ExpiresAt in the future at query time." },
                new { metric = "expiringSubscriptions", definition = "Active subscriptions whose CurrentPeriodEnd is within 30 days." }
            }
        });
    }
}

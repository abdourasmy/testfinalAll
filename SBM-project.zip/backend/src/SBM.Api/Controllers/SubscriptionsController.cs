using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Subscriptions.Domain;
using SBM.Modules.Subscriptions.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/subscriptions")]
[Authorize]
public class SubscriptionsController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public SubscriptionsController(SBM.Infrastructure.Persistence.SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateSubscriptionRequest(Guid CustomerId, Guid ProductId, Guid PlanId, bool Trial);

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Create([FromBody] CreateSubscriptionRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var plan = await _db.PricingPlans.FirstOrDefaultAsync(p => p.Id == request.PlanId && p.ProductId == request.ProductId, ct);
        if (plan is null) return NotFound(new { error = "Plan not found." });

        var periodDays = plan.Interval switch
        {
            SBM.Modules.Catalog.Entities.BillingInterval.Monthly => 30,
            SBM.Modules.Catalog.Entities.BillingInterval.Quarterly => 90,
            SBM.Modules.Catalog.Entities.BillingInterval.Annual => 365,
            SBM.Modules.Catalog.Entities.BillingInterval.Custom => plan.CustomDurationDays ?? 30,
            _ => 30
        };
        var status = request.Trial && plan.TrialDays > 0 ? SubscriptionStatus.Trial : SubscriptionStatus.Active;
        var subscription = new Subscription
        {
            OrganizationId = orgId,
            CustomerId = request.CustomerId,
            ProductId = request.ProductId,
            PlanId = plan.Id,
            Status = status,
            Access = AccessMode.Full,
            GracePeriodDays = 7,
            CurrentPeriodStart = DateTimeOffset.UtcNow,
            CurrentPeriodEnd = DateTimeOffset.UtcNow.AddDays(request.Trial && plan.TrialDays > 0 ? plan.TrialDays : periodDays)
        };
        _db.Subscriptions.Add(subscription);
        _db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = orgId, SubscriptionId = subscription.Id, EventType = status == SubscriptionStatus.Trial ? "trial_started" : "activated" });
        await _db.SaveChangesAsync(ct);
        return Created($"/api/subscriptions/{subscription.Id}", subscription);
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] Guid? customerId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var query = TenantScope.Org(_db.Subscriptions.AsNoTracking(), _tenant);
        if (customerId.HasValue) query = query.Where(s => s.CustomerId == customerId);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(s => s.CurrentPeriodEnd).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    public sealed record CancelRequest(string Reason);

    [HttpPost("{id:guid}/cancel")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Cancel(Guid id, [FromBody] CancelRequest request, CancellationToken ct = default)
    {
        var subscription = await TenantScope.Org(_db.Subscriptions, _tenant).FirstOrDefaultAsync(s => s.Id == id, ct);
        if (subscription is null) return NotFound();
        SubscriptionStateMachine.EnsureTransition(subscription.Status, SubscriptionStatus.Cancelled);
        subscription.Status = SubscriptionStatus.Cancelled;
        subscription.CancelledAt = DateTimeOffset.UtcNow;
        subscription.CancellationReason = request.Reason?.Trim();
        subscription.Access = AccessMode.None;
        _db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = subscription.OrganizationId, SubscriptionId = subscription.Id, EventType = "cancelled", Details = request.Reason });
        await _db.SaveChangesAsync(ct);
        return NoContent();
    }

    /// <summary>Ops/background endpoint: applies the expiration policy to due subscriptions. Idempotent.</summary>
    [HttpPost("apply-expiration-policy")]
    [Authorize(Policy = "PlatformAdmin")]
    public async Task<IActionResult> ApplyExpirationPolicy(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var candidates = await _db.Subscriptions.Where(s => s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.PastDue || s.Status == SubscriptionStatus.GracePeriod).ToListAsync(ct);
        var changed = 0;
        foreach (var s in candidates)
        {
            var daysPast = (int)Math.Floor((now - s.CurrentPeriodEnd).TotalDays);
            var result = ExpirationPolicy.Evaluate(daysPast, s.GracePeriodDays);
            if (result.Status != s.Status || result.Access != s.Access)
            {
                if (SubscriptionStateMachine.CanTransition(s.Status, result.Status))
                {
                    s.Status = result.Status;
                    s.Access = result.Access;
                    changed++;
                    _db.SubscriptionEvents.Add(new SubscriptionEvent { OrganizationId = s.OrganizationId, SubscriptionId = s.Id, EventType = result.Status == SubscriptionStatus.GracePeriod ? "grace_started" : "expired", Details = $"daysPastExpiry={daysPast}" });
                }
            }
        }
        await _db.SaveChangesAsync(ct);
        return Ok(new { changed });
    }
}

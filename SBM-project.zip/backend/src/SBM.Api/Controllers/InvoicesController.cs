using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Services;
using SBM.Modules.Billing.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/invoices")]
[Authorize]
public class InvoicesController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly InvoiceNumberingService _numbering;
    private readonly PaymentService _payments;
    private readonly ITenantContext _tenant;

    public InvoicesController(SBM.Infrastructure.Persistence.SbmDbContext db, InvoiceNumberingService numbering, PaymentService payments, ITenantContext tenant)
    {
        _db = db;
        _numbering = numbering;
        _payments = payments;
        _tenant = tenant;
    }

    public sealed record CreateInvoiceItem(string Description, int Quantity, decimal UnitPrice, decimal DiscountPercent, decimal TaxPercent);
    public sealed record CreateInvoiceRequest(Guid CustomerId, string? Prefix, string? FinancialYear, string Currency, List<CreateInvoiceItem> Items, DateTimeOffset? DueAt);

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Create([FromBody] CreateInvoiceRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        if (request.Items is null || request.Items.Count == 0) return ValidationProblem("At least one item is required.");
        var currency = (request.Currency ?? "EGP").ToUpperInvariant();

        var number = await _numbering.NextNumberAsync(orgId, request.Prefix ?? "INV", request.FinancialYear ?? DateTimeOffset.UtcNow.Year.ToString(), ct);
        var invoice = new Invoice
        {
            OrganizationId = orgId,
            CustomerId = request.CustomerId,
            Number = number,
            Prefix = (request.Prefix ?? "INV").ToUpperInvariant(),
            FinancialYear = request.FinancialYear ?? DateTimeOffset.UtcNow.Year.ToString(),
            Status = InvoiceStatus.Issued,
            IssuedAt = DateTimeOffset.UtcNow,
            DueAt = request.DueAt,
            Currency = currency
        };

        decimal subTotal = 0m, taxTotal = 0m, discountTotal = 0m;
        foreach (var item in request.Items)
        {
            var line = new InvoiceItem
            {
                OrganizationId = orgId,
                InvoiceId = invoice.Id,
                Description = item.Description?.Trim() ?? "Item",
                Quantity = Math.Max(1, item.Quantity),
                UnitPrice = item.UnitPrice,
                DiscountPercent = item.DiscountPercent,
                TaxPercent = item.TaxPercent,
                Currency = currency
            };
            subTotal += line.LineNet;
            taxTotal += line.LineTax;
            discountTotal += decimal.Round(line.Quantity * line.UnitPrice * line.DiscountPercent / 100m, 2, MidpointRounding.AwayFromZero);
            _db.InvoiceItems.Add(line);
        }

        invoice.SubTotal = subTotal;
        invoice.TaxTotal = taxTotal;
        invoice.DiscountTotal = discountTotal;
        invoice.GrandTotal = subTotal + taxTotal;
        _db.Invoices.Add(invoice);
        await _db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = invoice.Id }, invoice);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var invoice = await TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant).FirstOrDefaultAsync(i => i.Id == id, ct);
        if (invoice is null) return NotFound();
        var items = await _db.InvoiceItems.AsNoTracking().Where(i => i.OrganizationId == invoice.OrganizationId && i.InvoiceId == id).ToListAsync(ct);
        var payments = await _db.Payments.AsNoTracking().Where(p => p.OrganizationId == invoice.OrganizationId && p.InvoiceId == id).ToListAsync(ct);
        return Ok(new { invoice, items, payments });
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] Guid? customerId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var query = TenantScope.Org(_db.Invoices.AsNoTracking(), _tenant);
        if (customerId.HasValue) query = query.Where(i => i.CustomerId == customerId);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(i => i.IssuedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    public sealed record ConfirmPaymentRequest(Guid InvoiceId, decimal Amount, string Currency, string Method, string? ProviderReference, string IdempotencyKey, bool ConfirmedByProvider);

    [HttpPost("payments/confirm")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> ConfirmPayment([FromBody] ConfirmPaymentRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        if (string.IsNullOrWhiteSpace(request.IdempotencyKey)) return ValidationProblem("IdempotencyKey is required.");
        var outcome = await _payments.ProcessConfirmationAsync(new PaymentConfirmation(
            orgId, request.InvoiceId, request.Amount, (request.Currency ?? "EGP").ToUpperInvariant(),
            request.Method ?? "Manual", request.ProviderReference, request.IdempotencyKey, request.ConfirmedByProvider), ct);
        return Ok(outcome);
    }
}



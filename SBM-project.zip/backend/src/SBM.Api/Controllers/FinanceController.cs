using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Finance.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/finance")]
[Authorize]
public class FinanceController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public FinanceController(SBM.Infrastructure.Persistence.SbmDbContext db, ITenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateEntryRequest(string Type, string Category, string? Description, decimal Amount, string Currency, string? PaymentMethod, string? Account, string? Reference, string? ExternalRef);

    [HttpPost("entries")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> CreateEntry([FromBody] CreateEntryRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        if (!Enum.TryParse<FinanceEntryType>(request.Type, true, out var type)) return ValidationProblem("Type must be Income, Expense, Adjustment or Reversal.");
        if (request.Amount <= 0) return ValidationProblem("Amount must be positive.");
        if (string.IsNullOrWhiteSpace(request.Category)) return ValidationProblem("Category is required.");
        if (!string.IsNullOrWhiteSpace(request.ExternalRef) && await _db.FinanceEntries.AnyAsync(e => e.ExternalRef == request.ExternalRef, ct))
            return Conflict(new { error = "Duplicate ExternalRef; entry already recorded." });

        var entry = new FinanceEntry
        {
            OrganizationId = orgId,
            Type = type,
            Category = request.Category.Trim(),
            Description = request.Description?.Trim(),
            Amount = decimal.Round(request.Amount, 2, MidpointRounding.AwayFromZero),
            Currency = (request.Currency ?? "EGP").ToUpperInvariant(),
            PaymentMethod = request.PaymentMethod?.Trim() ?? "BankTransfer",
            Account = request.Account?.Trim(),
            Reference = request.Reference?.Trim(),
            ExternalRef = string.IsNullOrWhiteSpace(request.ExternalRef) ? null : request.ExternalRef.Trim(),
            CreatedByUserId = _tenant.UserId
        };
        _db.FinanceEntries.Add(entry);
        await _db.SaveChangesAsync(ct);
        return Created($"/api/finance/entries/{entry.Id}", entry);
    }

    public sealed record ReverseEntryRequest(string Reason);

    [HttpPost("entries/{id:guid}/reverse")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> ReverseEntry(Guid id, [FromBody] ReverseEntryRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var original = await TenantScope.Org(_db.FinanceEntries, _tenant).FirstOrDefaultAsync(e => e.Id == id, ct);
        if (original is null) return NotFound();
        var reversal = new FinanceEntry
        {
            OrganizationId = orgId,
            Type = FinanceEntryType.Reversal,
            Category = original.Category,
            Description = $"Reversal of {original.Id}: {request.Reason}",
            Amount = original.Amount,
            Currency = original.Currency,
            PaymentMethod = original.PaymentMethod,
            Account = original.Account,
            Reference = original.Reference,
            ReversalOfEntryId = original.Id,
            CreatedByUserId = _tenant.UserId
        };
        _db.FinanceEntries.Add(reversal); // original is untouched — append-only
        await _db.SaveChangesAsync(ct);
        return Ok(reversal);
    }

    [HttpGet("entries")]
    public async Task<IActionResult> List([FromQuery] DateTimeOffset? from, [FromQuery] DateTimeOffset? to, [FromQuery] string? type, [FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 200);
        var query = TenantScope.Org(_db.FinanceEntries.AsNoTracking(), _tenant).AsQueryable();
        if (from.HasValue) query = query.Where(e => e.OccurredAt >= from);
        if (to.HasValue) query = query.Where(e => e.OccurredAt <= to);
        if (Enum.TryParse<FinanceEntryType>(type, true, out var t)) query = query.Where(e => e.Type == t);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(e => e.OccurredAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpGet("summary")]
    public async Task<IActionResult> Summary([FromQuery] DateTimeOffset? from, [FromQuery] DateTimeOffset? to, CancellationToken ct = default)
    {
        var query = TenantScope.Org(_db.FinanceEntries.AsNoTracking(), _tenant).AsQueryable();
        if (from.HasValue) query = query.Where(e => e.OccurredAt >= from);
        if (to.HasValue) query = query.Where(e => e.OccurredAt <= to);
        var grouped = await query.GroupBy(e => e.Type)
            .Select(g => new { Type = g.Key.ToString(), Total = g.Sum(e => e.Amount), Count = g.Count() })
            .ToListAsync(ct);
        decimal Sum(string type) => grouped.FirstOrDefault(g => g.Type == type)?.Total ?? 0m;
        // Reversals offset their type implicitly by convention: report gross and net figures.
        var income = Sum("Income");
        var expenses = Sum("Expense");
        var reversals = Sum("Reversal");
        var adjustments = Sum("Adjustment");
        return Ok(new { income, expenses, adjustments, reversals, grossMargin = income - expenses, byType = grouped });
    }
}

using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Modules.Notifications.Audience;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/audiences")]
[Authorize]
public class AudiencesController : ControllerBase
{
    private readonly AudienceCandidateProjector _projector;
    private readonly ITenantContext _tenant;
    private readonly SbmDbContext _db;

    public AudiencesController(AudienceCandidateProjector projector, ITenantContext tenant, SbmDbContext db)
    {
        _projector = projector;
        _tenant = tenant;
        _db = db;
    }

    public sealed record ValidateRequest(string DocumentJson);
    public sealed record PreviewRequest(string DocumentJson, int MaxRecipients);

    [HttpPost("validate")]
    public IActionResult Validate([FromBody] ValidateRequest request)
    {
        var doc = ParseDocument(request.DocumentJson, out var error);
        if (doc is null) return BadRequest(new { error });
        AudienceValidator.Validate(doc); // throws AudienceValidationException -> 400 with errors
        return Ok(new { valid = true, ruleVersion = doc.Version });
    }

    [HttpPost("preview")]
    public async Task<IActionResult> Preview([FromBody] PreviewRequest request, CancellationToken ct = default)
    {
        var doc = ParseDocument(request.DocumentJson, out var error);
        if (doc is null) return BadRequest(new { error });
        AudienceValidator.Validate(doc);

        // Platform admins preview across the platform; org users preview their own tenant only.
        var orgId = _tenant.IsPlatformAdmin ? (Guid?)null : _tenant.OrganizationId;
        var candidates = await _projector.ProjectAsync(orgId, AudienceCandidateProjector.PreviewCap, ct);
        var matched = candidates.Where(c => AudienceEvaluator.Evaluate(doc.Root, c)).ToList();
        var cap = Math.Clamp(request.MaxRecipients <= 0 ? 25 : request.MaxRecipients, 1, 100);
        return Ok(new
        {
            sampleSize = candidates.Count,
            matchedInSample = matched.Count,
            estimatedRecipients = matched.Count, // estimate over the preview sample; full dispatch materializes at launch
            sample = matched.Take(cap).Select(m => new
            {
                m.EntityId,
                m.CustomerType,
                m.CustomerStatus,
                m.OrganizationId,
                m.SubscriptionStatus,
                m.LicenseState,
                m.AppVersion,
                m.LastActivityAt
            }),
            note = "Preview sample is capped; launch materializes the full recipient set with dedup, opt-out, quiet hours and frequency caps applied."
        });
    }

    public sealed record TopNPreviewRequest(string RankBy, string? OrderBy, bool Descending, int N, string? PreFilterJson);

    [HttpPost("topn-preview")]
    public async Task<IActionResult> TopNPreview([FromBody] TopNPreviewRequest request, CancellationToken ct = default)
    {
        if (request.N is <= 0 or > TopNRequest.MaxN) return ValidationProblem($"N must be between 1 and {TopNRequest.MaxN}.");
        var orgId = _tenant.IsPlatformAdmin ? (Guid?)null : _tenant.OrganizationId;
        var candidates = await _projector.ProjectAsync(orgId, AudienceCandidateProjector.DispatchCap, ct);

        AudienceDocument? preFilter = null;
        if (!string.IsNullOrWhiteSpace(request.PreFilterJson))
        {
            preFilter = ParseDocument(request.PreFilterJson, out var error);
            if (preFilter is null) return BadRequest(new { error });
        }
        var req = new TopNRequest(RankedEntity.Customer, request.OrderBy ?? "customer.registeredAt", request.Descending, request.N, preFilter);
        var selected = TopNSelector.Select(req, candidates);
        return Ok(new
        {
            entity = req.Entity.ToString(),
            orderBy = req.OrderBy,
            descending = req.Descending,
            requested = req.N,
            selected = selected.Count,
            sample = selected.Take(25).Select(s => new { s.EntityId, s.CustomerRegisteredAt, s.LastPurchaseAt, s.LastActivityAt })
        });
    }

    private static AudienceDocument? ParseDocument(string json, out string? error)
    {
        error = null;
        try
        {
            var doc = JsonSerializer.Deserialize<AudienceDocument>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = false });
            if (doc is null) { error = "Empty rule document."; return null; }
            return doc;
        }
        catch (JsonException ex)
        {
            error = $"Rule document is not valid JSON: {ex.Message}";
            return null;
        }
    }
}

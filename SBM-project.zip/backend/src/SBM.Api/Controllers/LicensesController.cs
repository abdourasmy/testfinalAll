using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SBM.Infrastructure.Services;
using SBM.Modules.Licensing.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api.Controllers;

[ApiController]
[Route("api/licenses")]
[Authorize]
public class LicensesController : ControllerBase
{
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly LicenseAppService _licenseService;
    private readonly ITenantContext _tenant;

    public LicensesController(SBM.Infrastructure.Persistence.SbmDbContext db, LicenseAppService licenseService, ITenantContext tenant)
    {
        _db = db;
        _licenseService = licenseService;
        _tenant = tenant;
    }

    public sealed record IssueLicenseRequest(Guid CustomerId, Guid ProductId, Guid ApplicationId, Guid PlanId, int ValidDays);
    public sealed record ActivateRequest(string DeviceId, string DeviceName, string Platform);
    public sealed record TransferRequest(Guid TargetCustomerId);
    public sealed record RevokeRequest(string Reason);

    [HttpPost]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Issue([FromBody] IssueLicenseRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var plan = await _db.PricingPlans.FirstOrDefaultAsync(p => p.Id == request.PlanId && p.ProductId == request.ProductId, ct);
        if (plan is null) return NotFound(new { error = "Plan not found for product." });

        var license = new License
        {
            OrganizationId = orgId,
            CustomerId = request.CustomerId,
            ProductId = request.ProductId,
            ApplicationId = request.ApplicationId,
            PlanId = plan.Id,
            Type = LicenseType.Hybrid,
            DeviceLimit = plan.DeviceLimit,
            SessionLimit = plan.SessionLimit,
            IssuedAt = DateTimeOffset.UtcNow,
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(Math.Clamp(request.ValidDays <= 0 ? 30 : request.ValidDays, 1, 3650))
        };
        _db.Licenses.Add(license);
        _db.LicenseEvents.Add(new LicenseEvent { OrganizationId = orgId, LicenseId = license.Id, EventType = "issued", Details = $"Plan {plan.Code}" });
        await _db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = license.Id }, license);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var license = await TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant).FirstOrDefaultAsync(l => l.Id == id, ct);
        return license is null ? NotFound() : Ok(license);
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] Guid? customerId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var query = TenantScope.Org(_db.Licenses.AsNoTracking(), _tenant);
        if (customerId.HasValue) query = query.Where(l => l.CustomerId == customerId);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(l => l.IssuedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new { total, page, pageSize, items });
    }

    [HttpPost("{id:guid}/activate")]
    public async Task<IActionResult> Activate(Guid id, [FromBody] ActivateRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var result = await _licenseService.ActivateDeviceAsync(orgId, id, request.DeviceId, request.DeviceName, request.Platform, ct);
        if (!result.Success) return Conflict(new { error = result.Error, result.ActiveDevices, result.DeviceLimit });
        return Ok(result);
    }

    [HttpPost("{id:guid}/devices/{deviceId}/deactivate")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Deactivate(Guid id, string deviceId, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var ok = await _licenseService.DeactivateDeviceAsync(orgId, id, deviceId, ct);
        return ok ? NoContent() : NotFound();
    }

    public sealed record StartSessionRequest(string DeviceId, Guid? UserId, Guid ApplicationId);

    [HttpPost("{id:guid}/sessions")]
    public async Task<IActionResult> StartSession(Guid id, [FromBody] StartSessionRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var result = await _licenseService.StartSessionAsync(orgId, id, request.DeviceId, request.UserId, request.ApplicationId, ct: ct);
        if (!result.Success) return Conflict(new { error = result.Error, result.LiveSessions, result.SessionLimit });
        return Ok(result);
    }

    public sealed record SessionHeartbeatRequest(Guid SessionId);

    [HttpPost("sessions/heartbeat")]
    public async Task<IActionResult> Heartbeat([FromBody] SessionHeartbeatRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var result = await _licenseService.HeartbeatAsync(orgId, request.SessionId, ct: ct);
        if (!result.Success) return Conflict(new { error = result.Error });
        return Ok(result);
    }

    [HttpPost("{id:guid}/transfer")]
    public async Task<IActionResult> Transfer(Guid id, [FromBody] TransferRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var result = await _licenseService.RequestTransferAsync(orgId, id, request.TargetCustomerId, _tenant.UserId ?? Guid.Empty, ct);
        if (!result.Success)
            return result.RequiresApproval
                ? Accepted(new { error = result.Error, requiresApproval = true })
                : Conflict(new { error = result.Error });
        return Ok(result);
    }

    [HttpPost("{id:guid}/revoke")]
    [Authorize(Policy = "OrgManager")]
    public async Task<IActionResult> Revoke(Guid id, [FromBody] RevokeRequest request, CancellationToken ct = default)
    {
        if (_tenant.OrganizationId is not { } orgId) return Forbid();
        var ok = await _licenseService.RevokeAsync(orgId, id, request.Reason ?? "manual", _tenant.UserId, ct);
        return ok ? NoContent() : NotFound();
    }
}

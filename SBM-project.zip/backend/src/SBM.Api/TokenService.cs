using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using SBM.Modules.Identity.Entities;
using SBM.Shared.Abstractions;

namespace SBM.Api;

/// <summary>JWT access tokens (short-lived) + opaque refresh sessions (rotated, revocable server-side).</summary>
public sealed class TokenService
{
    private readonly IConfiguration _config;
    private readonly SBM.Infrastructure.Persistence.SbmDbContext _db;
    private readonly ITenantContext _tenant;

    public TokenService(IConfiguration config, SBM.Infrastructure.Persistence.SbmDbContext db, ITenantContext tenant)
    {
        _config = config;
        _db = db;
        _tenant = tenant;
    }

    private string Key => _config["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is not configured. Set environment variable Jwt__Key.");
    private string Issuer => _config["Jwt:Issuer"] ?? "sbm";
    private string Audience => _config["Jwt:Audience"] ?? "sbm-api";
    private int AccessMinutes => int.TryParse(_config["Jwt:AccessTokenMinutes"], out var m) ? m : 15;
    private int RefreshDays => int.TryParse(_config["Jwt:RefreshTokenDays"], out var d) ? d : 14;

    public async Task<(string AccessToken, string RefreshToken, DateTimeOffset ExpiresAt)> IssueAsync(ApplicationUser user, IList<string> roles, CancellationToken ct = default)
    {
        var orgId = await _db.OrganizationMemberships
            .Where(m => m.UserId == user.Id && m.Status == "Active")
            .OrderBy(m => m.JoinedAt)
            .Select(m => (Guid?)m.OrganizationId)
            .FirstOrDefaultAsync(ct);

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.UserName ?? user.Email ?? user.Id.ToString()),
            new("scope", user.Scope == AccountScope.Platform ? "platform" : "organization"),
        };
        if (orgId.HasValue) claims.Add(new Claim("org_id", orgId.Value.ToString()));
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var now = DateTimeOffset.UtcNow;
        var expires = now.AddMinutes(AccessMinutes);
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Key));
        var token = new JwtSecurityToken(
            Issuer, Audience, claims, now.UtcDateTime, expires.UtcDateTime,
            new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        var refreshToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        _db.UserSessions.Add(new UserSession
        {
            UserId = user.Id,
            RefreshTokenHash = HashToken(refreshToken),
            ExpiresAt = now.AddDays(RefreshDays),
            DeviceDescription = "interactive-login"
        });
        await _db.SaveChangesAsync(ct);
        return (new JwtSecurityTokenHandler().WriteToken(token), refreshToken, expires);
    }

    public async Task<(bool Success, ApplicationUser? User, List<string> Roles)> ValidateRefreshAsync(string refreshToken, CancellationToken ct = default)
    {
        var hash = HashToken(refreshToken);
        var session = await _db.UserSessions.FirstOrDefaultAsync(s => s.RefreshTokenHash == hash, ct);
        if (session is null || !session.IsActive)
            return (false, null, new());
        var user = await _db.Users.FindAsync(new object?[] { session.UserId }, ct);
        if (user is null || user.DeactivatedAt is not null)
            return (false, null, new());
        // Rotate: revoke old session.
        session.RevokedAt = DateTimeOffset.UtcNow;
        session.RevokedReason = "rotated";
        session.LastUsedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);
        return (true, user, new List<string>()); // roles re-resolved in controller via UserManager
    }

    public async Task RevokeAsync(string refreshToken, CancellationToken ct = default)
    {
        var hash = HashToken(refreshToken);
        var session = await _db.UserSessions.FirstOrDefaultAsync(s => s.RefreshTokenHash == hash, ct);
        if (session is not null && session.RevokedAt is null)
        {
            session.RevokedAt = DateTimeOffset.UtcNow;
            session.RevokedReason = "logout";
            await _db.SaveChangesAsync(ct);
        }
    }

    public static string HashToken(string token) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
}

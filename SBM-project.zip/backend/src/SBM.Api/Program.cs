using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using SBM.Api;
using SBM.Infrastructure.Middleware;
using SBM.Infrastructure.Persistence;
using SBM.Infrastructure.Services;
using SBM.Shared.Abstractions;

var builder = WebApplication.CreateBuilder(args);

// ---------- Configuration ----------
var jwtKey = builder.Configuration["Jwt:Key"];
if (string.IsNullOrWhiteSpace(jwtKey))
    builder.Configuration["Jwt:Key"] = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(48)); // dev fallback; prod must set env var

builder.Services.AddDbContext<SbmDbContext>((sp, options) =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("SbmDatabase")
        ?? "Server=(localdb)\\MSSQLLocalDB;Database=SBM;Trusted_Connection=True;TrustServerCertificate=True;",
        sql => sql.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null)));

builder.Services.AddIdentity<SBM.Modules.Identity.Entities.ApplicationUser, IdentityRole<Guid>>(options =>
    {
        options.Password.RequiredLength = 10;
        options.Password.RequireNonAlphanumeric = true;
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.SignIn.RequireConfirmedEmail = false; // confirmed via organization invitation flow
    })
    .AddEntityFrameworkStores<SbmDbContext>()
    .AddDefaultTokenProviders();

builder.Services.AddAuthentication(options =>
    {
        // AddIdentity registers the application cookie as the default scheme; force JWT Bearer everywhere.
        options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultForbidScheme = JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"] ?? "sbm",
            ValidateAudience = true,
            ValidAudience = builder.Configuration["Jwt:Audience"] ?? "sbm-api",
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1)
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("PlatformAdmin", p => p.RequireRole("PlatformAdmin"));
    options.AddPolicy("OrgManager", p => p.RequireAssertion(ctx =>
        ctx.User.HasClaim(c => c.Type == "scope" && c.Value == "platform" && ctx.User.IsInRole("PlatformAdmin"))
        || ctx.User.IsInRole("Owner") || ctx.User.IsInRole("Manager")));
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ITenantContext, HttpTenantContext>();
builder.Services.AddScoped<TokenService>();
builder.Services.AddScoped<InvoiceNumberingService>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddScoped<LicenseAppService>();
builder.Services.AddScoped<AudienceCandidateProjector>();
builder.Services.AddScoped<CampaignLaunchService>();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<SBM.Modules.Notifications.Delivery.INotificationProvider, LoggingNotificationProvider>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHealthChecks()
    .AddDbContextCheck<SbmDbContext>("database", tags: new[] { "ready" });

// Restrictive CORS: configure allowed origins via config; deny all by default.
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(options => options.AddDefaultPolicy(policy =>
{
    if (allowedOrigins.Length == 0)
        policy.AllowAnyHeader().AllowAnyMethod().WithOrigins("http://localhost:5173", "http://localhost:5080");
    else
        policy.WithOrigins(allowedOrigins).AllowAnyHeader().AllowAnyMethod().AllowCredentials();
}));

// Rate limiting on sensitive endpoints.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("auth", httpContext => RateLimitPartition.GetFixedWindowLimiter(
        httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1) }));
    options.AddPolicy("api", httpContext => RateLimitPartition.GetFixedWindowLimiter(
        httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 600, Window = TimeSpan.FromMinutes(1) }));
});

var app = builder.Build();

// ---------- Startup: migrate + seed (development) ----------
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var db = services.GetRequiredService<SbmDbContext>();
    if (app.Configuration.GetValue<bool>("Database:ApplyMigrationsOnStartup") || app.Environment.IsDevelopment())
    {
        try { await db.Database.MigrateAsync(); }
        catch (Exception ex)
        {
            app.Logger.LogWarning(ex, "Automatic migration failed; apply migrations manually (see docs/deployment).");
        }
    }
    if (app.Configuration.GetValue("Seed:Enable", app.Environment.IsDevelopment()))
    {
        try
        {
            var users = services.GetRequiredService<UserManager<SBM.Modules.Identity.Entities.ApplicationUser>>();
            var roles = services.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
            await DbSeeder.SeedAsync(db, users, roles, app.Configuration);
        }
        catch (Exception ex) { app.Logger.LogWarning(ex, "Seeding skipped or failed."); }
    }
}

app.UseMiddleware<ExceptionHandlingMiddleware>();

// Security headers.
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
    ctx.Response.Headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'";
    await next();
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

app.MapHealthChecks("/health");
app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready")
});

app.MapControllers().RequireRateLimiting("api");

await app.RunAsync();

public partial class Program { }

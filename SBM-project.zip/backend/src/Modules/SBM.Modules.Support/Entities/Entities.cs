using SBM.Shared.Abstractions;

namespace SBM.Modules.Support.Entities;

public enum TicketPriority { Low = 0, Normal = 1, High = 2, Urgent = 3 }
public enum TicketStatus { Open = 0, InProgress = 1, OnHold = 2, Resolved = 3, Closed = 4 }
public enum TicketCategory { General = 0, Billing = 1, Technical = 2, Licensing = 3 }
public enum CommentVisibility { Customer = 0, Internal = 1 }

public class SupportTicket : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid? CustomerId { get; set; }           // optional link to account
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public TicketCategory Category { get; set; } = TicketCategory.General;
    public TicketPriority Priority { get; set; } = TicketPriority.Normal;
    public TicketStatus Status { get; set; } = TicketStatus.Open;
    public Guid? AssignedToUserId { get; set; }
    public Guid CreatedByUserId { get; set; }
    public DateTimeOffset? SlaDueAt { get; set; }
    public DateTimeOffset? ResolvedAt { get; set; }

    public static TimeSpan DefaultSla(TicketPriority priority) => priority switch
    {
        TicketPriority.Urgent => TimeSpan.FromHours(4),
        TicketPriority.High => TimeSpan.FromHours(24),
        TicketPriority.Normal => TimeSpan.FromHours(72),
        _ => TimeSpan.FromHours(168)
    };
}

public class TicketComment : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid TicketId { get; set; }
    public Guid? AuthorUserId { get; set; }
    public string Body { get; set; } = string.Empty;
    public CommentVisibility Visibility { get; set; } = CommentVisibility.Customer;
}

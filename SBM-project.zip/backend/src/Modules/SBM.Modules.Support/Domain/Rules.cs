using SBM.Modules.Support.Entities;

namespace SBM.Modules.Support.Domain;

/// <summary>Support ticket state machine. Resolved → Closed is final from the customer side; reopen goes Resolved → InProgress.</summary>
public static class TicketStateMachine
{
    private static readonly Dictionary<TicketStatus, TicketStatus[]> Allowed = new()
    {
        [TicketStatus.Open] = new[] { TicketStatus.InProgress, TicketStatus.OnHold, TicketStatus.Resolved, TicketStatus.Closed },
        [TicketStatus.InProgress] = new[] { TicketStatus.OnHold, TicketStatus.Resolved, TicketStatus.Closed },
        [TicketStatus.OnHold] = new[] { TicketStatus.InProgress, TicketStatus.Resolved, TicketStatus.Closed },
        [TicketStatus.Resolved] = new[] { TicketStatus.Closed, TicketStatus.InProgress }, // reopen via InProgress
        [TicketStatus.Closed] = Array.Empty<TicketStatus>(), // terminal
    };

    public static bool CanTransition(TicketStatus from, TicketStatus to) =>
        Allowed.TryGetValue(from, out var targets) && targets.Contains(to);

    public static void EnsureTransition(TicketStatus from, TicketStatus to)
    {
        if (!CanTransition(from, to))
            throw new InvalidOperationException($"Illegal ticket state transition {from} -> {to}.");
    }
}

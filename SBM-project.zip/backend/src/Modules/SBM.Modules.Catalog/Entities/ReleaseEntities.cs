using SBM.Shared.Abstractions;

namespace SBM.Modules.Catalog.Entities;

public enum ReleaseStatus { Draft = 0, Published = 1, Yanked = 2 }

/// <summary>Platform-level software release for a ProductApplication (e.g. Repair Center Pro Desktop 2.1.0).
/// Not tenant-scoped: releases are published by the platform owner to all eligible customers.</summary>
public class SoftwareRelease : AggregateRoot<Guid>
{
    public string ProductCode { get; set; } = string.Empty;
    public string ApplicationCode { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;       // SemVer
    public string Channel { get; set; } = "Stable";            // Stable | Beta | Nightly
    public string? ReleaseNotes { get; set; }
    public string? MinimumSupportedVersion { get; set; }
    public ReleaseStatus Status { get; set; } = ReleaseStatus.Draft;
    public DateTimeOffset? PublishedAt { get; set; }
    public DateTimeOffset? YankedAt { get; set; }
    public string? YankReason { get; set; }
    public Guid? CreatedByUserId { get; set; }
}

/// <summary>Downloadable asset belonging to a release. Content is stored on disk outside the web root;
/// SHA-256 is computed server-side at registration time.</summary>
public class ReleaseAsset : AggregateRoot<Guid>
{
    public Guid ReleaseId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = "application/octet-stream";
    public long SizeBytes { get; set; }
    public string Sha256 { get; set; } = string.Empty; // lowercase hex
    public string StoragePath { get; set; } = string.Empty; // absolute path (server-side only)
}

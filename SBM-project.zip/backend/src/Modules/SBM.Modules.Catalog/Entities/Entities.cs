using System.Collections.Generic;
using SBM.Shared.Abstractions;

namespace SBM.Modules.Catalog.Entities;

public enum ProductStatus { Draft = 0, Active = 1, Deprecated = 2, Retired = 3 }

public class Product : AggregateRoot<Guid>
{
    public string Code { get; set; } = string.Empty; // stable machine code, e.g. "REPAIR-PRO"
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Category { get; set; } = "Management"; // POS | Cashier | Inventory | Accounting | RepairCenter | Management
    public ProductStatus Status { get; set; } = ProductStatus.Draft;
    public string? BrandingJson { get; set; } // flexible branding payload (colors, logo path); versioned by Release
}

public enum ApplicationStatus { Draft = 0, Active = 1, Beta = 2, Deprecated = 3 }

public class ProductApplication : AggregateRoot<Guid>
{
    public Guid ProductId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = "Desktop"; // Desktop | Mobile | Web | POS | Cashier ...
    public List<string> Platforms { get; set; } = new(); // Windows | Android | iOS | Web
    public ApplicationStatus Status { get; set; } = ApplicationStatus.Draft;
    public string ReleaseChannel { get; set; } = "Stable"; // Stable | Beta | Internal | custom
    public string? MinimumSupportedVersion { get; set; }
    public string? CurrentVersion { get; set; }
    public string? BrandingJson { get; set; }
}

public class Feature : AggregateRoot<Guid>
{
    public Guid ProductId { get; set; }
    public string Code { get; set; } = string.Empty; // e.g. "INVOICING.BASIC"
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public List<string> Dependencies { get; set; } = new(); // codes of features this feature depends on
}

public enum BillingInterval { Monthly = 0, Quarterly = 1, Annual = 2, Custom = 3, OneTime = 4 }

public class PricingPlan : AggregateRoot<Guid>
{
    public Guid ProductId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public BillingInterval Interval { get; set; } = BillingInterval.Monthly;
    public int? CustomDurationDays { get; set; } // when Interval == Custom
    public decimal Price { get; set; }
    public string Currency { get; set; } = "EGP";
    public int DeviceLimit { get; set; } = 1;   // plan policy, never hardcoded globally
    public int SessionLimit { get; set; } = 1;  // concurrent sessions, independent of devices
    public bool IsTrial { get; set; }
    public int TrialDays { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Entitlement: which features a plan grants.</summary>
public class PlanFeature : AggregateRoot<Guid>
{
    public Guid PlanId { get; set; }
    public Guid FeatureId { get; set; }
}

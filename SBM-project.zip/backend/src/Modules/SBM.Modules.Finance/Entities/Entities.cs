using SBM.Shared.Abstractions;

namespace SBM.Modules.Finance.Entities;

/// <summary>
/// Append-only operational journal. Corrections are reversal/adjustment entries referencing
/// the original entry — historical rows are never silently modified.
/// NOTE: This is an operational ledger, not a certified accounting system; it does not claim
/// compliance with any formal accounting standard or tax e-invoicing regime.
/// </summary>
public enum FinanceEntryType { Income = 0, Expense = 1, Adjustment = 2, Reversal = 3 }

public class FinanceEntry : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public FinanceEntryType Type { get; set; }
    public string Category { get; set; } = string.Empty;
    public string? Description { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "EGP";
    public string PaymentMethod { get; set; } = "BankTransfer";
    public string? Account { get; set; } // cash/bank account identifier
    public string? Reference { get; set; } // invoice number, provider ref, ...
    public Guid? ReversalOfEntryId { get; set; }
    public string? ExternalRef { get; set; } // idempotency / dedup
    public Guid? CreatedByUserId { get; set; }
    public DateTimeOffset OccurredAt { get; set; } = DateTimeOffset.UtcNow;
}

public class FinanceAccount : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = "Bank"; // Cash | Bank
    public string Currency { get; set; } = "EGP";
    public decimal OpeningBalance { get; set; }
    public bool IsActive { get; set; } = true;
}

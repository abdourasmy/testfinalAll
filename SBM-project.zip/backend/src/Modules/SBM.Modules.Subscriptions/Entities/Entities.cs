using SBM.Shared.Abstractions;

namespace SBM.Modules.Subscriptions.Entities;

public enum SubscriptionStatus { Trial = 0, Active = 1, PastDue = 2, GracePeriod = 3, Suspended = 4, Expired = 5, Cancelled = 6 }

/// <summary>Capability mode the customer experiences. After grace ends, entitlements fall back
/// to ReadOnly where the product supports it; customer data is never deleted automatically.</summary>
public enum AccessMode { None = 0, ReadOnly = 1, Full = 2 }

public class Subscription : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public Guid ProductId { get; set; }
    public Guid PlanId { get; set; }
    public SubscriptionStatus Status { get; set; } = SubscriptionStatus.Trial;
    public AccessMode Access { get; set; } = AccessMode.Full;
    public int GracePeriodDays { get; set; } = 7;          // configurable
    public DateTimeOffset CurrentPeriodStart { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset CurrentPeriodEnd { get; set; }
    public DateTimeOffset? CancelledAt { get; set; }
    public string? CancellationReason { get; set; }
    public DateTimeOffset? SuspendedAt { get; set; }
}

public class SubscriptionEvent : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid SubscriptionId { get; set; }
    public string EventType { get; set; } = string.Empty; // activated | renewed | past_due | grace_started | suspended | expired | cancelled | reactivated | plan_changed
    public string? Details { get; set; }
    public Guid? ActorUserId { get; set; }
    public DateTimeOffset OccurredAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public class AddOn : AggregateRoot<Guid>
{
    public Guid ProductId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string Currency { get; set; } = "EGP";
    public bool IsActive { get; set; } = true;
}

public class SubscriptionAddOn : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid SubscriptionId { get; set; }
    public Guid AddOnId { get; set; }
    public decimal PriceAtPurchase { get; set; }
    public string Currency { get; set; } = "EGP";
}

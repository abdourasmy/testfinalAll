using SBM.Shared.Abstractions;

namespace SBM.Modules.Subscriptions.Entities;

public enum ApprovalKind { SubscriptionRenewal = 0, SubscriptionCancellation = 1 }
public enum ApprovalStatus { Pending = 0, Approved = 1, Rejected = 2 }

/// <summary>Customer portal requests that require staff approval. Created by portal users or staff,
/// decided by staff (OrgManager / PlatformAdmin).</summary>
public class ApprovalRequest : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public ApprovalKind Kind { get; set; }
    public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;
    public Guid SubscriptionId { get; set; }
    public Guid CustomerId { get; set; }
    public string? Reason { get; set; }
    public bool RequestedByPortal { get; set; }
    public Guid? RequestedByUserId { get; set; } // portal or staff user id
    public DateTimeOffset RequestedAt { get; set; } = DateTimeOffset.UtcNow;
    public Guid? DecidedByUserId { get; set; }
    public DateTimeOffset? DecidedAt { get; set; }
    public string? DecisionNote { get; set; }

    /// <summary>Optimistic concurrency token — prevents double execution of an approval.</summary>
    [System.ComponentModel.DataAnnotations.Timestamp]
    public byte[]? RowVersion { get; set; }
}

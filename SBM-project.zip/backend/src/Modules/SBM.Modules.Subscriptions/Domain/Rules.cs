using SBM.Modules.Subscriptions.Entities;

namespace SBM.Modules.Subscriptions.Domain;

/// <summary>Explicit subscription state machine. Subscription status is deliberately kept
/// separate from license status; a revoked license is not revived by an active subscription.</summary>
public static class SubscriptionStateMachine
{
    private static readonly Dictionary<SubscriptionStatus, SubscriptionStatus[]> Allowed = new()
    {
        [SubscriptionStatus.Trial] = new[] { SubscriptionStatus.Active, SubscriptionStatus.Expired, SubscriptionStatus.Cancelled },
        [SubscriptionStatus.Active] = new[] { SubscriptionStatus.PastDue, SubscriptionStatus.Suspended, SubscriptionStatus.Expired, SubscriptionStatus.Cancelled },
        [SubscriptionStatus.PastDue] = new[] { SubscriptionStatus.Active, SubscriptionStatus.GracePeriod, SubscriptionStatus.Suspended, SubscriptionStatus.Expired, SubscriptionStatus.Cancelled },
        [SubscriptionStatus.GracePeriod] = new[] { SubscriptionStatus.Active, SubscriptionStatus.Suspended, SubscriptionStatus.Expired, SubscriptionStatus.Cancelled },
        [SubscriptionStatus.Suspended] = new[] { SubscriptionStatus.Active, SubscriptionStatus.Expired, SubscriptionStatus.Cancelled },
        [SubscriptionStatus.Expired] = new[] { SubscriptionStatus.Active }, // renewal
        [SubscriptionStatus.Cancelled] = Array.Empty<SubscriptionStatus>(), // terminal
    };

    public static bool CanTransition(SubscriptionStatus from, SubscriptionStatus to) =>
        Allowed.TryGetValue(from, out var targets) && targets.Contains(to);

    public static void EnsureTransition(SubscriptionStatus from, SubscriptionStatus to)
    {
        if (!CanTransition(from, to))
            throw new InvalidOperationException($"Illegal subscription state transition {from} -> {to}.");
    }
}

/// <summary>Expiration policy. Configurable durations; after the grace period the entitlement
/// falls back to ReadOnly (where supported) — never deletes customer data.</summary>
public static class ExpirationPolicy
{
    public sealed record PolicyResult(SubscriptionStatus Status, AccessMode Access, bool ReadOnlyApplied);

    /// <param name="daysPastExpiry">Whole days since CurrentPeriodEnd (negative if not yet expired).</param>
    public static PolicyResult Evaluate(int daysPastExpiry, int gracePeriodDays)
    {
        if (daysPastExpiry < 0)
            return new PolicyResult(SubscriptionStatus.Active, AccessMode.Full, false);
        if (daysPastExpiry <= gracePeriodDays)
            return new PolicyResult(SubscriptionStatus.GracePeriod, AccessMode.Full, false);
        return new PolicyResult(SubscriptionStatus.Expired, AccessMode.ReadOnly, true);
    }
}

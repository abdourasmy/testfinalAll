namespace SBM.Modules.Notifications.Delivery;

public sealed record DeliveryCandidate(
    string Endpoint,
    Guid EntityId,           // dedup key component source (org/user/installation/device)
    string Channel,
    bool OptOut,
    int? QuietStartLocalMinutes,
    int? QuietEndLocalMinutes,
    string TimezoneId,
    int SentTodayForRecipient,
    int FrequencyCapPerDay);

public sealed record PlannedDelivery(string Endpoint, string Channel, bool Suppressed, string? SuppressionReason);

/// <summary>
/// Applies recipient semantics + policy filters before dispatch: opt-out enforcement,
/// quiet hours and frequency caps. Duplicate endpoints within one campaign are emitted once.
/// </summary>
public static class DeliveryPlanner
{
    public static IReadOnlyList<PlannedDelivery> Plan(
        IEnumerable<DeliveryCandidate> candidates,
        RecipientSemanticsFor planning,
        DateTimeOffset nowUtc)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var output = new List<PlannedDelivery>();

        foreach (var c in candidates)
        {
            var key = planning switch
            {
                RecipientSemanticsFor.PerOrganization => "org:" + c.EntityId,
                RecipientSemanticsFor.PerUser => "user:" + c.EntityId,
                RecipientSemanticsFor.PerInstallation => "inst:" + c.EntityId,
                RecipientSemanticsFor.PerDeviceEndpoint => "endpoint:" + c.Endpoint,
                _ => "entity:" + c.EntityId
            };

            if (!seen.Add(key)) { output.Add(new(c.Endpoint, c.Channel, true, "duplicate-recipient")); continue; }
            if (c.OptOut) { output.Add(new(c.Endpoint, c.Channel, true, "opt-out")); continue; }
            if (c.SentTodayForRecipient >= c.FrequencyCapPerDay) { output.Add(new(c.Endpoint, c.Channel, true, "frequency-cap")); continue; }
            if (InQuietHours(c, nowUtc)) { output.Add(new(c.Endpoint, c.Channel, true, "quiet-hours")); continue; }

            output.Add(new(c.Endpoint, c.Channel, false, null));
        }
        return output;
    }

    private static bool InQuietHours(DeliveryCandidate c, DateTimeOffset nowUtc)
    {
        if (c.QuietStartLocalMinutes is null || c.QuietEndLocalMinutes is null) return false;
        TimeZoneInfo tz;
        try { tz = TimeZoneInfo.FindSystemTimeZoneById(c.TimezoneId); }
        catch (TimeZoneNotFoundException) { return false; } // unknown tz: do not block delivery
        var local = TimeZoneInfo.ConvertTimeFromUtc(nowUtc.UtcDateTime, tz);
        var minutes = local.Hour * 60 + local.Minute;
        var start = c.QuietStartLocalMinutes.Value;
        var end = c.QuietEndLocalMinutes.Value;
        return start <= end
            ? minutes >= start && minutes < end
            : minutes >= start || minutes < end; // overnight window
    }

    public enum RecipientSemanticsFor { PerOrganization, PerUser, PerInstallation, PerDeviceEndpoint }
}

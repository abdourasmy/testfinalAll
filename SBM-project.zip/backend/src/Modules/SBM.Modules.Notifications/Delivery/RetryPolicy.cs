namespace SBM.Modules.Notifications.Delivery;

/// <summary>Exponential backoff with jitter and a max-attempt ceiling, after which the
/// message is dead-lettered (persisted), never silently dropped.</summary>
public sealed class RetryPolicy
{
    public int MaxAttempts { get; }
    public TimeSpan BaseDelay { get; }

    public RetryPolicy(int maxAttempts = 5, TimeSpan? baseDelay = null)
    {
        MaxAttempts = maxAttempts;
        BaseDelay = baseDelay ?? TimeSpan.FromSeconds(30);
    }

    public TimeSpan DelayForAttempt(int attempt, double? jitter01 = null)
    {
        if (attempt < 1) attempt = 1;
        var exp = Math.Pow(2, attempt - 1);
        var jitter = jitter01 ?? Random.Shared.NextDouble() * 0.2; // up to +20%
        return TimeSpan.FromMilliseconds(BaseDelay.TotalMilliseconds * exp * (1.0 + jitter));
    }

    public bool ShouldDeadLetter(int attemptCount) => attemptCount >= MaxAttempts;
}

public enum ErrorClass { Transient, Permanent, ProviderUnavailable, InvalidEndpoint, RateLimited }

/// <summary>Classifies provider errors to drive retry vs dead-letter decisions.</summary>
public static class ProviderErrorClassifier
{
    public static ErrorClass Classify(string? providerCode, int? httpStatus)
    {
        var code = (providerCode ?? "").ToLowerInvariant();
        if (code.Contains("invalid") && code.Contains("token")) return ErrorClass.InvalidEndpoint;
        if (code.Contains("unsubscribe") || code.Contains("optout")) return ErrorClass.Permanent;
        if (httpStatus is 429 || code.Contains("rate")) return ErrorClass.RateLimited;
        if (httpStatus is >= 500 || code.Contains("unavailable") || code.Contains("timeout")) return ErrorClass.ProviderUnavailable;
        if (httpStatus is >= 400 and < 500) return ErrorClass.Permanent;
        return ErrorClass.Transient;
    }

    public static bool IsRetryable(ErrorClass ec) => ec is ErrorClass.Transient or ErrorClass.ProviderUnavailable or ErrorClass.RateLimited;
}

namespace SBM.Modules.Notifications.Delivery;

public sealed record ProviderSendResult(bool Success, string? ProviderMessageId, string? ErrorCode, int? HttpStatus, string? ResponseSummary);

/// <summary>Channel provider abstraction. Real adapters (FCM, SMTP, Web Push, Windows) plug in here.</summary>
public interface INotificationProvider
{
    string Channel { get; }

    /// <summary>
    /// Sends a message. A successful result means ProviderAccepted ONLY — it is never treated as Delivered.
    /// </summary>
    Task<ProviderSendResult> SendAsync(string endpoint, string subject, string body, CancellationToken ct = default);
}

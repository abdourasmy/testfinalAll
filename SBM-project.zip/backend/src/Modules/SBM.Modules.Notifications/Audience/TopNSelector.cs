namespace SBM.Modules.Notifications.Audience;

public sealed record TopNRequest(
    RankedEntity Entity,          // what is being counted/ranked
    string OrderBy,               // field name from the registry
    bool Descending,
    int N,
    AudienceDocument? PreFilter)  // optional filters applied BEFORE ranking
{
    public const int MaxN = 10_000;
}

/// <summary>
/// Dynamic Top-N audiences with deterministic ordering: primary key (order field) plus a
/// stable tie-breaker (entity id). Ranks customers, organizations, users, installations or
/// devices distinctly from one another.
/// </summary>
public static class TopNSelector
{
    private sealed class NullableComparer : IComparer<object?>
    {
        public static readonly NullableComparer Instance = new();
        public int Compare(object? x, object? y)
        {
            if (ReferenceEquals(x, y)) return 0;
            if (x is null) return -1;
            if (y is null) return 1;
            return x switch
            {
                DateTimeOffset d => d.CompareTo((DateTimeOffset)y),
                SBM.Shared.Versioning.SemVer v => v.CompareTo((SBM.Shared.Versioning.SemVer)y),
                IComparable ic => ic.CompareTo(y),
                _ => string.CompareOrdinal(x.ToString(), y.ToString())
            };
        }
    }

    public static IReadOnlyList<AudienceCandidate> Select(TopNRequest request, IEnumerable<AudienceCandidate> source)
    {
        if (request.N <= 0) return Array.Empty<AudienceCandidate>();
        var n = Math.Min(request.N, TopNRequest.MaxN);

        IEnumerable<AudienceCandidate> filtered = source;
        if (request.PreFilter is not null)
        {
            AudienceValidator.Validate(request.PreFilter);
            filtered = filtered.Where(c => AudienceEvaluator.Evaluate(request.PreFilter.Root, c));
        }

        Func<AudienceCandidate, object?> key = request.OrderBy.ToLowerInvariant() switch
        {
            "customer.registeredat" => c => c.CustomerRegisteredAt,
            "purchase.lastat" => c => c.LastPurchaseAt,
            "organization.registeredat" => c => c.OrganizationRegisteredAt,
            "device.lastactivityat" => c => c.LastActivityAt,
            "device.lastsyncat" => c => c.LastSyncAt,
            "device.lastconnectionat" => c => c.LastConnectionAt,
            "subscription.expiration" => c => c.SubscriptionExpiration,
            "app.version" => c => SBM.Shared.Versioning.SemVer.TryParse(c.AppVersion, out var sv) ? sv : null,
            _ => throw new ArgumentException($"Field '{request.OrderBy}' is not a supported Top-N ordering field.")
        };

        var primary = request.Descending
            ? filtered.OrderByDescending(key, NullableComparer.Instance)
            : filtered.OrderBy(key, NullableComparer.Instance);

        // Deterministic tie-breaker: entity id ordinal — stable across runs and peers.
        return primary
            .ThenBy(c => c.EntityId.ToString("N"), StringComparer.Ordinal)
            .Take(n)
            .ToList();
    }
}

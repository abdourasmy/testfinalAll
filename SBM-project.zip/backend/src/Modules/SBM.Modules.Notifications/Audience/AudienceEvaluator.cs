using System.Text.Json;
using SBM.Shared.Versioning;

namespace SBM.Modules.Notifications.Audience;

/// <summary>
/// Evaluates a validated rule document against candidates. Evaluation is deterministic
/// and side-effect free. Production scale-out should translate the same validated tree to a
/// parameterized SQL query (never raw SQL from users); the in-memory engine is the reference
/// implementation and is also used for preview over a capped sample.
/// </summary>
public static class AudienceEvaluator
{
    public static bool Evaluate(RuleNode node, AudienceCandidate c) => node switch
    {
        GroupNode g => EvalGroup(g, c),
        ConditionNode cond => EvalCondition(cond, c),
        _ => false
    };

    private static bool EvalGroup(GroupNode g, AudienceCandidate c) => g.Op.ToLowerInvariant() switch
    {
        "and" => g.Children.All(ch => Evaluate(ch, c)),
        "or" => g.Children.Any(ch => Evaluate(ch, c)),
        "not" => !Evaluate(g.Children[0], c),
        _ => false
    };

    private static bool EvalCondition(ConditionNode cond, AudienceCandidate c)
    {
        var op = cond.Op.ToLowerInvariant();
        var field = cond.Field.ToLowerInvariant();
        var v = cond.Value;

        return field switch
        {
            "customer.id" => MatchString(c.CustomerId?.ToString(), op, v),
            "customer.type" => MatchString(c.CustomerType, op, v),
            "customer.status" => MatchString(c.CustomerStatus, op, v),
            "customer.registeredat" => MatchDate(c.CustomerRegisteredAt, op, v),
            "customer.country" => MatchString(c.CustomerCountry, op, v),
            "customer.city" => MatchString(c.CustomerCity, op, v, allowContains: true),
            "customer.tags" => MatchStringList(c.CustomerTags, op, v),
            "customer.classification" => MatchString(c.CustomerClassification, op, v),

            "organization.id" => MatchString(c.OrganizationId?.ToString(), op, v),
            "organization.status" => MatchString(c.OrganizationStatus, op, v),
            "organization.branchcount" => MatchInt(c.OrganizationBranchCount, op, v),
            "organization.registeredat" => MatchDate(c.OrganizationRegisteredAt, op, v),
            "branch.id" => MatchString(c.BranchId?.ToString(), op, v),

            "product.id" => MatchString(c.ProductId?.ToString(), op, v),
            "application.id" => MatchString(c.ApplicationId?.ToString(), op, v),
            "application.type" => MatchString(c.ApplicationType, op, v),
            "application.platform" => MatchString(c.Platform, op, v),
            "application.status" => MatchString(c.ApplicationStatus, op, v),
            "application.releasechannel" => MatchString(c.ReleaseChannel, op, v),

            "app.version" => MatchVersion(c.AppVersion, op, v),
            "app.role" => MatchString(c.AppRole, op, v),

            "subscription.status" => MatchString(c.SubscriptionStatus, op, v),
            "subscription.expiration" => MatchDate(c.SubscriptionExpiration, op, v),
            "subscription.renewaldate" => MatchDate(c.SubscriptionRenewalDate, op, v),
            "subscription.plan" => MatchString(c.PlanCode, op, v),
            "subscription.addons" => MatchStringList(c.AddOnCodes, op, v),

            "license.state" => MatchString(c.LicenseState, op, v),
            "license.type" => MatchString(c.LicenseType, op, v),
            "license.devicelimit" => MatchInt(c.DeviceLimit, op, v),
            "license.activationcount" => MatchInt(c.ActivationCount, op, v),

            "device.type" => MatchString(c.DeviceType, op, v),
            "device.platform" => MatchString(c.DevicePlatform, op, v),
            "device.activatedat" => MatchDate(c.DeviceActivatedAt, op, v),
            "device.lastactivityat" => MatchDate(c.LastActivityAt, op, v),
            "device.lastsyncat" => MatchDate(c.LastSyncAt, op, v),
            "device.lastconnectionat" => MatchDate(c.LastConnectionAt, op, v),

            "purchase.lastat" => MatchDate(c.LastPurchaseAt, op, v),
            _ => false
        };
    }

    private static bool MatchString(string? actual, string op, JsonElement v, bool allowContains = false)
    {
        switch (op)
        {
            case "eq": return StrEq(actual, v.GetString());
            case "ne": return !StrEq(actual, v.GetString());
            case "in": return actual is not null && v.EnumerateArray().Any(e => StrEq(actual, e.GetString()));
            case "nin": return actual is null || !v.EnumerateArray().Any(e => StrEq(actual, e.GetString()));
            case "contains" when allowContains:
                var needle = v.GetString();
                return actual is not null && needle is not null && actual.Contains(needle, StringComparison.OrdinalIgnoreCase);
            default: return false;
        }
    }

    private static bool StrEq(string? a, string? b) =>
        a is not null && b is not null && string.Equals(a, b, StringComparison.OrdinalIgnoreCase);

    private static bool MatchStringList(List<string> actual, string op, JsonElement v)
    {
        var needle = v.GetString();
        if (needle is null) return false;
        bool contains = actual.Contains(needle, StringComparer.OrdinalIgnoreCase);
        return op switch { "contains" => contains, "notcontains" => !contains, _ => false };
    }

    private static bool MatchInt(int? actual, string op, JsonElement v)
    {
        if (!actual.HasValue || !v.TryGetInt64(out var target)) return false;
        return op switch
        {
            "eq" => actual.Value == target,
            "ne" => actual.Value != target,
            "gt" => actual.Value > target,
            "gte" => actual.Value >= target,
            "lt" => actual.Value < target,
            "lte" => actual.Value <= target,
            _ => false
        };
    }

    private static bool MatchDate(DateTimeOffset? actual, string op, JsonElement v)
    {
        if (!actual.HasValue) return false;
        if (op == "between")
        {
            var start = DateTimeOffset.Parse(v[0].GetString()!);
            var end = DateTimeOffset.Parse(v[1].GetString()!);
            return actual.Value >= start && actual.Value <= end;
        }
        if (v.ValueKind != JsonValueKind.String || !DateTimeOffset.TryParse(v.GetString(), out var target)) return false;
        int c = actual.Value.CompareTo(target);
        return op switch
        {
            "eq" => c == 0,
            "ne" => c != 0,
            "gt" => c > 0,
            "gte" => c >= 0,
            "lt" => c < 0,
            "lte" => c <= 0,
            _ => false
        };
    }

    private static bool MatchVersion(string? actualRaw, string op, JsonElement v)
    {
        if (!SemVer.TryParse(actualRaw, out var actual) || actual is null)
            return false; // invalid installed version strings never match version predicates

        switch (op)
        {
            case "eq": return actual.CompareTo(SemVer.Parse(v.GetString()!)) == 0;
            case "ne": return actual.CompareTo(SemVer.Parse(v.GetString()!)) != 0;
            case "gt": return actual > SemVer.Parse(v.GetString()!);
            case "gte": return actual >= SemVer.Parse(v.GetString()!);
            case "lt": return actual < SemVer.Parse(v.GetString()!);
            case "lte": return actual <= SemVer.Parse(v.GetString()!);
            case "range": return SemVerRange.Parse(v.GetString()!).Contains(actual);
            case "family":
                {
                    var f = v.GetString()!;
                    var parts = f.Split('.');
                    if (parts.Length == 2 && parts[1].Equals("x", StringComparison.OrdinalIgnoreCase))
                        return actual.Major == int.Parse(parts[0]) && !actual.IsPrerelease;
                    if (parts.Length == 3 && parts[2].Equals("x", StringComparison.OrdinalIgnoreCase))
                        return actual.Major == int.Parse(parts[0]) && actual.Minor == int.Parse(parts[1]) && !actual.IsPrerelease;
                    return false;
                }
            case "notin":
                return !v.EnumerateArray().Any(e => SemVer.TryParse(e.GetString(), out var sv) && sv!.CompareTo(actual) == 0);
            default: return false;
        }
    }
}

namespace SBM.Modules.Notifications.Audience;

public enum FieldType { String, Bool, Int, Decimal, DateTime, Enum, Version, StringList }

public sealed record FieldDefinition(
    string Name,
    FieldType Type,
    string[] AllowedOperators,
    bool IsDate = false);

/// <summary>Registry of fields exposed to the audience rule engine. Only these fields,
/// only these operators. No raw SQL, no arbitrary expressions — ever.</summary>
public static class AudienceFieldRegistry
{
    private static readonly Dictionary<string, FieldDefinition> Fields = new(StringComparer.OrdinalIgnoreCase);

    static AudienceFieldRegistry()
    {
        void Add(string name, FieldType type, params string[] ops) =>
            Fields[name] = new FieldDefinition(name, type, ops);

        Add("customer.id", FieldType.String, "eq", "ne", "in", "nin");
        Add("customer.type", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("customer.status", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("customer.registeredAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("customer.country", FieldType.String, "eq", "ne", "in", "nin");
        Add("customer.city", FieldType.String, "eq", "ne", "in", "nin", "contains");
        Add("customer.tags", FieldType.StringList, "contains", "notcontains");
        Add("customer.classification", FieldType.String, "eq", "ne", "in", "nin");

        Add("organization.id", FieldType.String, "eq", "ne", "in", "nin");
        Add("organization.status", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("organization.branchCount", FieldType.Int, "eq", "ne", "gt", "gte", "lt", "lte");
        Add("organization.registeredAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("branch.id", FieldType.String, "eq", "ne", "in", "nin");

        Add("product.id", FieldType.String, "eq", "ne", "in", "nin");
        Add("application.id", FieldType.String, "eq", "ne", "in", "nin");
        Add("application.type", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("application.platform", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("application.status", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("application.releaseChannel", FieldType.Enum, "eq", "ne", "in", "nin");

        Add("app.version", FieldType.Version, "eq", "ne", "gt", "gte", "lt", "lte", "range", "family", "notIn");

        Add("app.role", FieldType.Enum, "eq", "ne", "in", "nin"); // trusted server-side assertion only

        Add("subscription.status", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("subscription.expiration", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("subscription.renewalDate", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("subscription.plan", FieldType.String, "eq", "ne", "in", "nin");
        Add("subscription.addOns", FieldType.StringList, "contains", "notcontains");

        Add("license.state", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("license.type", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("license.deviceLimit", FieldType.Int, "eq", "ne", "gt", "gte", "lt", "lte");
        Add("license.activationCount", FieldType.Int, "eq", "ne", "gt", "gte", "lt", "lte");

        Add("device.type", FieldType.String, "eq", "ne", "in", "nin");
        Add("device.platform", FieldType.Enum, "eq", "ne", "in", "nin");
        Add("device.activatedAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("device.lastActivityAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("device.lastSyncAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
        Add("device.lastConnectionAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");

        Add("purchase.lastAt", FieldType.DateTime, "eq", "ne", "gt", "gte", "lt", "lte", "between");
    }

    public static bool TryGet(string name, out FieldDefinition? definition) => Fields.TryGetValue(name, out definition);

    public static IReadOnlyCollection<FieldDefinition> All => Fields.Values;
}

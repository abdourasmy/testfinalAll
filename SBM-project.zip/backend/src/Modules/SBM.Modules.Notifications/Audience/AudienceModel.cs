using System.Text.Json;
using System.Text.Json.Serialization;
using SBM.Shared.Versioning;

namespace SBM.Modules.Notifications.Audience;

// ---------- Rule document (versioned JSON) ----------

public sealed record AudienceDocument(
    [property: JsonPropertyName("v")] int Version,
    [property: JsonPropertyName("root")] RuleNode Root)
{
    public const int CurrentVersion = 1;
}

[JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
[JsonDerivedType(typeof(GroupNode), "group")]
[JsonDerivedType(typeof(ConditionNode), "condition")]
public abstract record RuleNode;

public sealed record GroupNode(
    [property: JsonPropertyName("op")] string Op, // and | or | not
    [property: JsonPropertyName("children")] IReadOnlyList<RuleNode> Children) : RuleNode;

public sealed record ConditionNode(
    [property: JsonPropertyName("field")] string Field,
    [property: JsonPropertyName("op")] string Op,
    [property: JsonPropertyName("value")] JsonElement Value) : RuleNode;

// ---------- Candidate record evaluated against rules ----------
// Flat, trusted, server-projected view of a recipient candidate. Application roles
// and installation facts are derived from server-side assignments, never client input.

public sealed class AudienceCandidate
{
    public Guid EntityId { get; set; }          // id of the ranked/returned entity (customer, org, user, installation, device)
    public Guid? CustomerId { get; set; }
    public string? CustomerType { get; set; }
    public string? CustomerStatus { get; set; }
    public DateTimeOffset? CustomerRegisteredAt { get; set; }
    public string? CustomerCountry { get; set; }
    public string? CustomerCity { get; set; }
    public List<string> CustomerTags { get; set; } = new();
    public string? CustomerClassification { get; set; }

    public Guid? OrganizationId { get; set; }
    public string? OrganizationStatus { get; set; }
    public int? OrganizationBranchCount { get; set; }
    public DateTimeOffset? OrganizationRegisteredAt { get; set; }
    public Guid? BranchId { get; set; }

    public Guid? ProductId { get; set; }
    public Guid? ApplicationId { get; set; }
    public string? ApplicationType { get; set; }
    public string? Platform { get; set; }
    public string? ApplicationStatus { get; set; }
    public string? ReleaseChannel { get; set; }

    public string? AppVersion { get; set; }          // installed/current version, parsed as SemVer when applicable

    public string? AppRole { get; set; }             // trusted server-side role assertion

    public string? SubscriptionStatus { get; set; }
    public DateTimeOffset? SubscriptionExpiration { get; set; }
    public DateTimeOffset? SubscriptionRenewalDate { get; set; }
    public string? PlanCode { get; set; }
    public List<string> AddOnCodes { get; set; } = new();

    public string? LicenseState { get; set; }
    public string? LicenseType { get; set; }
    public int? DeviceLimit { get; set; }
    public int? ActivationCount { get; set; }

    public string? DeviceType { get; set; }
    public string? DevicePlatform { get; set; }
    public DateTimeOffset? DeviceActivatedAt { get; set; }
    public DateTimeOffset? LastActivityAt { get; set; }
    public DateTimeOffset? LastSyncAt { get; set; }
    public DateTimeOffset? LastConnectionAt { get; set; }

    // Purchase facts used by Top-N "latest purchases" style queries
    public DateTimeOffset? LastPurchaseAt { get; set; }
}

public enum RankedEntity { Customer = 0, Organization = 1, User = 2, Installation = 3, Device = 4 }
public enum RecipientSemantics { PerOrganization = 0, PerUser = 1, PerInstallation = 2, PerDeviceEndpoint = 3 }

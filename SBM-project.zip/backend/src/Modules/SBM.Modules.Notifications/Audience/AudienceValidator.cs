using System.Text.Json;

namespace SBM.Modules.Notifications.Audience;

public sealed class AudienceValidationException : Exception
{
    public IReadOnlyList<string> Errors { get; }
    public AudienceValidationException(IReadOnlyList<string> errors) : base(string.Join("; ", errors)) => Errors = errors;
}

/// <summary>Validates audience rule documents: schema, known fields, allowed operators,
/// type-correct values, and complexity limits. Query translation never executes raw SQL
/// or arbitrary expressions.</summary>
public static class AudienceValidator
{
    public const int MaxDepth = 8;
    public const int MaxNodes = 100;

    public static void Validate(AudienceDocument doc)
    {
        var errors = new List<string>();
        if (doc.Version != AudienceDocument.CurrentVersion)
            errors.Add($"Unsupported rule version {doc.Version}; expected {AudienceDocument.CurrentVersion}.");
        if (doc.Root is null) { errors.Add("Root rule node is required."); throw new AudienceValidationException(errors); }
        ValidateNode(doc.Root, 1, new NodeCounter(), errors);
        if (errors.Count > 0) throw new AudienceValidationException(errors);
    }

    private sealed class NodeCounter { public int Count; }

    private static void ValidateNode(RuleNode node, int depth, NodeCounter counter, List<string> errors)
    {
        counter.Count++;
        if (depth > MaxDepth) { errors.Add($"Rule nesting exceeds maximum depth of {MaxDepth}."); return; }
        if (counter.Count > MaxNodes) { errors.Add($"Rule exceeds maximum node count of {MaxNodes}."); return; }

        switch (node)
        {
            case GroupNode group:
                var op = group.Op?.ToLowerInvariant();
                if (op is not ("and" or "or" or "not"))
                {
                    errors.Add($"Unsupported group operator '{group.Op}'. Allowed: and, or, not.");
                    return;
                }
                if (op == "not" && group.Children.Count != 1)
                    errors.Add("NOT group must contain exactly one child.");
                if (op != "not" && group.Children.Count < 2)
                    errors.Add($"{op.ToUpperInvariant()} group must contain at least two children.");
                foreach (var child in group.Children) ValidateNode(child, depth + 1, counter, errors);
                break;

            case ConditionNode condition:
                ValidateCondition(condition, errors);
                break;

            default:
                errors.Add("Unknown rule node type.");
                break;
        }
    }

    private static void ValidateCondition(ConditionNode condition, List<string> errors)
    {
        if (!AudienceFieldRegistry.TryGet(condition.Field, out var def) || def is null)
        {
            errors.Add($"Unknown field '{condition.Field}'.");
            return;
        }
        var op = condition.Op?.ToLowerInvariant() ?? "";
        if (!def.AllowedOperators.Contains(op, StringComparer.OrdinalIgnoreCase))
        {
            errors.Add($"Operator '{condition.Op}' is not allowed for field '{def.Name}'. Allowed: {string.Join(", ", def.AllowedOperators)}.");
            return;
        }
        ValidateValue(def, condition, errors);
    }

    private static void ValidateValue(FieldDefinition def, ConditionNode condition, List<string> errors)
    {
        var v = condition.Value;
        try
        {
            switch (def.Type)
            {
                case FieldType.String:
                case FieldType.Enum:
                    if (ListOps(condition.Op)) { if (v.ValueKind != JsonValueKind.Array) errors.Add($"Field '{def.Name}' operator '{condition.Op}' expects an array value."); }
                    else if (v.ValueKind != JsonValueKind.String) errors.Add($"Field '{def.Name}' expects a string value.");
                    break;
                case FieldType.Bool:
                    if (v.ValueKind is not (JsonValueKind.True or JsonValueKind.False)) errors.Add($"Field '{def.Name}' expects a boolean value.");
                    break;
                case FieldType.Int:
                    if (!v.TryGetInt64(out _)) errors.Add($"Field '{def.Name}' expects an integer value.");
                    break;
                case FieldType.Decimal:
                    if (!v.TryGetDecimal(out _)) errors.Add($"Field '{def.Name}' expects a decimal value.");
                    break;
                case FieldType.DateTime:
                    if (condition.Op.Equals("between", StringComparison.OrdinalIgnoreCase))
                    {
                        if (v.ValueKind != JsonValueKind.Array || v.GetArrayLength() != 2
                            || !DateTimeOffset.TryParse(v[0].GetString(), out _) || !DateTimeOffset.TryParse(v[1].GetString(), out _))
                            errors.Add($"Field '{def.Name}' operator 'between' expects [start, end] ISO-8601 timestamps.");
                    }
                    else if (v.ValueKind != JsonValueKind.String || !DateTimeOffset.TryParse(v.GetString(), out _))
                        errors.Add($"Field '{def.Name}' expects an ISO-8601 timestamp string.");
                    break;
                case FieldType.Version:
                    ValidateVersionValue(condition, errors);
                    break;
                case FieldType.StringList:
                    if (v.ValueKind != JsonValueKind.String) errors.Add($"Field '{def.Name}' expects a single string value.");
                    break;
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or FormatException)
        {
            errors.Add($"Field '{def.Name}' value failed validation: {ex.Message}");
        }
    }

    private static void ValidateVersionValue(ConditionNode condition, List<string> errors)
    {
        var v = condition.Value;
        string op = condition.Op.ToLowerInvariant();
        if (op == "range")
        {
            if (v.ValueKind != JsonValueKind.String || !TryValidateRange(v.GetString()!))
                errors.Add("app.version 'range' expects e.g. \">=1.0.0 <2.0.0\".");
            return;
        }
        if (op == "family")
        {
            if (v.ValueKind != JsonValueKind.String || !TryValidateFamily(v.GetString()!))
                errors.Add("app.version 'family' expects e.g. \"2.x\" or \"2.3.x\".");
            return;
        }
        if (op == "notIn")
        {
            if (v.ValueKind != JsonValueKind.Array || v.EnumerateArray().Any(e => !IsValidVersion(e.GetString())))
                errors.Add("app.version 'notIn' expects an array of valid SemVer strings.");
            return;
        }
        if (v.ValueKind != JsonValueKind.String || !IsValidVersion(v.GetString()))
            errors.Add("app.version expects a valid SemVer 2.0.0 string (e.g. 2.1.0 or 2.1.0-rc.1).");
    }

    private static bool IsValidVersion(string? s) => SBM.Shared.Versioning.SemVer.TryParse(s, out _);

    private static bool TryValidateRange(string s)
    {
        try { SBM.Shared.Versioning.SemVerRange.Parse(s); return true; } catch (FormatException) { return false; }
    }

    private static bool TryValidateFamily(string s) =>
        System.Text.RegularExpressions.Regex.IsMatch(s ?? "", @"^\d+\.x$") || System.Text.RegularExpressions.Regex.IsMatch(s ?? "", @"^\d+\.\d+\.x$");

    private static bool ListOps(string op) =>
        op is "in" or "nin" or "notin";
}

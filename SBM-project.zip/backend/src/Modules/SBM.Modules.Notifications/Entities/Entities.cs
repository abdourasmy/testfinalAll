using SBM.Shared.Abstractions;

namespace SBM.Modules.Notifications.Entities;

public enum NotificationChannel { InApp = 0, Push = 1, WebPush = 2, Email = 3, Windows = 4 }

public class NotificationTemplate : AggregateRoot<Guid>
{
    public string Code { get; set; } = string.Empty;   // e.g. "SUBSCRIPTION.EXPIRING"
    public string Language { get; set; } = "ar";
    public NotificationChannel Channel { get; set; } = NotificationChannel.InApp;
    public string Name { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;   // mustache-style {{var}} placeholders, HTML-encoded on render for web/email
    public int Version { get; set; } = 1;
    public bool IsActive { get; set; } = true;
}

public enum AudienceExecutionMode { Dynamic = 0, FrozenSnapshot = 1 }
public enum CampaignStatus { Draft = 0, Scheduled = 1, Processing = 2, Completed = 3, PartiallyFailed = 4, Cancelled = 5 }
public enum RecipientSemanticsMode { PerOrganization = 0, PerUser = 1, PerInstallation = 2, PerDeviceEndpoint = 3 }

public class AudienceDefinition : AggregateRoot<Guid>
{
    public string Name { get; set; } = string.Empty;
    public string DocumentJson { get; set; } = string.Empty; // versioned rule document (see AudienceModel)
    public int RuleVersion { get; set; } = 1;
    public Guid? OrganizationId { get; set; } // null = platform-level definition (platform admins only)
}

public class AudienceSnapshot : AggregateRoot<Guid>
{
    public Guid AudienceDefinitionId { get; set; }
    public Guid? CampaignId { get; set; }
    public int RuleVersion { get; set; }
    public int CandidateCount { get; set; }
    public string ContentHash { get; set; } = string.Empty;  // hash of ordered recipient keys
    public string RecipientKeysJson { get; set; } = "[]";    // frozen ordered keys for reproducibility
}

public class Campaign : AggregateRoot<Guid>
{
    public string Name { get; set; } = string.Empty;
    public Guid? OrganizationId { get; set; } // null = platform-level campaign
    public string TemplateCode { get; set; } = string.Empty;
    public string Language { get; set; } = "ar";
    public NotificationChannel Channel { get; set; } = NotificationChannel.InApp;
    public Guid AudienceDefinitionId { get; set; }
    public AudienceExecutionMode ExecutionMode { get; set; } = AudienceExecutionMode.Dynamic;
    public Guid? SnapshotId { get; set; }
    public RecipientSemanticsMode RecipientSemantics { get; set; } = RecipientSemanticsMode.PerOrganization;
    public CampaignStatus Status { get; set; } = CampaignStatus.Draft;
    public string? IdempotencyKey { get; set; }              // guards against duplicate campaign processing
    public DateTimeOffset? ScheduledAt { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public int TotalRecipients { get; set; }
    public int SentCount { get; set; }
    public int FailedCount { get; set; }
}

public enum RecipientStatus { Queued = 0, Processing = 1, ProviderAccepted = 2, Delivered = 3, Opened = 4, Failed = 5, Cancelled = 6, Expired = 7 }

public class CampaignRecipient : AggregateRoot<Guid>
{
    public Guid CampaignId { get; set; }
    public string RecipientKey { get; set; } = string.Empty; // dedup key derived from RecipientSemantics
    public string Channel { get; set; } = "InApp";
    public string Endpoint { get; set; } = string.Empty;     // email address / FCM token / user id
    public Guid? TargetEntityId { get; set; }
    public RecipientStatus Status { get; set; } = RecipientStatus.Queued;
    public int AttemptCount { get; set; }
    public DateTimeOffset? NextAttemptAt { get; set; }
    public string? LastErrorClass { get; set; }
    public string? ProviderMessageId { get; set; }
    public DateTimeOffset? ProviderAcceptedAt { get; set; }
    public DateTimeOffset? DeliveredAt { get; set; }         // set ONLY from provider delivery confirmation, never from send acceptance
}

public class DeliveryAttempt : AggregateRoot<Guid>
{
    public Guid CampaignRecipientId { get; set; }
    public int AttemptNo { get; set; }
    public string Result { get; set; } = string.Empty;       // accepted | delivered | failed | deadletter
    public string? ErrorClass { get; set; }                  // transient | permanent | provider_unavailable | invalid_endpoint | rate_limited
    public string? ProviderMessageId { get; set; }
    public string? ResponseSummary { get; set; }
    public DateTimeOffset AttemptedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class NotificationPreference : AggregateRoot<Guid>
{
    public Guid? UserId { get; set; }                        // user-level preference ...
    public Guid? OrganizationId { get; set; }                 // ... or org-level default
    public NotificationChannel Channel { get; set; }
    public bool OptOut { get; set; }
    public int? QuietHoursStartLocalMinutes { get; set; }    // minutes since local midnight
    public int? QuietHoursEndLocalMinutes { get; set; }
    public string TimezoneId { get; set; } = "Africa/Cairo";
    public int FrequencyCapPerDay { get; set; } = 5;
}

using SBM.Shared.Abstractions;

namespace SBM.Modules.Customers.Entities;

public enum CustomerType { Individual = 0, Company = 1 }
public enum CustomerStatus { Active = 0, Suspended = 1, Inactive = 2 }

public class Customer : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public CustomerType Type { get; set; } = CustomerType.Company;
    public CustomerStatus Status { get; set; } = CustomerStatus.Active;
    public string Name { get; set; } = string.Empty;
    public string? LegalName { get; set; }
    public string? TaxIdentifier { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Country { get; set; }
    public string? City { get; set; }
    public string? Address { get; set; }
    public string? Classification { get; set; }
    public string? Tags { get; set; } // comma-separated tags; normalized on write
    public string? Notes { get; set; }
    public Guid? OwnerUserId { get; set; } // sales assignment
    /// <summary>Reseller attribution: commission accrues to this reseller for paid invoices of this customer.</summary>
    public Guid? ResellerId { get; set; }
    public DateTimeOffset RegisteredAt { get; set; } = DateTimeOffset.UtcNow;

    public void Suspend() { Status = CustomerStatus.Suspended; }
    public void Reactivate() { Status = CustomerStatus.Active; }
}

public class CustomerContact : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Title { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool IsPrimary { get; set; }
}

public class CustomerNote : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public string Body { get; set; } = string.Empty;
    public Guid AuthorUserId { get; set; }
}

public enum LeadStatus { New = 0, Qualified = 1, Won = 2, Lost = 3 }

public class Lead : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Company { get; set; }
    public string? Source { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public LeadStatus Status { get; set; } = LeadStatus.New;
    public Guid? OwnerUserId { get; set; }
    public Guid? ConvertedCustomerId { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public enum OpportunityStage { Open = 0, Negotiation = 1, Won = 2, Lost = 3 }

public class Opportunity : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid? CustomerId { get; set; }
    public Guid? LeadId { get; set; }
    public string Title { get; set; } = string.Empty;
    public decimal? ExpectedValue { get; set; }
    public string Currency { get; set; } = "EGP";
    public OpportunityStage Stage { get; set; } = OpportunityStage.Open;
    public DateTimeOffset? ExpectedCloseDate { get; set; }
    public Guid? OwnerUserId { get; set; }
}

using SBM.Shared.Abstractions;

namespace SBM.Modules.Billing.Entities;

public enum InvoiceStatus { Draft = 0, Issued = 1, PartiallyPaid = 2, Paid = 3, Void = 4, Overdue = 5 }

public class Invoice : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public string Number { get; set; } = string.Empty; // generated, unique per organization
    public string Prefix { get; set; } = "INV";
    public string FinancialYear { get; set; } = string.Empty; // e.g. "2026"
    public InvoiceStatus Status { get; set; } = InvoiceStatus.Draft;
    public string Currency { get; set; } = "EGP";

    public decimal SubTotal { get; set; }
    public decimal DiscountTotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal GrandTotal { get; set; }
    public decimal AmountPaid { get; set; }
    public decimal Outstanding => GrandTotal - AmountPaid;

    public DateTimeOffset? IssuedAt { get; set; }
    public DateTimeOffset? DueAt { get; set; }
    public DateTimeOffset? PaidAt { get; set; }
}

public class InvoiceItem : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid InvoiceId { get; set; }
    public string Description { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
    public string Currency { get; set; } = "EGP";

    public decimal LineNet => decimal.Round(Quantity * UnitPrice * (1m - DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
    public decimal LineTax => decimal.Round(LineNet * TaxPercent / 100m, 2, MidpointRounding.AwayFromZero);
    public decimal LineTotal => LineNet + LineTax;
}

/// <summary>Concurrency-safe sequence source for invoice numbering. Never MAX()+1;
/// a row is atomically incremented inside a transaction and guarded by a unique index
/// on Invoice.Number as the final backstop.</summary>
public class InvoiceSequence : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string Prefix { get; set; } = "INV";
    public string FinancialYear { get; set; } = string.Empty;
    public long NextValue { get; set; } = 1;

    /// <summary>Optimistic concurrency token (SQL Server rowversion). Guards the read-increment-write cycle
    /// without holding long-lived locks; conflicts retry automatically.</summary>
    [System.ComponentModel.DataAnnotations.Timestamp]
    public byte[]? RowVersion { get; set; }
}

public enum PaymentStatus { Pending = 0, Confirmed = 1, Failed = 2, Refunded = 3, PartiallyRefunded = 4 }

public class Payment : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid InvoiceId { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "EGP";
    public string Method { get; set; } = "Manual"; // Manual | Card | BankTransfer | OnlineProvider
    public string? ProviderReference { get; set; }
    public string? IdempotencyKey { get; set; }
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public DateTimeOffset? ConfirmedAt { get; set; }
}

/// <summary>Idempotency record for payment callbacks. The same key returns the stored outcome
/// instead of double-processing.</summary>
public class PaymentIdempotencyRecord : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string IdempotencyKey { get; set; } = string.Empty;
    public Guid? PaymentId { get; set; }
    public string Outcome { get; set; } = string.Empty; // e.g. "processed" | "duplicate"
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public enum RefundStatus { PendingApproval = 0, Approved = 1, Rejected = 2, Processed = 3 }

public class Refund : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid PaymentId { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "EGP";
    public string Reason { get; set; } = string.Empty;
    public string? ProviderReference { get; set; }
    public RefundStatus Status { get; set; } = RefundStatus.PendingApproval;
    public Guid RequestedByUserId { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public DateTimeOffset? ApprovedAt { get; set; }
}

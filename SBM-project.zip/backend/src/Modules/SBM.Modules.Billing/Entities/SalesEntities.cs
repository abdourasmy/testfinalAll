using SBM.Shared.Abstractions;

namespace SBM.Modules.Billing.Entities;

public enum QuotationStatus { Draft = 0, Sent = 1, Accepted = 2, Rejected = 3, Expired = 4, Converted = 5 }
public enum SalesOrderStatus { PendingConfirmation = 0, Confirmed = 1, Fulfilled = 2, Invoiced = 3, Cancelled = 4 }

/// <summary>Domain events raised by sales aggregates. They flow into the transactional outbox
/// (the offline-sync journal) automatically via SbmDbContext.SaveChangesAsync.</summary>
public abstract record SalesDomainEvent(string EntityType, Guid EntityId, Guid OrganizationId) : DomainEvent;
public sealed record QuotationStatusChanged(Guid EntityId, Guid OrganizationId, string From, string To)
    : SalesDomainEvent("quotation", EntityId, OrganizationId)
{ public override string EventType => "sales.quotation.status"; }
public sealed record OrderStatusChanged(Guid EntityId, Guid OrganizationId, string From, string To)
    : SalesDomainEvent("order", EntityId, OrganizationId)
{ public override string EventType => "sales.order.status"; }

public class Quotation : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public string Number { get; set; } = string.Empty; // QUO-{YEAR}-{000000}
    public QuotationStatus Status { get; set; } = QuotationStatus.Draft;
    public string Currency { get; set; } = "EGP";
    public decimal SubTotal { get; set; }
    public decimal DiscountTotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal GrandTotal { get; set; }
    public DateTimeOffset? ValidUntil { get; set; }
    public string? Notes { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public DateTimeOffset? SentAt { get; set; }
    public DateTimeOffset? AcceptedAt { get; set; }
    public DateTimeOffset? RejectedAt { get; set; }
    public Guid? ConvertedOrderId { get; set; }

    public void TransitionTo(QuotationStatus next)
    {
        var from = Status.ToString();
        Status = next;
        var now = DateTimeOffset.UtcNow;
        if (next == QuotationStatus.Sent) SentAt = now;
        else if (next == QuotationStatus.Accepted) AcceptedAt = now;
        else if (next == QuotationStatus.Rejected) RejectedAt = now;
        Raise(new QuotationStatusChanged(Id, OrganizationId, from, next.ToString()));
    }
}

public class QuotationLine : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid QuotationId { get; set; }
    public string Description { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
    public string Currency { get; set; } = "EGP";

    public decimal LineNet => decimal.Round(Quantity * UnitPrice * (1m - DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
    public decimal LineTax => decimal.Round(LineNet * TaxPercent / 100m, 2, MidpointRounding.AwayFromZero);
    public decimal LineTotal => LineNet + LineTax;
}

public class SalesOrder : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public Guid? QuotationId { get; set; }
    public string Number { get; set; } = string.Empty; // ORD-{YEAR}-{000000}
    public SalesOrderStatus Status { get; set; } = SalesOrderStatus.PendingConfirmation;
    public string Currency { get; set; } = "EGP";
    public decimal SubTotal { get; set; }
    public decimal DiscountTotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal GrandTotal { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public DateTimeOffset? ConfirmedAt { get; set; }
    public DateTimeOffset? FulfilledAt { get; set; }
    public Guid? InvoiceId { get; set; }

    public void TransitionTo(SalesOrderStatus next)
    {
        var from = Status.ToString();
        Status = next;
        var now = DateTimeOffset.UtcNow;
        if (next == SalesOrderStatus.Confirmed) ConfirmedAt = now;
        else if (next == SalesOrderStatus.Fulfilled) FulfilledAt = now;
        Raise(new OrderStatusChanged(Id, OrganizationId, from, next.ToString()));
    }
}

public class SalesOrderLine : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid SalesOrderId { get; set; }
    public string Description { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
    public string Currency { get; set; } = "EGP";

    public decimal LineNet => decimal.Round(Quantity * UnitPrice * (1m - DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
    public decimal LineTax => decimal.Round(LineNet * TaxPercent / 100m, 2, MidpointRounding.AwayFromZero);
    public decimal LineTotal => LineNet + LineTax;
}

/// <summary>Append-only audit of every sales lifecycle transition (quotation/order).</summary>
public class SalesEvent : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string EntityType { get; set; } = string.Empty; // Quotation | Order
    public Guid EntityId { get; set; }
    public string EventType { get; set; } = string.Empty;  // created | sent | accepted | rejected | converted | confirmed | fulfilled | invoiced | cancelled
    public string? Details { get; set; }
    public Guid? ActorUserId { get; set; }
    public DateTimeOffset OccurredAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public enum ResellerStatus { Active = 0, Suspended = 1 }

/// <summary>Reseller (partner) record. Platform-level; attribution happens via Customer.ResellerId.</summary>
public class Reseller : AggregateRoot<Guid>
{
    public string Name { get; set; } = string.Empty;
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public decimal CommissionPercent { get; set; } // e.g. 10 = 10%
    public ResellerStatus Status { get; set; } = ResellerStatus.Active;
    public Guid? LinkedOrganizationId { get; set; }
    public Guid? CreatedByUserId { get; set; }
}

public enum CommissionStatus { PendingApproval = 0, Approved = 1, Paid = 2, Rejected = 3 }

/// <summary>One computed commission per (reseller, invoice). Idempotent via unique index.</summary>
public class ResellerCommission : AggregateRoot<Guid>
{
    public Guid ResellerId { get; set; }
    public Guid OrganizationId { get; set; } // organization that issued the invoice (attributee)
    public Guid CustomerId { get; set; }
    public Guid InvoiceId { get; set; }
    public decimal InvoiceAmount { get; set; } // amount paid at calculation time
    public decimal CommissionAmount { get; set; }
    public string Currency { get; set; } = "EGP";
    public string Period { get; set; } = string.Empty; // yyyy-MM
    public CommissionStatus Status { get; set; } = CommissionStatus.PendingApproval;
    public DateTimeOffset CalculatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ApprovedAt { get; set; }
    public Guid? ApprovedByUserId { get; set; }
}

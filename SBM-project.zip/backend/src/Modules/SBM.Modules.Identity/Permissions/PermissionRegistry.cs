namespace SBM.Modules.Identity.Permissions;

/// <summary>Canonical granular permission catalog. Permissions are platform-wide codes assigned to roles
/// (RolePermission) and/or directly to users (UserPermission). See docs/USER_PERMISSIONS.md.</summary>
public static class PermissionRegistry
{
    public static readonly IReadOnlyList<string> All = new[]
    {
        // user management
        "users.read", "users.create", "users.update", "users.disable", "users.reset_password",
        "users.reset_mfa", "users.revoke_sessions",
        // roles & permissions
        "roles.read", "roles.assign",
        "permissions.read", "permissions.assign", "permissions.revoke",
        // customers
        "customers.read", "customers.create", "customers.update",
        // subscriptions
        "subscriptions.read", "subscriptions.create", "subscriptions.cancel", "subscriptions.renew",
        // licenses
        "licenses.read", "licenses.activate", "licenses.disable_device", "licenses.revoke",
        // invoices & payments
        "invoices.read", "invoices.create", "invoices.issue",
        "payments.read", "payments.create", "payments.refund.request", "payments.refund.approve", "payments.refund.execute",
        // finance
        "finance.read", "finance.create_entry", "finance.reverse_entry",
        // campaigns & audience
        "campaigns.read", "campaigns.create", "campaigns.launch", "campaigns.cancel",
        // reports & audit
        "reports.read", "reports.export", "audit.read",
        // support & catalog
        "support.read", "support.create", "support.manage",
        "catalog.read", "catalog.manage",
        // sales
        "sales.read", "sales.manage",
        // settings & resellers (added for completeness)
        "settings.manage", "resellers.read", "resellers.manage",
    };

    public const string PlatformAdminImplicit = "platform.admin"; // not in tenant catalog; reserved

    /// <summary>Default role → permissions for tenant org roles. PlatformAdmin is implicitly full-access.</summary>
    public static readonly IReadOnlyDictionary<string, string[]> Defaults = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
    {
        ["Owner"] = All.ToArray(),
        ["Manager"] = new[]
        {
            "customers.read", "customers.create", "customers.update",
            "subscriptions.read", "subscriptions.create", "subscriptions.cancel", "subscriptions.renew",
            "licenses.read", "licenses.activate", "licenses.disable_device", "licenses.revoke",
            "invoices.read", "invoices.create", "invoices.issue",
            "payments.read", "payments.create", "payments.refund.request", "payments.refund.approve",
            "finance.read", "finance.create_entry", "finance.reverse_entry",
            "campaigns.read", "campaigns.create", "campaigns.launch", "campaigns.cancel",
            "reports.read", "reports.export",
            "support.read", "support.create", "support.manage",
            "catalog.read", "catalog.manage",
            "sales.read", "sales.manage",
            "audit.read",
        },
        ["Member"] = new[]
        {
            "customers.read", "subscriptions.read", "licenses.read",
            "invoices.read", "payments.read", "reports.read",
            "support.read", "support.create", "catalog.read", "sales.read",
        },
        ["Cashier"] = new[]
        {
            "invoices.read", "invoices.create", "invoices.issue",
            "payments.read", "payments.create", "payments.refund.request", "customers.read",
        },
        ["Accountant"] = new[]
        {
            "invoices.read", "invoices.create", "invoices.issue",
            "payments.read", "payments.refund.approve", "payments.refund.execute",
            "finance.read", "finance.create_entry", "finance.reverse_entry",
            "reports.read", "reports.export", "audit.read", "customers.read",
        },
        ["Technician"] = new[]
        {
            "licenses.read", "licenses.activate", "licenses.disable_device",
            "support.read", "support.create", "support.manage", "catalog.read",
        },
        ["Salesperson"] = new[]
        {
            "customers.read", "customers.create", "customers.update",
            "subscriptions.read", "invoices.read", "invoices.create",
            "sales.read", "sales.manage", "reports.read",
        },
        ["Support"] = new[]
        {
            "support.read", "support.create", "support.manage",
            "customers.read", "subscriptions.read", "licenses.read", "invoices.read",
        },
        ["Finance"] = new[]
        {
            "finance.read", "finance.create_entry", "finance.reverse_entry",
            "payments.read", "payments.refund.approve", "payments.refund.execute",
            "reports.read", "reports.export", "audit.read", "invoices.read",
        },
    };

    public static string Category(string code) => code.Split('.', 2)[0];
}

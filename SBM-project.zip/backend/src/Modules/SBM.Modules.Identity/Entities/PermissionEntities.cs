using SBM.Shared.Abstractions;

namespace SBM.Modules.Identity.Entities;

/// <summary>Granular permission (e.g. users.create, payments.refund.approve). Platform-wide catalog, assigned per role or user.</summary>
public class Permission : AggregateRoot<Guid>
{
    public string Code { get; set; } = string.Empty;   // stable machine code
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = "general";
}

/// <summary>Role → Permission link. Roles are ASP.NET Identity roles (IdentityRole&lt;Guid&gt;) referenced by id.</summary>
public class RolePermission : AggregateRoot<Guid>
{
    public Guid RoleId { get; set; }
    public string PermissionCode { get; set; } = string.Empty;
}

/// <summary>Direct user → Permission override. IsGranted=false revokes a permission granted by role (explicit deny).</summary>
public class UserPermission : AggregateRoot<Guid>
{
    public Guid UserId { get; set; }
    public string PermissionCode { get; set; } = string.Empty;
    public bool IsGranted { get; set; } = true;
}

using Microsoft.AspNetCore.Identity;
using SBM.Shared.Abstractions;

namespace SBM.Modules.Identity.Entities;

public enum AccountScope { Platform = 0, Organization = 1 }

public class ApplicationUser : IdentityUser<Guid>
{
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>Platform administrators (owner's staff) vs customer organization users.</summary>
    public AccountScope Scope { get; set; } = AccountScope.Organization;

    public bool IsPlatformOwner { get; set; }
    public bool MfaEnabled { get; set; }
    public DateTimeOffset? DeactivatedAt { get; set; }

    /// <summary>Set only for customer-portal accounts: the customer this login may access. Staff accounts leave this null.</summary>
    public Guid? CustomerId { get; set; }

    /// <summary>When true, the user must choose a new password before any other action. Set by owner-initiated resets and forced password changes.</summary>
    public bool MustChangePassword { get; set; }

    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class Organization : AggregateRoot<Guid>, IOrganizationScoped
{
    public string Name { get; set; } = string.Empty;
    public string? LegalName { get; set; }
    public string? TaxIdentifier { get; set; }
    public string Country { get; set; } = "EG";
    public string? City { get; set; }
    /// <summary>IANA timezone identifier for organization-local display (UTC is stored internally).</summary>
    public string TimezoneId { get; set; } = "Africa/Cairo";
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public string Status { get; set; } = "Active"; // Active | Suspended
    public DateTimeOffset RegisteredAt { get; set; } = DateTimeOffset.UtcNow;

    // Tenant root: organization id equals its own id.
    public Guid OrganizationId => Id;
}

public class Branch : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Code { get; set; }
    public string? City { get; set; }
    public string Status { get; set; } = "Active";
}

public class OrganizationMembership : AggregateRoot<Guid>
{
    public Guid OrganizationId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid UserId { get; set; }
    public string Role { get; set; } = "Member"; // Owner | Manager | Member | Cashier | Accountant | Technician | Salesperson
    public string Status { get; set; } = "Active";
    public DateTimeOffset JoinedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class Invitation : AggregateRoot<Guid>, IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = "Member";
    public Guid? BranchId { get; set; }
    public string TokenHash { get; set; } = string.Empty;
    public DateTimeOffset ExpiresAt { get; set; }
    public string Status { get; set; } = "Pending"; // Pending | Accepted | Expired | Revoked
    public Guid InvitedByUserId { get; set; }
}

/// <summary>Server-side refresh session. Revocation is enforced on every refresh.</summary>
public class UserSession : AggregateRoot<Guid>
{
    public Guid UserId { get; set; }
    public string RefreshTokenHash { get; set; } = string.Empty;
    public string DeviceDescription { get; set; } = string.Empty;
    public string? IpAddress { get; set; }
    public DateTimeOffset IssuedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ExpiresAt { get; set; }
    public DateTimeOffset LastUsedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? RevokedAt { get; set; }
    public string? RevokedReason { get; set; }
    public bool IsActive => RevokedAt is null && ExpiresAt > DateTimeOffset.UtcNow;
}

public class SecurityEvent : AggregateRoot<Guid>
{
    public Guid? UserId { get; set; }
    public string EventType { get; set; } = string.Empty; // login.success, login.failed, session.revoked, ...
    public string? Details { get; set; }
    public string? IpAddress { get; set; }
    public DateTimeOffset OccurredAtUtc { get; set; } = DateTimeOffset.UtcNow;

    // Rich audit surface (append-only; never edit or delete existing rows).
    public Guid? OrganizationId { get; set; }
    public string? ActorType { get; set; }   // "staff" | "platform" | "portal" | "system"
    public string? TargetType { get; set; }  // User | Role | Permission | License | Payment | Refund | ...
    public string? TargetId { get; set; }
    public string? Action { get; set; }      // UserCreated | RoleChanged | PasswordResetInitiatedByOwner | ...
    public string? Result { get; set; }      // success | failure
    public string? CorrelationId { get; set; }
    public string? UserAgent { get; set; }
}

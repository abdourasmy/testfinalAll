using SBM.Shared.Abstractions;

namespace SBM.Modules.Licensing.Entities;

public enum LicenseState { Active = 0, Suspended = 1, Revoked = 2, Expired = 3 }
public enum LicenseType { Online = 0, Offline = 1, Hybrid = 2 }

public class License : AggregateRoot<Guid>, SBM.Shared.Abstractions.IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid CustomerId { get; set; }
    public Guid ProductId { get; set; }
    public Guid ApplicationId { get; set; }
    public Guid? SubscriptionId { get; set; }
    public Guid PlanId { get; set; }
    public LicenseType Type { get; set; } = LicenseType.Online;
    public LicenseState State { get; set; } = LicenseState.Active;
    public int DeviceLimit { get; set; } = 1;   // copied from plan at issuance (policy snapshot)
    public int SessionLimit { get; set; } = 1;  // concurrent sessions policy snapshot
    public DateTimeOffset IssuedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ExpiresAt { get; set; }
    public int GraceDays { get; set; } = 7;
    public DateTimeOffset? SuspendedAt { get; set; }
    public DateTimeOffset? RevokedAt { get; set; }
    public string? RevocationReason { get; set; }

    // Transfer policy (self-service)
    public int MaxTransfers { get; set; } = 3;
    public int TransferCooldownDays { get; set; } = 7;
    public int TransferCount { get; set; }
    public DateTimeOffset? LastTransferredAt { get; set; }
}

public class LicenseDevice : AggregateRoot<Guid>, SBM.Shared.Abstractions.IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid LicenseId { get; set; }
    public string DeviceId { get; set; } = string.Empty; // stable client-generated id
    public string DeviceName { get; set; } = string.Empty;
    public string Platform { get; set; } = "Windows";
    public DateTimeOffset ActivatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? DeactivatedAt { get; set; }
    public DateTimeOffset LastSeenAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? LastSyncAt { get; set; }
    public string? LastKnownAppVersion { get; set; }
    public string? DeviceType { get; set; }
    public bool IsActive => DeactivatedAt is null;
}

/// <summary>Concurrent-session lease. Server-issued; expiry enforced by heartbeat/renewal.</summary>
public class LicenseSession : AggregateRoot<Guid>, SBM.Shared.Abstractions.IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid SessionId { get; set; } = Guid.NewGuid();
    public Guid LicenseId { get; set; }
    public Guid DeviceActivationId { get; set; }
    public Guid? UserId { get; set; }
    public Guid ApplicationId { get; set; }
    public DateTimeOffset IssuedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ExpiresAt { get; set; }
    public DateTimeOffset LastHeartbeatAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? RevokedAt { get; set; }
    public bool IsLive(DateTimeOffset now) => RevokedAt is null && ExpiresAt > now;
}

/// <summary>Append-only license audit trail.</summary>
public class LicenseEvent : AggregateRoot<Guid>, SBM.Shared.Abstractions.IOrganizationScoped
{
    public Guid OrganizationId { get; set; }
    public Guid LicenseId { get; set; }
    public string EventType { get; set; } = string.Empty; // issued | activated | deactivated | renewed | suspended | revoked | transferred | lease.issued | lease.expired
    public string? Details { get; set; }
    public Guid? ActorUserId { get; set; }
    public DateTimeOffset OccurredAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

/// <summary>Signing-key metadata for ES256 license tokens. Private key material for production
/// lives in Azure Key Vault; this entity tracks identifiers, public keys and rotation state.</summary>
public class LicenseSigningKey : AggregateRoot<Guid>
{
    public string KeyId { get; set; } = string.Empty; // "kid" in token header/signature metadata
    public string Algorithm { get; set; } = "ES256";
    public string PublicKeyPem { get; set; } = string.Empty;
    public string? PrivateKeyPem { get; set; } // dev/local only; null when sourced from Key Vault
    public bool UseKeyVault { get; set; }
    public string Status { get; set; } = "Active"; // Active | Retired
    public DateTimeOffset NotBefore { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? RetiredAt { get; set; }
}

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SBM.Modules.Licensing.Crypto;

/// <summary>Versioned signed license payload (ES256 / ECDSA P-256 + SHA-256).</summary>
public sealed record LicensePayload(
    [property: JsonPropertyName("v")] int Version,
    [property: JsonPropertyName("iss")] string Issuer,
    [property: JsonPropertyName("lic")] Guid LicenseId,
    [property: JsonPropertyName("prd")] Guid ProductId,
    [property: JsonPropertyName("app")] Guid ApplicationId,
    [property: JsonPropertyName("cust")] Guid CustomerId,
    [property: JsonPropertyName("org")] Guid OrganizationId,
    [property: JsonPropertyName("iat")] long IssuedAtUnix,
    [property: JsonPropertyName("exp")] long ExpiresAtUnix,
    [property: JsonPropertyName("ent")] IReadOnlyList<string> Entitlements,
    [property: JsonPropertyName("dev")] LicensePolicy DevicePolicy,
    [property: JsonPropertyName("ses")] LicensePolicy SessionPolicy,
    [property: JsonPropertyName("kid")] string KeyId)
{
    public const int CurrentVersion = 1;
}

public sealed record LicensePolicy(
    [property: JsonPropertyName("limit")] int Limit); // 0 = unlimited

public sealed record SignedLicenseToken(string Token, string KeyId);

/// <summary>
/// ES256 signer/verifier. Keys are PEM (PKCS#8 private / SubjectPublicKeyInfo public).
/// Production deployments must set UseKeyVault on the signing key and provide an IKeyVaultSigner;
/// the private key never leaves Key Vault in that mode.
/// </summary>
public interface ILicenseSigner
{
    SignedLicenseToken Sign(LicensePayload payload, string privateKeyPem, string keyId);
    LicensePayload? Verify(string token, Func<string, string?> resolvePublicKeyPem, out string? failure);
}

public class EcdsaLicenseSigner : ILicenseSigner
{
    private static readonly JsonSerializerOptions JsonOptions = new() { DefaultIgnoreCondition = JsonIgnoreCondition.Never };

    public SignedLicenseToken Sign(LicensePayload payload, string privateKeyPem, string keyId)
    {
        var payloadJson = JsonSerializer.Serialize(payload, JsonOptions);
        var payloadBytes = Encoding.UTF8.GetBytes(payloadJson);
        using var ecdsa = ECDsa.Create();
        ecdsa.ImportPkcs8PrivateKey(Convert.FromBase64String(StripPem(privateKeyPem)), out _);
        var signature = ecdsa.SignData(payloadBytes, HashAlgorithmName.SHA256);
        return new SignedLicenseToken(Base64UrlEncode(payloadBytes) + "." + Base64UrlEncode(signature), keyId);
    }

    public LicensePayload? Verify(string token, Func<string, string?> resolvePublicKeyPem, out string? failure)
    {
        failure = null;
        var parts = token?.Split('.');
        if (parts is null || parts.Length != 2) { failure = "malformed-token"; return null; }

        byte[] payloadBytes, signature;
        try
        {
            payloadBytes = Base64UrlDecode(parts[0]);
            signature = Base64UrlDecode(parts[1]);
        }
        catch (FormatException) { failure = "malformed-token"; return null; }

        LicensePayload? payload;
        try { payload = JsonSerializer.Deserialize<LicensePayload>(payloadBytes, JsonOptions); }
        catch (JsonException) { failure = "malformed-payload"; return null; }
        if (payload is null) { failure = "malformed-payload"; return null; }
        if (payload.Version != LicensePayload.CurrentVersion) { failure = "unsupported-version"; return null; }

        var publicKeyPem = resolvePublicKeyPem(payload.KeyId);
        if (publicKeyPem is null) { failure = "unknown-key"; return null; }

        using var ecdsa = ECDsa.Create();
        try { ecdsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(StripPem(publicKeyPem)), out _); }
        catch (CryptographicException) { failure = "invalid-public-key"; return null; }

        if (!ecdsa.VerifyData(payloadBytes, signature, HashAlgorithmName.SHA256))
        {
            failure = "invalid-signature";
            return null;
        }
        return payload;
    }

    private static string StripPem(string pem) =>
        pem.Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "")
           .Replace("-----BEGIN PUBLIC KEY-----", "").Replace("-----END PUBLIC KEY-----", "")
           .Replace("\r", "").Replace("\n", "").Trim();

    private static string Base64UrlEncode(byte[] bytes) =>
        Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    private static byte[] Base64UrlDecode(string s)
    {
        var b64 = s.Replace('-', '+').Replace('_', '/');
        b64 = b64.PadRight(b64.Length + (4 - b64.Length % 4) % 4, '=');
        return Convert.FromBase64String(b64);
    }

    /// <summary>Generates a fresh ES256 key pair (PEM). Used for dev seeding and key rotation tooling.</summary>
    public static (string PublicPem, string PrivatePem) GenerateKeyPair()
    {
        using var ecdsa = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var pub = ecdsa.ExportSubjectPublicKeyInfoPem();
        var priv = ecdsa.ExportPkcs8PrivateKeyPem();
        return (pub, priv);
    }
}

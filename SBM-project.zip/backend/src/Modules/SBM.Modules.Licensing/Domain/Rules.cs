using SBM.Modules.Licensing.Entities;

namespace SBM.Modules.Licensing.Domain;

/// <summary>Explicit license state machine. A revoked or suspended license never becomes valid
/// merely because a subscription is active — callers must check license state independently.</summary>
public static class LicenseStateMachine
{
    private static readonly Dictionary<LicenseState, LicenseState[]> Allowed = new()
    {
        [LicenseState.Active] = new[] { LicenseState.Suspended, LicenseState.Revoked, LicenseState.Expired },
        [LicenseState.Suspended] = new[] { LicenseState.Active, LicenseState.Revoked, LicenseState.Expired },
        [LicenseState.Revoked] = Array.Empty<LicenseState>(),   // terminal
        [LicenseState.Expired] = new[] { LicenseState.Active }, // renewed
    };

    public static bool CanTransition(LicenseState from, LicenseState to) =>
        Allowed.TryGetValue(from, out var targets) && targets.Contains(to);

    public static void EnsureTransition(LicenseState from, LicenseState to)
    {
        if (!CanTransition(from, to))
            throw new InvalidOperationException($"Illegal license state transition {from} -> {to}.");
    }

    public static LicenseStateMachineResult Transition(LicenseState from, LicenseState to) =>
        CanTransition(from, to) ? new(true, null) : new(false, $"Illegal license state transition {from} -> {to}.");

    public sealed record LicenseStateMachineResult(bool Success, string? Error);
}

/// <summary>Device policy enforcement. DeviceLimit of 0 means unlimited.</summary>
public static class DevicePolicy
{
    public static bool CanActivate(int currentActiveDevices, int deviceLimit) =>
        deviceLimit == 0 || currentActiveDevices < deviceLimit;
}

/// <summary>Concurrent-session policy enforcement, independent of device limit. 0 = unlimited.</summary>
public static class SessionPolicy
{
    public static bool CanStartSession(int liveSessions, int sessionLimit) =>
        sessionLimit == 0 || liveSessions < sessionLimit;
}

/// <summary>Self-service license transfer policy.</summary>
public static class TransferPolicy
{
    public sealed record TransferDecision(bool Allowed, string? Reason);

    public static TransferDecision Evaluate(int transferCount, int maxTransfers, DateTimeOffset? lastTransferredAt, int cooldownDays, DateTimeOffset now)
    {
        if (transferCount >= maxTransfers)
            return new(false, $"Transfer limit reached ({maxTransfers}).");
        if (lastTransferredAt is { } last && now - last < TimeSpan.FromDays(cooldownDays))
            return new(false, $"Transfer cooldown active until {last.AddDays(cooldownDays):u}.");
        return new(true, null);
    }
}

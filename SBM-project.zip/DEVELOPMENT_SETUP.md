# Development Setup

## Prerequisites

| Tool | Version | Notes |
|---|---|---|
| .NET SDK | 10.0.x | `dotnet --list-sdks`; project targets `net10.0` |
| SQL Server LocalDB | any recent | ships with Visual Studio / Build Tools; `sqllocaldb start MSSQLLocalDB` |
| Git | 2.4x+ | |
| (Optional) Node.js | 22 | only for the retired React SPA in `frontend/web` — not required for SBM.Web |

Flutter is **not** required for the current scope (mobile/desktop are out of scope - see `PROJECT_STATUS.md`).

## First-time setup

```powershell
cd backend
dotnet restore SBM.slnx
dotnet build SBM.slnx
dotnet ef database update --project src/SBM.Infrastructure --startup-project src/SBM.Api
dotnet test                                   # expect 74 unit + 17 API integration + 22 web integration, all passing
dotnet run --project src/SBM.Api              # JWT API: http://localhost:5220
dotnet run --project src/SBM.Web --urls http://localhost:5221   # Staff console + portal: http://localhost:5221
```

A one-shot helper exists: `.\infrastructure\scripts\dev-setup.ps1`.

## Development seed

On Development startup (guarded by `Seed:Enable`), the app creates:

- Roles: `PlatformAdmin`, `Owner`, `Manager`, `Member`, plus cashier/accountant/technician/salesperson/support/finance roles.
- Platform owner `owner@sbm.local` (password `Owner!Test123`, overridable via `Seed__OwnerPassword`) - **dev only**; change immediately; never use in production.
- A throwaway ES256 signing key (`kid = dev-yyyymmdd`).
- Sample product `REPAIR-PRO` (Desktop, Windows, v2.1.0) with plan `PRO-MONTHLY` (DeviceLimit 3, SessionLimit 2) and features.

With `Seed:DemoData=true` (set in `appsettings.Development.json`), the web host also seeds an idempotent demo dataset:

- Demo organization `شركة تصليح برو (تجريبي)` and customer `عميل العرض التجريبي`.
- Org manager `manager@demo.sbm.local` / `ManagerDemo!123` (Manager role, membership in the demo org).
- Portal account `portal@sbm.local` / `PortalDemo!123` (linked to the demo customer; `customer_id` claim).
- One active subscription (PRO-MONTHLY), one license, two invoices (`INV-DEMO-0001` issued, `INV-DEMO-0002` paid), one open support ticket, one pending subscription-renewal approval request.
- Passwords come from config with **development-only defaults** (`Seed:DemoPortalPassword`, `Seed:DemoManagerPassword`). Demo seeding never runs unless `Seed:DemoData=true`; never enable in production configuration.

## Configuration

Configuration is standard ASP.NET (appsettings + environment variables with `__`). Reference:

| Key | Default (dev) | Notes |
|---|---|---|
| ConnectionStrings:SbmDatabase | LocalDB `SBM` | required; production uses Azure SQL with secrets |
| Jwt:Key | random per process | set via secret store; processes invalidate tokens on restart if unset |
| Jwt:Issuer / Jwt:Audience | sbm / sbm-api | |
| Seed:Enable | true (Dev) | **never true in production** |
| Seed:DemoData | true (Dev web host) | idempotent demo data; **never true in production** |
| Database:ApplyMigrationsOnStartup | true (Dev) | production applies migrations in CI/CD |
| Releases:StoragePath | `<web>/App_Data/releases` | release assets live outside the web root; set explicitly in production |
| Release:Version | dev | shown on Settings page |

## Web (staff console & portal)

- Staff console: `/` (login at `/login`). Arabic RTL by default; language toggle `/lang/en`.
- Customer portal: `/portal` (login at `/portal/login`). Separate cookie audience; every query is scoped by the `customer_id` claim.
- Seeded owner: `owner@sbm.local` / `Owner!Test123` (platform owner sees all tenants).
- Demo manager: `manager@demo.sbm.local` / `ManagerDemo!123` (org-scoped console).
- Demo portal: `portal@sbm.local` / `PortalDemo!123`.

## Health checks

- API: `/health`, `/health/ready`, `/health` equivalents on the web host at `/healthz`.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `Login failed for user` / LocalDB timeout | LocalDB not running | `sqllocaldb start MSSQLLocalDB` |
| Migration fails with duplicate object | stale scratch DB in dev | `dotnet ef database drop --project src/SBM.Infrastructure --startup-project src/SBM.Api` (dev only) |
| 401 on all API calls | wrong/expired token | login again; JWT is short-lived |
| Web POST returns 400 | missing antiforgery token | use the forms (token is injected); HTMX sends it via the `<meta name="csrf-token">` header |
| `License signing key is Key Vault-backed` error | `UseKeyVault=true` without KeyVault signer | wire Key Vault or use dev seed key |
| Tests time out on LocalDB | LocalDB contention with a running dev server | stop the dev server before running integration tests; suites use unique scratch databases and run single-threaded |

## Coding conventions

- C# nullable reference types enabled; 4-space indent; file-scoped namespaces; `decimal` for money.
- Razor views: RTL-first (`dir="rtl"`), bilingual Arabic/English literals via `LanguageService.T()`.
- HTMX for partial updates; antiforgery token rides every HTMX POST via `<meta name="csrf-token">` + `RequestVerificationToken` header.
- Tenant isolation is explicit: `TenantScope.Org(...)` / `Owns(...)`; no implicit EF query filters.

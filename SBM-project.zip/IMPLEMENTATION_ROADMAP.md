# SBM Implementation Roadmap

Legend: ✅ done & verified · 🟡 partial (works, gaps documented) · ⬜ not started (documented dependency or phase)

## Phase 0 - Greenfield foundation - ✅ (with notes)

- ✅ Repo structure, .editorconfig, .gitignore, solution (now 15 projects), CI workflow
- ✅ Backend: ASP.NET Core 10 (+ EF Core 10, Identity, JWT), modular monolith
- ✅ Health checks (/health, /health/ready, /healthz), structured logging, global exception middleware, security headers, rate limiting
- ✅ AuthN (JWT access + rotating refresh sessions, lockout, revocation, security events)
- ✅ AuthZ: PlatformAdmin / OrgManager policies; platform vs organization scope separation
- ✅ EF Core migrations on LocalDB; execution-strategy retries
- ✅ Unit tests (74) + integration tests (39; 17 API + 22 web, LocalDB-backed, migrations applied); CI green (backend job + web boot-smoke job)
- 🟡 Structured logging (Microsoft.Extensions.Logging; Serilog/OpenTelemetry not wired)
- 🟡 Technical spikes documented (Windows notifications, Key Vault, ETA e-invoicing) - blockers logged in PROJECT_STATUS

## Phase 1 - Owner MVP - ✅ (with documented gaps)

Done: Identity/tenancy (orgs, branches, memberships, enforcement), product catalog (products, applications, plans, features/entitlements), customers + CRM basics, licenses (issue/activate/lease/transfer/revoke, ES256, device & session limits, signing-key rotation), subscriptions (create/cancel, state machine, grace → ReadOnly policy), billing (invoice numbering concurrency-safe, idempotent payments, refunds with approval), finance (append-only journal with reversals), dashboards, sales lifecycle (Quotation → Send → Accept → Order → Confirm → Fulfill → Invoice) with sync-journal outbox integration, Arabic/English RTL UI.

Support module: ✅ done & verified (tickets, SLA due dates, team triage, customer portal replies).

Remaining (honest gaps): organization/user self-management UI (invitation flow), audit-log UI filters are minimal, real notification providers, release asset streaming from Blob Storage (filesystem today).

## Phase 1.5 - Egyptian fiscal review - ⬜ blocked externally
ETA e-invoicing/e-receipt applicability, tax codes, currency handling (EGP decimal is already safe), ETA SDK integration, professional accounting sign-off. No compliance claims are made. Tracks to official ETA publications before any implementation.

## Phase 2 - Advanced licensing & notifications - ✅ core (~75%)

Done: ES256 payloads, key rotation, device/session policy enforcement, heartbeat leases, transfer policy, audience rule engine (nested AND/OR/NOT, semver predicates, deterministic Top-N, frozen snapshots + content hash, opt-out/quiet-hours/frequency caps, dedup semantics, outbox + backoff + DLQ, `ProviderAccepted ≠ Delivered`), campaigns with launch/cancel/delivery summary, delivery through the real outbox dispatcher (dev logging provider), audience builder UI with server-side validate/preview.

Remaining: real provider adapters (FCM/SMTP/WebPush), remote configuration service + feature flags rollout, delivery-confirmation ingestion, scheduled campaign execution worker, Windows toast feasibility, offline-sync SDK for clients.

## Phase 3 - Release management - ✅ (core)

Done: `SoftwareRelease`/`ReleaseAsset` entities + `WebPlatformExpansion` migration, platform-admin UI (create draft, register asset with server-side SHA-256, publish, yank), channel + SemVer validation, unique release triple, per-request server-side eligibility checks in the portal, direct downloads with `X-Asset-Sha256` header, verified end-to-end (publish → eligible download → yank → 404).

Remaining: staged rollout (channels already modeled), code signing verification, Azure Blob Storage assets with signed URLs (filesystem storage today via `Releases:StoragePath`).

## Phase 4 - Resellers - ✅ (core)

Done: `Reseller`/`ResellerCommission` entities, platform-admin reseller management, commission calculation from paid invoices of attributed customers (`Customer.ResellerId`), idempotent commission rows per (reseller, invoice), approval workflow.

Remaining: reseller statements, automated commission payout, reseller portal (self-service).

## Phase 5 - Customer portal & support - ✅

Done: portal at `/portal` (separate cookie audience, `customer_id` isolation), subscriptions + renewal/cancellation requests (flow into staff approval queue; approval executes the business transition), licenses + device self-deactivation, invoices (real QuestPDF PDFs), eligible releases with server-side eligibility checks + downloads, support tickets + customer replies, language toggle. Verified end-to-end including portal→staff approval execution.

Remaining: portal downloads of offline license payloads, portal-side payment method management (needs payment provider integration), notification center in portal.

## Phase 6 - BI & automation - 🟡 (~25%)

Done: nine database-backed reports (revenue, payments, outstanding invoices, subscriptions, licenses, top customers, expenses, cancellations, support SLA) with CSV/XLSX/PDF export; dashboard with six-month chart and KPIs; audit log.

Remaining: saved/scheduled reports, telemetry ingestion, anomaly alerts, campaign A/B analytics, performance optimization passes.

## Recommended next milestones (in order)

1. Organization/user invitation + self-management UI (unblocks real tenant onboarding).
2. Notification provider adapters (FCM + SMTP) with delivery-status ingestion; then wire real campaign sending end-to-end.
3. Remote configuration + feature flags (rollout + kill switch; reused by desktop/mobile later).
4. Release asset storage on Azure Blob with signed URLs + code signing attestation.
5. Telemetry ingestion + dashboards (Phase 6).
6. Fiscal compliance review (Phase 1.5) with an external accountant — before any invoice goes to a customer.

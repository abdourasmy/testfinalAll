# SBM Security

## Scope

Identity, multi-tenancy, licensing, payments, notifications, file distribution, and administrative operations — the areas where a flaw is business-critical.

## Controls in place

**Authentication**
- ASP.NET Core Identity password storage (PBKDF2), lockout after 5 failures for 15 minutes, configurable.
- JWT bearer access tokens (15 min) + opaque refresh sessions rotated on every refresh; sessions are revocable server-side and on logout; deactivated accounts cannot authenticate.
- Rate limiting on `/api/auth/*` (10/min fixed window) and general API (300/min).

**Authorization**
- Role-based: `PlatformAdmin` (owner's staff) is strictly separated from organization roles (`Owner`, `Manager`, `Member`, cashier/accountant/technician/salesperson roles).
- `OrgManager` policy: platform admin **or** organization `Owner`/`Manager`.
- Every sensitive mutation checks tenant ownership or platform scope server-side (never client input). Explicit `TenantScope` row scoping; no implicit query filters.

**Data protection**
- Secrets: none in source. Dev uses a generated throwaway JWT key and a per-environment ES256 seed key; production must use Key Vault (`Jwt__Key` via secret store; `LicenseSigningKey.UseKeyVault=true`).
- License tokens are ES256-signed; clients can verify offline without trusting client-side state.
- Payments are never marked paid from a client callback; confirmation requires server-side provider verification (or explicit manual confirmation by authorized staff). Idempotency keys prevent double processing.

**Input/output**
- Request validation via typed DTOs + MinimalProblemDetails-style exception mapping (no stack traces leak; 500s log internally only).
- Parameterized EF Core queries only; audience rule engine has a typed field registry and no expression/SQL evaluation; raw SQL is never composed from user input.
- Security headers on every response (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, restrictive CSP).

**Audit**
- `SecurityEvent` records login success/failure/lockout + rich structured events (action, result, target, correlation, user agent, IP) — append-only, never deleted through the UI.
- `LicenseEvent` records license lifecycle (issue/activate/revoke/transfer/lease). Append-only `FinanceEntry` (reversals, never edits). Outbox dead-lettering is logged.
- `docs/SECURITY_INVARIANTS.md` lists the enforced invariants and their tests.

## 2026-11-18 — Production Hardening addendum

- Granular `Permission` / `RolePermission` / `UserPermission` system (51 catalog entries) with defaults per role; platform admin implicitly has all. `Users & Permissions` owner section: create/disable users, assign roles, grant/revoke permissions, reset password (one-time, forced change at next login), reset MFA, revoke sessions. Full model in `docs/USER_PERMISSIONS.md`.
- Forgot-password flow: identity token, one-time, 15-min lifetime, hashed at rest by Identity, anti-enumeration response, rate-limited, all sessions revoked on completion (`SecurityStamp` rotation).
- Global EF Core **query filters** as defense-in-depth on top of explicit `TenantScope` (see `SbmDbContext.ApplyTenantQueryFilters`); background workers are untouched.
- Session revocation via cookie `stamp` claim validated per-request (45s cache) — any stamp rotation (password reset, MFA reset, disable) kills all sessions within 45s.
- Production startup fails fast if `Seed:Enable` or `Seed:DemoData` are true (no demo accounts in production).
- Reports export hard cap 10,000 rows; CSV formula-injection guard.
- Refund execution is atomic under serializable transaction; sum(approved+processed) ≤ paid amount enforced; `ConcurrencyTests` covers parallel refund and device-activation races.

## Threat model (abbreviated)

| Threat | Mitigation | Residual risk |
|---|---|---|
| Cross-tenant data access (IDOR) | Tenant derived from signed token; explicit row scoping on every query; integration tests assert isolation | New endpoints must remember scoping — mitigated by `TenantScope` helper convention + tests |
| Privilege escalation (org → platform) | Separate `scope` claim + policy checks; dashboard requires `PlatformAdmin` | Role management UI not built yet |
| License forgery | ES256 signature verification; server is the only issuer; offline validation requires correct signed payload | Dev seed key must be rotated before any real distribution |
| Payment spoofing | Server-side confirmation only; idempotency keys; manual confirmations are staff-authorized | Real provider webhooks must be wired with signature verification before accepting real money |
| Token theft / replay | Short-lived JWTs; refresh rotation; server-side revocation; HTTPS required | XSS could exfiltrate token from web app — keep CSP tight; prefer httpOnly cookies for the web app |
| Notification abuse | Opt-out, quiet hours, frequency caps, dedup, campaign idempotency | In-app endpoints are user ids; real providers must enforce suppression lists |
| Denial of service | Rate limiting, request timeouts, connection pooling with retry | SQLi not applicable (EF parameterized) |

## Known limitations / not yet in place

- MFA is architecturally ready (`MfaEnabled` claim on user) but no second-factor enrollment UI yet.
- Secrets rotation drills and Key Vault integration are untested in this environment (no Azure subscription).
- No DAST/SAST pipeline yet (dependency audit is in CI).
- ETA e-invoicing / tax compliance: not implemented; requires official spec review + professional accounting sign-off (Phase 1.5). Do not represent SBM as compliant.

## Key Vault / production secret wiring (documented, not executed)

1. Store JWT key and license private key in Azure Key Vault.
2. Managed identity on the app service; `KeyVaultKeyStrategy` for signing; set `LicenseSigningKey.UseKeyVault=true` and null `PrivateKeyPem`.
3. CI/CD injects `ConnectionStrings__SbmDatabase` and `Jwt__Key` from Key Vault references only.
4. Rotate ES256 keys with overlapping validity (old key remains verifiable via `kid` until all outstanding tokens expire).

# Changelog

## [0.3.0] - 2026-11-18 — Production Hardening V1.0 (partial, verified)

### Added
- **Users & Permissions** owner section (`/users`): list/search/filter by role/status; create users with temporary one-time password (forced change at next login); disable/enable; assign/remove roles (not PlatformAdmin); direct grant/revoke of 51 catalog permissions; reset password (one-time, forced change); reset MFA; revoke all sessions (SecurityStamp rotation kills sessions within 45s); effective permissions view; security activity per user; permission system backed by `Permission`/`RolePermission`/`UserPermission` tables.
- **Granular permission enforcement**: `RequiresPermission` filter (Owner/PlatformAdmin full access; everyone else needs the permission). PlatformAdmin bypass; caller cannot grant a permission they do not possess.
- **Owner protection**: last-Owner removal blocked on every path (disable/demote); audit of blocked attempts; PlatformAdmin cannot be assigned from tenant screens.
- **Session hardening**: staff cookie carries `stamp`; per-request validation (45s cache) revokes sessions on stamp rotation (password change/reset, MFA reset, disable).
- **Force password change**: global filter redirects flagged users to `/change-password` for everything else.
- **Forgot password**: email-based link, one-time Identity token (hashed at rest, ~1-hour lifespan), anti-enumeration response, rate-limited (20/min/IP), all sessions invalidated on completion. Production uses a real provider to send emails; Development shows the link on-screen.
- **Owner password reset**: generates a temporary one-time password (plaintext never logged/stored), forces password change at next login, invalidates sessions.
- **Audit**: `SecurityEvent` extended (action/result/target/actor/correlation/user-agent) — append-only; password/MFA/session/user events recorded.
- **Correlation ID**: `X-Correlation-ID` middleware; echoed on every response; validated inbound; used by the audit writer.
- **Rate limiting (web)**: fixed-window 20/min/IP on login, MFA login, change/forgot/reset password.
- **EF Core global query filters** on every `IOrganizationScoped` entity as defense-in-depth (tenant/platform/none semantics, no filters on workers). `TenantScope` stays the explicit primary mechanism.
- **Organization timezone**: stored per organization (`TimezoneId`, default Africa/Cairo); UTC in storage; display wiring next release.

### Fixed
- **Payment idempotency**: scoped to `(OrganizationId, OperationType, IdempotencyKey)`; reuse with a *different* payload returns 409 Conflict instead of replaying the stored result (fingerprint check).
- **Refund invariant**: `sum(approved+processed) ≤ paid amount` enforced under serializable transaction at request AND approval; concurrent refund approval test added.
- **License activation concurrency**: per-license `sp_getapplock` + transaction + retry strategy — 10 concurrent activations of a 2-device-limit license now yield exactly ≤2 active devices (was: race-prone).
- **Production seed lockout**: `ProductionSeedGuard` throws at startup if `Seed:Enable`/`Seed:DemoData` are true in production (unit-tested); `appsettings.json` now defaults to `false`/`false`, `appsettings.Development.json` restores dev seed for dev only.
- **Execution strategy + transactions**: manual transactions wrapped in `CreateExecutionStrategy()` (retry-on-failure compatible) — API integration suite is green again (was failing 3/17).

### Tests
- Unit: 78/78 (+4 new: ProductionSeedGuard). API integration: 17/17. Web integration: 25/25 (+2 new concurrency). Total **120/120**.
- New `GlobalTenantFilterCheckTest` proves the global query filter enforces A/B/platform/none semantics.

### Known limitations (documented, not hidden)
- Notification providers (FCM/SMTP/WebPush) still dev-only.
- Correlation ID not yet written onto every outbox message.
- Exports capped at 10,000 rows; formula-injection-guarded CSV.
- Release assets live on the web server filesystem (`Releases:StoragePath`); production needs Blob + signed URLs.
- PlatformAdmin MFA not enforced (recommended, not required).

## [0.2.0] - 2026-11-18 - MVC + HTMX web platform (restored)

### Added
- `backend/src/SBM.Web` — ASP.NET Core MVC + Razor + HTMX web platform (port 5221) superseding the retired React SPA:
  - Staff console: dashboard (live metrics, six-month revenue chart, HTMX pending-approvals badge), Customers, Leads, Catalog, Subscriptions, Licenses, Invoices (real PDF download via QuestPDF), Finance journal, Sales full lifecycle (Quotation → Send → Accept → Convert to Order → Confirm → Fulfill → Convert to Invoice) with `SalesEvents` audit + outbox sync-journal integration, Refunds lifecycle, Approvals queue, Campaigns, Audience builder (server-side rule-engine validate/preview), platform Releases (create/publish/yank with SHA-256 asset registration), Resellers (commission calculation + approval), Support, nine database-backed Reports with CSV/XLSX/PDF export, Audit log, Settings, MFA (TOTP enrollment/QR/recovery codes).
  - Customer portal at `/portal` with a **separate cookie audience** (`sbm.portal`), `customer_id`-scoped isolation on every operation, subscription renewal/cancellation requests flowing into the staff approval queue, invoice PDFs, eligible release downloads with per-request server-side eligibility checks, support tickets, self-service device deactivation.
  - Cookie auth with two audiences; antiforgery on every POST (global filter + HTMX `RequestVerificationToken` header); friendly bilingual 403/404 pages instead of bare `Forbid()`; HTTP-level tenant isolation tests.
  - New entities and one migration (`WebPlatformExpansion`): `Quotation`/`QuotationLine`/`SalesOrder`/`SalesOrderLine`/`SalesEvent` (in Billing module), `ApprovalRequest` (Subscriptions module), `SoftwareRelease`/`ReleaseAsset` (Catalog module), `Reseller`/`ResellerCommission` (Billing module), `SystemSetting` (Infrastructure), `ApplicationUser.CustomerId` (portal linkage), `Customer.ResellerId` (commission attribution).
  - Development-only, idempotent demo seed (`Seed:DemoData=true`): demo organization/customer, manager and portal accounts, two invoices, one subscription, one license, one ticket, one pending renewal request.
- `backend/SBM.Web/Dockerfile` and `backend/SBM.Api/Dockerfile` (multi-stage); `docker-compose.yml` updated: JWT API on host 5220, MVC web on host 8080 (`docker compose config` valid).
- CI: `web` job now builds `SBM.Web` and boot-smoke-tests it against LocalDB (`/healthz`, `/login`); React build job removed (React SPA retired; ADR 0005 supersedes ADR 0002). Unrelated workflows preserved.
- Tests: new project `SBM.Web.IntegrationTests` (22 tests: auth, antiforgery, tenant isolation, portal isolation, sales workflow end-to-end, audience validation/preview, report exports, PDF downloads, MFA enroll/confirm/disable with real TOTP, release eligibility + yank, portal→staff approval flow). API integration suite kept green (17). Total 113 tests.
- Documentation: `COMPLETION_REPORT.md`, ADRs 0005 (MVC + HTMX), 0002 marked superseded, `TECH` refresh of README/PROJECT_STATUS/CHANGELOG/DEVELOPMENT_SETUP/DEPLOYMENT_GUIDE/ARCHITECTURE.

### Fixed
- Reports `revenue` and `payments` no longer fail with untranslatable EF SQL grouping (client-side grouping preserved; regression tests added).
- Platform-owner operations no longer return bare `Forbid()` — friendly localized 403 pages (security policy unchanged).
- `UseStatusCodePagesWithReExecute` no longer masks 4xx POSTs as "405 Allow: GET" (status page endpoint accepts any HTTP method).
- `MfaController` recovery-codes route collision with `/mfa/recovery-codes` POST (404 fixed); MFA flow verified end-to-end (enroll → TOTP login → recovery code redemption → disable).
- Approval service renewal path no longer rejects valid Active→Active renewals (state machine only guards real status transitions now).
- Outbox drains unknown/non-campaign message types gracefully (acknowledges sales/sync-journal rows).

### Changed
- `TenantScope` moved from `SBM.Api` to `SBM.Shared.Abstractions` (single source of truth for both hosts).

## [0.1.0] - 2026-11-17 - Greenfield MVP foundation

### Added
- Backend (ASP.NET Core 10): Identity/tenancy (JWT access + rotating refresh sessions, role/scope separation), Customers + CRM basics, Catalog (products/applications/plans/features), Licensing (ES256 payloads, device & session policies, heartbeat leases, transfer policy, revocation, key rotation), Subscriptions (state machine, grace → ReadOnly), Billing (concurrency-safe invoice numbering, idempotent payments, refunds with approval), Finance (append-only journal + reversals), Notifications (rule engine, preview, campaigns, transactional outbox, retry/DLQ, opt-out/quiet hours/caps, deterministic Top-N).
- Web frontend (React + TypeScript + Vite): Arabic RTL default + English LTR, login, Owner Command Center dashboard, customers list/create, licenses, finance summary.
- Backend builds clean; `dotnet test` = 90 tests green.
- CI workflow (GitHub Actions) for backend build/test and frontend build/audit.
- Support module: tickets with SLA due dates by priority, status state machine (Open→InProgress→OnHold→Resolved→Closed; reopen via InProgress), internal vs customer comments (staff-only internal notes), tenant isolation - unit and integration tests.
- Documentation: architecture, security, deployment, API, DB design, roadmap, setup, backup drill.

### Fixed
- JWT authentication default scheme: Identity application cookie was winning challenges (401 with `/Account/Login` redirect) - now JWT Bearer is the default scheme for authenticate/challenge/forbid.
- Tenant isolation: implicit EF query filters were unreliable (shared model caching) - replaced with explicit `TenantScope` scoping everywhere; verified by integration tests.
- Invoice numbering: replace Serializable/upsert sequence approach with optimistic rowversion cycle (deadlock-free under 5-way concurrency).

- Audience/campaign delivery lifecycle: campaigns flip to `Completed`/`PartiallyFailed` automatically when all recipients reach a terminal state (or when the audience was empty); integration test `CampaignDispatchTests` verifies launch → dispatch → completion via the real outbox worker.

### Known limitations
- No real notification providers (FCM/SMTP/WebPush/Windows not wired), no Key Vault integration exercise, no ETA fiscal compliance, no Flutter apps (SDK unavailable), no support module UI, no exports.

### Added
- Backend (ASP.NET Core 10): Identity/tenancy (JWT access + rotating refresh sessions, role/scope separation), Customers + CRM basics, Catalog (products/applications/plans/features), Licensing (ES256 payloads, device & session policies, heartbeat leases, transfer policy, revocation, key rotation), Subscriptions (state machine, grace → ReadOnly), Billing (concurrency-safe invoice numbering, idempotent payments, refunds with approval), Finance (append-only journal + reversals), Notifications (rule engine, preview, campaigns, transactional outbox, retry/DLQ, opt-out/quiet hours/caps, deterministic Top-N).
- Web frontend (React + TypeScript + Vite): Arabic RTL default + English LTR, login, Owner Command Center dashboard, customers list/create, licenses, finance summary.
- Backend builds clean; `dotnet test` = 90 tests green.
- CI workflow (GitHub Actions) for backend build/test and frontend build/audit.
- Support module: tickets with SLA due dates by priority, status state machine (Open→InProgress→OnHold→Resolved→Closed; reopen via InProgress), internal vs customer comments (staff-only internal notes), tenant isolation — unit and integration tests.
- Documentation: architecture, security, deployment, API, DB design, roadmap, setup, backup drill.

### Fixed
- JWT authentication default scheme: Identity application cookie was winning challenges (401 with `/Account/Login` redirect) — now JWT Bearer is the default scheme for authenticate/challenge/forbid.
- Tenant isolation: implicit EF query filters were unreliable (shared model caching) — replaced with explicit `TenantScope` scoping everywhere; verified by integration tests.
- Invoice numbering: replace Serializable/upsert sequence approach with optimistic rowversion cycle (deadlock-free under 5-way concurrency).

- Audience/campaign delivery lifecycle: campaigns flip to `Completed`/`PartiallyFailed` automatically when all recipients reach a terminal state (or when the audience was empty); integration test `CampaignDispatchTests` verifies launch → dispatch → completion via the real outbox worker.

### Known limitations
- No real notification providers (FCM/SMTP/WebPush/Windows not wired), no Key Vault integration exercise, no ETA fiscal compliance, no Flutter apps (SDK unavailable), no support module UI, no exports.

# Changelog

## [0.2.0] - 2026-11-18 - MVC + HTMX web platform (restored)

### Added
- `backend/src/SBM.Web` — ASP.NET Core MVC + Razor + HTMX web platform (port 5221) superseding the retired React SPA:
  - Staff console: dashboard (live metrics, six-month revenue chart, HTMX pending-approvals badge), Customers, Leads, Catalog, Subscriptions, Licenses, Invoices (real PDF download via QuestPDF), Finance journal, Sales full lifecycle (Quotation → Send → Accept → Convert to Order → Confirm → Fulfill → Convert to Invoice) with `SalesEvents` audit + outbox sync-journal integration, Refunds lifecycle, Approvals queue, Campaigns, Audience builder (server-side rule-engine validate/preview), platform Releases (create/publish/yank with SHA-256 asset registration), Resellers (commission calculation + approval), Support, nine database-backed Reports with CSV/XLSX/PDF export, Audit log, Settings, MFA (TOTP enrollment/QR/recovery codes).
  - Customer portal at `/portal` with a **separate cookie audience** (`sbm.portal`), `customer_id`-scoped isolation on every operation, subscription renewal/cancellation requests flowing into the staff approval queue, invoice PDFs, eligible release downloads with per-request server-side eligibility checks, support tickets, self-service device deactivation.
  - Cookie auth with two audiences; antiforgery on every POST (global filter + HTMX `RequestVerificationToken` header); friendly bilingual 403/404 pages instead of bare `Forbid()`; HTTP-level tenant isolation tests.
  - New entities and one migration (`WebPlatformExpansion`): `Quotation`/`QuotationLine`/`SalesOrder`/`SalesOrderLine`/`SalesEvent` (in Billing module), `ApprovalRequest` (Subscriptions module), `SoftwareRelease`/`ReleaseAsset` (Catalog module), `Reseller`/`ResellerCommission` (Billing module), `SystemSetting` (Infrastructure), `ApplicationUser.CustomerId` (portal linkage), `Customer.ResellerId` (commission attribution).
  - Development-only, idempotent demo seed (`Seed:DemoData=true`): demo organization/customer, manager and portal accounts, two invoices, one subscription, one license, one ticket, one pending renewal request.
- `backend/SBM.Web/Dockerfile` and `backend/SBM.Api/Dockerfile` (multi-stage); `docker-compose.yml` updated: JWT API on host 5220, MVC web on host 8080 (`docker compose config` valid).
- CI: `web` job now builds `SBM.Web` and boot-smoke-tests it against LocalDB (`/healthz`, `/login`); React build job removed (React SPA retired; ADR 0005 supersedes ADR 0002). Unrelated workflows preserved.
- Tests: new project `SBM.Web.IntegrationTests` (22 tests: auth, antiforgery, tenant isolation, portal isolation, sales workflow end-to-end, audience validation/preview, report exports, PDF downloads, MFA enroll/confirm/disable with real TOTP, release eligibility + yank, portal→staff approval flow). API integration suite kept green (17). Total 113 tests.
- Documentation: `COMPLETION_REPORT.md`, ADRs 0005 (MVC + HTMX), 0002 marked superseded, `TECH` refresh of README/PROJECT_STATUS/CHANGELOG/DEVELOPMENT_SETUP/DEPLOYMENT_GUIDE/ARCHITECTURE.

### Fixed
- Reports `revenue` and `payments` no longer fail with untranslatable EF SQL grouping (client-side grouping preserved; regression tests added).
- Platform-owner operations no longer return bare `Forbid()` — friendly localized 403 pages (security policy unchanged).
- `UseStatusCodePagesWithReExecute` no longer masks 4xx POSTs as "405 Allow: GET" (status page endpoint accepts any HTTP method).
- `MfaController` recovery-codes route collision with `/mfa/recovery-codes` POST (404 fixed); MFA flow verified end-to-end (enroll → TOTP login → recovery code redemption → disable).
- Approval service renewal path no longer rejects valid Active→Active renewals (state machine only guards real status transitions now).
- Outbox drains unknown/non-campaign message types gracefully (acknowledges sales/sync-journal rows).

### Changed
- `TenantScope` moved from `SBM.Api` to `SBM.Shared.Abstractions` (single source of truth for both hosts).

## [0.1.0] - 2026-11-17 - Greenfield MVP foundation

### Added
- Backend (ASP.NET Core 10): Identity/tenancy (JWT access + rotating refresh sessions, role/scope separation), Customers + CRM basics, Catalog (products/applications/plans/features), Licensing (ES256 payloads, device & session policies, heartbeat leases, transfer policy, revocation, key rotation), Subscriptions (state machine, grace → ReadOnly), Billing (concurrency-safe invoice numbering, idempotent payments, refunds with approval), Finance (append-only journal + reversals), Notifications (rule engine, preview, campaigns, transactional outbox, retry/DLQ, opt-out/quiet hours/caps, deterministic Top-N).
- Web frontend (React + TypeScript + Vite): Arabic RTL default + English LTR, login, Owner Command Center dashboard, customers list/create, licenses, finance summary.
- Backend builds clean; `dotnet test` = 90 tests green.
- CI workflow (GitHub Actions) for backend build/test and frontend build/audit.
- Support module: tickets with SLA due dates by priority, status state machine (Open→InProgress→OnHold→Resolved→Closed; reopen via InProgress), internal vs customer comments (staff-only internal notes), tenant isolation - unit and integration tests.
- Documentation: architecture, security, deployment, API, DB design, roadmap, setup, backup drill.

### Fixed
- JWT authentication default scheme: Identity application cookie was winning challenges (401 with `/Account/Login` redirect) - now JWT Bearer is the default scheme for authenticate/challenge/forbid.
- Tenant isolation: implicit EF query filters were unreliable (shared model caching) - replaced with explicit `TenantScope` scoping everywhere; verified by integration tests.
- Invoice numbering: replace Serializable/upsert sequence approach with optimistic rowversion cycle (deadlock-free under 5-way concurrency).

- Audience/campaign delivery lifecycle: campaigns flip to `Completed`/`PartiallyFailed` automatically when all recipients reach a terminal state (or when the audience was empty); integration test `CampaignDispatchTests` verifies launch → dispatch → completion via the real outbox worker.

### Known limitations
- No real notification providers (FCM/SMTP/WebPush/Windows not wired), no Key Vault integration exercise, no ETA fiscal compliance, no Flutter apps (SDK unavailable), no support module UI, no exports.

### Added
- Backend (ASP.NET Core 10): Identity/tenancy (JWT access + rotating refresh sessions, role/scope separation), Customers + CRM basics, Catalog (products/applications/plans/features), Licensing (ES256 payloads, device & session policies, heartbeat leases, transfer policy, revocation, key rotation), Subscriptions (state machine, grace → ReadOnly), Billing (concurrency-safe invoice numbering, idempotent payments, refunds with approval), Finance (append-only journal + reversals), Notifications (rule engine, preview, campaigns, transactional outbox, retry/DLQ, opt-out/quiet hours/caps, deterministic Top-N).
- Web frontend (React + TypeScript + Vite): Arabic RTL default + English LTR, login, Owner Command Center dashboard, customers list/create, licenses, finance summary.
- Backend builds clean; `dotnet test` = 90 tests green.
- CI workflow (GitHub Actions) for backend build/test and frontend build/audit.
- Support module: tickets with SLA due dates by priority, status state machine (Open→InProgress→OnHold→Resolved→Closed; reopen via InProgress), internal vs customer comments (staff-only internal notes), tenant isolation — unit and integration tests.
- Documentation: architecture, security, deployment, API, DB design, roadmap, setup, backup drill.

### Fixed
- JWT authentication default scheme: Identity application cookie was winning challenges (401 with `/Account/Login` redirect) — now JWT Bearer is the default scheme for authenticate/challenge/forbid.
- Tenant isolation: implicit EF query filters were unreliable (shared model caching) — replaced with explicit `TenantScope` scoping everywhere; verified by integration tests.
- Invoice numbering: replace Serializable/upsert sequence approach with optimistic rowversion cycle (deadlock-free under 5-way concurrency).

- Audience/campaign delivery lifecycle: campaigns flip to `Completed`/`PartiallyFailed` automatically when all recipients reach a terminal state (or when the audience was empty); integration test `CampaignDispatchTests` verifies launch → dispatch → completion via the real outbox worker.

### Known limitations
- No real notification providers (FCM/SMTP/WebPush/Windows not wired), no Key Vault integration exercise, no ETA fiscal compliance, no Flutter apps (SDK unavailable), no support module UI, no exports.

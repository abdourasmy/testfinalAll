import { useEffect, useState } from "react";
import { api } from "./api";
import type { DashboardSummary, Customer, License, FinanceSummary, Paged } from "./api";
import { STR } from "./i18n";
import type { Lang } from "./i18n";

type View = "dashboard" | "customers" | "licenses" | "finance";

export default function App() {
  const [lang, setLang] = useState<Lang>("ar");
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem("sbm.token"));
  const [view, setView] = useState<View>("dashboard");
  const [darkNote] = useState("");
  const t = STR[lang];
  const isRtl = lang === "ar";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = isRtl ? "rtl" : "ltr";
  }, [lang, isRtl]);

  if (!token) return <Login lang={lang} onToggleLang={() => setLang(l => (l === "ar" ? "en" : "ar"))} onLogin={(tok) => { sessionStorage.setItem("sbm.token", tok); setToken(tok); }} />;

  return (
    <div className="app" dir={isRtl ? "rtl" : "ltr"}>
      <aside className="sidebar">
        <div className="brand">{t.appName}<small>SBM v0.1</small></div>
        <nav className="nav">
          <button className={view === "dashboard" ? "active" : ""} onClick={() => setView("dashboard")}>{t.dashboard}</button>
          <button className={view === "customers" ? "active" : ""} onClick={() => setView("customers")}>{t.customers}</button>
          <button className={view === "licenses" ? "active" : ""} onClick={() => setView("licenses")}>{t.licenses}</button>
          <button className={view === "finance" ? "active" : ""} onClick={() => setView("finance")}>{t.finance}</button>
        </nav>
        <div style={{ marginTop: "2rem" }}>
          <button className="ghost" style={{ color: "#cdd9ec", borderColor: "rgba(255,255,255,0.25)" }} onClick={() => setLang(l => (l === "ar" ? "en" : "ar"))}>{lang === "ar" ? "English" : "العربية"}</button>
          <button className="ghost" style={{ color: "#cdd9ec", borderColor: "rgba(255,255,255,0.25)", marginInlineStart: 6 }} onClick={() => { sessionStorage.removeItem("sbm.token"); setToken(null); }}>{t.signOut}</button>
        </div>
        {darkNote && <p className="note">{darkNote}</p>}
      </aside>
      <main className="content">
        {view === "dashboard" && <Dashboard t={t} token={token} />}
        {view === "customers" && <Customers t={t} token={token} />}
        {view === "licenses" && <Licenses t={t} token={token} />}
        {view === "finance" && <Finance t={t} token={token} />}
      </main>
    </div>
  );
}

function Login({ lang, onLogin, onToggleLang }: { lang: Lang; onLogin: (t: string) => void; onToggleLang: () => void }) {
  const t = STR[lang];
  const [email, setEmail] = useState("owner@sbm.local");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const result = await api.login(email.trim(), password);
      onLogin(result.accessToken);
    } catch (err: any) {
      const offline = err instanceof TypeError || String(err?.message ?? "").includes("Failed to fetch");
      setError(offline
        ? (lang === "ar" ? "تعذر الوصول إلى الخادم. تأكد أن الـ API يعمل على http://localhost:5220 ثم أعد المحاولة." : "Cannot reach the API at http://localhost:5220. Start it, then try again.")
        : (lang === "ar" ? "بيانات الدخول غير صحيحة." : "Invalid credentials."));
    } finally { setBusy(false); }
  };

  return (
    <div className="login-wrap" dir={lang === "ar" ? "rtl" : "ltr"}>
      <form className="card login-box" onSubmit={submit}>
        <div className="brand" style={{ color: "#0f2340", borderBottomColor: "var(--sbm-border)" }}>{t.appName}<small style={{ color: "var(--sbm-primary)" }}>SBM</small></div>
        <h1>{t.signIn}</h1>
        <label>{t.email}<input type="email" value={email} onChange={e => setEmail(e.target.value)} required autoFocus /></label>
        <label style={{ display: "block", marginTop: "0.6rem" }}>{t.password}<input type="password" value={password} onChange={e => setPassword(e.target.value)} required /></label>
        {error && <p className="error">{error}</p>}
        <div className="toolbar" style={{ marginTop: "0.8rem" }}>
          <button className="primary" type="submit" disabled={busy}>{t.signIn}</button>
          <button type="button" className="ghost" onClick={onToggleLang}>{lang === "ar" ? "English" : "العربية"}</button>
        </div>
      </form>
    </div>
  );
}

function Dashboard({ t, token }: { t: typeof STR["ar"]; token: string }) {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { api.dashboard(token).then(setData).catch(e => setError(String(e?.message ?? e))); }, [token]);
  if (error) return <div className="card"><p className="error">{error}</p></div>;
  if (!data) return <p>{t.loading}</p>;
  const cards: [string, string][] = [
    [t.totalCustomers, String(data.totalCustomers)],
    [t.activeOrgs, String(data.activeOrganizations)],
    [t.activeSubscriptions, String(data.activeSubscriptions)],
    [t.activeLicenses, String(data.activeLicenses)],
    [t.activeDevices, String(data.activeDevices)],
    [t.liveSessions, String(data.liveSessions)],
    [t.mrr, data.monthlyRecurringRevenue.toFixed(2)],
    [t.outstanding, data.outstandingBalances.toFixed(2)],
  ];
  return (
    <>
      <h1>{t.dashboard}</h1>
      <div className="cards">{cards.map(([label, value]) => (
        <div key={label} className="card metric"><div className="label">{label}</div><div className="value">{value}</div></div>
      ))}</div>
      <div className="card">
        <div className="label">{t.mrr} — metric definitions</div>
        <ul>{data.metricDefinitions.map(d => <li key={d.metric}><strong>{d.metric}</strong>: {d.definition}</li>)}</ul>
      </div>
    </>
  );
}

function Customers({ t, token }: { t: typeof STR["ar"]; token: string }) {
  const [page, setPage] = useState<Paged<Customer> | null>(null);
  const [search, setSearch] = useState("");
  const [name, setName] = useState("");
  const [type, setType] = useState("Company");
  const [error, setError] = useState<string | null>(null);

  const load = () => api.customers(token, 1, search).then(setPage).catch(e => setError(String(e?.message ?? e)));
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [token]);

  const add = async () => {
    if (!name.trim()) return;
    try { await api.createCustomer(token, { name: name.trim(), type }); setName(""); await load(); }
    catch (e: any) { setError(String(e?.message ?? e)); }
  };

  return (
    <>
      <h1>{t.customers}</h1>
      <div className="card">
        <div className="toolbar">
          <input placeholder={t.search} value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === "Enter" && load()} />
          <button className="primary" onClick={load}>{t.search}</button>
        </div>
        <div className="toolbar">
          <input placeholder={t.name} value={name} onChange={e => setName(e.target.value)} />
          <select value={type} onChange={e => setType(e.target.value)}><option>Company</option><option>Individual</option></select>
          <button className="primary" onClick={add}>{t.add}</button>
        </div>
        {error && <p className="error">{error}</p>}
      </div>
      <table className="card" style={{ padding: 0 }}>
        <thead><tr><th>{t.name}</th><th>{t.type}</th><th>Status</th><th>Email</th></tr></thead>
        <tbody>
          {page?.items.map(c => <tr key={c.id}><td>{c.name}</td><td>{c.type}</td><td>{c.status}</td><td>{c.email}</td></tr>)}
          {page?.items.length === 0 && <tr><td colSpan={4}>—</td></tr>}
        </tbody>
      </table>
    </>
  );
}

function Licenses({ t, token }: { t: typeof STR["ar"]; token: string }) {
  const [page, setPage] = useState<Paged<License> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { api.licenses(token).then(setPage).catch(e => setError(String(e?.message ?? e))); }, [token]);
  return (
    <>
      <h1>{t.licenses}</h1>
      {error && <div className="card"><p className="error">{error}</p></div>}
      <table className="card" style={{ padding: 0 }}>
        <thead><tr><th>ID</th><th>State</th><th>Devices</th><th>Sessions</th><th>Expires</th></tr></thead>
        <tbody>
          {page?.items.map(l => <tr key={l.id}><td>{l.id.slice(0, 8)}…</td><td>{l.state}</td><td>{l.deviceLimit}</td><td>{l.sessionLimit}</td><td>{new Date(l.expiresAt).toLocaleDateString()}</td></tr>)}
          {page?.items.length === 0 && <tr><td colSpan={5}>—</td></tr>}
        </tbody>
      </table>
    </>
  );
}

function Finance({ t, token }: { t: typeof STR["ar"]; token: string }) {
  const [summary, setSummary] = useState<FinanceSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { api.financeSummary(token).then(setSummary).catch(e => setError(String(e?.message ?? e))); }, [token]);
  if (error) return <div className="card"><p className="error">{error}</p></div>;
  if (!summary) return <p>{t.loading}</p>;
  return (
    <>
      <h1>{t.finance}</h1>
      <div className="cards">
        <div className="card metric"><div className="label">Income</div><div className="value">{summary.income.toFixed(2)}</div></div>
        <div className="card metric"><div className="label">Expenses</div><div className="value">{summary.expenses.toFixed(2)}</div></div>
        <div className="card metric"><div className="label">Gross margin</div><div className="value">{summary.grossMargin.toFixed(2)}</div></div>
      </div>
    </>
  );
}

// Thin typed API client for the SBM backend. Base URL from env; defaults to local API.
const BASE: string = (import.meta as any).env?.VITE_API_BASE ?? "http://localhost:5220";

export class ApiError extends Error {
  readonly status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}, token?: string | null): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(BASE + path, { ...options, headers });
  if (!response.ok) {
    let message = `${response.status}`;
    try { message = (await response.text()) || message; } catch { /* ignore */ }
    throw new ApiError(response.status, message);
  }
  const text = await response.text();
  return (text ? JSON.parse(text) : undefined) as T;
}

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  user: { id: string; email: string; displayName: string };
}

export interface DashboardSummary {
  totalCustomers: number;
  activeOrganizations: number;
  activeSubscriptions: number;
  expiringSubscriptions: number;
  activeLicenses: number;
  revokedLicenses: number;
  activeDevices: number;
  liveSessions: number;
  monthlyRecurringRevenue: number;
  outstandingBalances: number;
  monthConfirmedPayments: number;
  monthExpenses: number;
  openSupportTickets: number;
  campaigns: number;
  metricDefinitions: { metric: string; definition: string }[];
}

export interface Customer {
  id: string;
  name: string;
  type: string;
  status: string;
  email?: string;
  phone?: string;
  city?: string;
  registeredAt: string;
}

export interface Paged<T> { total: number; page: number; pageSize: number; items: T[] }

export interface License {
  id: string;
  customerId: string;
  state: string;
  deviceLimit: number;
  sessionLimit: number;
  expiresAt: string;
}

export interface FinanceSummary {
  income: number;
  expenses: number;
  adjustments: number;
  reversals: number;
  grossMargin: number;
}

export const api = {
  login: (email: string, password: string) =>
    request<LoginResult>("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  me: (token: string) => request<{ id: string; email: string; displayName: string; scope: string } | undefined>("/api/auth/me", {}, token),
  dashboard: (token: string) => request<DashboardSummary>("/api/dashboard/summary", {}, token),
  customers: (token: string, page = 1, search = "") =>
    request<Paged<Customer>>(`/api/customers?page=${page}&pageSize=25${search ? "&search=" + encodeURIComponent(search) : ""}`, {}, token),
  createCustomer: (token: string, body: { name: string; type: string; email?: string }) =>
    request<Customer>("/api/customers", { method: "POST", body: JSON.stringify(body) }, token),
  licenses: (token: string) => request<Paged<License>>("/api/licenses?page=1&pageSize=25", {}, token),
  financeSummary: (token: string) => request<FinanceSummary>("/api/finance/summary", {}, token),
};

# SBM Web

React + TypeScript admin frontend. See ../../DEVELOPMENT_SETUP.md for setup.


pm run dev - dev server on http://localhost:5173 (API base URL: VITE_API_BASE, default http://localhost:5220).


pm run build - type-check + production build into dist/.

